// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_NLP_PAUSE_LEVEL_PAUSE_PREDICTOR_H_
#define TTS_NLP_PAUSE_LEVEL_PAUSE_PREDICTOR_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "tts/util/crf/crf.h"

namespace nlp {
namespace prosody {

enum PauseLevelList { kProsodyLevel = 0, kPhraseLevel, kBreakLevel };

struct InputToken {
  string word;
  int word_id;
  string pos;
};

class PausePredictor {
 public:
  explicit PausePredictor(const string& pause_model);
  ~PausePredictor();

  // It's thread safe.
  bool Predict(const vector<InputToken>& tokens, vector<int>* result) const;

 private:
  void GenPauseFeat(const InputToken& token, string* feat) const;
  bool GetPauseLevel(const vector<InputToken>& tokens, int level,
                     vector<int>* result) const;
  void MergeResult(const vector<vector<int>> all_level_result,
                   vector<int>* result) const;

  unique_ptr<crf::CrfModel> model_;

  DISALLOW_COPY_AND_ASSIGN(PausePredictor);
};
}  // namespace prosody
}  // namespace nlp

#endif  // TTS_NLP_PAUSE_LEVEL_PAUSE_PREDICTOR_H_
