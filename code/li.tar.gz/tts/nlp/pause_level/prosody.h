// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: yongqianglimobvoi.com (Yongqiang Li)

#ifndef TTS_NLP_PAUSE_LEVEL_PROSODY_H_
#define TTS_NLP_PAUSE_LEVEL_PROSODY_H_

#include <map>
#include <memory>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

#include "mobvoi/base/basictypes.h"
#include "third_party/one/prosody_model.h"

namespace nlp {
namespace prosody {

class Prosody {
 public:
  explicit Prosody(const std::string& resource_file);
  ~Prosody();

  bool InferenceProsody(const std::vector<int>& input,
                        std::vector<int>* output) const;

 private:
  void LoadId(const std::string& id_path);
  void IDMap(const std::vector<int>& input, std::vector<int>* input_id) const;
  void MergeResult(const std::vector<std::vector<int>> all_level_result,
                   std::vector<int>* result) const;

  std::unordered_map<int, int> id_dict_;
  std::shared_ptr<mobvoi::one::ProsodyModel> model_;

  DISALLOW_COPY_AND_ASSIGN(Prosody);
};

}  // namespace prosody
}  // namespace nlp

#endif  // TTS_NLP_PAUSE_LEVEL_PROSODY_H_
