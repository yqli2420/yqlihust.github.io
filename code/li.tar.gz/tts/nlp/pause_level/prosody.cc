// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: yongqiangli@mobvoi.com (Yongqiang Li)

#include "tts/nlp/pause_level/prosody.h"

#include <cmath>

#include "mobvoi/base/file.h"
#include "mobvoi/base/file/proto_util.h"
#include "mobvoi/base/log.h"

#include "tts/nlp/pause_level/proto/prosody_resource.pb.h"
#include "tts/util/tts_util/util.h"

namespace nlp {
namespace prosody {

Prosody::Prosody(const std::string& resource_file) {
  ProsodyResource resource;
  CHECK(mobvoi::ReadProtoFromTextFile(resource_file, &resource))
      << resource_file << " load failed!";
  string dir = mobvoi::File::FindFileDir(resource_file);
  resource.set_model_file(dir + resource.model_file());
  resource.set_id_file(dir + resource.id_file());
  LoadId(resource.id_file());
  model_.reset(new mobvoi::one::ProsodyModel(resource.model_file()));
}

Prosody::~Prosody() {}

bool Prosody::InferenceProsody(const std::vector<int>& input,
                               std::vector<int>* output) const {
  std::vector<int> input_id;
  IDMap(input, &input_id);
  std::vector<std::vector<int>> output_tmp;
  model_->Inference(input_id, &output_tmp);
  for (int i = 0; i < output_tmp.size(); ++i) {
    for (int j = 0; j < output_tmp[i].size(); ++j) {
      --output_tmp[i][j];
    }
  }
  MergeResult(output_tmp, output);
  return true;
}

void Prosody::LoadId(const std::string& id_path) {
  std::vector<std::string> lines;
  tts::GetConfigCenterLines(id_path, &lines);
  for (const auto& line : lines) {
    std::vector<std::string> segs;
    mobvoi::SplitStringToVector(line, " ", true, &segs);
    if (segs.size() != 2) {
      LOG(WARNING) << "uniform dict invalid";
      continue;
    }
    id_dict_[StringToInt(segs[0])] = StringToInt(segs[1]);
  }
}

void Prosody::IDMap(const std::vector<int>& input,
                    std::vector<int>* input_id) const {
  for (auto it : input) {
    auto iter = id_dict_.find(it);
    if (iter != id_dict_.end()) {
      input_id->emplace_back(iter->second);
    } else {
      input_id->emplace_back(1);
    }
  }
}

// merge all level results
// high level break point should set to next lowerer level break point
// e.g.  0 1 0 + 0 2 0 = 0 2 0
//       0 0 1 + 0 2 0 = 0 0 2
void Prosody::MergeResult(const std::vector<std::vector<int>> all_level_result,
                          std::vector<int>* result) const {
  if (all_level_result.empty()) return;
  result->resize(all_level_result[0].size(), 0);
  for (size_t level = 0; level < all_level_result.size(); ++level) {
    int pause_level = level + 2;
    vector<int> cur_level = all_level_result[level];
    for (size_t i = 0; i < cur_level.size(); ++i) {
      // jump non break point
      if (cur_level[i] == 0) continue;

      // if first level, set result directly
      if (level == 0) {
        result->at(i) = pause_level;
        continue;
      }
      // otherwise, find next lowerer level break point to set
      for (size_t j = i; j < cur_level.size(); ++j) {
        if (result->at(j) == pause_level - 1) {
          result->at(i) = pause_level;
          break;
        }
      }
    }
  }
}

}  // namespace prosody
}  // namespace nlp
