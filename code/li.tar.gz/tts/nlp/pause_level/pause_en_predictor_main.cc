// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaoqin.feng@mobvoi.com

#include "mobvoi/util/string/string_map.h"
#include "mobvoi/util/utf8/utf8_util.h"
#include "re2/re2.h"
#include "tts/nlp/pause_level/pause_predictor.h"
#include "tts/util/tts_util/util.h"

DEFINE_string(text,
              "Hello.Please tell me how the weather is"
              " in Beijing today.",
              "");
DEFINE_bool(has_segment, false, "whether text has % to segment");
DEFINE_string(pause_model,
              "external/config/front_end/pause_model/en_pause_model",
              "pause model");
DEFINE_string(trie_dict, "external/config/front_end/g2p/eng_marisa",
              "trie_dict");

void GenPausePredictTokenID(const string& result_str,
                            vector<nlp::prosody::InputToken>* tp) {
  mobvoi::StringMap m;
  m.OpenModelFile(FLAGS_trie_dict);
  vector<string> pieces;
  SplitString(result_str, '%', &pieces);
  if (pieces.empty()) return;
  for (size_t j = 0; j < pieces.size(); ++j) {
    vector<string> eng;
    SplitString(pieces[j], ' ', &eng);
    if (eng.empty()) return;
    for (size_t k = 0; k < eng.size(); ++k) {
      size_t key_id;
      string input_lower = tts::ToLower(eng[k]);
      if (!m.FindKeyID(input_lower, &key_id)) {
        key_id = tts::kEnglishKeyId;
      }
      nlp::prosody::InputToken tp_tmp;
      tp_tmp.word = eng[k];
      tp_tmp.word_id = key_id;
      tp_tmp.pos = tts::kEnglishPos;
      tp->push_back(tp_tmp);
    }
  }
}

void GenPausePredictToken(string text, string* result_str) {
  re2::RE2 re("[^a-zA-Z|'|-]+");
  re2::RE2::GlobalReplace(&text, re, " ");
  re2::RE2::GlobalReplace(&text, "\\'", "dianhao");
  vector<string> eng;
  SplitString(text, ' ', &eng);
  RE2 re2("([a-zA-Z]+([-]{0,}[a-zA-Z]+){0,})");
  vector<string> result;
  for (size_t k = 0; k < eng.size(); ++k) {
    string cur_phone;
    RE2::Extract(eng[k], re2, "\\0", &cur_phone);
    result.push_back(cur_phone);
  }
  *result_str = JoinVector(result, ' ');
  re2::RE2::GlobalReplace(result_str, "dianhao", "'");
}

int main(int argc, char** argv) {
  google::ParseCommandLineFlags(&argc, &argv, false);
  std::unique_ptr<nlp::prosody::PausePredictor> pause_predictor;
  pause_predictor.reset(new nlp::prosody::PausePredictor(FLAGS_pause_model));
  vector<nlp::prosody::InputToken> tp;
  LOG(INFO) << "The Origin Text is: " << FLAGS_text;
  if (!FLAGS_has_segment) {
    string result_str;
    GenPausePredictToken(FLAGS_text, &result_str);
    LOG(INFO) << result_str;
    GenPausePredictTokenID(result_str, &tp);
  } else {
    GenPausePredictTokenID(FLAGS_text, &tp);
  }
  vector<int> result;
  if (!pause_predictor->Predict(tp, &result)) {
    LOG(INFO) << "Fail to predict pause level";
  } else {
    string res_str = "";
    for (size_t i = 0; i < tp.size(); ++i) {
      LOG(INFO) << tp[i].word << " " << result[i];
      string res = (result[i] == 0) ? " " : "%";
      res_str += tp[i].word + res;
    }
    LOG(INFO) << "The Predict Result is: " << res_str;
  }
  return 0;
}
