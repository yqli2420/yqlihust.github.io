// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: yongqiangli@mobvoi.com (Yongqiang Li)

#include "tts/nlp/pause_level/prosody.h"

#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/util/utf8/utf8_util.h"

#include "tts/nlp/segmenter/segmenter.h"
#include "tts/util/tts_util/util.h"

DEFINE_string(text, "树上骑个猴,地上一个猴,请问一共几个猴?", "");
DEFINE_string(segmenter_conf,
              "external/config/front_end/segmenter/man_segmenter.conf",
              "segmenter reosurce config");
DEFINE_string(prosody_conf,
              "external/config/front_end/pause_model/man_prosody.conf",
              "pause model");

void GenPausePredictToken(const string& text,
                          nlp::segmenter::Segmenter* segmenter, vector<int>* tp,
                          vector<string>* word) {
  vector<nlp::segmenter::SegmentWord> segment_words;
  segmenter->WordSegmentation(text, &segment_words);
  for (size_t i = 0; i < segment_words.size(); ++i) {
    nlp::segmenter::SegmentWord t_word = segment_words[i];
    LOG(INFO) << "word " << t_word.word << " id " << t_word.word_id;
    tp->push_back(t_word.word_id);
    word->push_back(t_word.word);
  }
}
void GetPauseLevel(const string& text, nlp::segmenter::Segmenter* segmenter,
                   nlp::prosody::Prosody* pause_predictor) {
  vector<int> tp;
  vector<string> word;
  GenPausePredictToken(text, segmenter, &tp, &word);
  vector<int> result;
  if (!pause_predictor->InferenceProsody(tp, &result)) {
    LOG(INFO) << "Fail to predict pause level";
  } else {
    for (size_t i = 0; i < tp.size(); ++i) {
      LOG(INFO) << word[i] << " " << tp[i] << " " << result[i];
    }
  }
}

int main(int argc, char** argv) {
  google::ParseCommandLineFlags(&argc, &argv, false);
  std::unique_ptr<nlp::segmenter::Segmenter> segmenter;
  std::unique_ptr<nlp::prosody::Prosody> prosody_predictor;

  segmenter.reset(new nlp::segmenter::Segmenter(FLAGS_segmenter_conf));
  prosody_predictor.reset(new nlp::prosody::Prosody(FLAGS_prosody_conf));

  GetPauseLevel(FLAGS_text, segmenter.get(), prosody_predictor.get());
  return 0;
}
