// Copyright 2016 Mobvoi Inc. All Rights Reserved.
// Author: hhguo@mobvoi.com

#include "tts/nlp/pause_level/pause_predictor.h"

#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/util/utf8/utf8_util.h"
#include "tts/nlp/segmenter/segmenter.h"
#include "tts/util/tts_util/util.h"

DEFINE_string(text, "树上骑个猴,地上一个猴,请问一共几个猴?", "");
DEFINE_bool(has_segment, false, "whether text has # to segment");
DEFINE_string(segmenter_conf,
              "external/config/front_end/segmenter/man_segmenter.conf",
              "segmenter reosurce config");
DEFINE_string(pause_model,
              "external/config/front_end/pause_model/mandarin_pause_model",
              "pause model");

void GenPausePredictToken(const string& text,
                          nlp::segmenter::Segmenter* segmenter,
                          vector<nlp::prosody::InputToken>* tp) {
  vector<nlp::segmenter::SegmentWord> segment_words;
  segmenter->WordSegmentation(text, &segment_words);
  for (size_t i = 0; i < segment_words.size(); ++i) {
    nlp::segmenter::SegmentWord t_word = segment_words[i];
    nlp::prosody::InputToken tp_tmp;
    tp_tmp.word = t_word.word;
    tp_tmp.word_id = t_word.word_id;
    tp_tmp.pos = t_word.pos;
    tp->push_back(tp_tmp);
  }
}

void GetPauseLevel(const string& text, nlp::segmenter::Segmenter* segmenter,
                   nlp::prosody::PausePredictor* pause_predictor) {
  vector<nlp::prosody::InputToken> tp;
  GenPausePredictToken(text, segmenter, &tp);
  vector<int> result;
  if (!pause_predictor->Predict(tp, &result)) {
    LOG(INFO) << "Fail to predict pause level";
  } else {
    for (size_t i = 0; i < tp.size(); ++i) {
      LOG(INFO) << tp[i].word << " " << result[i];
    }
  }
}

void GetPauseLevel(const vector<string>& text,
                   nlp::segmenter::Segmenter* segmenter,
                   nlp::prosody::PausePredictor* pause_predictor) {
  vector<nlp::prosody::InputToken> tp;
  for (size_t i = 0; i < text.size(); ++i) {
    GenPausePredictToken(text[i], segmenter, &tp);
  }
  vector<int> result;
  if (!pause_predictor->Predict(tp, &result)) {
    LOG(INFO) << "Fail to predict pause level";
  } else {
    for (size_t i = 0; i < tp.size(); ++i) {
      LOG(INFO) << tp[i].word << " " << result[i];
    }
  }
}

int main(int argc, char** argv) {
  google::ParseCommandLineFlags(&argc, &argv, false);
  std::unique_ptr<nlp::segmenter::Segmenter> segmenter;
  std::unique_ptr<nlp::prosody::PausePredictor> pause_predictor;

  segmenter.reset(new nlp::segmenter::Segmenter(FLAGS_segmenter_conf));
  pause_predictor.reset(new nlp::prosody::PausePredictor(FLAGS_pause_model));

  if (!FLAGS_has_segment) {
    GetPauseLevel(FLAGS_text, segmenter.get(), pause_predictor.get());
  } else {
    vector<string> text;
    SplitString(FLAGS_text, '#', &text);
    GetPauseLevel(FLAGS_text, segmenter.get(), pause_predictor.get());
  }
  return 0;
}
