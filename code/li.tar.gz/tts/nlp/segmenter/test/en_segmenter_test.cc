// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaoqin.feng@mobvoi.com (xiaoqin.feng)

#include "tts/nlp/segmenter/en_segmenter.h"
#include "mobvoi/base/log.h"
#include "third_party/gtest/gtest.h"

namespace nlp {
namespace segmenter {

class EnglishSegmenterTest : public ::testing::Test {
 protected:
  virtual void SetUp() {
    const string kTrieDict = "external/config/front_end/g2p/eng_marisa";
    en_segmenter_.reset(new EnglishSegmenter(kTrieDict));
  }

  void EnglishSegmentWordTest(const string& text,
                              const vector<int>& expect_word_id,
                              const vector<string>& expect_pos) const {
    vector<SegmentWord> segment_words;
    en_segmenter_->WordSegmentation(text, &segment_words);
    ASSERT_EQ(expect_word_id.size(), segment_words.size()) << text;
    ASSERT_EQ(expect_pos.size(), segment_words.size()) << text;
    for (size_t i = 0; i < expect_word_id.size(); ++i) {
      EXPECT_EQ(expect_word_id[i], segment_words[i].word_id);
      EXPECT_EQ(expect_pos[i], segment_words[i].pos);
    }
  }

  std::unique_ptr<EnglishSegmenter> en_segmenter_;
};

TEST_F(EnglishSegmenterTest, segmentertest) {
  const string text = "hello`can`you`tell`me`your`name";
  const vector<int> expect_word_id = {
      31234,   1500000, 564,     1500000, 2584,    1500000, 15413,
      1500000, 128,     1500000, 17141,   1500000, 11627,
  };
  const vector<string> expect_pos = {
      "En", "En", "En", "En", "En", "En", "En",
      "En", "En", "En", "En", "En", "En",
  };
  EnglishSegmentWordTest(text, expect_word_id, expect_pos);
}

}  // namespace segmenter
}  // namespace nlp
