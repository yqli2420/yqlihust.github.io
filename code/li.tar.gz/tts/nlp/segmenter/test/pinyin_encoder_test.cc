// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/nlp/segmenter/impl/pinyin_encoder.h"

#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/string_util.h"
#include "third_party/gtest/gtest.h"

namespace nlp {
namespace segmenter {

static const string kTestDataDir =       // NOLINT
    "tts/nlp/segmenter/test/testdata/";  // NOLINT

class PinyinEncoderTest : public ::testing::Test {
 protected:
  virtual void SetUp() {
    const string phone_list = kTestDataDir + "pinyin_list.txt";
    vector<string> phone_lines;
    file::SimpleLineReader phone_reader(phone_list, true, "#");
    phone_reader.ReadLines(&phone_lines);
    vector<string> one_byte(phone_lines.begin(), phone_lines.begin() + 127);
    vector<string> two_byte(phone_lines.begin() + 127, phone_lines.end());
    pinyin_encoder_.reset(new PinyinEncoder(one_byte, two_byte));
  }
  void EncodeDecodeTest(const string& pinyin) const {
    int syllable_num;
    string encoded;
    pinyin_encoder_->Encode(pinyin, &syllable_num, &encoded);
    string decoded = pinyin_encoder_->Decode(encoded.data(), syllable_num);
    EXPECT_EQ(pinyin, decoded);
  }

  std::unique_ptr<PinyinEncoder> pinyin_encoder_;
};

TEST_F(PinyinEncoderTest, SingleTest) {}

TEST_F(PinyinEncoderTest, SimpleTest) {
  string pinyin1 = "yve4 guang1 bao3 he2";
  EncodeDecodeTest(pinyin1);

  string pinyin2 = "shi4 qing2";
  EncodeDecodeTest(pinyin2);
}

TEST_F(PinyinEncoderTest, FileTest) {
  string test_file = kTestDataDir + "pinyin_test.txt";
  vector<string> lines;
  file::SimpleLineReader reader(test_file, true, "#");
  reader.ReadLines(&lines);
  for (auto& line : lines) {
    vector<string> segs;
    SplitString(line, '\t', &segs);
    const string& original = segs[0];
    EncodeDecodeTest(original);
  }
}

}  // namespace segmenter
}  // namespace nlp
