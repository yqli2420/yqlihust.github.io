// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaoqin.feng@mobvoi.com (xiaoqin.feng)

#ifndef TTS_NLP_SEGMENTER_EN_SEGMENTER_H_
#define TTS_NLP_SEGMENTER_EN_SEGMENTER_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/util/string/string_map.h"
#include "tts/nlp/segmenter/impl/segmenter_def.h"

namespace nlp {
namespace segmenter {

class EnglishSegmenter {
 public:
  explicit EnglishSegmenter(const string& english_marisa_file);
  ~EnglishSegmenter();
  bool WordSegmentation(const string& input,
                        vector<SegmentWord>* segmentwords) const;

 private:
  mobvoi::StringMap english_marisa_trie_map_;

  DISALLOW_COPY_AND_ASSIGN(EnglishSegmenter);
};
}  // namespace segmenter
}  // namespace nlp
#endif  // TTS_NLP_SEGMENTER_EN_SEGMENTER_H_
