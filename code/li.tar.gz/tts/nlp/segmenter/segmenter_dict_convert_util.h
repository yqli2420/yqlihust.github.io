// Copyright 2017 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Zheng Zhang)

#ifndef TTS_NLP_SEGMENTER_SEGMENTER_DICT_CONVERT_UTIL_H_
#define TTS_NLP_SEGMENTER_SEGMENTER_DICT_CONVERT_UTIL_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "tts/nlp/segmenter/impl/pinyin_encoder.h"
#include "tts/nlp/segmenter/impl/segmenter_util.h"
#include "tts/nlp/segmenter/proto/segmenter_resource.pb.h"

namespace nlp {
namespace segmenter {

static const char kDictSepSign = '\t';

static const float kDefaultWeight = -1;

enum ManDictFormat {
  kManWord = 0,
  kManFreq,
  kManPos,
  kManPron,
  kManAllNum,
};

struct WordDict {
  string word;
  vector<util::Rune> word_u;
  string pron;
  int freq;
  float weight;
  string pos;
  int pos_id;

  WordDict() : freq(0), weight(0.0), pos_id(0) {}
  ~WordDict() {}
};

bool PhoneMapCmpByValue(const std::pair<string, float>& left,
                        const std::pair<string, float>& right);
void LoadWordDict(const string& dict_file, int max_word_len,
                  vector<WordDict>* word_dict);
void GenPhoneList(const vector<WordDict>& word_dict,
                  vector<string>* phone_list);
void CalculateWeight(vector<WordDict>* word_dict);
void SelectTopNWords(int top_n_number, vector<WordDict>* word_dict);
void SortWordDict(vector<WordDict>* word_dict);
SegmenterDict GenerateSegDict(const vector<WordDict>& word_dict,
                              const string& lan_type,
                              const vector<string>& phone_list);
void GenerateProtoDict(const vector<WordDict>& word_dict,
                       const string& protobuf_file,
                       const vector<string>& phone_list);
void GenerateTextDict(const vector<WordDict>& word_dict,
                      const string& text_file);
// Save trie for darts / masira.
void SaveTrie(const vector<WordDict>& word_dict, const string& path);
void SaveMarisaTrie(vector<WordDict>* word_dict, const string& path);

}  // namespace segmenter
}  // namespace nlp
#endif  // TTS_NLP_SEGMENTER_SEGMENTER_DICT_CONVERT_UTIL_H_
