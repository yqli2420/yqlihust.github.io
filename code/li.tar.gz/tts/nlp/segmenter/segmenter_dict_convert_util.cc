// Copyright 2017 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Zheng Zhang)

#include "tts/nlp/segmenter/segmenter_dict_convert_util.h"

#include <cmath>

#include "mobvoi/base/file.h"
#include "mobvoi/base/file/proto_util.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/string_util.h"
#include "third_party/marisa/trie.h"

namespace nlp {
namespace segmenter {

bool PhoneMapCmpByValue(const std::pair<string, float>& left,
                        const std::pair<string, float>& right) {
  return left.second > right.second;
}

bool DictCmpOnFreq(const WordDict& left, const WordDict& right) {
  return left.freq > right.freq;
}

bool DictCmpOnUnicode(const WordDict& left, const WordDict& right) {
  for (size_t i = 0; i < left.word_u.size() && i < right.word_u.size(); ++i) {
    if (left.word_u[i] == right.word_u[i]) continue;
    if (left.word_u[i] < right.word_u[i]) return true;
    return false;
  }
  return left.word_u.size() < right.word_u.size();
}

bool DictCmpOnString(const WordDict& left, const WordDict& right) {
  for (size_t i = 0; i < left.word.size() && i < right.word.size(); ++i) {
    if (left.word[i] == right.word[i]) continue;
    if (left.word[i] < right.word[i]) return true;
    return false;
  }
  return left.word.size() < right.word.size();
}

void SaveMarisaTrie(vector<WordDict>* word_dict, const string& path) {
  marisa::Keyset keyset;
  map<string, int> key_to_id;
  int id = 0;
  for (auto word : *word_dict) {
    marisa::Key key;
    key.set_str(word.word.c_str());
    keyset.push_back(key);
    key_to_id[word.word] = id;
    ++id;
  }
  marisa::Trie trie;
  trie.build(keyset);
  map<int, string> saved_ids;
  for (size_t i = 0; i < keyset.size(); ++i) {
    string key(keyset[i].ptr(), keyset[i].length());
    VLOG(1) << "key : " << key << ", id : " << i
            << ", keyset id : " << keyset[i].id();
    saved_ids[keyset[i].id()] = key;
  }
  trie.save(path.c_str());
  // There are two methods to make sure key id equal to index of
  // vector<DictUnit*>.
  // 1, save maping info in file. load it when inited.
  // 2, change order for word_dict using keyset's order.
  // Here we use the second method.
  vector<WordDict> new_word_dict;
  CHECK_EQ(saved_ids.size(), word_dict->size());
  for (size_t i = 0; i < saved_ids.size(); ++i) {
    // Find key by id
    string key = saved_ids[i];
    // find original id by key
    int original_id = key_to_id[key];
    new_word_dict.push_back(word_dict->at(original_id));
  }
  word_dict->swap(new_word_dict);
}

void LoadWordDict(const string& dict_file, int max_word_len,
                  vector<WordDict>* word_dict) {
  VLOG(1) << "begin to load dict ...";

  map<string, int> pos_type;
  InitPosTypeMap(&pos_type);

  vector<string> lines;
  file::SimpleLineReader reader(dict_file, true);
  reader.ReadLines(&lines);

  set<string> word_set;
  int count = 0;
  for (const string& line : lines) {
    count += 1;
    vector<string> segs;
    WordDict word_dict_tmp;
    SplitString(line, kDictSepSign, &segs);
    CHECK(segs.size() == ManDictFormat::kManAllNum)
        << "Invalid number of columns: " << segs.size()
        << ", at line: " << count << ", in file: " << dict_file;
    string word_tmp = segs[ManDictFormat::kManWord];
    string pron_tmp = segs[ManDictFormat::kManPron];
    int freq_tmp = StringToInt(segs[ManDictFormat::kManFreq]);
    string pos_tmp = segs[ManDictFormat::kManPos];
    if (word_set.find(word_tmp) != word_set.end()) {
      LOG(WARNING) << "repeated word: " << word_tmp;
      continue;
    }
    vector<util::Rune> word_u;
    if (!util::Utf8ToUnicode(word_tmp, &word_u)) {
      LOG(WARNING) << "word illegal: " << word_tmp;
      continue;
    }
    if (word_u.size() > (size_t)max_word_len) {
      VLOG(1) << "too long words: " << word_tmp;
      continue;
    }
    word_dict_tmp.word = word_tmp;
    word_dict_tmp.word_u = word_u;
    word_dict_tmp.freq = freq_tmp;
    word_dict_tmp.pron = pron_tmp;
    word_dict_tmp.pos = pos_tmp;
    word_dict_tmp.pos_id = pos_type[pos_tmp];
    word_dict->push_back(word_dict_tmp);
    word_set.insert(word_tmp);
    if (count % 10000 == 0) {
      VLOG(1) << "process lines: " << count;
    }
  }
  VLOG(1) << "dict number: " << word_set.size();
}

void CalculateWeight(vector<WordDict>* word_dict) {
  VLOG(1) << "begin to calculate weight ...";
  int64 sum = 0;
  for (WordDict& cword : *word_dict) sum += cword.freq;
  for (WordDict& cword : *word_dict) {
    float weight =
        log(static_cast<float>(cword.freq) / sum) / cword.word_u.size();
    cword.weight = weight;
  }
}

// select by word frequency
// TODO(zhengzhang): replace with other rules
void SelectTopNWords(int top_n_number, vector<WordDict>* word_dict) {
  VLOG(1) << "begin to select top n words: " << top_n_number << " ...";
  vector<WordDict> mono_dict;
  vector<WordDict> words_dict;
  for (const WordDict& cword : *word_dict) {
    vector<util::Rune> unicode;
    util::Utf8ToUnicode(cword.word, &unicode);
    if (unicode.size() == 1)
      mono_dict.push_back(cword);
    else
      words_dict.push_back(cword);
  }
  sort(words_dict.begin(), words_dict.end(), DictCmpOnFreq);
  top_n_number = std::min(top_n_number, static_cast<int>(words_dict.size()));
  words_dict.resize(top_n_number);
  word_dict->clear();
  word_dict->insert(word_dict->end(), words_dict.begin(), words_dict.end());
  word_dict->insert(word_dict->end(), mono_dict.begin(), mono_dict.end());
}

void SortWordDict(vector<WordDict>* word_dict) {
  VLOG(1) << "begin to sort word dict ...";
  sort(word_dict->begin(), word_dict->end(), DictCmpOnUnicode);
}

SegmenterDict GenerateSegDict(const vector<WordDict>& word_dict,
                              const vector<string>& phone_list) {
  SegmenterDict proto_segmenter_dict;
  std::unique_ptr<PinyinEncoder> pinyin_encoder;
  size_t index = 0;
  for (; index < 127 && index < phone_list.size(); ++index) {
    proto_segmenter_dict.add_one_byte_prons(phone_list[index]);
  }
  for (; index < phone_list.size(); ++index) {
    proto_segmenter_dict.add_two_byte_prons(phone_list[index]);
  }
  vector<string> one_byte_syllable(proto_segmenter_dict.one_byte_prons_size());
  vector<string> two_byte_syllable(proto_segmenter_dict.two_byte_prons_size());
  for (size_t i = 0; i < (size_t)proto_segmenter_dict.one_byte_prons_size();
       i++) {
    one_byte_syllable[i] = proto_segmenter_dict.one_byte_prons(i);
  }
  for (size_t i = 0; i < (size_t)proto_segmenter_dict.two_byte_prons_size();
       i++) {
    two_byte_syllable[i] = proto_segmenter_dict.two_byte_prons(i);
  }
  pinyin_encoder.reset(new PinyinEncoder(one_byte_syllable, two_byte_syllable));
  for (const WordDict& cword : word_dict) {
    int syllable_num = 0;
    string encoded_pinyin;
    if (!pinyin_encoder->Encode(cword.pron, &syllable_num, &encoded_pinyin)) {
      LOG(INFO) << "bad pron";
      continue;
    }
    CHECK_LT(syllable_num, kuint8max) << "syllable_num is greater than 256.";
    proto_segmenter_dict.add_pron(encoded_pinyin);
    proto_segmenter_dict.add_pron_num(syllable_num);
    proto_segmenter_dict.add_weight(cword.weight);
    proto_segmenter_dict.add_pos(cword.pos_id);
  }
  return proto_segmenter_dict;
}

void GenerateProtoDict(const vector<WordDict>& word_dict,
                       const string& protobuf_file,
                       const vector<string>& phone_list) {
  LOG(INFO) << "begin to write proto dict ...";
  SegmenterDict proto_segmenter_dict;
  proto_segmenter_dict = GenerateSegDict(word_dict, phone_list);
  mobvoi::WriteProtoToFile(protobuf_file, proto_segmenter_dict);
}

void GenerateTextDict(const vector<WordDict>& word_dict,
                      const string& text_file) {
  VLOG(1) << "begin to write text dict ...";
  FILE* fp = fopen(text_file.c_str(), "w");
  CHECK(fp) << "Failed to open file : " << text_file;
  for (const WordDict& cword : word_dict) {
    fprintf(fp, "%s\n", cword.pron.c_str());
  }
  fclose(fp);
}

void GenPhoneList(const vector<WordDict>& word_dict,
                  vector<string>* phone_list) {
  map<string, int> phone_map;
  for (const WordDict& cword : word_dict) {
    vector<string> prons;
    SplitString(cword.pron, kPronSylSign, &prons);
    for (const string& syl : prons) {
      if (phone_map.find(syl) != phone_map.end()) {
        phone_map.at(syl) += 1;
      } else {
        phone_map.insert(make_pair(syl, 1));
      }
    }
  }
  vector<std::pair<string, float>> phone_vector(phone_map.begin(),
                                                phone_map.end());
  sort(phone_vector.begin(), phone_vector.end(), PhoneMapCmpByValue);
  phone_list->resize(phone_vector.size());
  for (size_t i = 0; i < phone_vector.size(); ++i) {
    phone_list->at(i) = phone_vector[i].first;
  }
}

}  // namespace segmenter
}  // namespace nlp
