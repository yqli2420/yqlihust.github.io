// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/nlp/segmenter/impl/base_segmenter.h"

#include "mobvoi/base/log.h"
#include "mobvoi/base/string_util.h"
#include "tts/util/tts_util/util.h"

namespace nlp {
namespace segmenter {

BaseSegmenter::BaseSegmenter() {}

BaseSegmenter::~BaseSegmenter() {}

bool BaseSegmenter::Cut(const string& str, const string& user_dict,
                        vector<SegmentWord>* result) const {
  // TODO(zhengzhang): remove ' ' in the future
  vector<string> segs;
  SplitString(str, ' ', &segs);
  for (const string& str_seg : segs) {
    vector<util::Rune> unicode;
    unicode.reserve(str_seg.size());

    if (!util::Utf8ToUnicode(str_seg, &unicode)) {
      LOG(ERROR) << "Fail to decode str:" << str_seg;
    }
    vector<SegmentWord> tmp;
    if (!Cut(unicode.begin(), unicode.end(), user_dict, &tmp)) {
      LOG(WARNING) << "segmenter failed in text: " << str_seg;
      continue;
    }
    result->insert(result->end(), tmp.begin(), tmp.end());
  }
  SetEnglishPuncPos(result);
  SetSpecialWordId(result);
  // merge digit words
  MergeWords(result);
  return true;
}

void SetEnglishPuncPos(vector<SegmentWord>* segment_words) {
  for (auto it = segment_words->begin(); it != segment_words->end(); ++it) {
    if (it == segment_words->begin()) continue;
    if (it->pos == tts::kPunctuationPos && (it - 1)->pos == tts::kEnglishPos) {
      it->pos = tts::kEnglishPos;
    }
  }
}

void SetSpecialWordId(vector<SegmentWord>* segment_words) {
  for (auto it = segment_words->begin(); it != segment_words->end(); ++it) {
    if (it->pos == tts::kEnglishPos) {
      it->word_id = tts::kEnglishId;
    } else if (it->pos == tts::kNumberPos) {
      it->word_id = tts::kNumberId;
    }
  }
}

void MergeWords(vector<SegmentWord>* segment_words) {
  if (segment_words->empty()) {
    LOG(WARNING) << "segment words empty";
    return;
  }
  int status = JudgeStatus(segment_words->begin()->word);
  int segment_wordlen = util::utflen(segment_words->begin()->word.c_str());
  for (auto it = segment_words->begin() + 1; it != segment_words->end(); ++it) {
    int status_tmp = JudgeStatus(it->word);
    int segment_wordlen_tmp = util::utflen(it->word.c_str());
    if ((status_tmp == Status::kEnglish && status == Status::kEnglish) ||
        (status_tmp == Status::kDigital && status == Status::kDigitalBegin) ||
        (status_tmp == Status::kDigital && status == Status::kDigital) ||
        (status_tmp == Status::kDigitalEnd &&
         status == Status::kDigitalBegin) ||
        (status_tmp == Status::kDigitalEnd && status == Status::kDigital)) {
      int word_len =
          (status_tmp == Status::kEnglish && status == Status::kEnglish)
              ? kMaxEnglishWordLen
              : kMaxWordLen;
      if (segment_wordlen + segment_wordlen_tmp < word_len) {
        (it - 1)->word += it->word;
        (it - 1)->pron += " " + it->pron;  // add space for later processing
        segment_words->erase(it);
        segment_wordlen += segment_wordlen_tmp;
        --it;
      } else {
        segment_wordlen = segment_wordlen_tmp;
      }
    } else {
      segment_wordlen = segment_wordlen_tmp;
    }
    status = status_tmp;
  }
}

}  // namespace segmenter
}  // namespace nlp
