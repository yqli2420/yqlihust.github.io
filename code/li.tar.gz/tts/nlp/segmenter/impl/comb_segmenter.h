// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_NLP_SEGMENTER_IMPL_COMB_SEGMENTER_H_
#define TTS_NLP_SEGMENTER_IMPL_COMB_SEGMENTER_H_

#include "tts/nlp/segmenter/impl/hmm_segmenter.h"
#include "tts/nlp/segmenter/impl/mp_segmenter.h"
#include "tts/nlp/segmenter/proto/segmenter_resource.pb.h"

namespace nlp {
namespace segmenter {
class CombSegmenter : public BaseSegmenter {
 public:
  CombSegmenter(const SegmenterResource& segmenter_resource,
                const string& hmm_model);
  virtual ~CombSegmenter();

  virtual bool Cut(vector<util::Rune>::const_iterator begin,
                   vector<util::Rune>::const_iterator end,
                   const string& user_dict, vector<SegmentWord>* result) const;

 private:
  bool HMMCut(vector<util::Rune>::const_iterator begin,
              vector<util::Rune>::const_iterator end,
              vector<SegmentWord>* result) const;
  // TODO(zhengzhang): useful functions, may use in the future
  // bool IsWordCutOK(const vector<SegmentWord>& words_cut) const;

  // mp segmenter for the first cut
  std::unique_ptr<MPSegmenter> mp_segmenter_;
  // hmm segmenter to cut phrase
  std::unique_ptr<HMMSegmenter> hmm_segmenter_;

  DISALLOW_COPY_AND_ASSIGN(CombSegmenter);
};
}  // namespace segmenter
}  // namespace nlp
#endif  // TTS_NLP_SEGMENTER_IMPL_COMB_SEGMENTER_H_
