// Copyright 2016 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/nlp/segmenter/impl/pinyin_encoder.h"

#include "mobvoi/base/log.h"
#include "mobvoi/base/string_util.h"

namespace nlp {
namespace segmenter {

PinyinEncoder::PinyinEncoder(const vector<string>& one_byte,
                             const vector<string>& two_byte) {
  GenSyllableMap(one_byte, two_byte);
  GenIdMap(one_byte, two_byte);
}

PinyinEncoder::~PinyinEncoder() {}

bool PinyinEncoder::Encode(const string& pinyin, int* syllable_num,
                           string* encoded_pinyin) {
  vector<string> pron_syls;
  SplitString(pinyin, ' ', &pron_syls);
  *syllable_num = pron_syls.size();
  return Encode(pron_syls, encoded_pinyin);
}

bool PinyinEncoder::Encode(const vector<string>& pron_segs,
                           string* encoded_pinyin) {
  for (const auto& p : pron_segs) {
    const auto it = syllable_to_id_.find(p);
    if (it == syllable_to_id_.end()) {
      LOG(WARNING) << "bad pron : " << p;
      return false;
    }
    if (it->second <= kint8max) {
      encoded_pinyin->append(1, static_cast<char>(it->second));
    } else {
      uint8 high = static_cast<char>(it->second >> 8);
      uint8 low = static_cast<char>(it->second << 8 >> 8);
      encoded_pinyin->append(1, high);  // NOLINT
      encoded_pinyin->append(1, low);   // NOLINT
    }
  }
  return true;
}

string PinyinEncoder::Decode(const char* encoded_str, int syllable_num) {
  vector<string> phoneme;
  const char* ptr = encoded_str;
  int decoded_syllable = 0;
  while (decoded_syllable < syllable_num) {
    // Try to get one byte if it's < 127.
    uint16 id = 0;
    if ((uint8) * (uint8*)ptr <= kint8max) {  // NOLINT
      id = (uint8)*ptr;
      ptr += sizeof(uint8);
    } else {
      // Use two bytes, and treat it as uint16.
      uint16 high = ((uint8)*ptr);
      uint16 low = (uint8) * (ptr + 1);
      id = (high << 8) + low;
      ptr += sizeof(uint16);
    }
    phoneme.push_back(id_to_syllable_[id]);
    ++decoded_syllable;
  }
  return JoinVector(phoneme, ' ');
}

void PinyinEncoder::GenSyllableMap(const vector<string>& one_byte,
                                   const vector<string>& two_byte) {
  CHECK_EQ(one_byte.size(), kint8max);
  for (size_t i = 0; i < one_byte.size(); ++i) {
    syllable_to_id_.insert(std::make_pair(one_byte[i], i));
  }
  for (size_t i = 0; i < two_byte.size(); ++i) {
    // Use two bytes to save it,
    // 1xxxxxxx,xxxxxxxx  it has low 15 bits. which is enough for all syllables.
    // So here we use 0x8000 + index as value.
    static uint16 kFeatureValue = (1 << 15);
    uint16 value = kFeatureValue + i;
    syllable_to_id_.insert(std::make_pair(two_byte[i], value));
  }
}

void PinyinEncoder::GenIdMap(const vector<string>& one_byte,
                             const vector<string>& two_byte) {
  CHECK_EQ(one_byte.size(), kint8max);
  for (uint16 i = 0; i < one_byte.size(); ++i) {
    id_to_syllable_.insert(std::make_pair(i, one_byte[i]));
  }
  for (size_t i = 0; i < two_byte.size(); ++i) {
    // Use two bytes to save it,
    // 1xxxxxxx,xxxxxxxx  it has low 15 bits. which is enough for all syllables.
    // So here we use 0x8000 + index as value.
    static uint16 kFeatureValue = (1 << 15);
    uint16 value = kFeatureValue + i;
    id_to_syllable_.insert(std::make_pair(value, two_byte[i]));
  }
}

bool PinyinEncoder::AddPinyin(const string& pinyin, int* syllable_num,
                              string* encoded_pinyin) {
  vector<string> pron_syls;
  SplitString(pinyin, ' ', &pron_syls);
  *syllable_num = pron_syls.size();
  for (size_t i = 0; i < pron_syls.size(); ++i) {
    const auto it = syllable_to_id_.find(pron_syls[i]);
    uint16 value;
    if (it == syllable_to_id_.end()) {
      static uint16 kFeatureValue = (1 << 15);
      value = kFeatureValue + syllable_to_id_.size() + 1;
      id_to_syllable_.insert(std::make_pair(value, pron_syls[i]));
      syllable_to_id_.insert(std::make_pair(pron_syls[i], value));
    } else {
      value = it->second;
    }
    if (value <= kint8max) {
      encoded_pinyin->append(1, static_cast<char>(value));
    } else {
      uint8 high = static_cast<char>(value >> 8);
      uint8 low = static_cast<char>(value << 8 >> 8);
      encoded_pinyin->append(1, high);  // NOLINT
      encoded_pinyin->append(1, low);   // NOLINT
    }
  }
  return true;
}

}  // namespace segmenter
}  // namespace nlp
