// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/nlp/segmenter/impl/dict_trie.h"

#include "mobvoi/base/file/proto_util.h"
#include "mobvoi/base/log.h"
#include "tts/nlp/segmenter/impl/segmenter_util.h"
#include "tts/nlp/segmenter/proto/segmenter_resource.pb.h"

namespace nlp {
namespace segmenter {

DictTrie::DictTrie(const string& dict_trie, const string& dict_unit)
    : min_weight_(kMaxDouble), max_weight_(kMinDouble) {
  VLOG(2) << "Size of DictUnit:" << sizeof(DictUnit);
  trie_.reset(new trie::MarisaTrie(dict_trie));
  LoadDict(dict_unit);
  SetMinWeight();
  SetMaxWeight();
  CHECK(trie_);
}

DictTrie::~DictTrie() {
  for (auto& dict_unit : dict_units_) {
    free(dict_unit);
  }
}

const DictUnit* DictTrie::Find(vector<util::Rune>::const_iterator begin,
                               vector<util::Rune>::const_iterator end) const {
  int word_id = trie_->Find(begin, end);
  if (word_id == trie::kNotFound) return NULL;
  return dict_units_[word_id];
}

bool DictTrie::FindPrefix(vector<util::Rune>::const_iterator begin,
                          vector<util::Rune>::const_iterator end, size_t offset,
                          vector<Dag>* dag) const {
  vector<trie::DagNode> dag_node;
  if (!trie_->FindPrefix(begin, end, &dag_node)) return false;
  for (const auto& node : dag_node) {
    Dag dag_tmp;
    dag_tmp.dict_unit = dict_units_[node.id];
    dag_tmp.word_id = node.id;
    dag_tmp.next_pos = offset + node.u_len;
    dag_tmp.word = vector<util::Rune>(begin, begin + node.u_len);
    dag->push_back(dag_tmp);
  }
  return true;
}

// TODO(zhengzhang): save trie and unit
void DictTrie::Save(const string& save_path) const { trie_->Save(save_path); }

string DictTrie::GetPron(const DictUnit& d) const {
  return pinyin_encoder_->Decode(d.pron, d.syllable_num);
}

bool DictTrie::EncodePinyin(const string& pinyin, int* syllable_num,
                            string* encoded_pinyin) {
  if (!pinyin_encoder_->Encode(pinyin, syllable_num, encoded_pinyin)) {
    encoded_pinyin->clear();
    return pinyin_encoder_->AddPinyin(pinyin, syllable_num, encoded_pinyin);
  }
  return true;
}

void DictTrie::LoadDict(const string& dict_unit_file) {
  SegmenterDict segmenter_dict;
  mobvoi::ReadProtoFromFile(dict_unit_file, &segmenter_dict);
  dict_units_.reserve(segmenter_dict.pron_size() + dict_units_.size());

  vector<string> one_byte_syllable(segmenter_dict.one_byte_prons_size());
  vector<string> two_byte_syllable(segmenter_dict.two_byte_prons_size());
  for (size_t i = 0; i < (size_t)segmenter_dict.one_byte_prons_size(); ++i) {
    one_byte_syllable[i] = segmenter_dict.one_byte_prons(i);
  }
  for (size_t i = 0; i < (size_t)segmenter_dict.two_byte_prons_size(); ++i) {
    two_byte_syllable[i] = segmenter_dict.two_byte_prons(i);
  }
  pinyin_encoder_.reset(
      new PinyinEncoder(one_byte_syllable, two_byte_syllable));
  int memory_size = 0;
  for (size_t i = 0; i < (size_t)segmenter_dict.pron_size(); ++i) {
    string encoded_pinyin;
    encoded_pinyin = segmenter_dict.pron(i);
    DictUnit* dict_unit = reinterpret_cast<DictUnit*>(
        malloc(sizeof(DictUnit) + encoded_pinyin.size() - 2));
    memory_size += (sizeof(DictUnit) + encoded_pinyin.size() - 2);
    dict_unit->weight = WeightEncoding(segmenter_dict.weight(i));
    dict_unit->tag = segmenter_dict.pos(i);
    dict_unit->syllable_num = segmenter_dict.pron_num(i);
    memcpy(dict_unit->pron, encoded_pinyin.data(), encoded_pinyin.size());
    dict_units_.push_back(dict_unit);
  }
  VLOG(3) << "modle size " << memory_size / 1024.0 / 1024.0;
}

void DictTrie::SetMinWeight() {
  uint8 ret = kMinUint8;
  for (const auto& dict_unit : dict_units_) {
    ret = std::max(dict_unit->weight, ret);
  }
  min_weight_ = WeightDecoding(ret);
}

void DictTrie::SetMaxWeight() {
  uint8 ret = kMaxUint8;
  for (const auto& dict_unit : dict_units_) {
    ret = std::min(dict_unit->weight, ret);
  }
  max_weight_ = WeightDecoding(ret);
}

}  // namespace segmenter
}  // namespace nlp
