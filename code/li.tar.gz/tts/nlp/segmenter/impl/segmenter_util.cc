// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: ranzhang@mobvoi.com (Dylan)

#include "tts/nlp/segmenter/impl/segmenter_util.h"

namespace nlp {
namespace segmenter {

static const char* kPosTypeArray[] = {
    "a",  "ad", "Ag", "an", "b", "c", "d",  "e", "En",  "f",  "g",
    "h",  "i",  "j",  "k",  "l", "m", "mq", "n", "Ng",  "nr", "nrw",
    "ns", "nt", "nz", "o",  "p", "q", "r",  "s", "t",   "Tg", "u",
    "v",  "vd", "Vg", "vn", "w", "x", "y",  "z", "unk",
};

static const char* kDigitWord[] = {"零", "一", "壹", "幺", "二", "两", "三",
                                   "四", "五", "六", "七", "八", "九", "十",
                                   "百", "千", "万", "亿", "点"};
static const char* kDigitPostCombWord[] = {"岁", "年",   "月", "日", "时",
                                           "分", "秒",   "名", "度", "个",
                                           "里", "公里", "米", "路"};
static const char* kDigitPreCombWord[] = {"百分之", "第"};

string Tag(size_t pos_id) {
  if (pos_id >= arraysize(kPosTypeArray)) return kDefaultPos;
  return kPosTypeArray[pos_id];
}

void InitPosTypeMap(map<string, int>* pos_type) {
  for (size_t i = 0; i < arraysize(kPosTypeArray); ++i) {
    pos_type->insert(std::make_pair(string(kPosTypeArray[i]), i));
  }
}

size_t GetPosId(const string& pos) {
  size_t id;
  for (id = 0; id < arraysize(kPosTypeArray); ++id) {
    if (kPosTypeArray[id] == pos) {
      return id;
    }
  }
  // return default;
  return id - 1;
}

bool InList(const string& word, const char** word_list, int size) {
  for (size_t i = 0; i < (size_t)size; ++i)
    if (word == word_list[i]) return true;
  return false;
}

bool IsAlphabet(const vector<util::Rune>& unicode) {
  for (size_t i = 0; i < unicode.size(); ++i)
    if (!(unicode[i] >= 'A' && unicode[i] <= 'Z') &&
        !(unicode[i] >= 'a' && unicode[i] <= 'z'))
      return false;
  return true;
}

// TODO(zhengzhang): refactor this into re2
// TODO(zhengzhang): define Unicode in util
int JudgeStatus(const string& word) {
  vector<util::Rune> unicode;
  util::Utf8ToUnicode(word, &unicode);
  if (IsAlphabet(unicode)) {
    return Status::kEnglish;
  }
  int number_begin = -1;
  int number_end = -1;
  for (size_t i = 0; i < unicode.size(); ++i) {
    string utf8 = util::RuneToWord(unicode[i]);
    if (!InList(utf8, kDigitWord, arraysize(kDigitWord)) ||
        (utf8 == "百" && i + 2 < unicode.size() &&
         util::RuneToWord(unicode[i + 1]) == "分" &&
         util::RuneToWord(unicode[i + 2]) == "之")) {
      if (number_begin != -1) number_end = i;
    } else {
      if (number_begin == -1) number_begin = i;
      if (number_end != -1) return Status::kNone;
    }
  }
  if (number_begin == -1) {
    number_begin = unicode.size();
    number_end = 0;
  }
  if (number_end == -1) number_end = unicode.size();
  string pre_word;
  util::UnicodeToUtf8(unicode.begin(), unicode.begin() + number_begin,
                      &pre_word);
  string post_word;
  util::UnicodeToUtf8(unicode.begin() + number_end, unicode.end(), &post_word);
  if (pre_word.empty() && post_word.empty()) return Status::kDigital;
  if (!pre_word.empty() && !post_word.empty() && pre_word.size() != word.size())
    return Status::kNone;
  if (!pre_word.empty())
    if (InList(pre_word, kDigitPreCombWord, arraysize(kDigitPreCombWord)))
      return Status::kDigitalBegin;
  if (!post_word.empty())
    if (InList(post_word, kDigitPostCombWord, arraysize(kDigitPostCombWord)))
      return Status::kDigitalEnd;
  return Status::kNone;
}

float WeightDecoding(uint8 weight_uint8) {
  // for user word weight decode
  if (weight_uint8 == kMaxUint8) return kUserWordWeight;
  return static_cast<int>(weight_uint8) / kEncoderNum;
}
uint8 WeightEncoding(float weight_float) {
  return (uint8)(weight_float * kEncoderNum);
}

}  // namespace segmenter
}  // namespace nlp
