// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaoqin.feng@mobvoi.com (xiaoqin.feng)

#include "tts/nlp/segmenter/en_segmenter.h"
#include "tts/synthesizer/label_generator/label_def.h"
#include "tts/util/tts_util/util.h"
#include "mobvoi/base/log.h"

namespace nlp {
namespace segmenter {

EnglishSegmenter::EnglishSegmenter(const string& english_marisa_file) {
  if (!english_marisa_file.empty()) {
    english_marisa_trie_map_.OpenModelFile(english_marisa_file);
  }
}

EnglishSegmenter::~EnglishSegmenter() {}

// Split English text with seperate mark: word phrase break
void SplitEngWord(const string& input, vector<string>* words) {
  string word_tmp;
  for (size_t i = 0; i < input.size(); ++i) {
    string char_tmp = input.substr(i, 1);
    // TODO(zhengzhang): process kSepMarkSilence in the future
    if (char_tmp == tts::kSepMarkWord || char_tmp == tts::kSepMarkPhrase ||
        char_tmp == tts::kSepMarkSP || char_tmp == tts::kSepMarkLP ||
        char_tmp == tts::kSepMarkSilence) {
      if (!word_tmp.empty()) {
        words->push_back(word_tmp);
        word_tmp.clear();
      }
      words->push_back(char_tmp);
    } else {
      word_tmp += char_tmp;
    }
  }
  if (!word_tmp.empty()) {
    words->push_back(word_tmp);
  }
}

bool EnglishSegmenter::WordSegmentation(
    const string& input, vector<SegmentWord>* segmentwords) const {
  VLOG(2) << "Start word segmentation ...";
  vector<string> words;
  SplitEngWord(input, &words);
  for (const string& word : words) {
    SegmentWord tmp;
    // TODO(zhengzhang): move ToLower function out in the future
    // word_token_tmp.word = ToLower(word);
    tmp.word = word;
    size_t temp_word_id;
    string input_lower = tts::ToLower(tmp.word);
    if (!english_marisa_trie_map_.FindKeyID(input_lower, &temp_word_id))
      temp_word_id = tts::kEnglishKeyId;
    tmp.word_id = static_cast<int>(temp_word_id);
    tmp.pos = tts::kEnglishPos;
    segmentwords->push_back(tmp);
  }
  if (segmentwords->empty()) {
    return false;
  }
  VLOG(2) << "Word segmentation finished";
  return true;
}

}  // namespace segmenter
}  // namespace nlp
