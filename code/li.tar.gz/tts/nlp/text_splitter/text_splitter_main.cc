// Copyright 2017 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/nlp/text_splitter/text_splitter.h"

#include "mobvoi/base/file.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/time.h"
#include "mobvoi/util/utf8/utf8_util.h"
#include "third_party/gflags/gflags.h"

DEFINE_string(text, "", "");
DEFINE_string(ssml_text_file, "", "");
DEFINE_int32(batch_size, 50, "");
DEFINE_bool(bench_mark, false, "switch to run bench mark");

void Bench(std::shared_ptr<nlp::splitter::TextSplitter> text_splitter,
           const vector<tts::SsmlText>& ssml_texts) {
  int64 begin_time = mobvoi::GetTimeInMs();
  int total_length = 0;
  for (size_t i = 0; i < 10000; ++i) {
    vector<vector<tts::SsmlText>> split_texts;
    total_length +=
        util::utflen(tts::SsmlParser::Instance().JoinText(ssml_texts).c_str());
    text_splitter->TextSplit(ssml_texts, FLAGS_batch_size, &split_texts);
  }
  int64 end_time = mobvoi::GetTimeInMs();
  int64 used_time = end_time - begin_time;

  LOG(INFO) << "text length: " << total_length;
  LOG(INFO) << "used time: " << used_time;
  if (used_time) {
    LOG(INFO) << "performance(character/second): "
              << total_length * 1000.0 / used_time;
  }
}

int main(int argc, char** argv) {
  google::ParseCommandLineFlags(&argc, &argv, false);

  std::shared_ptr<nlp::splitter::TextSplitter> text_splitter =
      std::make_shared<nlp::splitter::TextSplitter>();
  string text;
  if (!FLAGS_text.empty()) {
    text = FLAGS_text;
  } else if (!FLAGS_ssml_text_file.empty()) {
    mobvoi::File::ReadFileToStringOrDie(FLAGS_ssml_text_file, &text);
  } else {
    LOG(ERROR) << "please input split text or ssml text file";
  }

  vector<tts::SsmlText> ssml_texts;
  tts::SsmlParser::Instance().ParseText(text, &ssml_texts);

  if (FLAGS_bench_mark) {
    Bench(text_splitter, ssml_texts);
  } else {
    vector<vector<tts::SsmlText>> split_texts;
    text_splitter->TextSplit(ssml_texts, FLAGS_batch_size, &split_texts);
    int max_len = 0;
    for (const auto& split_text : split_texts) {
      string split_content = tts::SsmlParser::Instance().JoinText(split_text);
      int len = util::utflen(split_content.c_str());
      max_len = std::max(len, max_len);
      LOG(INFO) << len << ", text : " << split_content;
    }
    LOG(INFO) << "max length: " << max_len;
  }
  return 0;
}
