// Copyright 2017 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (zheng zhang)

#include "tts/nlp/text_splitter/text_splitter.h"

#include "mobvoi/base/file.h"
#include "third_party/gtest/gtest.h"

namespace nlp {
namespace splitter {

static const int kLenThreshold = 50;
static const string kTestDataDir = "tts/nlp/text_splitter/testdata/";  // NOLINT

class TextSplitterTest : public ::testing::Test {
 protected:
  virtual void SetUp() { text_splitter_.reset(new TextSplitter()); }
  void TextSplitterCaseTest(const string& test_file,
                            const vector<string>& expect_texts) const {
    string text;
    mobvoi::File::ReadFileToStringOrDie(test_file, &text);
    vector<tts::SsmlText> ssml_texts;
    tts::SsmlParser::Instance().ParseText(text, &ssml_texts);
    tts::SsmlParser::Instance().LogSsml(ssml_texts);

    vector<vector<tts::SsmlText>> split_texts;
    text_splitter_->TextSplit(ssml_texts, kLenThreshold, &split_texts);

    ASSERT_EQ(expect_texts.size(), split_texts.size());
    for (size_t i = 0; i < split_texts.size(); ++i) {
      string result_text = tts::SsmlParser::Instance().JoinText(split_texts[i]);
      EXPECT_EQ(expect_texts[i], result_text) << expect_texts[i] << "\n"
                                              << result_text;
    }
  }

  std::unique_ptr<TextSplitter> text_splitter_;
};

TEST_F(TextSplitterTest, TextSplit) {
  string test_file;

  test_file = kTestDataDir + "ssml1.xml";
  vector<string> expect_texts1;
  expect_texts1.emplace_back(
      "杨浦区今天多云，30°C到40°C，当前温度是33°C。"
      "夏日炎炎，衣物轻薄透气，室外注");
  expect_texts1.emplace_back("");
  expect_texts1.emplace_back(
      "意遮阳避暑，室内酌情添加空调衫，不建议在露天场所逛街。");
  expect_texts1.emplace_back("");
  TextSplitterCaseTest(test_file, expect_texts1);

  test_file = kTestDataDir + "ssml4.xml";
  vector<string> expect_texts2;
  expect_texts2.emplace_back(
      "杨浦区今天多云，30°C到40°C，当前^"
      "温度是33°C。夏日炎炎，衣物轻薄透气，室外注");
  expect_texts2.emplace_back("");
  expect_texts2.emplace_back(
      "意遮阳避暑，室内酌情添,加空调衫，不建议在露天场所逛街。`");
  TextSplitterCaseTest(test_file, expect_texts2);

  test_file = kTestDataDir + "ssml3.xml";
  vector<string> expect_texts3;
  expect_texts3.emplace_back("Beijing Today overcast clouds, 22°F to 29°,");
  expect_texts3.emplace_back(
      "about twenty two degrees fahrenheit to twenty nine ");
  expect_texts3.emplace_back("degrees fahrenheit^");
  TextSplitterCaseTest(test_file, expect_texts3);
}

// static const char* eng_user_dict =
//     "nlp\/text_splitter/testdata/eng_user_dict";
//
// TEST(TextSplitterTest, SplitTextByLanguage) {
//   TextSplitter text_splitter(eng_user_dict);
//   {
//     const string text =
//         "能不能帮我翻译一下How are you ? Fine thank you这句话";
//     vector<SplitTextType> pieces;
//     text_splitter.SplitTextByLanguage(text, &pieces);
//     ASSERT_EQ(pieces.size(), 3UL);
//     EXPECT_EQ(pieces[0].second, "能不能帮我翻译一下");
//     EXPECT_EQ(pieces[1].second, "How are you ? Fine thank you");
//     EXPECT_EQ(pieces[2].second, "这句话");
//   }
//   {
//     const string text =
//         "How are you?你好吗我很好Fine, thank you.你呢And you ?";
//     vector<SplitTextType> pieces;
//     text_splitter.SplitTextByLanguage(text, &pieces);
//     ASSERT_EQ(pieces.size(), 5UL);
//     EXPECT_EQ(pieces[0].second, "How are you?");
//     EXPECT_EQ(pieces[1].second, "你好吗我很好");
//     EXPECT_EQ(pieces[2].second, "Fine, thank you.");
//     EXPECT_EQ(pieces[3].second, "你呢");
//     EXPECT_EQ(pieces[4].second, "And you ?");
//   }
//   {
//     const string text = "How are you?Fine, thank you.And you ?";
//     vector<SplitTextType> pieces;
//     text_splitter.SplitTextByLanguage(text, &pieces);
//     ASSERT_EQ(pieces.size(), 1UL);
//     EXPECT_EQ(pieces[0].second, "How are you?Fine, thank you.And you ?");
//   }
//   {
//     const string text = "中华人民共和国从此站起来了.";
//     vector<SplitTextType> pieces;
//     text_splitter.SplitTextByLanguage(text, &pieces);
//     ASSERT_EQ(pieces.size(), 1UL);
//     EXPECT_EQ(pieces[0].second, "中华人民共和国从此站起来了.");
//   }
//   {
//     const string text = "\n中华人民共和国从此站起来了.";
//     vector<SplitTextType> pieces;
//     text_splitter.SplitTextByLanguage(text, &pieces);
//     ASSERT_EQ(pieces.size(), 1UL);
//     EXPECT_EQ(pieces[0].second, "\n中华人民共和国从此站起来了.");
//   }
// }
//
// TEST(TextSplitterTest, SplitEngText) {
//   const string text = "PM,IBM, 出门问问,欢迎您, IBM, NASA.";
//   TextSplitter text_splitter(eng_user_dict);
//   vector<SplitTextType> pieces;
//   text_splitter.SplitTextByLanguage(text, &pieces);
//   text_splitter.SplitEngText(&pieces);
//   ASSERT_EQ(pieces.size(), 5UL);
//   EXPECT_EQ(pieces[0].second, "PM,");
//   EXPECT_EQ(pieces[1].second, "IBM, ");
//   EXPECT_EQ(pieces[2].second, "出门问问,欢迎您, ");
//   EXPECT_EQ(pieces[3].second, "IBM, ");
//   EXPECT_EQ(pieces[4].second, "nasa.");
//   EXPECT_EQ(tts::LanguageType::kSingleABC, pieces[0].first);
//   EXPECT_EQ(tts::LanguageType::kSingleABC, pieces[1].first);
//   EXPECT_EQ(tts::LanguageType::kMandarin, pieces[2].first);
//   EXPECT_EQ(tts::LanguageType::kSingleABC, pieces[3].first);
//   EXPECT_EQ(tts::LanguageType::kEnglish, pieces[4].first);
// }
//
// TEST(TextSplitterTest, SplitLongMandarinText) {
//   int text_batch_size = 20;
//   const string text =
//       "向香港特别行政区，同胞澳门和台，湾同胞海外侨胞，"
//       "向香港特别行政区，同胞澳门和台";
//   TextSplitter text_splitter(eng_user_dict);
//   vector<string> split_text;
//   bool is_punc_end;
//   text_splitter.SplitLongMandarinText(text, text_batch_size, &is_punc_end,
//                                      &split_text);
//   ASSERT_EQ(split_text.size(), 3UL);
//   EXPECT_EQ(split_text[0], "向香港特别行政区，同胞澳门和台，");
//   EXPECT_EQ(split_text[1], "湾同胞海外侨胞，向香港特别行政区，");
//   EXPECT_EQ(split_text[2], "同胞澳门和台");
// }
//
// TEST(TextSplitterTest, SplitLongEnglishText) {
//   int text_batch_size = 2;
//   const string text = "welcome to beijing, welcome, to, bei jing too, yeah.";
//   TextSplitter text_splitter(eng_user_dict);
//   vector<string> split_text;
//   bool is_punc_end;
//   text_splitter.SplitLongEnglishText(text, text_batch_size, &is_punc_end,
//                                     &split_text);
//   ASSERT_EQ(split_text.size(), 4);
//   EXPECT_EQ(split_text[0], "welcome to beijing");
//   EXPECT_EQ(split_text[1], " welcome, to");
//   EXPECT_EQ(split_text[2], " bei jing too");
//   EXPECT_EQ(split_text[3], " yeah.");
// }
}  // namespace splitter
}  // namespace nlp
