// Copyright 2017 Mobvoi Inc. All Rights Reserved.
// Author: xiaoqin.feng@mobvoi.com

#include "tts/nlp/polyphone/dict_polyphone.h"
#include "tts/synthesizer/label_generator/label_def.h"
#include "tts/util/tts_util/util.h"

#include "mobvoi/base/log.h"

namespace nlp {
namespace polyphone {

static const char kPolyphoneSegSepMark[] = ",";
static const char kPolyphoneItemSepMark = ' ';
enum PolyphoneFileFormat {
  kPolyWord = 0,
  kPolyPron,
  kPolyType,
  kPolyKeyword,
  kPolyOffset,
  kPolyAllnum,
};

static PolyphoneRuleType GetRuleType(const string& type) {
  if (type == "keyword") return PolyphoneRuleType::kTypeKeyword;
  if (type == "pos") return PolyphoneRuleType::kTypePos;
  if (type == "idx") return PolyphoneRuleType::kTypeIdx;
  if (type == "tone") return PolyphoneRuleType::kTypeTone;
  if (type == "single") return PolyphoneRuleType::kTypeSingle;
  if (type == "all") return PolyphoneRuleType::kTypeAll;
  if (type == "special_name") return PolyphoneRuleType::kTypeSpecialName;
  if (type == "general_name") return PolyphoneRuleType::kTypeGeneralName;
  return PolyphoneRuleType::kTypeError;
}

DictPolyphone::DictPolyphone(const string& base_rule,
                             const string& language_dependency_rule,
                             const string& config_center,
                             const string& name_rule) {
  LoadPolyphoneRule(base_rule);
  LoadPolyphoneRule(language_dependency_rule);
  LoadPolyphoneRule(config_center);
  LoadPolyphoneRule(name_rule);
}

DictPolyphone::~DictPolyphone() {}

bool DictPolyphone::PolyphoneProcess(vector<PolyphoneToken>* polyphone_tokens,
                                     map<int, int>* polyphone_prob) const {
  return true;
}

bool DictPolyphone::PolyphoneProcess(
    vector<PolyphoneToken>* polyphone_tokens) const {
  VLOG(2) << "Start to process dict polyphone ...";
  for (const auto& polyphone_rule : polyphone_base_rule_) {
    if (polyphone_rule.type == PolyphoneRuleType::kTypeKeyword) {
      KeywordProcess(polyphone_rule, polyphone_tokens);
    } else if (polyphone_rule.type == PolyphoneRuleType::kTypePos) {
      PosProcess(polyphone_rule, polyphone_tokens);
    } else if (polyphone_rule.type == PolyphoneRuleType::kTypeIdx) {
      IdxProcess(polyphone_rule, polyphone_tokens);
    } else if (polyphone_rule.type == PolyphoneRuleType::kTypeTone) {
      ToneProcess(polyphone_rule, polyphone_tokens);
    } else if (polyphone_rule.type == PolyphoneRuleType::kTypeSingle) {
      SingleProcess(polyphone_rule, polyphone_tokens);
    } else if (polyphone_rule.type == PolyphoneRuleType::kTypeAll) {
      AllProcess(polyphone_rule, polyphone_tokens);
    } else {
      // kTypeError
      continue;
    }
  }
  for (const auto& polyphone_name_rule : polyphone_special_name_rule_) {
    SpecialNamePolyProcess(polyphone_name_rule, polyphone_tokens);
  }
  for (const auto& polyphone_name_rule : polyphone_general_name_rule_) {
    GeneralNamePolyProcess(polyphone_name_rule, polyphone_tokens);
  }
  VLOG(2) << "Dict Polyphone finished";
  return true;
}

PolyphoneRule* DictPolyphone::FindPolyphoneRuleByWord(const string& word) {
  for (auto it = polyphone_special_name_rule_.begin();
       it != polyphone_special_name_rule_.end(); it++) {
    if (it->word == word) {
      return &(*it);
    }
  }
  return nullptr;
}

int DictPolyphone::GetMaxKeyWordSize(
    const PolyphoneRule& polyphone_rule) const {
  int max_length = 0;
  for (const auto& key_word : polyphone_rule.key_words) {
    int key_word_length = static_cast<int>(util::utflen(key_word.c_str()));
    if (key_word_length > max_length) max_length = key_word_length;
  }
  return max_length;
}

void DictPolyphone::LoadPolyphoneRule(const string& polyphone_rule) {
  vector<string> lines;
  tts::GetConfigCenterLines(polyphone_rule, &lines);
  PolyphoneRuleType rule_type = PolyphoneRuleType::kTypeError;
  for (const auto& line : lines) {
    vector<string> segs;
    mobvoi::SplitStringToVector(line, kPolyphoneSegSepMark, false, &segs);
    if (segs.size() != PolyphoneFileFormat::kPolyAllnum) {
      LOG(WARNING) << "polyphone rule invalid: " << line;
      continue;
    }
    rule_type = GetRuleType(segs[PolyphoneFileFormat::kPolyType]);
    vector<string> key_words;
    SplitString(segs[PolyphoneFileFormat::kPolyKeyword], kPolyphoneItemSepMark,
                &key_words);
    string word = segs[PolyphoneFileFormat::kPolyWord];
    if (rule_type == PolyphoneRuleType::kTypeSpecialName) {
      PolyphoneRule* find_rule = FindPolyphoneRuleByWord(word);
      if (find_rule != nullptr) {
        for (const auto& key_word : key_words) {
          find_rule->key_words.insert(key_word);
        }
        continue;
      }
    }

    PolyphoneRule rule;
    rule.word = word;
    rule.type = rule_type;
    rule.offset = StringToInt(segs[PolyphoneFileFormat::kPolyOffset]);
    SplitString(segs[PolyphoneFileFormat::kPolyPron], kPolyphoneItemSepMark,
                &rule.prons);

    if ((size_t)util::utflen(rule.word.c_str()) != rule.prons.size()) {
      LOG(WARNING) << "error format: " << line;
      continue;
    }
    for (const auto& key_word : key_words) {
      rule.key_words.insert(key_word);
    }
    if (rule.type == PolyphoneRuleType::kTypeSpecialName)
      polyphone_special_name_rule_.emplace_back(rule);
    else if (rule.type == PolyphoneRuleType::kTypeGeneralName)
      polyphone_general_name_rule_.emplace_back(rule);
    else
      polyphone_base_rule_.emplace_back(rule);
  }

  if (rule_type == PolyphoneRuleType::kTypeSpecialName)
    polyphone_special_name_rule_.shrink_to_fit();
  else if (rule_type == PolyphoneRuleType::kTypeGeneralName)
    polyphone_general_name_rule_.shrink_to_fit();
  else
    polyphone_base_rule_.shrink_to_fit();
}

// replace target word pron with correct pron
// if token words in offset range has in key word set
void DictPolyphone::KeywordProcess(
    const PolyphoneRule& polyphone_rule,
    vector<PolyphoneToken>* polyphone_tokens) const {
  int direction = (polyphone_rule.offset > 0) ? 1 : -1;
  for (size_t i = 0; i < polyphone_tokens->size(); ++i) {
    if (polyphone_tokens->at(i).pron_fixed == true ||
        polyphone_tokens->at(i).p_pron_fixeds.size() ==
            (size_t)util::utflen(polyphone_tokens->at(i).word.c_str()))
      continue;
    if (polyphone_tokens->at(i).word == polyphone_rule.word) {
      for (size_t j = 1; j <= (size_t)abs(polyphone_rule.offset); ++j) {
        int target_offset = i + j * direction;
        if (target_offset < 0 ||
            (size_t)target_offset >= polyphone_tokens->size())
          break;
        string word = polyphone_tokens->at(target_offset).word;
        if (polyphone_rule.key_words.find(word) !=
            polyphone_rule.key_words.end()) {
          for (size_t k = 0; k < polyphone_rule.prons.size(); ++k) {
            if (polyphone_tokens->at(i).p_pron_fixeds.find(k) ==
                polyphone_tokens->at(i).p_pron_fixeds.end()) {
              polyphone_tokens->at(i).prons[k] = polyphone_rule.prons[k];
              polyphone_tokens->at(i).p_pron_fixeds[k] = true;
            }
          }
          break;
        }
      }
    }
  }
}

// replace target word pron with correct pron
// if offset token pos is in key word set
void DictPolyphone::PosProcess(const PolyphoneRule& polyphone_rule,
                               vector<PolyphoneToken>* polyphone_tokens) const {
  for (size_t i = 0; i < polyphone_tokens->size(); ++i) {
    if (polyphone_tokens->at(i).pron_fixed == true ||
        polyphone_tokens->at(i).p_pron_fixeds.size() ==
            (size_t)util::utflen(polyphone_tokens->at(i).word.c_str()))
      continue;
    int target_offset = i + polyphone_rule.offset;
    if (polyphone_tokens->at(i).word == polyphone_rule.word &&
        target_offset >= 0 &&
        (size_t)target_offset < polyphone_tokens->size() &&
        polyphone_rule.key_words.find(
            polyphone_tokens->at(target_offset).pos) !=
            polyphone_rule.key_words.end()) {
      for (size_t j = 0; j < polyphone_rule.prons.size(); ++j) {
        if (polyphone_tokens->at(i).p_pron_fixeds.find(j) ==
            polyphone_tokens->at(i).p_pron_fixeds.end()) {
          polyphone_tokens->at(i).prons[j] = polyphone_rule.prons[j];
          polyphone_tokens->at(i).p_pron_fixeds[j] = true;
        }
      }
    }
  }
}

// replace target word pron with correct pron
// if target word is in target position of the sentence
void DictPolyphone::IdxProcess(const PolyphoneRule& polyphone_rule,
                               vector<PolyphoneToken>* polyphone_tokens) const {
  for (int i = -1; i < static_cast<int>(polyphone_tokens->size() + 1); ++i) {
    if (i == -1 || i == static_cast<int>(polyphone_tokens->size()) ||
        polyphone_tokens->at(i).word == tts::kSepMarkSilence ||
        polyphone_tokens->at(i).word == tts::kSepMarkLP) {
      int target_offset;
      if (polyphone_rule.offset >= 0)
        target_offset = polyphone_rule.offset + i + 1;
      else
        target_offset = polyphone_rule.offset + i;
      if (target_offset < 0 ||
          target_offset >= static_cast<int>(polyphone_tokens->size())) {
        VLOG(2) << "poly rule out of range: " << polyphone_rule.offset;
        continue;
      }
      if (polyphone_tokens->at(target_offset).pron_fixed == true ||
          polyphone_tokens->at(target_offset).p_pron_fixeds.size() ==
              (size_t)util::utflen(
                  polyphone_tokens->at(target_offset).word.c_str()))
        return;
      if (polyphone_tokens->at(target_offset).word == polyphone_rule.word) {
        for (size_t j = 0; j < polyphone_rule.prons.size(); ++j) {
          if (polyphone_tokens->at(target_offset).p_pron_fixeds.find(j) ==
              polyphone_tokens->at(target_offset).p_pron_fixeds.end()) {
            polyphone_tokens->at(target_offset).prons[j] =
                polyphone_rule.prons[j];
            polyphone_tokens->at(target_offset).p_pron_fixeds[j] = true;
          }
        }
      }
    }
  }
}

// replace target word pron with correct pron
// if offset token tone is in key word set
void DictPolyphone::ToneProcess(
    const PolyphoneRule& polyphone_rule,
    vector<PolyphoneToken>* polyphone_tokens) const {
  for (size_t i = 0; i < polyphone_tokens->size(); ++i) {
    if (polyphone_tokens->at(i).pron_fixed == true ||
        polyphone_tokens->at(i).p_pron_fixeds.size() ==
            (size_t)util::utflen(polyphone_tokens->at(i).word.c_str()))
      continue;
    int target_offset = i + polyphone_rule.offset;
    if (polyphone_tokens->at(i).word == polyphone_rule.word &&
        target_offset >= 0 &&
        (size_t)target_offset < polyphone_tokens->size()) {
      string offset_pron = polyphone_tokens->at(target_offset).prons.front();
      if (!offset_pron.empty() &&
          polyphone_rule.key_words.find(offset_pron.substr(
              offset_pron.size() - 1)) != polyphone_rule.key_words.end()) {
        for (size_t j = 0; j < polyphone_rule.prons.size(); ++j) {
          if (polyphone_tokens->at(i).p_pron_fixeds.find(j) ==
              polyphone_tokens->at(i).p_pron_fixeds.end()) {
            polyphone_tokens->at(i).prons[j] = polyphone_rule.prons[j];
            polyphone_tokens->at(i).p_pron_fixeds[j] = true;
          }
        }
      }
    }
  }
}

// replace target word pron with correct pron
// if single token word is target word
void DictPolyphone::SingleProcess(
    const PolyphoneRule& polyphone_rule,
    vector<PolyphoneToken>* polyphone_tokens) const {
  for (auto& polyphone_token : *polyphone_tokens) {
    if (polyphone_token.pron_fixed == true ||
        polyphone_token.p_pron_fixeds.size() ==
            (size_t)util::utflen(polyphone_token.word.c_str()))
      continue;
    if (polyphone_token.word == polyphone_rule.word) {
      for (size_t i = 0; i < polyphone_rule.prons.size(); ++i) {
        if (polyphone_token.p_pron_fixeds.find(i) ==
            polyphone_token.p_pron_fixeds.end()) {
          polyphone_token.prons[i] = polyphone_rule.prons[i];
          polyphone_token.p_pron_fixeds[i] = true;
        }
      }
    }
  }
}

// replace target word pron with correct pron all
void DictPolyphone::AllProcess(const PolyphoneRule& polyphone_rule,
                               vector<PolyphoneToken>* polyphone_tokens) const {
  for (auto& polyphone_token : *polyphone_tokens) {
    if (polyphone_token.pron_fixed == true ||
        polyphone_token.p_pron_fixeds.size() ==
            (size_t)util::utflen(polyphone_token.word.c_str()))
      continue;
    vector<util::Rune> unicodes;
    util::Utf8ToUnicode(polyphone_token.word, &unicodes);
    if (unicodes.size() != polyphone_token.prons.size()) {
      LOG(WARNING) << "mismatch pron for word: " << polyphone_token.word << " "
                   << JoinVector(polyphone_token.prons, kPolyphoneItemSepMark);
      continue;
    }
    if (polyphone_token.word == polyphone_rule.word) {
      for (size_t i = 0; i < unicodes.size(); ++i) {
        util::Rune unicode = unicodes[i];
        if (polyphone_token.p_pron_fixeds.find(i) ==
            polyphone_token.p_pron_fixeds.end()) {
          polyphone_token.prons[i] = polyphone_rule.prons[i];
          polyphone_token.p_pron_fixeds[i] = true;
        }
      }
    }
  }
}

// replace target word pron with correct pron
// if target word in name_rules & type is special_name
void DictPolyphone::SpecialNamePolyProcess(
    const PolyphoneRule& polyphone_name_rule,
    vector<PolyphoneToken>* polyphone_tokens) const {
  int max_key_word_length = GetMaxKeyWordSize(polyphone_name_rule);
  for (size_t i = 0; i < polyphone_tokens->size(); ++i) {
    if (polyphone_tokens->at(i).pron_fixed == true ||
        polyphone_tokens->at(i).p_pron_fixeds.size() ==
            (size_t)util::utflen(polyphone_tokens->at(i).word.c_str()))
      continue;
    if (polyphone_tokens->at(i).word == polyphone_name_rule.word) {
      string token_str;
      for (size_t offset = 1; offset < polyphone_tokens->size() - i; ++offset) {
        vector<util::Rune> token_unicodes;
        if (max_key_word_length <= 0) continue;
        util::Utf8ToUnicode(polyphone_tokens->at(i + offset).word,
                            &token_unicodes);
        max_key_word_length -= token_unicodes.size();
        int token_end = max_key_word_length >= 0
                            ? token_unicodes.size()
                            : token_unicodes.size() - abs(max_key_word_length);
        for (size_t token_offset = 0; token_offset < token_end; ++token_offset)
          token_str += util::RuneToWord(token_unicodes[token_offset]);
      }
      for (const auto& key_word : polyphone_name_rule.key_words) {
        if (token_str.find(key_word) == 0) {
          for (size_t j = 0; j < polyphone_name_rule.prons.size(); ++j) {
            if (polyphone_tokens->at(i).p_pron_fixeds.find(j) ==
                polyphone_tokens->at(i).p_pron_fixeds.end()) {
              polyphone_tokens->at(i).prons[j] = polyphone_name_rule.prons[j];
              polyphone_tokens->at(i).p_pron_fixeds[j] = true;
            }
          }
          break;
        }
      }
    }
  }
}

// replace target word pron with correct pron
// if target word in name_rules & type is general_name
void DictPolyphone::GeneralNamePolyProcess(
    const PolyphoneRule& polyphone_name_rule,
    vector<PolyphoneToken>* polyphone_tokens) const {
  PolyphoneRule rule;
  for (const auto& polyphone_special_name_rule : polyphone_special_name_rule_) {
    rule = polyphone_name_rule;
    rule.word = polyphone_special_name_rule.word;
    rule.prons = polyphone_special_name_rule.prons;
    KeywordProcess(rule, polyphone_tokens);
  }
}

mobvoi::unordered_set<string> DictPolyphone::GetPolyphoneModelDict() const {
  mobvoi::unordered_set<string> polyphone_model_dict;
  return polyphone_model_dict;
}

}  // namespace polyphone
}  // namespace nlp
