// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaoqin.feng@mobvoi.com

#include "tts/nlp/polyphone/crf_polyphone.h"

#include <regex>  //NOLINT
#include "mobvoi/base/file/file.h"
#include "mobvoi/base/file/proto_util.h"
#include "mobvoi/base/log.h"
#include "re2/re2.h"
#include "tts/synthesizer/label_generator/label_def.h"
#include "tts/util/tts_util/util.h"

DEFINE_bool(all_use_poly_model, false, "enable all polyphone word prediction");

static const int kPolyphoneLevel = 0;
static int kWordWinOffset = 5;
static int kPosWinOffset = 3;
static const char kDefaultWord[] = "bound";
static const char kDefaultSymbol[] = "def_syb";
static const char kDefaultEngSymbol[] = "eng_syb";
static const char kDefaultNumberSymbol[] = "num_syb";
static const char kDefaultPos[] = "pos";
static const char kPolyphoneModelPattern[] =
    "([a-zA-Z0-9_]+)\\s*:\\s*\"([a-zA-Z0-9_]+)\"";

namespace nlp {
namespace polyphone {

CrfPolyphone::CrfPolyphone(const string& polyphone_model,
                           const string& polyphone_dict) {
  if (polyphone_model.empty() || polyphone_dict.empty()) return;
  LoadPolyphoneModel(polyphone_dict, polyphone_model);
}

CrfPolyphone::~CrfPolyphone() {}

void CrfPolyphone::LoadPolyphoneModel(const string& polyphone_dict_path,
                                      const string& polyphone_model_path) {
  vector<string> lines;
  vector<string> values;
  tts::GetConfigCenterLines(polyphone_dict_path, &lines);
  mobvoi::unordered_set<string> polyphone_type_set;
  for (const auto& line : lines) {
    mobvoi::SplitStringToVector(line, ",", false, &values);
    if (values.size() == 3) {
      PolyphoneParms polyphone_parms = {StringToInt(values[1]), values[2]};
      polyphone_type_set.insert(values[2]);
      polyphone_dict_.insert(std::make_pair(values[0], polyphone_parms));
    }
  }
  tts::GetConfigCenterLines(polyphone_model_path, &lines);
  string dir = mobvoi::File::FindFileDir(polyphone_model_path);
  static re2::RE2 polyphone_model_pattern(kPolyphoneModelPattern);
  string type, model;
  for (const auto& line : lines) {
    if (re2::RE2::FullMatch(line, polyphone_model_pattern, &type, &model)) {
      if (polyphone_type_set.find(type) != polyphone_type_set.end() &&
          mobvoi::File::Exists(mobvoi::File::JoinPath(dir, model))) {
        VLOG(2) << "add model: " << type << " " << model;
        polyphone_models_[type].reset(
            new crf::CrfModel(mobvoi::File::JoinPath(dir, model)));
      }
    }
  }
}

bool CrfPolyphone::IsTarget(const string& character, const string& word) const {
  if (polyphone_dict_.find(character) != polyphone_dict_.end()) {
    auto iter = polyphone_dict_.find(character);
    int strict_len = iter->second.strict_len;
    if (!FLAGS_all_use_poly_model && util::utflen(word.c_str()) > strict_len) {
      return false;
    } else {
      return true;
    }
  }
  return false;
}

void CrfPolyphone::GenCrfFeat(const vector<InputToken>& tokens, int offset,
                              const vector<string>& pos_lists,
                              string* feat) const {
  vector<string> feat_lines;
  for (int i = offset - kWordWinOffset; i <= offset + kWordWinOffset; ++i) {
    if (i < 0 || (size_t)i >= tokens.size()) {
      feat_lines.emplace_back(kDefaultWord);
    } else {
      if (tts::IsChineseWord(tokens[i].word))
        feat_lines.emplace_back(tokens[i].word);
      else if (tts::AllLetter(tokens[i].word))
        feat_lines.emplace_back(kDefaultEngSymbol);
      else if (tts::AllDigit(tokens[i].word))
        feat_lines.emplace_back(kDefaultNumberSymbol);
      else
        feat_lines.emplace_back(kDefaultSymbol);
    }
  }
  for (int i = tokens[offset].word_location - kPosWinOffset;
       i <= tokens[offset].word_location + kPosWinOffset; ++i) {
    if (i < 0 || (size_t)i >= pos_lists.size()) {
      feat_lines.emplace_back(kDefaultPos);
    } else {
      feat_lines.emplace_back(pos_lists[i]);
    }
  }
  *feat = JoinVector(feat_lines, '\t');
  VLOG(3) << *feat;
}

bool CrfPolyphone::Predict(const vector<string>& pos_lists,
                           vector<InputToken>* tokens,
                           map<int, int>* polyphone_prob) const {
  if (polyphone_models_.empty()) {
    VLOG(2) << "crf model not exists.";
    return false;
  }
  int man_word_num = -1;
  for (size_t i = 0; i < tokens->size(); ++i) {
    if (tts::IsChineseWord(tokens->at(i).word)) {
      man_word_num++;
    }
    if (tokens->at(i).is_target) {
      vector<string> feat_lines;
      string feat_line;
      GenCrfFeat(*tokens, i, pos_lists, &feat_line);
      feat_lines.emplace_back(feat_line);
      vector<string> pred_result;
      vector<map<string, float>> top_result;
      string model_type = polyphone_dict_.at(tokens->at(i).word).model_type;
      if (polyphone_models_.at(model_type)
              ->DoCrfPred(kPolyphoneLevel, feat_lines, &pred_result,
                          &top_result)) {
        vector<float> probs;
        for (const auto& top_s : top_result[0]) {
          probs.emplace_back(top_s.second);
        }
        sort(probs.rbegin(), probs.rend());
        if (probs.size() >= 2) {
          int temp_prob = EucDistance(probs.at(0), probs.at(1));
          polyphone_prob->insert(std::make_pair(man_word_num, temp_prob));
        }
        tokens->at(i).pinyin = pred_result[0];
      } else {
        return false;
      }
    }
  }
  return true;
}

int CrfPolyphone::EucDistance(const float a, const float b) const {
  VLOG(2) << a << " : " << b << " : "
          << static_cast<int>((a - b) * (a - b) * 100);
  return static_cast<int>((a - b) * (a - b) * 100);
}

bool CrfPolyphone::PolyphoneProcess(
    vector<PolyphoneToken>* polyphone_tokens) const {
  map<int, int> polyphone_prob;
  return PolyphoneProcess(polyphone_tokens, &polyphone_prob);
}

//  postprocess for 一
void CrfPolyphone::DoYiPolyphoneCheck(vector<InputToken>* input_tokens) const {
  // See Document:
  // https://docs.google.com/document/d/1hw1Zil9bldYHtlcqej2Nf2SqRLlLv6Mg4lNw7-W6iCw/edit?usp=sharing
  // Rule1 : 不允许的组合及变换
  //      Post:  一*  21->11 23-> 13 25->15 22->42   44 -> 24
  //      Pre: *一 22->21
  //      Mid: *一* 414 -> 424
  // Rule2 : 固定组合
  //      一一细数、一一到来 ： 两个一在一起的时候，将都读一声
  //      单独的一，读一声 //需要在多音字部分处理（符号信息）
  //      kYiPreWord:以壹一二三四五六七八九零十第其点统之第
  //      (一之前是这些词的读一声)
  //      kYiPostWord:壹一二三四五六七八九零月至日流号是百千十万和加减乘除区厂阁汽院秒
  //      (一之后是这些词的读一声)
  //      出现在相同的词中间读轻声，除了一*一*的组合
  //      //需要在多音字部分处理（符号信息）
  if (input_tokens->empty()) return;
  const string kYiPreWord = "以壹一二三四五六七八九零十第其点统之第张期唯惟";
  const string kYiPostWord =
      "壹一二三四五六七八九零月至日流号是百千十万亿和加减乘除区厂阁汽院秒郎";
  char pre_tone = char();
  string pre_word = string();
  for (size_t i = 0; i < input_tokens->size() - 1; ++i) {
    if (input_tokens->at(i).is_target && input_tokens->at(i).word == "一") {
      char now_tone = input_tokens->at(i).pinyin.back();
      char res_tone = now_tone;
      if (pre_tone == '2' && now_tone == '2') res_tone = '1';
      if (tts::IsChineseWord(input_tokens->at(i + 1).word)) {
        string next_word = input_tokens->at(i + 1).word;
        char next_tone = input_tokens->at(i + 1).pinyin.back();
        if (now_tone == '2' &&
            (next_tone == '1' || next_tone == '3' || next_tone == '5'))
          res_tone = '1';
        if (now_tone == '2' && next_tone == '2') res_tone = '4';
        if (now_tone == '4' && next_tone == '4') res_tone = '2';
        if (now_tone == '1' && next_tone == '4') {
          if (!pre_word.empty() && pre_tone == '4') res_tone = '2';
        }
        if (kYiPostWord.find(next_word) != string::npos) res_tone = '1';
        if (pre_word == next_word) {
          if (i < 2 || input_tokens->at(i - 2).word != "一") res_tone = '5';
          if (i >= 2 && input_tokens->at(i - 2).word == "一")
            res_tone = input_tokens->at(i - 2).pinyin.back();
        }
      } else {
        if (pre_word.empty()) res_tone = '1';
      }
      if (!pre_word.empty() && kYiPreWord.find(pre_word) != string::npos)
        res_tone = '1';
      input_tokens->at(i).pinyin.back() = res_tone;
    }
    if (tts::IsChineseWord(input_tokens->at(i).word)) {
      pre_tone = input_tokens->at(i).pinyin.back();
      pre_word = input_tokens->at(i).word;
    } else {
      pre_tone = char();
      pre_word.clear();
    }
  }
  if (!input_tokens->empty() &&
      input_tokens->at(input_tokens->size() - 1).word == "一")
    input_tokens->at(input_tokens->size() - 1).pinyin.back() = '1';
}

bool CrfPolyphone::PolyphoneProcess(vector<PolyphoneToken>* polyphone_tokens,
                                    map<int, int>* polyphone_prob) const {
  VLOG(2) << "Start to process crf  polyphone ...";
  vector<InputToken> input_tokens;
  vector<string> pos_lists;
  for (size_t i = 0; i < polyphone_tokens->size(); ++i) {
    pos_lists.emplace_back(polyphone_tokens->at(i).pos);
    string word = polyphone_tokens->at(i).word;
    vector<string> prons = polyphone_tokens->at(i).prons;
    if (tts::IsChineseWord(word)) {
      vector<string> characters;
      util::SplitUtf8String(word, &characters);
      // skip character number and pron number mismatch words
      if (characters.size() != prons.size()) {
        LOG(WARNING) << "word: " << word
                     << " pron size mismatch: " << prons.size();
        continue;
      }
      if (polyphone_tokens->at(i).pron_fixed) {
        for (size_t j = 0; j < characters.size(); ++j) {
          input_tokens.emplace_back(
              InputToken(characters[j], prons[j], i, false));
        }
      } else {
        map<size_t, bool> p_pron_fixeds = polyphone_tokens->at(i).p_pron_fixeds;
        for (size_t j = 0; j < characters.size(); ++j) {
          if (p_pron_fixeds.find(j) != p_pron_fixeds.end()) {
            input_tokens.emplace_back(
                InputToken(characters[j], prons[j], i, false));
          } else {
            input_tokens.emplace_back(InputToken(
                characters[j], prons[j], i, IsTarget(characters[j], word)));
          }
        }
      }
    } else {
      // not chinese word
      input_tokens.emplace_back(
          InputToken(word, JoinVector(prons, ','), i, false));
    }
  }
  if (!Predict(pos_lists, &input_tokens, polyphone_prob)) {
    return false;
  }
  int cur_loc = -1;
  for (const auto& input_token : input_tokens) {
    if (cur_loc != input_token.word_location) {
      // update a new word pron
      cur_loc = input_token.word_location;
      polyphone_tokens->at(cur_loc).prons.clear();
    }
    vector<string> prons;
    SplitString(input_token.pinyin, ',', &prons);
    for (const auto& pron : prons) {
      polyphone_tokens->at(cur_loc).prons.emplace_back(pron);
    }
  }
  VLOG(2) << "Crf Polyphone finished";
  return true;
}

mobvoi::unordered_set<string> CrfPolyphone::GetPolyphoneModelDict() const {
  mobvoi::unordered_set<string> polyphone_model_dict;
  for (auto poly_dict : polyphone_dict_) {
    polyphone_model_dict.insert(poly_dict.first);
  }
  return polyphone_model_dict;
}

}  // namespace polyphone
}  // namespace nlp
