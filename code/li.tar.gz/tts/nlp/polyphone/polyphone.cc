// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaoqin.feng@mobvoi.com

#include "tts/nlp/polyphone/polyphone.h"
#include "mobvoi/base/file/file.h"
#include "mobvoi/base/file/proto_util.h"
#include "mobvoi/base/log.h"
#include "tts/nlp/polyphone/comb_polyphone.h"
#include "tts/nlp/polyphone/proto/polyphone_resource.pb.h"
#include "tts/util/tts_util/util.h"

namespace nlp {
namespace polyphone {

Polyphone::Polyphone(const string& resource_file) {
  PolyphoneResource polyphone_resource;
  CHECK(mobvoi::ReadProtoFromTextFile(resource_file, &polyphone_resource))
      << resource_file << " load failed!";
  string dir = mobvoi::File::FindFileDir(resource_file);
  polyphone_resource.set_base_rule(
      tts::AppendPath(dir, polyphone_resource.base_rule()));
  polyphone_resource.set_name_rule(
      tts::AppendPath(dir, polyphone_resource.name_rule()));
  polyphone_resource.set_language_dependency_rule(
      tts::AppendPath(dir, polyphone_resource.language_dependency_rule()));
  polyphone_resource.set_config_center(
      tts::AppendPath(dir, polyphone_resource.config_center()));
  polyphone_resource.set_polyphone_dict(
      tts::AppendPath(dir, polyphone_resource.polyphone_dict()));
  polyphone_resource.set_polyphone_model(
      tts::AppendPath(dir, polyphone_resource.polyphone_model()));
  polyphone_.reset(
      static_cast<PolyphoneImpl*>(new CombPolyphone(polyphone_resource)));
}

Polyphone::~Polyphone() {}

bool Polyphone::PolyphoneProcess(
    vector<PolyphoneToken>* polyphone_tokens) const {
  return polyphone_->PolyphoneProcess(polyphone_tokens);
}

bool Polyphone::PolyphoneProcess(vector<PolyphoneToken>* polyphone_tokens,
                                 map<int, int>* polyphone_prob) const {
  return polyphone_->PolyphoneProcess(polyphone_tokens, polyphone_prob);
}

mobvoi::unordered_set<string> Polyphone::GetPolyphoneModelDict() const {
  return polyphone_->GetPolyphoneModelDict();
}

}  // namespace polyphone
}  // namespace nlp
