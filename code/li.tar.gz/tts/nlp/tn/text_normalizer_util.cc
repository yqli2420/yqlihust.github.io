// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/nlp/tn/text_normalizer_util.h"

#include "mobvoi/base/log.h"

namespace nlp {
namespace tn {

static const char kBodySepMark = ',';
enum BodyFormat {
  kBodyBegin = 0,
  kBodyEnd,
  kBodyAllNum,
};

std::pair<int, int> ParseBody(const string& body, int max) {
  if (body.empty()) return std::make_pair(0, max);

  vector<string> bodys;
  SplitString(body, kBodySepMark, &bodys);
  if (bodys.size() != BodyFormat::kBodyAllNum) {
    LOG(FATAL) << "body mismatch: " << body << " " << max;
  }
  int begin = std::max(0, StringToInt(bodys[BodyFormat::kBodyBegin]));
  int end = std::min(max, StringToInt(bodys[BodyFormat::kBodyEnd]));
  return std::make_pair(begin, end);
}

PatternHandler::PatternHandler(const string& _pattern, ProcessFunction _fn,
                               const string& _body, TnChoiceType _choice_type,
                               const string& _name)
    : fn(_fn), choice_type(_choice_type), name(_name) {
  re2_obj.reset(new re2::RE2(_pattern));
  body = ParseBody(_body, re2_obj->NumberOfCapturingGroups());
}

PatternHandler::PatternHandler(const string& _pattern, ProcessFunction _fn,
                               const string& _option, const string& _body,
                               TnChoiceType _choice_type, const string& _name)
    : fn(_fn), option(_option), choice_type(_choice_type), name(_name) {
  re2_obj.reset(new re2::RE2(_pattern));
  body = ParseBody(_body, re2_obj->NumberOfCapturingGroups());
}

string GetPronFromSymbol(const string& symbol,
                         const Symbol2Pron* symbol_pron_map, size_t length) {
  for (size_t i = 0; i < length; ++i)
    if (symbol == symbol_pron_map[i].symbol) return symbol_pron_map[i].pron;
  return "";
}

string ParsePronFromPattern(const string& input, const Pattern2Sub* pattern_sub,
                            size_t length) {
  string output = input;
  for (size_t i = 0; i < length; ++i)
    re2::RE2::GlobalReplace(&output, pattern_sub[i].obj, pattern_sub[i].sub);
  return output;
}

string NormalizeNumString(const string& number_str) {
  string norm_str = number_str;
  re2::RE2::GlobalReplace(&norm_str, "[^0-9.]", "");
  re2::RE2::GlobalReplace(&norm_str, "\\.+", ".");
  // filter last 0s in decimal: 13.123000 -> 13.123   12.00 -> 12 12.800 -> 12.8
  // remain 3.0 -> 3.0
  re2::RE2::GlobalReplace(&norm_str, "^(\\d+\\.[1-9]+)0+$", "\\1");
  re2::RE2::GlobalReplace(&norm_str, "^(\\d+)\\.00+$", "\\1");
  return norm_str;
}

}  // namespace tn
}  // namespace nlp
