// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/nlp/tn/text_normalizer_impl.h"

#include "mobvoi/base/file/proto_util.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/util/utf8/charset_util.h"
#include "tts/nlp/tn/proto/tn_resource.pb.h"
#include "tts/util/tts_util/util.h"

namespace nlp {
namespace tn {

static const int kMaxArgs = 17;  // defined in re2
static const int kMaxMatchTime = 20;
static const string kCaseIgnore = "(?i)";               // NOLINT
static const string kNonLetterFront = "(^|[^a-zA-Z])";  // NOLINT
static const string kNonLetterEnd = "($|[^a-zA-Z])";    // NOLINT
static const re2::RE2 blank_obj("\\ ");

static const char kSpNormSepMark = ',';
enum SpNormFormat {
  kSpNormPattern = 0,
  kSpNormReplace,
  kSpNormAllNum,
};

TextNormalizerImpl::TextNormalizerImpl(const PatternHandler* pattern_handlers,
                                       size_t pattern_number,
                                       const FundHandler* fund_handlers,
                                       size_t base_number,
                                       const string& resource_file) {
  TnResource resource;
  mobvoi::ReadProtoFromTextFile(resource_file, &resource);
  string dir = mobvoi::File::FindFileDir(resource_file);
  string measure_dict = resource.measure_dict();
  if (!measure_dict.empty()) {
    LOG(INFO) << "tts init measure_trie";
    trie_[kMeasureTrie].reset(trie::ReadWordListToMarisa(dir + measure_dict));
  }
  string place_dict = resource.place_dict();
  if (!place_dict.empty()) {
    LOG(INFO) << "tts init place_trie";
    trie_[kPlaceTrie].reset(trie::ReadWordListToMarisa(dir + place_dict));
  }

  string special_normalize_local =
      tts::AppendPath(dir, resource.special_normalize_local());
  LoadSpecialNormalizeWords(special_normalize_local);
  string special_normalize = tts::AppendPath(dir, resource.special_normalize());
  LoadSpecialNormalizeWords(special_normalize);

  pattern_handlers_.reserve(pattern_number);
  for (size_t i = 0; i < pattern_number; ++i) {
    pattern_handlers_.emplace_back(std::move(pattern_handlers[i]));
  }

  for (size_t i = 0; i < base_number; ++i) {
    fund_handlers_[fund_handlers[i].key] = fund_handlers[i].fn;
  }

  RegistPostProcess();
}

TextNormalizerImpl::~TextNormalizerImpl() {
  // for (auto sp_tn : special_tn_) delete sp_tn.regex_obj;
}

void TextNormalizerImpl::ParseSsmlTags(const vector<tts::SsmlText>& texts,
                                       vector<tts::SsmlText>* text_without_ssml,
                                       map<int, string>* offsets_phone,
                                       map<int, string>* offsets_pause) const {
  string text_tmp;
  size_t offset = 0;
  for (const auto& text : texts) {
    if (text.tag.name == tts::kSsmlWordKey ||
        text.tag.name == tts::kSsmlTnKey || text.tag.name == tts::kSsmlSubKey) {
      if (!text_tmp.empty()) {
        text_without_ssml->emplace_back(tts::SsmlText(text_tmp));
        text_tmp.clear();
      }
      text_without_ssml->emplace_back(text);
      offset += util::utflen(text.text.c_str());
    } else {
      if (text.tag.name == tts::kSsmlPhoneKey) {
        if (tts::IsChineseWord(text.text) &&
            util::utflen(text.text.c_str()) != 1) {
          VLOG(2) << "p phoneme tag word error len : "
                  << util::utflen(text.text.c_str());
          continue;
        }
        // process phone p tags
        auto attr_it = text.tag.attrs.find(tts::kSsmlWordPhone);
        if (attr_it != text.tag.attrs.end()) {
          offsets_phone->insert(std::make_pair(offset, attr_it->second));
        }
      } else if (text.tag.name == tts::kSsmlPauseKey) {
        if (!text_tmp.empty()) {
          // process pause pau tags
          auto attr_it = text.tag.attrs.find(tts::kSsmlPauseLevel);
          if (attr_it != text.tag.attrs.end()) {
            offsets_pause->insert(std::make_pair(offset - 1, attr_it->second));
          }
        }
      }
      offset += util::utflen(text.text.c_str());
      text_tmp += text.text;
    }
  }
  if (!text_tmp.empty()) {
    text_without_ssml->emplace_back(tts::SsmlText(text_tmp));
  }
}

void TextNormalizerImpl::SsmlPostProcess(
    tts::TnDetail detail, map<int, string> offsets_phone,
    map<int, string> offsets_pause, vector<tts::SsmlText>* ssml_outputs) const {
  vector<int> offsets;
  size_t start = 0;
  size_t i_start = 0;
  for (auto tnp : detail.tn_mappings) {
    for (size_t i = start; i < tnp.offset; ++i) {
      offsets.emplace_back(i);
    }
    i_start = tnp.offset;
    int tn_pause_offset = -1;
    for (size_t i = 0; i < util::utflen(tnp.input.c_str()); ++i) {
      auto pause_find = offsets_pause.find(i_start);
      if (pause_find != offsets_pause.end()) {
        tn_pause_offset = pause_find->first;
      }
      i_start += 1;
    }
    for (size_t i = 0; i < util::utflen(tnp.output.c_str()); ++i) {
      offsets.emplace_back(tn_pause_offset);
    }
    start = tnp.offset + util::utflen(tnp.input.c_str());
  }
  size_t offset_now = offsets.size();
  for (size_t i = offset_now; i < util::utflen(detail.tn_output.c_str()); ++i) {
    offsets.emplace_back(start++);
  }
  vector<tts::SsmlText> ptexts;
  start = 0;
  string text_tmp = string();
  for (auto it = ssml_outputs->begin(); it != ssml_outputs->end(); ++it) {
    if (it->tag.name == tts::kSsmlWordKey) {
      if (!text_tmp.empty()) {
        ptexts.emplace_back(tts::SsmlText(text_tmp));
        text_tmp.clear();
      }
      ptexts.emplace_back(*it);
      start += util::utflen(it->text.c_str());
    } else {
      if (it->tag.name == tts::kSsmlTnKey) {
        text_tmp += it->text;
        start += util::utflen(it->text.c_str());
      } else {
        vector<string> characters;
        util::SplitUtf8String(it->text, &characters);
        for (size_t i = 0; i < characters.size(); ++i) {
          if (start + i >= offsets.size()) continue;
          auto phone_find = offsets_phone.find(offsets[start + i]);
          if (phone_find != offsets_phone.end()) {
            if (!text_tmp.empty()) {
              ptexts.emplace_back(tts::SsmlText(text_tmp));
              text_tmp.clear();
            }
            tts::SsmlTag tag(tts::kSsmlPhoneKey);
            tag.attrs.insert(
                std::make_pair(tts::kSsmlWordPhone, phone_find->second));
            tts::SsmlText tmp_ssml(characters[i], tag);
            ptexts.emplace_back(tmp_ssml);
          }
          auto pause_find = offsets_pause.find(offsets[start + i]);
          if (pause_find != offsets_pause.end()) {
            if (phone_find == offsets_phone.end()) {
              text_tmp += characters[i];
              ptexts.emplace_back(tts::SsmlText(text_tmp));
              text_tmp.clear();
            }
            tts::SsmlTag tag(tts::kSsmlPauseKey);
            tag.attrs.insert(
                std::make_pair(tts::kSsmlPauseLevel, pause_find->second));
            tts::SsmlText tmp_ssml(string(), tag);
            ptexts.emplace_back(tmp_ssml);
          }
          if (phone_find == offsets_phone.end() &&
              pause_find == offsets_pause.end())
            text_tmp += characters[i];
        }
        start += util::utflen(it->text.c_str());
      }
    }
  }
  if (!text_tmp.empty()) {
    ptexts.emplace_back(tts::SsmlText(text_tmp));
  }
  if (!ptexts.empty()) *ssml_outputs = ptexts;
}

bool TextNormalizerImpl::Normalize(const vector<tts::SsmlText>& ssml_inputs,
                                   const string& option,
                                   vector<tts::SsmlText>* ssml_outputs,
                                   tts::TnDetail* detail) const {
  detail->tn_input = tts::SsmlParser::Instance().JoinText(ssml_inputs);
  vector<tts::SsmlText> ptexts;
  map<int, string> offsets_phone;
  map<int, string> offsets_pause;
  // remove ssml phone key and record target phone offset
  ParseSsmlTags(ssml_inputs, &ptexts, &offsets_phone, &offsets_pause);
  if (!ptexts.empty())
    *ssml_outputs = ptexts;
  else
    *ssml_outputs = ssml_inputs;
  // TODO(zhengzhang): combined ssml_input texts tn
  int offset = 0;
  for (auto it = ssml_outputs->begin(); it != ssml_outputs->end(); ++it) {
    string tmp_origin = it->text;
    if (!util::ConvertDbcToSbc(it->text, &it->text)) {
      // convert to unicode failed
      continue;
    } else {
      vector<string> origin_characters, convert_characters;
      util::SplitUtf8String(tmp_origin, &origin_characters);
      util::SplitUtf8String(it->text, &convert_characters);
      if (origin_characters.size() != convert_characters.size()) continue;
      for (size_t i = 0; i < origin_characters.size(); ++i) {
        if (origin_characters[i] != convert_characters[i]) {
          detail->tn_mappings.emplace_back(i + offset, origin_characters[i],
                                           convert_characters[i], string());
        }
      }
    }
    ParseSsmlRules(&(*it), offset, detail);
    // Given a input, run each pattern to determine if it is partial matched.
    // If so, replace the matched part with the corresponding Chinese
    // characters.
    // If more than one pattern were matched, the first match wins.

    string output_text_tmp = it->text;
    SpecialNormalize(&output_text_tmp, offset, detail);

    for (const auto& pattern_handler : pattern_handlers_) {
      if (ConformOption(pattern_handler, option)) {
        ProcessPattern(output_text_tmp, pattern_handler, &it->text, offset,
                       detail);
        output_text_tmp = it->text;
      }
    }
    PostProcess(&it->text, offset, detail);
    offset += util::utflen(it->text.c_str());
  }
  RemoveFrontPunc(ssml_outputs, 0, detail);
  if (VLOG_IS_ON(2)) tts::SsmlParser::Instance().LogSsml(*ssml_outputs);
  detail->tn_output = tts::SsmlParser::Instance().JoinText(*ssml_outputs);
  if (VLOG_IS_ON(3)) detail->Display();
  detail->Format();
  if (VLOG_IS_ON(2)) detail->Display();
  SsmlPostProcess(*detail, offsets_phone, offsets_pause, ssml_outputs);
  return true;
}

bool TextNormalizerImpl::Normalize(const vector<tts::SsmlText>& ssml_inputs,
                                   const string& option,
                                   vector<tts::SsmlText>* ssml_outputs) const {
  tts::TnDetail detail;
  return Normalize(ssml_inputs, option, ssml_outputs, &detail);
}

bool TextNormalizerImpl::Normalize(const string& input, const string& option,
                                   string* output,
                                   tts::TnDetail* detail) const {
  vector<tts::SsmlText> ssml_inputs;
  tts::SsmlParser::Instance().ParseText(input, &ssml_inputs);
  vector<tts::SsmlText> ssml_outputs;
  if (!Normalize(ssml_inputs, option, &ssml_outputs, detail)) return false;
  *output = tts::SsmlParser::Instance().JoinText(ssml_outputs);
  return true;
}

bool TextNormalizerImpl::Normalize(const string& input, const string& option,
                                   string* output) const {
  tts::TnDetail detail;
  return Normalize(input, option, output, &detail);
}

void TextNormalizerImpl::PostProcess(string* text) const {
  int offset = 0;
  tts::TnDetail detail;
  PostProcess(text, offset, &detail);
}

void TextNormalizerImpl::LoadSpecialNormalizeWords(
    const string& special_normalize) {
  tn_handlers_["remain"].reset(static_cast<BaseHandler*>(new LeafHandler()));
  vector<string> lines;
  tts::GetConfigCenterLines(special_normalize, &lines);
  for (const auto& line : lines) {
    vector<string> segs;
    SplitString(line, kSpNormSepMark, &segs);
    if (segs.size() != SpNormFormat::kSpNormAllNum) {
      LOG(WARNING) << "special normalize line invalid: " << line;
    }
    VLOG(2) << "load special normalize: " << segs[SpNormFormat::kSpNormPattern];

    string key = segs[SpNormFormat::kSpNormPattern];
    string value = segs[SpNormFormat::kSpNormReplace];
    tn_handlers_[key].reset(static_cast<BaseHandler*>(new LeafHandler(value)));

    if (tts::AllLetter(key)) {
      process_handlers_.emplace_back(new BranchHandler(
          kNonLetterFront + "(" + key + ")" + kNonLetterEnd,
          {tn_handlers_["remain"], tn_handlers_[key], tn_handlers_["remain"]},
          "1,2"));
    } else {
      process_handlers_.emplace_back(
          new BranchHandler("(" + key + ")", {tn_handlers_[key]}));
    }
  }
}

void TextNormalizerImpl::ProcessPattern(const string& input,
                                        const PatternHandler& pattern,
                                        string* output, int offset,
                                        tts::TnDetail* detail) const {
  string norm = input;
  auto regx = pattern.re2_obj.get();
  int param_num = regx->NumberOfCapturingGroups();
  VLOG(3) << "process pattern: " << regx->pattern();

  const re2::RE2::Arg* args[kMaxArgs];
  re2::StringPiece strs[kMaxArgs];
  re2::RE2::Arg args_value[kMaxArgs];

  for (int i = 0; i < kMaxArgs; ++i) {
    args_value[i] = re2::RE2::Arg(&strs[i]);
    args[i] = &args_value[i];
  }

  re2::StringPiece norm_piece(norm);
  string norm_pre;
  size_t offset_tmp = 0;
  while (norm_piece.length() > offset_tmp &&
         re2::RE2::PartialMatchN(norm_piece.data() + offset_tmp, *regx, args,
                                 param_num)) {
    VLOG(3) << "MATCHED: " << regx->pattern();
    string replace_string;
    int start = strs[0].data() - norm_piece.data();
    int body_start = strs[pattern.body.first].data() - norm_piece.data();
    int body_offset = util::utflen(norm_piece.data()) -
                      util::utflen(strs[pattern.body.first].data());
    int len = strs[param_num - 1].data() - strs[0].data() +
              strs[param_num - 1].length();
    int body_len = strs[pattern.body.second - 1].data() -
                   strs[pattern.body.first].data() +
                   strs[pattern.body.second - 1].length();
    pattern.fn(strs, param_num, trie_, &replace_string);
    int body_replace_begin = strs[pattern.body.first].data() - strs[0].data();
    int body_replace_end = strs[param_num - 1].data() +
                           strs[param_num - 1].length() -
                           strs[pattern.body.second - 1].data() -
                           strs[pattern.body.second - 1].length();
    int body_replace_len =
        replace_string.size() - body_replace_begin - body_replace_end;
    string body_replace_string =
        replace_string.substr(body_replace_begin, body_replace_len);
    norm_pre = norm;
    VLOG(3) << norm.substr(start, len) << " -> " << replace_string;
    tts::TnMapping tn_mapping_tmp(offset + body_offset,
                                  norm.substr(body_start, body_len),
                                  body_replace_string, pattern.name);
    if (replace_string.find("<MTag>") == string::npos)
      GenerateCandidates(norm.substr(body_start, body_len), pattern.choice_type,
                         &tn_mapping_tmp.candidates);
    norm.replace(start, len, replace_string);
    if (norm_pre == norm) {
      // LOG(WARNING) << "tn no change in text: " << norm;
      offset_tmp = start + len;
    }
    if (!tn_mapping_tmp.candidates.empty() || norm_pre != norm) {
      detail->tn_mappings.emplace_back(tn_mapping_tmp);
    }
    norm_piece = norm;
  }
  *output = norm;
}

bool TextNormalizerImpl::FundHandlerProcess(const string& input,
                                            const string& method,
                                            string* output) const {
  auto it_key = fund_handlers_.find(method);
  if (it_key == fund_handlers_.end()) return false;
  *output = it_key->second(input);
  return true;
}

void TextNormalizerImpl::GenerateCandidates(
    const string& input, const TnChoiceType& choice_type,
    map<string, string>* candidates) const {
  if (choice_type == TnChoiceType::kNon) return;
  vector<string> choices;
  SplitString(kTnChoiceList[choice_type], kOptionSepMark, &choices);
  mobvoi::unordered_set<string> candidate_values;
  for (const auto& choice : choices) {
    string choice_output;
    if (!FundHandlerProcess(input, choice, &choice_output)) continue;
    re2::RE2::GlobalReplace(&choice_output, blank_obj, tts::kSepMarkWord);
    if (input != choice_output &&
        candidate_values.find(choice_output) == candidate_values.end()) {
      candidate_values.insert(choice_output);
      candidates->insert(std::make_pair(choice, choice_output));
    }
  }
}

void TextNormalizerImpl::RegistPostProcess() {
  tn_handlers_["to_none"].reset(
      static_cast<BaseHandler*>(new LeafHandler(tts::kSepMarkNone)));
  tn_handlers_["to_word"].reset(
      static_cast<BaseHandler*>(new LeafHandler(tts::kSepMarkWord)));
  tn_handlers_["to_phrase"].reset(
      static_cast<BaseHandler*>(new LeafHandler(tts::kSepMarkPhrase)));
  tn_handlers_["to_sp"].reset(
      static_cast<BaseHandler*>(new LeafHandler(tts::kSepMarkSP)));
  tn_handlers_["to_lp"].reset(
      static_cast<BaseHandler*>(new LeafHandler(tts::kSepMarkLP)));
  tn_handlers_["to_sil"].reset(
      static_cast<BaseHandler*>(new LeafHandler(tts::kSepMarkSilence)));
  // process blank
  post_process_handlers_.emplace_back(new BranchHandler(
      "([a-zA-Z])(\\s+)", {tn_handlers_["remain"], tn_handlers_["to_word"]},
      "1,2"));
  post_process_handlers_.emplace_back(
      new BranchHandler("(\\s+$)", {tn_handlers_["to_none"]}));
  post_process_handlers_.emplace_back(
      new BranchHandler("(\\s+)", {tn_handlers_["to_phrase"]}));
  // normalize punc
  post_process_handlers_.emplace_back(
      new BranchHandler("(\\n|!|\\.|;|\\?|…|。)", {tn_handlers_["to_sil"]}));
  post_process_handlers_.emplace_back(new BranchHandler(
      "(﹔|,|:|\\[|\\]|_|{|}|~|–|—|〜|、)", {tn_handlers_["to_lp"]}));
  post_process_handlers_.emplace_back(new BranchHandler(
      "(\"|·|“|”|〈|〉|『|』|「|」|﹁|﹂|﹃|﹄|﹏|《|》|【|】|〔|〕|\\(|\\))",
      {tn_handlers_["to_phrase"]}));
  // remove repeat punc
  // join continues punctuation string to 1 punc, remain highest level punc
  // e.g. ^^,今天,^.. -> ,今天.
  post_process_handlers_.emplace_back(new BranchHandler(
      "([\\^,@\\.\\`]*\\.+[\\^,@\\.\\`]*)", {tn_handlers_["to_sil"]}));
  post_process_handlers_.emplace_back(
      new BranchHandler("([\\^,@\\`]*,+[\\^,@\\`]*)", {tn_handlers_["to_lp"]}));
  post_process_handlers_.emplace_back(
      new BranchHandler("([\\^,\\`]*@+[\\^,\\`]*)", {tn_handlers_["to_sp"]}));
  post_process_handlers_.emplace_back(new BranchHandler(
      "([\\`\\^]*\\^+[\\`\\^]*)", {tn_handlers_["to_phrase"]}));
  post_process_handlers_.emplace_back(
      new BranchHandler("(\\`+)", {tn_handlers_["to_word"]}));
  // remove front punc
  remove_punc_handlers_.reset(
      new BranchHandler("(^[\\^,@\\.\\`]+)", {tn_handlers_["to_none"]}));
}

// delete front and tail blank, merge continuous blank
// if text not all punctuation, return true
void TextNormalizerImpl::PostProcess(string* text, int offset,
                                     tts::TnDetail* detail) const {
  string output = *text;
  for (const auto& post_handler : post_process_handlers_) {
    output = post_handler->Process(output, offset, detail);
  }
  *text = output;
}

// TODO(zhengzhang): process ssml rules and then combine new pure texts
// TODO(zhengzhang): hide SsmlTag in the future
void TextNormalizerImpl::ParseSsmlRules(tts::SsmlText* ssml_text, int offset,
                                        tts::TnDetail* detail) const {
  VLOG(2) << "begin to process tn ssml rules";
  if (ssml_text->tag.name == tts::kSsmlSubKey) {
    auto it_attr = ssml_text->tag.attrs.find(tts::kSsmlTnSubAlias);
    if (it_attr != ssml_text->tag.attrs.end()) {
      detail->tn_mappings.emplace_back(offset, ssml_text->text, it_attr->second,
                                       tts::kSsmlTnSubAlias);
      ssml_text->text = it_attr->second;
    }
    return;
  }
  if (ssml_text->tag.name != tts::kSsmlTnKey) return;
  auto it_attr = ssml_text->tag.attrs.find(tts::kSsmlTnInterAs);
  if (it_attr == ssml_text->tag.attrs.end()) return;

  string output;
  if (!FundHandlerProcess(ssml_text->text, it_attr->second, &output)) return;

  detail->tn_mappings.emplace_back(offset, ssml_text->text, output,
                                   it_attr->second);
  ssml_text->text = output;
  // TODO(zhengzhang): process this more elegance
  ssml_text->tag.clear();
}

void TextNormalizerImpl::SpecialNormalize(string* text, int offset,
                                          tts::TnDetail* detail) const {
  string output = *text;
  for (const auto& process_handler : process_handlers_) {
    output = process_handler->Process(output, offset, detail);
  }
  *text = output;
}

// independent this function for use of gen crf corpus in pause level module
void TextNormalizerImpl::RemoveFrontPunc(vector<tts::SsmlText>* ssml_output,
                                         int offset,
                                         tts::TnDetail* detail) const {
  if (ssml_output->empty()) return;
  string output =
      remove_punc_handlers_->Process(ssml_output->at(0).text, offset, detail);
  ssml_output->at(0).text = output;
}

// judge if option is in pattern option
bool ConformOption(const PatternHandler& pattern, const string& option) {
  if (!pattern.option.empty()) {
    vector<string> domains;
    SplitString(pattern.option, kOptionSepMark, &domains);
    if (std::find(domains.begin(), domains.end(), option) == domains.end()) {
      VLOG(2) << "pass pattern: " << pattern.re2_obj->pattern()
              << " for domain: " << pattern.option;
      return false;
    }
  }
  return true;
}

}  // namespace tn
}  // namespace nlp
