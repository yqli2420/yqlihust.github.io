// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_NLP_TN_TEXT_NORMALIZER_H_
#define TTS_NLP_TN_TEXT_NORMALIZER_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "tts/nlp/tn/text_normalizer_def.h"
#include "tts/util/ssml/ssml_parser.h"
#include "tts/util/tts_util/tts_data.h"

namespace nlp {
namespace tn {

class TextNormalizerImpl;

class TextNormalizer {
 public:
  TextNormalizer(const string& language, const string& tn_resource);
  ~TextNormalizer();

  bool Normalize(const vector<tts::SsmlText>& ssml_inputs, const string& option,
                 vector<tts::SsmlText>* ssml_outputs) const;
  bool Normalize(const vector<tts::SsmlText>& ssml_inputs, const string& option,
                 vector<tts::SsmlText>* ssml_outputs,
                 tts::TnDetail* detail) const;
  bool Normalize(const string& input, const string& option,
                 string* output) const;
  bool Normalize(const string& input, const string& option, string* output,
                 tts::TnDetail* detail) const;
  void PostProcess(string* text) const;

 private:
  TextNormalizerImpl* CreateImpl(const string& language,
                                 const string& tn_resource);

  std::unique_ptr<TextNormalizerImpl> p_impl;
  DISALLOW_COPY_AND_ASSIGN(TextNormalizer);
};

}  // namespace tn
}  // namespace nlp
#endif  // TTS_NLP_TN_TEXT_NORMALIZER_H_
