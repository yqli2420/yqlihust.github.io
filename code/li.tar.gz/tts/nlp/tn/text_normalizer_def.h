// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_NLP_TN_TEXT_NORMALIZER_DEF_H_
#define TTS_NLP_TN_TEXT_NORMALIZER_DEF_H_

#include "mobvoi/base/compat.h"

namespace nlp {
namespace tn {

static const char kDomainCall[] = "public.call";
static const char kDomainStock[] = "public.stock";
static const char kDomainWeather[] = "public.weather";
static const char kDomainCalc[] = "public.calculator";
static const char kDomainConv[] = "public.conversion";
static const char kDomainWenyanAddress[] = "wenyan.address";
static const char kDomainNavigation[] = "public.navigation";

}  // namespace tn
}  // namespace nlp
#endif  // TTS_NLP_TN_TEXT_NORMALIZER_DEF_H_
