// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/nlp/tn/english_text_normalizer.h"
#include "tts/nlp/tn/common_pattern_handler.h"

#include "mobvoi/base/log.h"
#include "mobvoi/base/string_util.h"
#include "tts/util/tts_util/util.h"

namespace nlp {
namespace tn {
namespace english {

static const char* kThPostfix = "th ";
static const char* kIethPostfix = "ieth ";
static const char* kSPostfix = "s ";
static const char* kEsPostfix = "es ";
static const char* kIesPostfix = "ies ";

static const char* kNegativePron = "minus ";
static const char* kPlusPron = "plus ";
static const char* kPointPron = "point ";
static const char* kZeroPron = "zero ";
static const char* kOnePron = "one ";
static const char* kThePron = "the ";

static const char* kAndPron = "and ";
static const char* kOPron = "o ";
static const char* kPerPron = "per ";
static const char* kToPron = "to ";
static const char* kAPron = "ay ";

static const char* kDigitsPron[] = {
    "zero ", "one ", "two ",   "three ", "four ",
    "five ", "six ", "seven ", "eight ", "nine ",
};
static const char* kTwoDigitTeenPron[] = {
    "ten ",     "eleven ",  "twelve ",    "thirteen ", "fourteen ",
    "fifteen ", "sixteen ", "seventeen ", "eighteen ", "nineteen ",
};
static const char* kTwoDigitTyPron[] = {
    "",       "",       "twenty ",  "thirty ", "forty ",
    "fifty ", "sixty ", "seventy ", "eighty ", "ninety ",
};
static const char* kHundredPron = "hundred ";
static const char* kGroupsPron[] = {
    "", "thousand ", "million ", "billion ",
};

static const Symbol2Pron kSpecialNumber2Ordinal[] = {
    {"one", "first "},      {"two", "second "},   {"three", "third "},
    {"five", "fifth "},     {"eight", "eighth "}, {"nine", "ninth "},
    {"twelve", "twelfth "},
};
static const Symbol2Pron kSpecialPluralWord[] = {
    {"foot", "feet "},
};

static const Symbol2Pron kDateAbbv2Pron[] = {
    {"jan", "January"},   {"feb", "February"},    {"mar", "March"},
    {"apr", "April"},     {"jun", "June"},        {"jul", "July"},
    {"aug", "August"},    {"sep", "September"},   {"sept", "September"},
    {"oct", "October"},   {"nov", "November"},    {"dec", "December"},

    {"sun", "Sunday"},    {"mon", "Monday"},      {"tue", "Tuesday"},
    {"tues", "Tuesday"},  {"wed", "Wednesday"},   {"thu", "Thursday"},
    {"thur", "Thursday"}, {"fri", "Friday"},      {"sat", "Saturday"},

    {"i.e", "that is"},   {"e.g", "for example"}, {"etc", "and so on"},

    {"am", "AM"},
};

static const char* kNumberPron = "number ";

static const Symbol2Pron kPercent2Pron[] = {
    {"%", "percent"}, {"‰", "permill"},
};

static const char* kHalfPron = "one half ";

static const Symbol2Pron kCurrency2Pron[] = {
    {"＄", "dollar "},
    {"$", "dollar "},
    {"USD", "dollar "},
    {"GBP", "pound "},
    {"HKD", "HongKong dollar "},
    {"￥", "yuan "},
    {"¥", "yuan "},
    {"CNY", "yuan "},
    {"RMB", "yuan "},
    {"€", "euro "},
    {"￡", "euro "},
    {"£", "pound "},
    {"₩", "won "},
    {"KRW", "won "},
    {"JPY", "yen "},
};

static const Symbol2Pron kMeasure2Pron[] = {
    {"ghz", "gigahertz "}, {"mhz", "megahertz "}, {"khz", "kilohertz "},
    {"hz", "hertz "},      {"km", "kilometer "},  {"dm", "decimeter "},
    {"cm", "centimeter "}, {"mm", "millimeter "}, {"nm", "nanometer "},
    {"m", "meter "},       {"gb", "gigabyte "},   {"G", "G "},
    {"mb", "megabyte "},   {"M", "M "},           {"kb", "kilobyte "},
    {"lb", "pound "},      {"K", "K "},           {"b", "B "},
    {"B", "B "},           {"kg", "kilogram "},   {"g", "gram "},
    {"h", "hour "},        {"H", "hour "},        {"s", "second "},
    {"S", "S "},           {"yd", "yard "},       {"ft", "foot "},
    {"ml", "milliliter "}, {"gal", "gallon "},    {"pkg", "package "},
};

static const Symbol2Pron kMonth2Pron[] = {
    {"1", "January "},  {"2", "February "},  {"3", "March "},
    {"4", "April "},    {"5", "May "},       {"6", "June "},
    {"7", "July "},     {"8", "August "},    {"9", "September "},
    {"10", "October "}, {"11", "November "}, {"12", "December "},
};

static const string kTelSepPron = string() + kSepMarkLP + " ";  // NOLINT

static const char* kDegreePron = "degree";
static const Symbol2Pron kTemperature2Pron[] = {
    {"°F", "fahrenheit "},
};

static const char* kOClockPron = "o'clock ";
static const char* kOhPron = "oh ";
static const char* kSecondPron = "second ";

static const Symbol2Pron kMeasurePunc2Pron[] = {
    {"/", "per "}, {"-", "to "},
};

static const Symbol2Pron kSymbol2Pron[] = {
    {"+", "plus "},
    {"-", " "},
    {"‘", "'"},
    {"’", "'"},
    {">", "greater than "},
    {"<", " less than "},
    {"=", "equal "},
    {"㎡", "square meters "},
    {"/", " per "},
    {"→", "to "},
};

// common methods
// Append s into last word back: eighty -> eighties
static void AppendS(string* word) {
  mobvoi::TrimString(*word, " ", word);
  if (word->back() == 'y') {
    word->pop_back();
    word->append(kIesPostfix);
  } else if (word->back() == 'x' || word->back() == 's') {
    word->append(kEsPostfix);
  } else {
    word->append(kSPostfix);
  }
}

// Get plural type of measure words
static void GetPlural(string* word) {
  mobvoi::TrimString(*word, " ", word);
  string plural = GetPronFromSymbol(*word, kSpecialPluralWord,
                                    arraysize(kSpecialPluralWord));
  if (plural.empty()) {
    AppendS(word);
  } else {
    *word = plural;
  }
}

// convert number to ordinal number: one -> first
// special use a list to convert
static void Number2Ordinal(string* number) {
  string ordinal = GetPronFromSymbol(*number, kSpecialNumber2Ordinal,
                                     arraysize(kSpecialNumber2Ordinal));
  if (ordinal.empty()) {
    if (number->back() == 'y') {
      number->pop_back();
      ordinal = *number + kIethPostfix;
    } else {
      ordinal = *number + kThPostfix;
    }
  }
  *number = ordinal;
}

// read as value first
// convert last word to ordinal reading
static string ReadAsOrdinal(const string& input) {
  string pron;
  ReadAsValue(input, &pron);
  vector<string> segs;
  SplitString(pron, ' ', &segs);
  Number2Ordinal(&segs.back());
  pron = JoinVector(segs, ' ');
  return pron;
}

// read number of two by two
// 10xx 20xx read as value
// xx00 read as xx hundred
// xx0x read as xx o x
// number more than 4 read as digit, less than 2 read as value
static string ReadAsYear(const string& input) {
  string pron;
  if (input.size() <= 2) {
    ReadAsValue(input, &pron);
  } else if (input.size() > 4) {
    pron = ReadAsDigit(input);
  } else {
    string first = input.substr(0, input.size() - 2);
    string second = input.substr(input.size() - 2, 2);
    int value1 = StringToInt(first);
    int value2 = StringToInt(second);
    if (value1 % 10 == 0) {
      ReadAsValue(input, &pron);
    } else if (value2 == 0) {
      ReadAsValue(first, &pron);
      pron.append(kHundredPron);
    } else if (value2 < 10) {
      ReadAsValue(first, &pron);
      pron.append(kOPron);
      ReadAsValue(second, &pron);
    } else {
      ReadAsValue(first, &pron);
      ReadAsValue(second, &pron);
    }
  }
  return pron;
}

// Gen pron for a number string
// read sign
// normalize to contain only 0~9 and '.'
// begin or end is '.' pron as point
// return true if is plural
static bool GetPronForNumString(const string& number, string* pron) {
  bool is_plural = false;
  if (number.empty()) return is_plural;
  if (number[0] == '-') pron->append(kNegativePron);
  string number_norm = NormalizeNumString(number);
  vector<string> segs;
  SplitString(number_norm, '.', &segs);
  if (segs.size() == 0) return is_plural;
  if (number_norm[0] == '.') pron->append(kPointPron);
  // more than 1 '.', read seperate as value
  if (segs.size() > 2) {
    for (size_t i = 0; i < segs.size() - 1; ++i) {
      ReadAsValue(segs[i], pron);
      pron->append(kPointPron);
    }
    ReadAsValue(segs.back(), pron);
  } else {
    // interger part
    is_plural = ReadAsValue(segs[0], pron);
    if (segs.size() == 2) {
      pron->append(kPointPron);
      // fraction part
      pron->append(ReadAsDigit(segs[1]));
      is_plural = true;
    }
  }
  if (number_norm.back() == '.') pron->append(kPointPron);
  return is_plural;
}

// read a number string contain 0~9 support a-z
// rule: digits read as one by one, return empty if input empty
// a-z as A-Z
// + as plus
string ReadAsDigit(const string& input) {
  string pron;
  string upper_input = tts::ToUpper(input);
  for (size_t i = 0; i < upper_input.size(); ++i) {
    if (upper_input[i] == '+') {  // +
      pron.append(kPlusPron);
      continue;
    }
    // a-z
    if (upper_input[i] >= 'A' && upper_input[i] <= 'Z') {
      if (upper_input[i] == 'A') {
        pron.append(kAPron);
      } else {
        pron.append(upper_input.substr(i, 1) + " ");
      }
      continue;
    }
    if (upper_input[i] < '0' || upper_input[i] > '9') continue;
    int value = upper_input[i] - '0';
    pron.append(kDigitsPron[value]);
  }
  return pron;
}

// read a number string contain 0~9
// return true if value is plural
string ReadAsValue(const string& input) {
  string output;
  ReadAsValue(input, &output);
  return output;
}
bool ReadAsValue(const string& input, string* pron) {
  string input_tmp = input;
  static re2::RE2 nonnumber_obj("\\D");
  re2::RE2::GlobalReplace(&input_tmp, nonnumber_obj, "");
  // trim front 0s
  size_t nonzero_offset = input_tmp.find_first_not_of("0");
  if (nonzero_offset == string::npos) {
    pron->append(kZeroPron);
    return true;
  }
  string trim_zero = input_tmp.substr(nonzero_offset);
  size_t length = trim_zero.size();
  if (length > kNumberMaxLength) {
    pron->append(ReadAsDigit(trim_zero));
    return true;
  }
  int group_num = 0;
  bool need_and = false;
  for (size_t i = 0; i < length; ++i) {
    int position = length - i - 1;
    int digit = trim_zero[i] - '0';
    int unit = position % kEnglishGroupNumber;
    int group = position / kEnglishGroupNumber;
    group_num = digit * 10 + group_num;

    if (digit != 0) {
      // append and
      if (need_and && (unit == 1 || unit == 0)) {
        pron->append(kAndPron);
        need_and = false;
      }
      if (unit == 1) {  // tens digit
        if (digit == 1) {
          ++i;
          position = length - i - 1;
          digit = trim_zero[i] - '0';
          unit = position % kEnglishGroupNumber;
          group = position / kEnglishGroupNumber;
          group_num = digit * 10 + group_num;
          pron->append(kTwoDigitTeenPron[digit]);
        } else {
          pron->append(kTwoDigitTyPron[digit]);
        }
      } else if (unit == 2) {  // hundreds digit
        pron->append(kDigitsPron[digit]);
        pron->append(kHundredPron);
      } else {
        pron->append(kDigitsPron[digit]);
      }
    }
    if (unit == 2) need_and = true;
    if (unit == 0) {
      if (group_num != 0) {
        pron->append(kGroupsPron[group]);
      }
      group_num = 0;
      need_and = false;  // TODO(zhengzhang): fix need and: 2025025
    }
  }  // End core loop
  if (*pron == kOnePron) return false;
  return true;
}

// month / day
string ReadAsDate(const string& input) {
  string output;
  static re2::RE2 month_day_pattern("(0?[1-9]|1[0-2])/(0?[1-9]|[12]\\d|3[01])");
  if (re2::RE2::FullMatch(input, month_day_pattern)) {
    vector<string> segs;
    SplitString(input, '/', &segs);
    string month = segs[0];
    string day = segs[1];
    output += GetPronFromSymbol(month, kMonth2Pron, arraysize(kMonth2Pron));
    output += kThePron + ReadAsOrdinal(day);
  } else {
    output = input;
  }
  return output;
}

string ReadAsTelephone(const string& input) {
  vector<string> segs;
  vector<bool> is_digit;
  mandarin::SplitStringByNumber(input, &segs, &is_digit);

  string output = kTelSepPron;
  for (size_t i = 0; i < segs.size(); ++i) {
    if (!is_digit[i]) {
      if (segs[i] == " " || segs[i] == "-") {
        output += kTelSepPron;
      } else {
        output += segs[i];
      }
      continue;
    }
    output += ReadAsDigit(segs[i]);
  }
  output += kTelSepPron;
  return output;
}

// Number handler
// Percentage 17%: boundary number %
void PercentHandler(const re2::StringPiece* str_args, int args_num,
                    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                    string* output) {
  VLOG(2) << "Process percentage ...";
  string pron;
  GetPronForNumString(str_args[1].as_string(), &pron);
  pron.append(GetPronFromSymbol(str_args[2].as_string(), kPercent2Pron,
                                arraysize(kPercent2Pron)));
  *output = str_args[0].as_string() + pron;
}

// ordinal number: 1st 101st
// boundary number_with_abbv boundary
void OrdinalAbbvHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process ordinal abbreviation ...";
  string pron = ReadAsOrdinal(NormalizeNumString(str_args[1].as_string()));
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}

// number + s: 1990s
// boundary number_with_s boundary
void NumberSHandler(const re2::StringPiece* str_args, int args_num,
                    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                    string* output) {
  VLOG(2) << "Process number s ...";
  string pron = ReadAsYear(NormalizeNumString(str_args[1].as_string()));
  vector<string> segs;
  SplitString(pron, ' ', &segs);
  AppendS(&segs.back());
  pron = JoinVector(segs, ' ');
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}

// @
void AtHandler(const re2::StringPiece* str_args, int args_num,
               const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
               string* output) {
  VLOG(2) << "Process @ ...";
  *output = kAtPron;
}

// currency
// boundary unit number unit boundary
void CurrencyHandler(const re2::StringPiece* str_args, int args_num,
                     const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                     string* output) {
  VLOG(2) << "Process currency ...";
  string pron;
  GetPronForNumString(str_args[2].as_string(), &pron);
  string symbol =
      str_args[1].empty() ? str_args[3].as_string() : str_args[1].as_string();
  pron.append(
      GetPronFromSymbol(symbol, kCurrency2Pron, arraysize(kCurrency2Pron)));
  *output = str_args[0].as_string() + pron + str_args[4].as_string();
}

// measure
// boundary number space unit per unit boundary
void MeasureHandler(const re2::StringPiece* str_args, int args_num,
                    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                    string* output) {
  VLOG(2) << "Process measure pattern ...";
  string pron;
  string num = str_args[1].as_string();
  string unit1 = str_args[3].as_string();
  string unit2 = str_args[5].as_string();
  bool is_plural = GetPronForNumString(num, &pron);
  unit1 = (unit1.size() == 1) ? unit1 : tts::ToLower(unit1);
  unit1 = GetPronFromSymbol(unit1, kMeasure2Pron, arraysize(kMeasure2Pron));
  if (is_plural) GetPlural(&unit1);
  pron.append(unit1);
  if (!str_args[4].empty()) pron.append(kPerPron);
  if (!unit2.empty()) {
    unit2 = (unit2.size() == 1) ? unit2 : tts::ToLower(unit2);
    pron.append(
        GetPronFromSymbol(unit2, kMeasure2Pron, arraysize(kMeasure2Pron)));
  }
  *output = str_args[0].as_string() + pron + str_args[6].as_string();
}

// Comma Number type:
// boundary number boundary
void CommaNumberHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process comma number pattern ...";
  string number = str_args[1].as_string();
  static re2::RE2 comma_obj(",");
  re2::RE2::GlobalReplace(&number, comma_obj, "");
  string pron;
  GetPronForNumString(number, &pron);
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}

// Date
// boundary month sep day sep year boundary
void DateHandler(const re2::StringPiece* str_args, int args_num,
                 const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                 string* output) {
  VLOG(2) << "Process date pattern ...";
  string pron;
  const string& month = str_args[1].as_string();
  const string& day = str_args[3].as_string();
  const string& year = str_args[5].as_string();
  if (!month.empty()) {
    pron.append(GetPronFromSymbol(month, kMonth2Pron, arraysize(kMonth2Pron)));
  }
  if (!day.empty()) {
    pron.append(kThePron);
    pron.append(ReadAsOrdinal(day));
  }
  if (!year.empty()) {
    pron.append(ReadAsYear(year));
  }
  *output = str_args[0].as_string() + pron + str_args[6].as_string();
}

// on 7/12
// keyword month / day boundary
void MonthDayHandler(const re2::StringPiece* str_args, int args_num,
                     const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                     string* output) {
  VLOG(2) << "Process month day pattern ...";
  string month = str_args[1].as_string();
  string day = str_args[3].as_string();
  string pron = GetPronFromSymbol(month, kMonth2Pron, arraysize(kMonth2Pron));
  pron += kThePron;
  pron += ReadAsOrdinal(day);
  *output = str_args[0].as_string() + pron + str_args[4].as_string();
}

// 4 number Year: in 1998
// in year boundary
void YearHandler(const re2::StringPiece* str_args, int args_num,
                 const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                 string* output) {
  VLOG(2) << "Process year ...";
  string pron = ReadAsYear(str_args[1].as_string());
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}

// Phone number:
// boundary preword tel (sep tel)pair postword boundary
void TelHandler(const re2::StringPiece* str_args, int args_num,
                const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                string* output) {
  VLOG(2) << "Process telephone number ...";
  string pron = kTelSepPron;
  for (int i = 2; i < args_num - 2; i += 2) {
    string pron_tmp = ReadAsDigit(str_args[i].as_string());
    if (!pron_tmp.empty()) pron.append(pron_tmp + kTelSepPron);
  }
  *output = str_args[0].as_string() + str_args[1].as_string() + pron +
            str_args[args_num - 2].as_string() +
            str_args[args_num - 1].as_string();
}

// Temperature:
// boundary number space unit
void TemperatureHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process temperature ...";
  string pron;
  bool is_plural = GetPronForNumString(str_args[1].as_string(), &pron);
  string unit = kDegreePron;
  if (is_plural) GetPlural(&unit);
  pron.append(unit);
  pron.append(str_args[2].as_string());
  pron.append(GetPronFromSymbol(str_args[3].as_string(), kTemperature2Pron,
                                arraysize(kTemperature2Pron)));
  *output = str_args[0].as_string() + pron;
}

// Time:
// boundary hour sep min sep sec sep boundary
void TimeHandler(const re2::StringPiece* str_args, int args_num,
                 const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                 string* output) {
  VLOG(2) << "Process time pattern ...";
  string pron;
  string hour = str_args[1].as_string();
  string minute = str_args[3].as_string();
  string second = str_args[5].as_string();
  // Handle hour
  ReadAsValue(hour, &pron);
  // Handle minute and second
  string minute_pron;
  ReadAsValue(minute, &minute_pron);
  string second_pron;
  string second_unit;
  bool is_plural = false;
  if (!second.empty()) is_plural = ReadAsValue(second, &second_pron);
  if (minute_pron == kZeroPron &&
      (second_pron.empty() || second_pron == kZeroPron)) {
    pron.append(kOClockPron);
  } else {
    if (minute.size() == 1 || minute[0] == '0') pron.append(kOhPron);
    pron.append(minute_pron);
    if (second_pron != kZeroPron && !second_pron.empty()) {
      pron.append(second_pron);
      second_unit = kSecondPron;
      if (is_plural) GetPlural(&second_unit);
      pron.append(second_unit);
    }
  }
  *output = str_args[0].as_string() + pron + str_args[7].as_string();
}

// Fraction: 1/2 2/3
// boundary number / number boundary
void FractionHandler(const re2::StringPiece* str_args, int args_num,
                     const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                     string* output) {
  VLOG(2) << "Process fraction pattern ...";
  string pron;
  string num1 = str_args[1].as_string();
  string num2 = str_args[3].as_string();
  if (num1 == "1" && num2 == "2") {
    pron = kHalfPron;
  } else {
    bool is_plural = ReadAsValue(num1, &pron);
    string denominator = ReadAsOrdinal(num2);
    if (is_plural) GetPlural(&denominator);
    pron.append(denominator);
  }
  *output = str_args[0].as_string() + pron + str_args[4].as_string();
}

// Per: meter / hour,  2 degree - 3 degree
// boundary measure space /
void MeasurePuncHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process measure punctuation pattern ...";
  string pron = GetPronFromSymbol(str_args[3].as_string(), kMeasurePunc2Pron,
                                  arraysize(kMeasurePunc2Pron));
  *output = str_args[0].as_string() + str_args[1].as_string() +
            str_args[2].as_string() + pron;
}

// Serial: MU7089 G65 730Li
// boundary serial boundary
void SerialHandler(const re2::StringPiece* str_args, int args_num,
                   const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                   string* output) {
  VLOG(2) << "Process serial pattern ...";
  string pron = ReadAsDigit(str_args[1].as_string());
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}

// Number to: -13~14
// boundary number - number boundary
void NumberToHandler(const re2::StringPiece* str_args, int args_num,
                     const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                     string* output) {
  VLOG(2) << "Process number to pattern ...";
  static re2::RE2 year_pattern_obj(kYearPattern);
  string pron;
  string num1 = str_args[1].as_string();
  string num2 = str_args[3].as_string();
  if (re2::RE2::FullMatch(num1, year_pattern_obj) &&
      re2::RE2::FullMatch(num2, year_pattern_obj)) {
    pron.append(ReadAsYear(num1));
    pron.append(kToPron);
    pron.append(ReadAsYear(num2));
  } else {
    GetPronForNumString(num1, &pron);
    pron.append(kToPron);
    GetPronForNumString(num2, &pron);
  }
  *output = str_args[0].as_string() + pron + str_args[4].as_string();
}

// abbreviation Mar, Oct.
// boundary abbv point boundary
void AbbreviationHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process abbreviation pattern ...";
  string pron = GetPronFromSymbol(tts::ToLower(str_args[1].as_string()),
                                  kDateAbbv2Pron, arraysize(kDateAbbv2Pron));
  *output = str_args[0].as_string() + pron + str_args[3].as_string();
}

// No. pattern: no.3
// boundary no number boundary
void NoHandler(const re2::StringPiece* str_args, int args_num,
               const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
               string* output) {
  VLOG(2) << "Process no pattern ...";
  string pron = kNumberPron;
  if (str_args[3].empty()) {
    pron += str_args[2].as_string();
  } else {
    ReadAsValue(str_args[2].as_string(), &pron);
  }
  *output = str_args[0].as_string() + pron + str_args[3].as_string();
}

// default pattern
// rules: float or signed number read as value
// 0x read as digit, xx or xxx read as value other read as digit
void DefaultNumberHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process default number ...";
  string pron;
  string number = str_args[1].as_string();
  if (number.find_first_of(".") != string::npos || number[0] == '-') {  // float
    GetPronForNumString(number, &pron);
  } else {  // int
    if (number[0] == '0') {
      pron.append(ReadAsDigit(number));
    } else {
      ReadAsValue(number, &pron);
    }
  }
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}

// default symbols
void SymbolsHandler(const re2::StringPiece* str_args, int args_num,
                    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                    string* output) {
  VLOG(2) << "Process symbols ...";
  string pron;
  pron.append(GetPronFromSymbol(str_args[0].as_string(), kSymbol2Pron,
                                arraysize(kSymbol2Pron)));
  *output = pron;
}

// merge continues space
// space
void ContinuesSpaceHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process space pattern ...";
  *output = " ";
}

// post process: delete front space, and space before a comma
// space
void PostProcessHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process post process pattern ...";
  static re2::RE2 post_obj(" ");
  string pron = str_args[0].as_string();
  re2::RE2::GlobalReplace(&pron, post_obj, "");
  *output = pron;
}

}  // namespace english
}  // namespace tn
}  // namespace nlp
