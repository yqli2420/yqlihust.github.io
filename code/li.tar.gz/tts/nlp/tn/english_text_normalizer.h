// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_NLP_TN_ENGLISH_TEXT_NORMALIZER_H_
#define TTS_NLP_TN_ENGLISH_TEXT_NORMALIZER_H_

#include "tts/nlp/tn/common_pattern_handler.h"
#include "tts/nlp/tn/text_normalizer_util.h"
#include "tts/util/tts_util/util.h"

namespace nlp {
namespace tn {
namespace english {

static const size_t kEnglishGroupNumber = 3;
static const size_t kNumberMaxLength = 12;

// common pattern
static const char* kSpacePattern = "(\\s?)";
static const char* kPointPattern = "(\\.)";
static const char* kSlashPattern = "(/)";
static const char* kHyphenPattern = "(-)";
static const char* kNumberFrontBd = "(^|[^\\d.])";
static const char* kNumberEndBd = "($|[^\\d.])";
static const char* kWordFrontBd = "(^|\\W)";
static const char* kWordEndBd = "($|\\W)";
static const char* kFloatPattern = "( ?\\d+(?:\\.\\d+)?)";
static const char* kSignedFloatPattern = "(-?\\d+(?:\\.\\d+)?)";
static const char* kSerialPattern = "(\\w*(?:\\d[a-zA-Z]|[a-zA-Z]\\d)\\w*)";

// TODO(zheng zhang): Sun may confuse with word sun,
// TODO(zheng zhang): SAT may confuse with abbv sat,
static const char* kDateAbbvPattern =
    "(Mon|mon|MON|Tue|tue|TUE|Tues|tues|TUES|Wed|wed|WED"
    "|Thu|thu|THU|Thur|thur|THUR|Fri|fri|FRI|Sat|sat"
    "|Jan|jan|JAN|Feb|feb|FEB|Mar|mar|MAR"
    "|Jun|jun|JUN|Jnl|jnl|JNL|Aug|aug|AUG"
    "|Sep|sep|SEP|Sept|sept|SEPT|Oct|oct|OCT"
    "|Nov|nov|NOV|Dec|dec|DEC"
    "|i\\.e|e\\.g|etc|AM)(\\.?)";
static const string kSpecialAbbvPattern = string() +  // NOLINT
                                          "(^|\\W)" + kDateAbbvPattern +
                                          "(\\.?(?:$|\\W))";

static const string kNoPattern = string() +  // NOLINT
                                 "(^|\\W)([Nn][Oo]\\.)(\\d+)" + kNumberEndBd;
static const string kNoPattern2 = string() +  // NOLINT
                                  "(^|\\s)(No\\.)(\\s|$)()";

// number part
// percent
static const char* kPercentFrontBd = "(^|[^\\d.%‰])";
static const string kPercentPattern = string() +  // NOLINT
                                      kPercentFrontBd + kSignedFloatPattern +
                                      "([%‰])";

// ordinal pattern
static const char* kOrdinalAbbvPattern =
    "(1st|2nd|3rd|[04-9]th"  // single number
    "|\\d{0,9}[02-9](?:1st|2nd|3rd)|\\d{0,9}(?:1[1-3]|\\d[04-9])th)";
static const string kOrdinalPattern = string() +  // NOLINT
                                      kNumberFrontBd + kOrdinalAbbvPattern +
                                      kWordEndBd;

// fraction
static const string kFractionPattern = string() +  // NOLINT
                                       kNumberFrontBd + "(\\d+)(/)(\\d+)" +
                                       kNumberEndBd;

// number + s pattern
static const string kNumberSPattern = string() +  // NOLINT
                                      kNumberFrontBd + "(\\d+'?[s|S])" +
                                      kWordEndBd;

static const char kAtPron[] = " at ";
static const string kAtPattern = "(@)";

// currency pattern
static const char* kCurrencyUnits = "([$＄¥￥€£￡₩])";
static const char* kCurrencyUnitsString = "(HKD|JPY|CNY|RMB|USD|GBP|KRW)";
static const string kCurrencyPattern = string() +  // NOLINT
                                       "()" + kCurrencyUnits + kFloatPattern +
                                       "()" + kWordEndBd;
static const string kCurrencyString1Pattern =
    string() +  // NOLINT
    kWordFrontBd + kCurrencyUnitsString + kFloatPattern + "()" + kWordEndBd;
static const string kCurrencyString2Pattern =
    string() +  // NOLINT
    kWordFrontBd + "()" + kFloatPattern + kCurrencyUnitsString + kWordEndBd;

// measure
static const char* kMeasureAbbv =
    "([gG][hH]z|[mM][hH]z|[kK][hH]z|[hH]z"           // freqency
    "|[kK][mM]|[dD][mM]|[cC][mM]|[mM][mM]|[nN][mM]"  // distance
    "|[gG][bB]|[mM][bB]|[kK][bB]"                    // memory
    "|[kK][gG]|lb"                                   // weight
    "|yd|ft"                                         // area
    "|ml|gal|pkg"                                    // volume
    "|g|G|m|M|K|[sS]|[hH]|[bB])";                    // single measure
static const string kMeasureAbbvPattern = string() + kWordFrontBd +  // NOLINT
                                          kFloatPattern + kSpacePattern +
                                          kMeasureAbbv + "()()($|[^A-Za-z])";
static const string kMeasureCombAbbvPattern =
    string() + kWordFrontBd +  // NOLINT
    kFloatPattern + kSpacePattern + kMeasureAbbv + "(/)" + kMeasureAbbv +
    "($|[^A-Za-z])";

// comma number
static const string kCommaNumberPattern =
    string() +  // NOLINT
    kNumberFrontBd + "(-?\\d{1,3}(?:,\\d{3}){1,}(?:\\.\\d+)?)" + kNumberEndBd;

// date pattern
static const char* kDateSeperate = "([.\\-/])";
static const char* kYearPattern = "(1[6-9]\\d{2}|2[0-4]\\d{2})";
static const char* kMonthPattern = "(0?[1-9]|1[0-2])";
static const char* kMonthStrictPattern = "(0[1-9])";
static const char* kDayPattern = "(0?[1-9]|[12]\\d|3[01])";
static const char* kDayStrictPattern = "(0[1-9]|[12]\\d|3[01])";
static const char* kDateFrontBd = "(^[./\\-]?|\\D[./\\-]|[^\\d./\\-])";
static const char* kDateEndBd = "([./\\-]?$|[./\\-][^\\d]|[^\\d./\\-])";
static const char* kYearKeyWord = "(in |year )";
static const string kYearMonthDayPointPattern =
    string() +  // NOLINT
    kDateFrontBd + kMonthPattern + kPointPattern + kDayPattern + kPointPattern +
    kYearPattern + kDateEndBd;
static const string kYearMonthDaySlashPattern =
    string() +  // NOLINT
    kDateFrontBd + kMonthPattern + kSlashPattern + kDayPattern + kSlashPattern +
    kYearPattern + kDateEndBd;
static const string kYearMonthDayHyphenPattern =
    string() +  // NOLINT
    kDateFrontBd + kMonthPattern + kHyphenPattern + kDayPattern +
    kHyphenPattern + kYearPattern + kDateEndBd;
static const string kMonthDayPattern = string() +  // NOLINT
                                       kDateFrontBd + "()()" +
                                       kMonthStrictPattern + kDateSeperate +
                                       kDayStrictPattern + kDateEndBd;
static const string kYearStrictPattern = string() +  // NOLINT
                                         kYearKeyWord + kYearPattern +
                                         kNumberEndBd;
static const char kDateFractionKWPre[] = "(on )";
static const string kDateFractionPattern = string() +  // NOLINT
                                           kDateFractionKWPre + kMonthPattern +
                                           "(/)" + kDayPattern + kNumberEndBd;

// telephone pattern
static const char* kTelSeperate = "([\\- ]?)";
static const char* kCountryCode = "((?:\\(?\\+?8\\d\\)?)?)";
static const char* kAreaCode = "((?:\\(?(?:\\d{3}|0\\d{3})\\)?))";
static const char* kMobileHead = "(1[3578]\\d)";
static const char* kTelFrontBd = "(^|\\D\\s|[^\\d.\\-])";
static const char* kTelEndBd = "($|\\s\\D|[^\\d\\-])";
static const char* kTelKeyWord = "(telephone |number |phone |call |tel )";
static const string kTelPattern1 =
    string() +  // NOLINT
    kTelFrontBd + "()" + kCountryCode + kTelSeperate + kAreaCode +
    kTelSeperate + "(\\d{4})" + kTelSeperate + "(\\d{4})" + "()" + kTelEndBd;
static const string kTelPattern2 =
    string() +  // NOLINT
    kTelFrontBd + "()" + kCountryCode + kTelSeperate + kAreaCode +
    kTelSeperate + "([1-9]\\d{2})" + kTelSeperate + "(\\d{4})()" + kTelEndBd;
static const string kMobilePattern =
    string() +  // NOLINT
    kTelFrontBd + "()" + kCountryCode + kTelSeperate + kMobileHead +
    kTelSeperate + "(\\d{4})" + kTelSeperate + "(\\d{4})" + "()" + kTelEndBd;
static const string kStrongSpecialTelPattern1 =
    string() + kTelFrontBd +  // NOLINT
    "()(400\\d)" + kTelSeperate + "(\\d{3})" + kTelSeperate + "(\\d{3})()" +
    kTelEndBd;
static const string kStrongSpecialTelPattern2 =
    string() + kTelFrontBd +  // NOLINT
    "()(400)" + kTelSeperate + "(\\d{3})" + kTelSeperate + "(\\d{4})()" +
    kTelEndBd;
static const string kStrongSpecialTelPattern3 =
    string() +  // NOLINT
    kTelFrontBd + "()(955\\d{2}|12306|10086|10010)()()()()()" + kTelEndBd;
static const char* kWeakSpecialTel = "(110|119|120|114|911)()()()()";
static const char* kDefaultTelPattern =
    "(^|[^\\-*/=<>])()(\\d{2,})(-)(\\d{2,})(-)(\\d{2,})()($|[^+\\-*/=<>])";
static const string kWeakSpecialTelPattern1 =
    string() + kTelKeyWord + "(\\D{0,3})" + kWeakSpecialTel + "()" + kTelEndBd;
static const string kWeakSpecialTelPattern2 = string() + kTelFrontBd + "()" +
                                              kWeakSpecialTel + "(\\D{0,3})" +
                                              kTelKeyWord;

// temperature
static const char* kTemperatureSign = "(℃|°C|°F|℉|°)";
static const string kTemperaturePattern = string() +  // NOLINT
                                          kNumberFrontBd + kSignedFloatPattern +
                                          kSpacePattern + kTemperatureSign;

// time
static const char* kTimeSeperate = "(:)";
static const char* kHourPattern = "(0?\\d|1\\d|2[0-3])";
static const char* kMinSecPattern = "([0-5]\\d)";
static const char* kTimeFrontBd = "(^|[^\\d.:])";
static const char* kTimeEndBd = "($|[^\\d.:])";
static const string kTimeFullPattern =
    string() + kTimeFrontBd + kHourPattern +  // NOLINT
    kTimeSeperate + kMinSecPattern + kTimeSeperate + kMinSecPattern + "()" +
    kTimeEndBd;
static const string kTimePartPattern =
    string() + kTimeFrontBd + kHourPattern +  // NOLINT
    kTimeSeperate + kMinSecPattern + "()()()" + kTimeEndBd;

// measure punctuation
static const char* kCombMeasureWord =
    "(meters?|kilometers?|seconds?|minutes?|hours?|days?|degrees?)";
static const char* kMeasurePunc = "([/\\-])";
static const string kMeasurePuncPattern = string() +  // NOLINT
                                          kWordFrontBd + kCombMeasureWord +
                                          kSpacePattern + kMeasurePunc;

// serial number
static const string kSerialNumPattern = string() +  // NOLINT
                                        kWordFrontBd + kSerialPattern +
                                        kWordEndBd;

// to pattern
static const char* kToSymbol = "(\\s?[～~\\-]\\s?)";
static const string kNumberToPattern = string() +  // NOLINT
                                       kNumberFrontBd + kSignedFloatPattern +
                                       kToSymbol + kSignedFloatPattern +
                                       kNumberEndBd;

// default
static const string kSignedNumberPattern = string() +  // NOLINT
                                           kNumberFrontBd + "(-?[\\d.]*\\d+)" +
                                           "($|[^\\d])";

static const char* kSymbolPattern = "([+<>=㎡→‘’]|->)";

static const char* kContinuesSpacePattern = "( {2,})";

static const char* kPostProcessPattern = "((?:^\\s)|(?:\\s,))";

// common function
string ReadAsDigit(const string& input);
string ReadAsValue(const string& input);
string ReadAsDate(const string& input);
string ReadAsTelephone(const string& input);
bool ReadAsValue(const string& input, string* pron);
void AbbreviationHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void NoHandler(const re2::StringPiece* str_args, int args_num,
               const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
               string* output);
void PercentHandler(const re2::StringPiece* str_args, int args_num,
                    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                    string* output);
void OrdinalAbbvHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void NumberSHandler(const re2::StringPiece* str_args, int args_num,
                    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                    string* output);
void AtHandler(const re2::StringPiece* str_args, int args_num,
               const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
               string* output);
void CurrencyHandler(const re2::StringPiece* str_args, int args_num,
                     const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                     string* output);
void MeasureHandler(const re2::StringPiece* str_args, int args_num,
                    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                    string* output);
void CommaNumberHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void DateHandler(const re2::StringPiece* str_args, int args_num,
                 const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                 string* output);
void MonthDayHandler(const re2::StringPiece* str_args, int args_num,
                     const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                     string* output);
void TelHandler(const re2::StringPiece* str_args, int args_num,
                const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                string* output);
void YearHandler(const re2::StringPiece* str_args, int args_num,
                 const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                 string* output);
void TemperatureHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void TimeHandler(const re2::StringPiece* str_args, int args_num,
                 const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                 string* output);
void FractionHandler(const re2::StringPiece* str_args, int args_num,
                     const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                     string* output);
void SerialHandler(const re2::StringPiece* str_args, int args_num,
                   const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                   string* output);
void NumberToHandler(const re2::StringPiece* str_args, int args_num,
                     const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                     string* output);
void MeasurePuncHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void DefaultNumberHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void SymbolsHandler(const re2::StringPiece* str_args, int args_num,
                    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                    string* output);
void ContinuesSpaceHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void PostProcessHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);

static const PatternHandler kEnglishPatternHandlers[] = {
    // special regex pattern
    {kSpecialAbbvPattern, AbbreviationHandler},
    {kNoPattern, NoHandler},
    {kNoPattern2, NoHandler},
    {kPercentPattern, PercentHandler},      // 20,1%, 45.6%, 45%, 10‰
    {kOrdinalPattern, OrdinalAbbvHandler},  // 1st 12th
    {kNumberSPattern, NumberSHandler},      // 60s 60's 1990s 2000's

    {kAtPattern, AtHandler},  // @you

    {kCurrencyPattern, CurrencyHandler},         // ￥1.4 ￥28
    {kCurrencyString1Pattern, CurrencyHandler},  // RMB1.4 RMB28
    {kCurrencyString2Pattern, CurrencyHandler},  // 1.4USD 28USD

    {kMeasureCombAbbvPattern, MeasureHandler},  // 1.4m/s 28m/kg
    {kMeasureAbbvPattern, MeasureHandler},      // 1.4kg 28MB
    {kCommaNumberPattern, CommaNumberHandler},  // 13,000,000

    // date
    {kYearMonthDayPointPattern, DateHandler},   // 03.12.2015
    {kYearMonthDaySlashPattern, DateHandler},   // 03/12/2015
    {kYearMonthDayHyphenPattern, DateHandler},  // 03-12-2015
    {kMonthDayPattern, DateHandler},            // 07-03
    {kDateFractionPattern, MonthDayHandler},    // on 7/3

    // Telephone
    {kTelPattern1, TelHandler},    // +86 010 8231 2343
    {kTelPattern2, TelHandler},    // +86 0721 831 2343
    {kMobilePattern, TelHandler},  // +86 010 8231 2343

    {kStrongSpecialTelPattern1, TelHandler},  // 400-811-9090
    {kStrongSpecialTelPattern2, TelHandler},  // 4008-811-090
    {kStrongSpecialTelPattern3, TelHandler},  // 95592
    {kWeakSpecialTelPattern1, TelHandler},
    {kWeakSpecialTelPattern2, TelHandler},
    {kDefaultTelPattern, TelHandler},

    {kYearStrictPattern, YearHandler},

    {kTemperaturePattern, TemperatureHandler},  // 34.32℃  -34.32℃

    // time
    {kTimeFullPattern, TimeHandler},  // 10:30:06
    {kTimePartPattern, TimeHandler},  // 18:30 12:00AM, 3:10PM
    // fraction
    {kFractionPattern, FractionHandler},  // 1/2 3/5
    {kSerialNumPattern, SerialHandler},   // MU7089 G65 730Li

    {kNumberToPattern, NumberToHandler},        // -12~13
    {kMeasurePuncPattern, MeasurePuncHandler},  // meters/hour

    // default
    {kSignedNumberPattern, DefaultNumberHandler},     // 1939234 10.123
    {kSymbolPattern, SymbolsHandler},                 // + < > =
    {kContinuesSpacePattern, ContinuesSpaceHandler},  // continues space
    {kPostProcessPattern, PostProcessHandler},        // continues space
};

static const FundHandler kEnglishFundHandlers[] = {
    {tts::kSsmlTnAsDigits, ReadAsDigit},
    {tts::kSsmlTnAsValue, ReadAsValue},
    {tts::kSsmlTnAsDate, ReadAsDate},
    {tts::kSsmlTnAsTelephone, ReadAsTelephone},
    {tts::kSsmlTnAsManValue, nlp::tn::mandarin::ReadAsValue},
    {tts::kSsmlTnAsManDigits, nlp::tn::mandarin::ReadAsDigit},
    {tts::kSsmlTnAsManDate, nlp::tn::mandarin::ReadAsDate},
    {tts::kSsmlTnAsManTelephone, nlp::tn::mandarin::ReadAsTelephone},
    {tts::kSsmlTnAsContact, nlp::tn::mandarin::ReadAsName},
    {tts::kSsmlTnAsBookName, nlp::tn::mandarin::ReadAsBook},
    {tts::kSsmlTnAsBuilding, nlp::tn::mandarin::ReadAsBuilding},
    {tts::kSsmlTnAsFestival, nlp::tn::mandarin::ReadAsFestival},
    {tts::kSsmlTnAsValueLiang, nlp::tn::mandarin::ReadAsDecimalValueLiang},
    {tts::kSsmlTnAsValueEr, nlp::tn::mandarin::ReadAsDecimalValueEr},
    {tts::kSsmlTnAsDigitYao, nlp::tn::mandarin::ReadAsDigitYao},
    {tts::kSsmlTnAsDigitYi, nlp::tn::mandarin::ReadAsDigitYi},
    {tts::kSsmlTnAsRatio, nlp::tn::mandarin::ReadAsRatio},
    {tts::kSsmlTnAsScale, nlp::tn::mandarin::ReadAsScale},
    {tts::kSsmlTnAsMath, nlp::tn::mandarin::ReadAsMath},
    {tts::kSsmlTnAsTime, nlp::tn::mandarin::ReadAsTime},
    {tts::kSsmlTnAsFraction, nlp::tn::mandarin::ReadAsFraction},
    {tts::kSsmlTnAsAlphabet, nlp::tn::mandarin::ReadAsAlphabet},
    {tts::kSsmlTnAsWord, nlp::tn::mandarin::ReadAsWord},
    {tts::kSsmlTnAsSymbol, nlp::tn::mandarin::ReadAsSymbol},
};

}  // namespace english
}  // namespace tn
}  // namespace nlp

#endif  // TTS_NLP_TN_ENGLISH_TEXT_NORMALIZER_H_
