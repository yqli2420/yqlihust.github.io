// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_NLP_TN_TN_HANDLER_H_
#define TTS_NLP_TN_TN_HANDLER_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "re2/re2.h"
#include "tts/nlp/tn/text_normalizer_def.h"
#include "tts/util/tts_util/tts_data.h"

namespace nlp {
namespace tn {

class BaseHandler {
 public:
  BaseHandler();
  virtual ~BaseHandler();

  virtual string FullMatchProcess(const string& input) const = 0;
  virtual string Process(const string& input, int offset,
                         tts::TnDetail* detail) const = 0;

 private:
  DISALLOW_COPY_AND_ASSIGN(BaseHandler);
};

class LeafHandler : public BaseHandler {
 public:
  LeafHandler();
  explicit LeafHandler(const std::unordered_map<string, string>& handler_map);
  explicit LeafHandler(const string& replace);
  virtual ~LeafHandler();

  virtual string FullMatchProcess(const string& input) const;
  virtual string Process(const string& input, int offset,
                         tts::TnDetail* detail) const;

 private:
  std::unordered_map<string, string> handler_map_;
  bool const_replace_;
  string replace_;
  DISALLOW_COPY_AND_ASSIGN(LeafHandler);
};

class BranchHandler : public BaseHandler {
 public:
  BranchHandler();
  BranchHandler(const string& pattern,
                const vector<std::shared_ptr<BaseHandler>>& _handlers,
                const string& _body = "");
  virtual ~BranchHandler();

  virtual string FullMatchProcess(const string& input) const;
  virtual string Process(const string& input, int offset,
                         tts::TnDetail* detail) const;

 private:
  std::shared_ptr<re2::RE2> pattern_;
  vector<std::shared_ptr<BaseHandler>> handlers_;
  // pattern body begin and end
  pair<int, int> body_;
  DISALLOW_COPY_AND_ASSIGN(BranchHandler);
};

}  // namespace tn
}  // namespace nlp
#endif  // TTS_NLP_TN_TN_HANDLER_H_
