// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/nlp/tn/text_normalizer.h"

#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/string_util.h"
#include "third_party/gtest/gtest.h"
#include "tts/util/tts_util/util.h"

DEFINE_bool(do_acc_test, false, "If true, do Tn AccTest");

namespace nlp {
namespace tn {

static const char kTextNormalizerSegSepMark = '\t';
enum TNTestFormat {
  kInput = 0,
  kExpect,
  kTNTestAllNum,
};

static const string kTnResourceDir = "external/config/front_end/tn/";  // NOLINT
static const string kTestDataDir = "tts/nlp/tn/testdata/";             // NOLINT

void TextNormalize(std::shared_ptr<TextNormalizer> text_normalizer,
                   const string& input, const string& option, string* result) {
  vector<tts::SsmlText> tn_inputs;
  vector<tts::SsmlText> tn_outputs;
  tts::SsmlParser::Instance().ParseText(input, &tn_inputs);
  text_normalizer->Normalize(tn_inputs, option, &tn_outputs);
  *result = tts::SsmlParser::Instance().JoinText(tn_outputs);
}

void TextNormalizerCaseTest(std::shared_ptr<TextNormalizer> text_normalizer,
                            const string& input, const string& option,
                            const string& expect) {
  string result;
  TextNormalize(text_normalizer, input, option, &result);
  ASSERT_EQ(expect, result) << expect << "\n" << result;
}

void TextNormalizerFileTest(std::shared_ptr<TextNormalizer> text_normalizer,
                            const string& test_file, const string& option) {
  vector<string> lines;
  file::SimpleLineReader file_reader(test_file, true, "#");
  file_reader.ReadLines(&lines);
  for (const auto& line : lines) {
    vector<string> segs;
    SplitString(line, kTextNormalizerSegSepMark, &segs);
    ASSERT_EQ(TNTestFormat::kTNTestAllNum, segs.size());
    string input = segs[TNTestFormat::kInput];
    string expect = segs[TNTestFormat::kExpect];
    TextNormalizerCaseTest(text_normalizer, input, option, expect);
  }
}

void TextNormalizerFileAccTest(std::shared_ptr<TextNormalizer> text_normalizer,
                               const string& test_file, const string& option,
                               float accuracy) {
  vector<string> lines;
  file::SimpleLineReader file_reader(test_file, true, "#");
  file_reader.ReadLines(&lines);
  int correct = 0;
  for (const auto& line : lines) {
    vector<string> segs;
    SplitString(line, kTextNormalizerSegSepMark, &segs);
    ASSERT_EQ(TNTestFormat::kTNTestAllNum, segs.size());
    string input = segs[TNTestFormat::kInput];
    string expect = segs[TNTestFormat::kExpect];
    string result;
    TextNormalize(text_normalizer, input, option, &result);
    if (expect == result) {
      correct += 1;
    } else {
      LOG(INFO) << input << "\nexpect: " << expect << "\n"
                << "result: " << result;
    }
  }
  if (lines.empty()) return;
  float result_acc = static_cast<float>(correct) / lines.size();
  LOG(INFO) << result_acc;
  EXPECT_GT(result_acc, accuracy) << result_acc;
}

TEST(TextNormalizerTest, MandarinTNTest) {
  const string tn_resource = kTnResourceDir + "man_tn.conf";
  std::shared_ptr<TextNormalizer> text_normalizer;
  text_normalizer.reset(
      new TextNormalizer(tts::kMandarinTypeString, tn_resource));

  const string option;
  const string input = "现在美国西部时间\n09点00分,星期六\n2015年10月10日";
  const string expect = "现在美国西部时间^九点整,星期六^二零一五年十月十日";
  TextNormalizerCaseTest(text_normalizer, input, option, expect);
}

TEST(TextNormalizerTest, EnglishTNTest) {
  const string tn_resource = kTnResourceDir + "eng_tn.conf";
  std::shared_ptr<TextNormalizer> text_normalizer;
  text_normalizer.reset(
      new TextNormalizer(tts::kEnglishTypeString, tn_resource));

  const string option;
  const string input = "1308230 km/h, yes";
  const string expect =
      "one`million`three`hundred`and`eight`thousand`two`hundred`and`"
      "thirty`kilometers`per`hour,yes";
  TextNormalizerCaseTest(text_normalizer, input, option, expect);
}

TEST(TextNormalizerTest, MandarinFileTest) {
  LOG(INFO) << "begin mandarin tn test";
  const string tn_resource = kTnResourceDir + "man_tn.conf";
  std::shared_ptr<TextNormalizer> text_normalizer;
  text_normalizer.reset(
      new TextNormalizer(tts::kMandarinTypeString, tn_resource));

  string option;
  string test_file;

  test_file = kTestDataDir + "mandarin_text_normalizer.txt";
  TextNormalizerFileTest(text_normalizer, test_file, option);

  // calculator domain tn
  test_file = kTestDataDir + "mandarin_text_normalizer_calculator.txt";
  option = kDomainCalc;
  TextNormalizerFileTest(text_normalizer, test_file, option);
  LOG(INFO) << "finish mandarin tn test";
}

TEST(TextNormalizerTest, AccTest) {
  if (FLAGS_do_acc_test) {
    LOG(INFO) << "begin mandarin acc test";
    const string tn_resource = kTnResourceDir + "man_tn.conf";
    std::shared_ptr<TextNormalizer> text_normalizer;
    text_normalizer.reset(
        new TextNormalizer(tts::kMandarinTypeString, tn_resource));

    string option;
    string test_file;
#ifndef FOR_PORTABLE
    float accuracy = 0.9;
#else
    float accuracy = 0.8;
#endif
    test_file = kTestDataDir + "tn_test.txt";
    TextNormalizerFileAccTest(text_normalizer, test_file, option, accuracy);
    LOG(INFO) << "finish tn acc test";
  }
}

TEST(TextNormalizerTest, TaiwaneseFileTest) {
  LOG(INFO) << "begin taiwanese tn test";
#ifndef FOR_PORTABLE
  const string tn_resource = kTnResourceDir + "tw_tn.conf";
#else
  const string tn_resource = kTnResourceDir + "man_tn.conf";
#endif
  std::shared_ptr<TextNormalizer> text_normalizer;
  text_normalizer.reset(
      new TextNormalizer(tts::kTaiwaneseTypeString, tn_resource));

  const string option;
  string test_file;

  test_file = kTestDataDir + "taiwanese_text_normalizer.txt";
  TextNormalizerFileTest(text_normalizer, test_file, option);
  LOG(INFO) << "finish taiwanese tn test";
}

TEST(TextNormalizerTest, EnglishFileTest) {
  LOG(INFO) << "begin english tn test";
  const string tn_resource = kTnResourceDir + "eng_tn.conf";
  std::shared_ptr<TextNormalizer> text_normalizer;
  text_normalizer.reset(
      new TextNormalizer(tts::kEnglishTypeString, tn_resource));

  const string option;
  string test_file;

  test_file = kTestDataDir + "english_text_normalizer.txt";
  TextNormalizerFileTest(text_normalizer, test_file, option);
  LOG(INFO) << "finish english tn test ";
}

TEST(TextNormalizerTest, DbcToSbcTest) {
  const string tn_resource = kTnResourceDir + "man_tn.conf";
  std::shared_ptr<TextNormalizer> text_normalizer;
  text_normalizer.reset(
      new TextNormalizer(tts::kMandarinTypeString, tn_resource));

  const string test_file = kTestDataDir + "dbc2sbc.txt";
  const string option;

  TextNormalizerFileTest(text_normalizer, test_file, option);
}

TEST(TextNormalizerTest, MandarinDomainTest) {
  const string tn_resource = kTnResourceDir + "man_tn.conf";
  std::shared_ptr<TextNormalizer> text_normalizer;
  text_normalizer.reset(
      new TextNormalizer(tts::kMandarinTypeString, tn_resource));

  const string text1 = "123";
  const string option1 = kDomainWenyanAddress;
  const string expect1 = "幺二三";
  TextNormalizerCaseTest(text_normalizer, text1, option1, expect1);

  const string text2 = "123";
  const string option2 = kDomainCall;
  const string expect2 = "幺二三";
  TextNormalizerCaseTest(text_normalizer, text2, option2, expect2);

  const string text3 = "12.33";
  const string option3 = kDomainWeather;
  const string expect3 = "十二点三三";
  TextNormalizerCaseTest(text_normalizer, text3, option3, expect3);
}

TEST(TextNormalizerTest, TaiwaneseDomainTest) {
#ifndef FOR_PORTABLE
  const string tn_resource = kTnResourceDir + "tw_tn.conf";
#else
  const string tn_resource = kTnResourceDir + "man_tn.conf";
#endif
  std::shared_ptr<TextNormalizer> text_normalizer;
  text_normalizer.reset(
      new TextNormalizer(tts::kTaiwaneseTypeString, tn_resource));

  const string text1 = "123";
  const string option1 = kDomainCall;
  const string expect1 = "一二三";
  TextNormalizerCaseTest(text_normalizer, text1, option1, expect1);
}

}  // namespace tn
}  // namespace nlp
