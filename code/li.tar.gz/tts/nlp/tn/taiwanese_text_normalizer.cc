// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

// See below page for ref
// http://www.zhihu.com/question/22629654
// http://zh.wikipedia.org/wiki/%E4%B8%AD%E6%96%87%E6%95%B0%E5%AD%97
#include "tts/nlp/tn/taiwanese_text_normalizer.h"

#include "mobvoi/base/log.h"

namespace nlp {
namespace tn {
namespace mandarin {

// Taiwan format: 34℃  -> 摄氏三十四度
void TWTemperatureHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process tw temperature ...";
  string append_unit = kDuPron;
  string pron;
  string temperature_unit =
      GetPronFromSymbol(str_args[3].as_string(), kTWTemperature2Pron,
                        arraysize(kTWTemperature2Pron));
  if (temperature_unit.empty()) {
    append_unit = str_args[3].as_string();
  }
  pron.append(temperature_unit);
  if (str_args[1].as_string() == "-" && StringToDouble(str_args[2].as_string()))
    pron.append(kNegativeTemperature);
  pron.append(GetPronForNumString(str_args[2].as_string(), false));
  pron.append(append_unit);
  *output = str_args[0].as_string() + pron;
}

// Temperature: boundary sign number to sign number unit
void TWTemperatureHandler2(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process tw temperature2 ...";
  string pron;
  string append_unit = kDuPron;
  string temperature_unit =
      GetPronFromSymbol(str_args[6].as_string(), kTWTemperature2Pron,
                        arraysize(kTWTemperature2Pron));
  if (!temperature_unit.empty()) {
    pron.append(temperature_unit);
  } else {
    append_unit = str_args[6].as_string();
  }
  if (str_args[1].as_string() == "-" && StringToDouble(str_args[2].as_string()))
    pron.append(kNegativeTemperature);
  pron.append(GetPronForNumString(str_args[2].as_string(), false));
  if (!temperature_unit.empty()) {
    pron.append(append_unit);
  }
  if (str_args[3].as_string() == "~" || str_args[3].as_string() == "-")
    pron.append(kToPron);
  else
    pron.append(str_args[3].as_string());
  if (str_args[4].as_string() == "-" && StringToDouble(str_args[5].as_string()))
    pron.append(kNegativeTemperature);
  pron.append(GetPronForNumString(str_args[5].as_string(), false));
  pron.append(append_unit);
  *output = str_args[0].as_string() + pron;
}

void TWTimeHandler(const re2::StringPiece* str_args, int args_num,
                   const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                   string* output) {
  VLOG(2) << "Process taiwanese time pattern ...";
  string pron;
  string time_word = str_args[0].as_string();
  pron.append(ReadAsValue(str_args[1].as_string(), true, true));
  pron.append(kHourPron);
  // Handle minute and second
  string minute_pron = ReadAsNumberTime(str_args[3].as_string());
  string second_pron = ReadAsNumberTime(str_args[5].as_string());
  if (minute_pron == kZeroPron &&
      (second_pron.empty() || second_pron == kZeroPron)) {
    pron.append(kEmptyPron);
  } else {
    pron.append(minute_pron);
    pron.append(kMinPron);
    if (second_pron != kZeroPron && !second_pron.empty()) {
      pron.append(second_pron);
      pron.append(kSecPron);
    }
  }
  *output = str_args[0].as_string() + pron + str_args[8].as_string();
}

}  // namespace mandarin
}  // namespace tn
}  // namespace nlp
