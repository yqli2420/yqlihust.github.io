// Copyright 2014 Mobvoi Inc. All Rights Reserved.
// Author: qli@mobvoi.com (Qian Li)
// Created on: Jul 23, 2014
//
// Load a G2P/P2G model and generate pronunciation/spelling hypotheses for
// input items.

#ifndef TTS_NLP_G2P_PHONETISAURUS_G2P_H_
#define TTS_NLP_G2P_PHONETISAURUS_G2P_H_

#include "third_party/openfst/include/fst/fstlib.h"
#include "tts/nlp/g2p/g2p_impl.h"
#include "tts/nlp/g2p/fst_path_finder.h"

namespace nlp {
namespace g2p {

class PhonetisaurusG2p : public G2pImpl {
 public:
  explicit PhonetisaurusG2p(const string& model);
  virtual ~PhonetisaurusG2p();

  virtual bool GetPron(const string& text, vector<string>* syl_prons) const;

 private:
  void LoadClusters();
  bool InSymbolTable(const string& character) const;
  bool WordToFSA(const vector<string>& words, fst::StdVectorFst* ofst) const;
  bool Phoneticize(const vector<string>& word, vector<PathData>* path,
                   int beam = 500) const;

  string tie_;
  string sb_;
  string se_;
  unordered_set<string> skip_seqs_;
  map<vector<string>, int> clusters_;

  unique_ptr<fst::StdFst> g2p_model_;
  const fst::SymbolTable* isyms_;  // This pointer is owned by g2p_model_.

  DISALLOW_COPY_AND_ASSIGN(PhonetisaurusG2p);
};

}  // namespace g2p
}  // namespace nlp
#endif  // TTS_NLP_G2P_PHONETISAURUS_G2P_H_
