// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_NLP_G2P_G2P_UTIL_H_
#define TTS_NLP_G2P_G2P_UTIL_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"

namespace nlp {
namespace g2p {

void ParseSyllable(const string& pron, vector<string>* syl_prons);
void GetSinglePron(const string& text_lower, vector<string>* syl_prons);
bool HasEngVowel(const vector<string>& phonemes);
void JoinSyllable(const vector<string>& phonemes, vector<string>* syl_prons);

}  // namespace g2p
}  // namespace nlp

#endif  // TTS_NLP_G2P_G2P_UTIL_H_
