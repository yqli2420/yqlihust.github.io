// Copyright 2014 Mobvoi Inc. All Rights Reserved.
// Author: qli@mobvoi.com (Qian Li)

// See paper for detail :
// Improving WFST-based G2P Conversion with Alignment Constraints and
//  RNNLM N-best Rescoring

#include "tts/nlp/g2p/phonetisaurus_g2p.h"

#include "mobvoi/base/string_util.h"
#include "tts/nlp/g2p/g2p_util.h"
#include "tts/util/tts_util/util.h"

namespace nlp {
namespace g2p {

using fst::StdArc;
using fst::StdFst;
using fst::StdVectorFst;

PhonetisaurusG2p::PhonetisaurusG2p(const string& model)
    : sb_("<s>"), se_("</s>") {
  VLOG(1) << "Loading G2P model";
  skip_seqs_.insert("eps");
  skip_seqs_.insert(sb_);
  skip_seqs_.insert(se_);
  skip_seqs_.insert("_");
  skip_seqs_.insert("-");
  skip_seqs_.insert("<eps>");
  g2p_model_.reset(StdFst::Read(model));
  isyms_ = g2p_model_->InputSymbols();
  tie_ = isyms_->Find(1);  // The separator symbol is reserved for index 1

  // For english only. "i|g}i" for example. It means ig is aligned to i.
  LoadClusters();
  VLOG(1) << "Complete loading G2P model";
}

PhonetisaurusG2p::~PhonetisaurusG2p() {}

bool PhonetisaurusG2p::GetPron(const string& text,
                               vector<string>* syl_prons) const {
  string input_lower = tts::ToLower(text);
  vector<string> tokens;
  if (!mobvoi::SplitUTF8String(input_lower, &tokens)) {
    LOG(WARNING) << "Failed to split: " << input_lower;
    return false;
  }

  vector<string> entry;
  for (size_t i = 0; i < tokens.size(); ++i) {
    if (!InSymbolTable(tokens[i])) {
      LOG(WARNING) << tokens[i] << " not found in input symbols table.";
    } else if (skip_seqs_.find(tokens[i]) != skip_seqs_.end()) {
      LOG(WARNING) << "is skip seqs , skip it:" << tokens[i];
    } else {
      entry.emplace_back(tokens[i]);
    }
  }

  if (entry.empty()) {
    VLOG(2) << "phonetisaurus entry is empty: " << text;
    return false;
  }

  vector<PathData> paths;
  Phoneticize(entry, &paths);
  if (paths.empty()) {
    VLOG(2) << "phonetisaurus path is empty: " << text;
    return false;
  }

  // Split the tied phones.
  vector<string> phonemes;
  for (size_t j = 0; j < paths[0].opath.size(); ++j) {
    vector<string> pinyins;
    mobvoi::SplitStringToVector(paths[0].opath[j], tie_.c_str(), true,
                                &pinyins);
    phonemes.insert(phonemes.end(), pinyins.begin(), pinyins.end());
  }
  // Get pron for non vowel words
  if (!HasEngVowel(phonemes)) {
    GetSinglePron(input_lower, syl_prons);
  } else {
    JoinSyllable(phonemes, syl_prons);
  }
  return true;
}

// Load the clusters file containing the list of
// subsequences generated during multiple-to-multiple alignment
void PhonetisaurusG2p::LoadClusters() {
  for (size_t i = 2; i < isyms_->NumSymbols(); ++i) {
    string sym = isyms_->Find(i);
    // Only process input symbols with seperator "|"
    if (sym.find(tie_) == string::npos) {
      continue;
    }
    vector<string> cluster;
    SplitString(sym, '|', &cluster);
    clusters_[cluster] = i;
  }
}

bool PhonetisaurusG2p::InSymbolTable(const string& character) const {
  int64 key = isyms_->Find(character);
  return key != fst::kNoSymbol && key != 1;
}

// Transform an input spelling/pronunciation into an equivalent
// FSA, adding extra arcs as needed to accomodate clusters.
bool PhonetisaurusG2p::WordToFSA(const vector<string>& tokens,
                                 StdVectorFst* ofst) const {
  vector<string> entry = tokens;
  // Build word fsa.
  ofst->AddState();
  ofst->SetStart(0);

  ofst->AddState();
  ofst->AddArc(0, StdArc(isyms_->Find(sb_), isyms_->Find(sb_), 0, 1));
  size_t i = 0;

  // Build the basic FSA
  for (i = 0; i < entry.size(); ++i) {
    ofst->AddState();
    const string& ch = entry[i];
    ofst->AddArc(i + 1, StdArc(isyms_->Find(ch), isyms_->Find(ch), 0, i + 2));
  }

  // Add any cluster arcs
  for (auto iter = clusters_.begin(); iter != clusters_.end(); ++iter) {
    vector<string>::iterator iter_result;
    vector<string>::iterator start = entry.begin();
    vector<string> cluster = iter->first;
    while (iter_result != entry.end()) {
      iter_result = search(start, entry.end(), cluster.begin(), cluster.end());
      if (iter_result != entry.end()) {
        ofst->AddArc(iter_result - entry.begin() + 1,
                     StdArc(iter->second, iter->second, 0,
                            iter_result - entry.begin() + cluster.size() + 1));
        start = iter_result + cluster.size();
      }
    }
  }

  ofst->AddState();
  ofst->AddArc(i + 1, StdArc(isyms_->Find(se_), isyms_->Find(se_), 0, i + 2));
  ofst->SetFinal(i + 2, 0);
  ofst->SetInputSymbols(isyms_);
  ofst->SetOutputSymbols(isyms_);
  return true;
}

// Generate pronunciation/spelling hypotheses for an
// input entry.
// Hlist = ShortestPath(Det (Proj (W . M)))
bool PhonetisaurusG2p::Phoneticize(const vector<string>& word,
                                   vector<PathData>* path, int beam) const {
  CHECK(path != NULL);
  path->clear();

  StdVectorFst efst;
  if (!WordToFSA(word, &efst)) {
    return false;
  }

  StdVectorFst result;
  fst::Compose(efst, *g2p_model_, &result);

  StdVectorFst shortest;
  ShortestPath(result, &shortest, 1, true);
  FstPathFinder pathfinder(skip_seqs_);
  pathfinder.FindAllStrings(shortest);
  *path = pathfinder.paths();
  return true;
}

}  // namespace g2p
}  // namespace nlp
