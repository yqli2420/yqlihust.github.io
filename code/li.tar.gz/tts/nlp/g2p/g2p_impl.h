// Copyright 2014 Mobvoi Inc. All Rights Reserved.
// Author: qli@mobvoi.com (Qian Li)
// Created on: Jul 28, 2014
//
// Common interface for different G2P engines.

#ifndef TTS_NLP_G2P_G2P_IMPL_H_
#define TTS_NLP_G2P_G2P_IMPL_H_

#include "mobvoi/base/compat.h"

namespace nlp {
namespace g2p {

class G2pImpl {
 public:
  G2pImpl() {}
  virtual ~G2pImpl() {}

  // Gets the phonetic pronunciation for a word, return true if success
  // output pron is a vector of syllable joined with ' '
  // e.g. smartphone -> S M AA1 R T
  //                    F OW1 N
  virtual bool GetPron(const string& text, vector<string>* syl_prons) const = 0;

 private:
  DISALLOW_COPY_AND_ASSIGN(G2pImpl);
};

}  // namespace g2p
}  // namespace nlp
#endif  // TTS_NLP_G2P_G2P_IMPL_H_
