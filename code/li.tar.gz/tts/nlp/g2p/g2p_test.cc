// Copyright 2016 Mobvoi Inc. All Rights Reserved.
// Author: ylchen@mobvoi.com (Yunlin Chen)

#include "tts/nlp/g2p/g2p.h"
#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/log.h"
#include "third_party/gtest/gtest.h"

namespace nlp {
namespace g2p {

class G2pTest : public ::testing::Test {
 protected:
  virtual void SetUp() {
    const string g2p_conf_file = "external/config/front_end/g2p/eng_g2p.conf";
    g2p_.reset(new G2p(g2p_conf_file));
  }

  void G2pCaseTest(const string& text,
                   const vector<string>& expect_pron) const {
    vector<string> pron;
    g2p_->GetPron(text, &pron);
    EXPECT_EQ(expect_pron, pron);
  }

  std::unique_ptr<G2p> g2p_;
};

TEST_F(G2pTest, GetPronFromUserDict) {
  string text = "IT";
  vector<string> expect_pron = {"AY1", "T IY1"};
  G2pCaseTest(text, expect_pron);
}

TEST_F(G2pTest, GetPronFromWordDict) {
  string text = "linda";
  vector<string> expect_pron = {"L IH1 N", "D AH0"};
  G2pCaseTest(text, expect_pron);
}

TEST_F(G2pTest, GetPronSingle) {
  string text = "USB";
  vector<string> expect_pron = {"Y UW1", "EH1 S", "B IY1"};
  G2pCaseTest(text, expect_pron);
}

TEST_F(G2pTest, GetPronNonPinyin) {
  string text = "hang";
  vector<string> expect_pron = {"HH AE1 NG"};
  G2pCaseTest(text, expect_pron);
}

TEST_F(G2pTest, GetPronPinyin) {
  string text = "pinyin_hang";
  vector<string> expect_pron = {"HH AA1 NG"};
  G2pCaseTest(text, expect_pron);
}

TEST_F(G2pTest, GetPronPinyins) {
  string text = "yinghang";
  vector<string> expect_pron = {"Y IY1 N", "HH AA1 NG"};
  G2pCaseTest(text, expect_pron);
}

TEST_F(G2pTest, GetPronPinyins2) {
  string text = "yingong";
  vector<string> expect_pron = {"Y IY1 N", "G AO1 NG"};
  G2pCaseTest(text, expect_pron);
}

TEST_F(G2pTest, GetPronPinyins3) {
  string text = "liulijie";
  vector<string> expect_pron = {"L Y OW1", "L IY1", "JH Y AE1"};
  G2pCaseTest(text, expect_pron);
}

TEST_F(G2pTest, GetPronPinyin4) {
  string text = "lindara";
  vector<string> expect_pron = {"L IY1 N", "D AA1", "R AA1"};
  G2pCaseTest(text, expect_pron);
}

TEST_F(G2pTest, GetPronPinyin5) {
  string text = "lianang";
  vector<string> expect_pron = {"L Y AH1 N", "AA1 NG"};
  G2pCaseTest(text, expect_pron);
}

TEST_F(G2pTest, GetPronPinyin6) {
  string text = "xi'an";
  vector<string> expect_pron = {"SH IY1", "AA0 N"};
  G2pCaseTest(text, expect_pron);
}

TEST_F(G2pTest, GetPronFromModel) {
  string text = "lucario";
  vector<string> expect_pron = {"L UW0", "K AA1", "R IY0", "OW0"};
  G2pCaseTest(text, expect_pron);
}

TEST_F(G2pTest, GetAbbvPron) {
  string text = "miki's";
  vector<string> expect_pron = {"M IH1", "K IY1 Z"};
  G2pCaseTest(text, expect_pron);
}

TEST_F(G2pTest, GetAbbvPron2) {
  string text = "I'm";
  vector<string> expect_pron = {"AY1 M"};
  G2pCaseTest(text, expect_pron);
}

TEST_F(G2pTest, GetAbbvPron3) {
  string text = "you're";
  vector<string> expect_pron = {"Y UH1 R"};
  G2pCaseTest(text, expect_pron);
}

TEST_F(G2pTest, GetAbbvPron4) {
  string text = "couldn't";
  vector<string> expect_pron = {"K UH1", "D AH0 N T"};
  G2pCaseTest(text, expect_pron);
}
TEST_F(G2pTest, GetAbbvPron5) {
  string text = "should've";
  vector<string> expect_pron = {"SH UH1", "D AH0 V"};
  G2pCaseTest(text, expect_pron);
}

}  // namespace g2p
}  // namespace nlp
