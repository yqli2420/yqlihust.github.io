// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_NLP_G2P_DICT_G2P_H_
#define TTS_NLP_G2P_DICT_G2P_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/util/string/string_map.h"
#include "tts/nlp/g2p/g2p_impl.h"

namespace nlp {
namespace g2p {

class DictG2p : public G2pImpl {
 public:
  DictG2p(const string& user_dict, const string& config_center,
          const string& word_dict, const string& pinyin_dict);
  virtual ~DictG2p();

  virtual bool GetPron(const string& text, vector<string>* syl_prons) const;

 private:
  void LoadUserDict(const string& user_dict_path);
  void LoadWordDict(const string& word_dict);
  bool GetPronFromUserDict(const string& text, vector<string>* syl_prons) const;
  bool GetPronFromWordDict(const string& text, vector<string>* syl_prons) const;
  bool ProcessPinyin(const string& text, vector<string>* syl_prons) const;
  bool SplitPinyin(const string& text, vector<string>* pinyins) const;
  bool SplitPinyinString(const string& text, vector<string>* pinyins) const;

  mobvoi::unordered_map<string, string> user_dict_;
  unique_ptr<mobvoi::StringMap> word_dict_;
  mobvoi::unordered_map<string, string> pinyin_dict_;

  DISALLOW_COPY_AND_ASSIGN(DictG2p);
};

}  // namespace g2p
}  // namespace nlp
#endif  // TTS_NLP_G2P_DICT_G2P_H_
