// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_NLP_G2P_G2P_H_
#define TTS_NLP_G2P_G2P_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"

namespace nlp {
namespace g2p {

class G2pImpl;

class G2p {
 public:
  explicit G2p(const string& resource_file);
  ~G2p();

  bool GetPron(const string& text, vector<string>* syl_prons) const;

 private:
  unique_ptr<G2pImpl> g2p_;

  DISALLOW_COPY_AND_ASSIGN(G2p);
};

}  // namespace g2p
}  // namespace nlp
#endif  // TTS_NLP_G2P_G2P_H_
