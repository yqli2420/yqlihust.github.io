// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_NLP_RANDOM_RANDOM_TTS_H_
#define TTS_NLP_RANDOM_RANDOM_TTS_H_

#include "tts/util/random/random.h"

namespace nlp {
namespace random {

union data {
  int intdata;
  char chardata[4];
};

class RandomTTS {
 public:
  explicit RandomTTS(int32 seed);
 private:
  data random_data;
}

}  // namespace random
}  // namespace nlp
#endif  // TTS_NLP_RANDOM_RANDOM_TTS_H_
