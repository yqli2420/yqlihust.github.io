// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/nlp/t2s/trad_simp_converter.h"

#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/string_util.h"
#include "third_party/gtest/gtest.h"

namespace nlp {
namespace t2s {

static const string kTestDataDir = "tts/nlp/t2s/testdata/";  // NOLINT

class T2sTest : public ::testing::Test {
 protected:
  virtual void SetUp() {
    const string trad_simp_conf_file =
        "external/config/front_end/t2s/trad_to_simp.txt";
    trad_simp_converter_.reset(new Trad2SimpConverter(trad_simp_conf_file));
  }
  void T2sCaseTest(const string& trad, const string& simp_expect) const {
    string simp;
    trad_simp_converter_->Convert(trad, &simp);
    EXPECT_EQ(simp_expect, simp);
  }
  void T2sFileTest(const string& input_file, const string& expect_file) const {
    vector<string> input_lines;
    file::SimpleLineReader file_reader_input(input_file, true, "#");
    file_reader_input.ReadLines(&input_lines);
    vector<string> expect_lines;
    file::SimpleLineReader file_reader_expect(expect_file, true, "#");
    file_reader_expect.ReadLines(&expect_lines);
    EXPECT_EQ(input_lines.size(), expect_lines.size());
    for (size_t i = 0; i < input_lines.size(); ++i) {
      string input = input_lines[i];
      string expect = expect_lines[i];
      T2sCaseTest(input, expect);
    }
  }

  std::unique_ptr<Trad2SimpConverter> trad_simp_converter_;
};

TEST_F(T2sTest, SingleCaseTest) {
  const string trad = "中華人民共和國從此站起來了";
  const string simp = "中华人民共和国从此站起来了";

  T2sCaseTest(trad, simp);
}

TEST_F(T2sTest, SingleFileTest) {
  const string input_file = kTestDataDir + "trad_simp_converter_input.txt";
  const string expect_file = kTestDataDir + "trad_simp_converter_expect.txt";
  T2sFileTest(input_file, expect_file);
}

}  // namespace t2s
}  // namespace nlp
