// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

// Simplified and Traditional conversion

#ifndef TTS_NLP_T2S_TRAD_SIMP_CONVERTER_H_
#define TTS_NLP_T2S_TRAD_SIMP_CONVERTER_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"

namespace nlp {
namespace t2s {

class Trad2SimpConverter {
 public:
  explicit Trad2SimpConverter(const string& conf_file);
  ~Trad2SimpConverter();

  bool Convert(const string& trad, string* simp) const;
 private:
  bool LoadTradSimpMap(const string& conf_file);

  std::unordered_map<uint32, uint32> trad_simp_map_;
  DISALLOW_COPY_AND_ASSIGN(Trad2SimpConverter);
};

}  // namespace t2s
}  // namespace nlp
#endif  // TTS_NLP_T2S_TRAD_SIMP_CONVERTER_H_
