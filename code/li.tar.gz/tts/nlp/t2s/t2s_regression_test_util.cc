// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: fllin@mobvoi.com (Fenglv Lin)

#include "tts/nlp/t2s/t2s_regression_test_util.h"

#include <vector>
#include <string>

#include "mobvoi/base/flags.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/base/time.h"
#include "third_party/jsoncpp/json.h"

DEFINE_string(trad_to_simp, "external/config/front_end/t2s/trad_to_simp.txt",
              "");

namespace nlp {
namespace t2s {

using std::string;

T2SRegressionTestUtil::T2SRegressionTestUtil() {
  t2s.reset(new nlp::t2s::Trad2SimpConverter(FLAGS_trad_to_simp));
}

void T2SRegressionTestUtil::RunTestCases(const string& test_file,
                                         Json::Value* result) const {
  Json::Value& node = *result;
  string error_file_name = test_file + ".error";
  FILE* fw = fopen(error_file_name.c_str(), "w");
  vector<string> test_cases;
  file::SimpleLineReader file_reader(test_file, true, "#");
  file_reader.ReadLines(&test_cases);
  int right = 0;
  int total_test_case = 0;
  for (auto& test_case : test_cases) {
    vector<string> segs;
    SplitString(test_case, '\t', &segs);
    if (segs.size() != 2) continue;
    ++total_test_case;
    string simp;
    t2s->Convert(segs[0], &simp);
    if (simp == segs[1]) {
      ++right;
    } else {
      fprintf(fw, "origin: %s\texpect: %s\tpredict: %s\n",
              segs[0].c_str(), segs[1].c_str(), simp.c_str());
      fflush(fw);
      LOG(ERROR) << "Trad2Simp convert error, origin text: " << segs[0]
                  << ", expete result: " << segs[1]
                  << ", convert result: " << simp;
    }
  }

  fclose(fw);
  node["precision"] = 0;
  node["recall"] = 0;
  node["accuracy"] = 0;
  node["f1_score"] = 0;
  node["test_type"] = "t2s";
  node["sentence"] = total_test_case;
  node["sentence_result"] = 1.0 * right / total_test_case;
  node["language"] = "mandarin";
  node["query_date"] = static_cast<Json::UInt64>(mobvoi::GetTimeInMs());
}

}  // namespace t2s
}  // namespace nlp
