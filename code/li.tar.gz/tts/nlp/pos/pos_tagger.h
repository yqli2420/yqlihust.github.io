// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_NLP_POS_POS_TAGGER_H_
#define TTS_NLP_POS_POS_TAGGER_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/mutex.h"

namespace CRFPP {
class TaggerImpl;
}  // namespace CRFPP

namespace nlp {
namespace segmenter {
class PosCrfModel;

class PosTagger {
 public:
  PosTagger(const string& pos_crf_model,
            const string& word_id_conf);
  ~PosTagger();

  // It's thread safe.
  bool Tag(const vector<string>& tokens,
           vector<string>* result) const;

 private:
  std::unique_ptr<PosCrfModel> model_;
  mutable mobvoi::Mutex mutex_;
  std::unique_ptr<CRFPP::TaggerImpl> tagger_;
  DISALLOW_COPY_AND_ASSIGN(PosTagger);
};
}  // namespace segmenter
}  // namespace nlp

#endif  // TTS_NLP_POS_POS_TAGGER_H_
