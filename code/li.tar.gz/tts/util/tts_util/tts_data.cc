// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/util/tts_util/tts_data.h"
#include "mobvoi/base/base64.h"
#include "mobvoi/base/log.h"
#include "mobvoi/util/utf8/utf8_util.h"
#include "third_party/jsoncpp/json.h"
#include "tts/synthesizer/label_generator/label_def.h"

namespace tts {

static const float kFrameShift = 0.005;  // 5ms

void AppendRawData(const RawData& from, RawData* to) {
  VecFastAppend(from.data, &(to->data));
  VecFastAppend(from.phonemes, &(to->phonemes));
  VecFastAppend(from.durations, &(to->durations));
  VecFastAppend(from.feature, &(to->feature));
}

void JsonWrapper(const RawData& raw_data, const TTSOption& tts_option,
                 string* data_res) {
  Json::Value root;
  if (tts_option.alignment()) {
    Json::Value phonemes;
    Json::Value alignments;
    float time = 0.0;
    if (tts_option.file_format() == "mp3") {
      // mp3 CBR overall delay 1105 samples
      time += static_cast<float>(1105) / tts_option.sampling_frequency();
    }
    for (size_t i = 0; i < raw_data.phonemes.size(); ++i) {
      // remove last SIL alignment for mp3 padding mismatch
      if (i == raw_data.phonemes.size() - 1 &&
          raw_data.phonemes[i] == kPhoneSilence) {
        continue;
      }
      phonemes[i] = raw_data.phonemes[i];
      time += raw_data.durations[i] * kFrameShift;
      alignments[i] = time;
      root["phonemes"] = std::move(phonemes);
      root["alignments"] = std::move(alignments);
      VLOG(2) << raw_data.phonemes[i] << " " << raw_data.durations[i]
              << " frames, end time " << time;
    }
  } else if (tts_option.detail_output()) {
    Json::Value debug_infos;
    Json::Value phonemes;
    Json::Value durations;
    for (size_t i = 0; i < raw_data.phonemes.size(); ++i) {
      phonemes[i] = raw_data.phonemes[i];
      durations[i] = raw_data.durations[i];
    }
    for (size_t i = 0; i < raw_data.debug_infos.size(); ++i) {
      debug_infos[i]["g2pTnText"] = raw_data.debug_infos[i]["g2pTnText"];
      debug_infos[i]["prosodyText"] = raw_data.debug_infos[i]["prosodyText"];
    }
    string audio_data;
    base::Base64Encode(*data_res, &audio_data);

    root["debug_infos"] = debug_infos.toStyledString();
    root["phonemes"] = std::move(phonemes);
    root["durations"] = std::move(durations);
    root["audio"] = std::move(audio_data);
  } else {
    return;
  }
  *data_res = root.toStyledString();
}

void TnDetail::Display() {
  VLOG(2) << "tn inputs: " << tn_input;
  VLOG(2) << "tn mappings: ";
  for (const auto& mapping : tn_mappings) {
    VLOG(2) << mapping.offset << " " << mapping.name << " \"" << mapping.input
            << "\" --> \"" << mapping.output << "\"";
    if (!mapping.candidates.empty()) {
      for (const auto& candidate : mapping.candidates) {
        VLOG(2) << "    candidates: " << candidate.first << " "
                << candidate.second;
      }
    }
  }
  VLOG(2) << "tn mapping end ...";
  VLOG(2) << "tn outputs: " << tn_output;
}

void TnDetail::Format() {
  vector<int> offsets;
  vector<bool> modifys;
  vector<string> names;
  vector<map<string, string>> candidates_list;
  for (int i = 0; i < util::utflen(tn_input.c_str()); ++i) {
    offsets.emplace_back(i);
    modifys.push_back(false);  // vector<bool> has no emplace back
    candidates_list.emplace_back();
    names.emplace_back(string());
  }
  for (const auto& tn_mapping : tn_mappings) {
    int tmp = offsets[tn_mapping.offset];
    size_t tn_input_len = util::utflen(tn_mapping.input.c_str());
    size_t tn_output_len = util::utflen(tn_mapping.output.c_str());
    size_t find = tn_mapping.output.find("<MTag>");
    if (find != string::npos) {
      offsets.insert(offsets.begin() + tn_mapping.offset + tn_input_len,
                     util::utflen("<MTag>"), tmp);
    } else {
      offsets.erase(offsets.begin() + tn_mapping.offset,
                    offsets.begin() + tn_mapping.offset + tn_input_len);
      offsets.insert(offsets.begin() + tn_mapping.offset, tn_output_len, tmp);
    }
    modifys.erase(modifys.begin() + tn_mapping.offset,
                  modifys.begin() + tn_mapping.offset + tn_input_len);
    names.erase(names.begin() + tn_mapping.offset,
                names.begin() + tn_mapping.offset + tn_input_len);
    candidates_list.erase(
        candidates_list.begin() + tn_mapping.offset,
        candidates_list.begin() + tn_mapping.offset + tn_input_len);
    modifys.insert(modifys.begin() + tn_mapping.offset, tn_output_len, true);
    names.insert(names.begin() + tn_mapping.offset, tn_output_len,
                 tn_mapping.name);

    // TODO(zhengzhang): reproduce delete candidates
    if (tn_output_len <= 0) {
      continue;
    }
    candidates_list.insert(candidates_list.begin() + tn_mapping.offset,
                           tn_output_len - 1, {});
    candidates_list.insert(candidates_list.begin() + tn_mapping.offset,
                           tn_mapping.candidates);
  }
  vector<string> input_utf8;
  vector<string> output_utf8;
  util::SplitUtf8String(tn_input, &input_utf8);
  util::SplitUtf8String(tn_output, &output_utf8);
  vector<TnMapping> tn_mappings_tmp;
  size_t begin_off = 0;
  size_t end_off = 0;
  int begin_num = 0;
  while (begin_off < offsets.size()) {
    if (modifys[begin_off] || begin_num != offsets[begin_off]) {
      int offset = begin_num;
      string input;
      string output;
      end_off = begin_off;
      while (end_off < offsets.size() && begin_num == offsets[end_off]) {
        end_off += 1;
      }
      for (size_t i = begin_off; i < end_off; ++i) {
        output += output_utf8[i];
      }
      size_t input_end =
          (end_off == offsets.size()) ? input_utf8.size() : offsets[end_off];
      for (size_t i = begin_num; i < input_end; ++i) {
        input += input_utf8[i];
      }
      TnMapping mapping_tmp(offset, input, output, names[begin_off]);
      if (begin_off != end_off) {
        mapping_tmp.candidates = candidates_list[begin_off];
      }
      begin_off = end_off;
      if (begin_off < offsets.size()) begin_num = offsets[begin_off];
      tn_mappings_tmp.emplace_back(mapping_tmp);
    } else {
      begin_off += 1;
      begin_num += 1;
    }
  }
  tn_mappings = tn_mappings_tmp;
}

}  // namespace tts
