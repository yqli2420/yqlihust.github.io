// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/util/tts_util/wave_util.h"

#include <stdio.h>
#include <algorithm>
#include <cmath>
#ifdef TTS_USE_AVX2
#include <immintrin.h>
#endif  // TTS_USE_AVX2
#ifdef __ARM_NEON
#include <arm_neon.h>
#endif  // __ARM_NEON

#include "mobvoi/base/log.h"
#include "tts/util/tts_util/tts_data.h"

namespace tts {

static const int kWavHeadLen = 44;
// less than threshould will be treated as silence and do not normalize
static const int kSilenceVarThreshould = 1000;

void WaveFile::WriteRiffHeader(int sampling_frequency, int nsamples,
                               string* riff_header) {
  // See http://www.topherlee.com/software/pcm-tut-wavformat.html
  char data_01_04[] = {'R', 'I', 'F', 'F'};
  int data_05_08 = sizeof(int16) * nsamples + 36;
  char data_09_12[] = {'W', 'A', 'V', 'E'};
  char data_13_16[] = {'f', 'm', 't', ' '};
  int data_17_20 = 16;
  int16 data_21_22 = 1;  // PCM
  int16 data_23_24 = 1;  // monoral
  int data_25_28 = sampling_frequency;
  int data_29_32 = sampling_frequency * sizeof(int16);
  int16 data_33_34 = sizeof(int16);
  int16 data_35_36 = static_cast<int16>(sizeof(int16) * 8);
  char data_37_40[] = {'d', 'a', 't', 'a'};
  int data_41_44 = sizeof(int16) * nsamples;

  riff_header->append(data_01_04, sizeof(char) * 4);
  riff_header->append((const char*)&data_05_08, sizeof(int) * 1);
  riff_header->append(data_09_12, sizeof(char) * 4);
  riff_header->append(data_13_16, sizeof(char) * 4);
  riff_header->append((const char*)&data_17_20, sizeof(int) * 1);
  riff_header->append((const char*)&data_21_22, sizeof(int16) * 1);
  riff_header->append((const char*)&data_23_24, sizeof(int16) * 1);
  riff_header->append((const char*)&data_25_28, sizeof(int) * 1);
  riff_header->append((const char*)&data_29_32, sizeof(int) * 1);
  riff_header->append((const char*)&data_33_34, sizeof(int16) * 1);
  riff_header->append((const char*)&data_35_36, sizeof(int16) * 1);
  riff_header->append(data_37_40, sizeof(char) * 4);
  riff_header->append((const char*)&data_41_44, sizeof(int) * 1);
}

void WaveFile::ReadWaveFile(const string& filename, vector<int16>* data,
                            int* sampling_rate) {
  VLOG(1) << "Begin to read file:" << filename;
  FILE* fp = fopen(filename.c_str(), "r");
  CHECK(fp) << "Failed to open file:" << filename;
  static const int kSamplingRateOffset = 24;
  fseek(fp, kSamplingRateOffset, SEEK_SET);
  int r = fread(reinterpret_cast<void*>(sampling_rate), sizeof(int), 1, fp);
  CHECK_EQ(r, 1) << "Failed to read sampling_rate.";

  static const int kRiffHeaderSize = 44;
  fseek(fp, kRiffHeaderSize, SEEK_SET);
  int16 d = 0;
  while (fread(reinterpret_cast<void*>(&d), sizeof(int16), 1, fp) == 1) {
    data->push_back(d);
  }
  fclose(fp);
}

void WaveFile::ReadWaveFileInfo(const string& filename, vector<int16>* data,
                                int* sampling_rate, int* bits_per_sample,
                                int16* channels) {
  VLOG(1) << "Begin to read file:" << filename;
  FILE* fp = fopen(filename.c_str(), "r");
  CHECK(fp) << "Failed to open file:" << filename;
  static const int kSamplingRateOffset = 24;
  fseek(fp, kSamplingRateOffset, SEEK_SET);
  int r = fread(reinterpret_cast<void*>(sampling_rate), sizeof(int), 1, fp);
  CHECK_EQ(r, 1) << "Failed to read sampling_rate.";

  static const int kBitsPerSampleOffset = 16;
  fseek(fp, kBitsPerSampleOffset, SEEK_SET);
  r = fread(reinterpret_cast<void*>(bits_per_sample), sizeof(int), 1, fp);
  CHECK_EQ(r, 1) << "Failed to read bits per sample.";

  static const int kChannelsOffset = 22;
  fseek(fp, kChannelsOffset, SEEK_SET);
  r = fread(reinterpret_cast<void*>(channels), sizeof(int16), 1, fp);
  CHECK_EQ(r, 1) << "Failed to read channels.";

  static const int kRiffHeaderSize = 88;
  fseek(fp, kRiffHeaderSize, SEEK_SET);
  int16 d = 0;
  while (fread(reinterpret_cast<void*>(&d), sizeof(int16), 1, fp) == 1) {
    data->push_back(d);
  }
  NormalizeWave(data, kDefaultVolume, kDefaultNormalizeFactor);
  fclose(fp);
}

bool WaveFile::ReadRawFile(const string& filename, vector<int16>* data) {
  VLOG(1) << "Begin to read file:" << filename;
  FILE* fp = fopen(filename.c_str(), "r");
  CHECK(fp) << "Failed to open file:" << filename;
  fseek(fp, 0L, SEEK_END);
  int file_len = ftell(fp) / 2;
  fseek(fp, 0L, SEEK_SET);
  data->reserve(file_len);
  int16 d = 0;
  while (fread(reinterpret_cast<void*>(&d), sizeof(int16), 1, fp) == 1) {
    data->push_back(d);
  }
  fclose(fp);
  return true;
}

void WaveFile::AudioMix(const vector<int16>& bg_buf, const float volume,
                        const float bgm_volume, const int bgm_beg,
                        vector<int16>* src_buf) {
  map<int, int> section;
  section[0] = src_buf->size();
  AudioMix(bg_buf, section, volume, bgm_volume, bgm_beg, src_buf);
}

void WaveFile::AudioMix(const vector<int16>& bg_buf,
                        const map<int, int>& section, const float volume,
                        const float bgm_volume, const int bgm_beg,
                        vector<int16>* src_buf) {
  vector<int16> mix_buf;
  double factor = 1;
  int mix_value = 0;
  int bg_len = bg_buf.size();
  int bgm_index = bgm_beg;
  float bgm_factor = pow(bgm_volume, 1.5);
  int index = 0;

  for (auto it : section) {
    mix_buf.insert(mix_buf.end(), src_buf->begin() + index,
                   src_buf->begin() + it.first);
    for (int i = it.first; i < it.second; i++) {
      mix_value = static_cast<int>(src_buf->at(i) * volume +
                                   bg_buf[bgm_index % bg_len] * bgm_factor)
          * factor;
      if (mix_value > INT16_MAX) {
        factor =
            static_cast<double>(INT16_MAX) / static_cast<double>(mix_value);
        mix_value = INT16_MAX;
      }
      if (mix_value < INT16_MIN) {
        factor =
            static_cast<double>(INT16_MIN) / static_cast<double>(mix_value);
        mix_value = INT16_MIN;
      }
      if (factor < 1) {
        factor += static_cast<double>(1 - factor) / static_cast<double>(32);
      }
      mix_buf.push_back(static_cast<int16>(mix_value));
      ++bgm_index;
    }
    index = it.second;
  }
  mix_buf.insert(mix_buf.end(), src_buf->begin() + index, src_buf->end());
  src_buf->clear();
  tts::VecFastAppend(mix_buf, src_buf);
}

void WaveFile::ConvertDataToWave(const vector<int16>& raw_data,
                                 int sampling_frequency, string* data) {
  static const int RiffHeaderSize = 44;
  data->reserve(RiffHeaderSize + raw_data.size() * sizeof(int16));
  WriteRiffHeader(sampling_frequency, raw_data.size(), data);
  VLOG(1) << "append wav header success:" << data;
  data->append(reinterpret_cast<const char*>(raw_data.data()),
               raw_data.size() * sizeof(int16));
}

void WaveFile::ConvertDataToRaw(const vector<int16>& raw_data,
                                int sampling_frequency, string* data) {
  data->reserve(raw_data.size() * sizeof(int16));
  data->append(reinterpret_cast<const char*>(raw_data.data()),
               raw_data.size() * sizeof(int16));
}

void WaveFile::ConvertWaveToData(const string& wav, vector<int16>* raw_data) {
  if (wav.size() < kWavHeadLen) return;
  raw_data->reserve(wav.size() - kWavHeadLen);
  for (size_t i = kWavHeadLen; i < wav.size(); i += sizeof(int16)) {
    raw_data->push_back(*reinterpret_cast<const int16*>(&wav[i]));
  }
}

bool WaveFile::IsSilence(const vector<int16>& datas) {
  if (datas.size() <= 1) return true;
  float data_sum = 0.0;
  for (const auto& data : datas) {
    data_sum += std::abs(data);
  }
  float data_mean = data_sum / datas.size();

  float variance_sum = 0.0;
  for (const auto& data : datas) {
    float x = std::abs(data) - data_mean;
    variance_sum += x * x;
  }
  float variance = variance_sum / (datas.size() - 1);
  return variance < kSilenceVarThreshould;
}

void WaveFile::NormalizeWaveVanilla(vector<int16>* data, float volume,
                                    float ratio) {
  if (data->empty()) {
    return;
  }
  int16 data_max = 0;
  volume = volume > kDefaultVolume ? kDefaultVolume : volume;
  // minmax_element is slow using benchmark. maybe caused by
  // CPU branch mis-predicting.
  //  auto result = std::minmax_element(data->begin(), data->end());
  //  int16 maxv = std::max(std::abs(*result.first), std::abs(*result.second));
  for (size_t i = 0; i < data->size(); ++i) {
    auto abs_value = abs((*data)[i]);
    data_max = abs_value > data_max ? abs_value : data_max;
  }
  // avoid plosive in silence data
  if (data_max == 0) return;

  float threshold = kint16max;
  float factor = threshold / data_max;
  ratio = ratio == kNoNormalizeFactor ? factor : std::min(ratio, factor);
  for (size_t i = 0; i < data->size(); ++i) {
    float temp = (*data)[i] * ratio;
    (*data)[i] = static_cast<int16>(temp * volume);
  }
}

#ifdef TTS_USE_AVX2
inline void Normalize(int16* d_ptr, __m256 ratio_ps, __m256 volume_ps) {
  // load 8xint16 data --> 8xint32 --> 8xfloat32
  // TODO(ypfeng): Not sure if this is the fastest
  __m256 data = _mm256_cvtepi32_ps(
      _mm256_cvtepi16_epi32(*reinterpret_cast<const __m128i*>(d_ptr)));
  __m256 data_norm = _mm256_mul_ps(data, ratio_ps);
  __m256 data_vol = _mm256_mul_ps(data_norm, volume_ps);
  // round to 0
  __m256i data_int32 = _mm256_cvtps_epi32(_mm256_round_ps(data_vol, 3));
  __m256i data_int16 = _mm256_packs_epi32(data_int32, data_int32);
  data_int16 = _mm256_permute4x64_epi64(data_int16, 0xD8);
  __m128i data_result = _mm256_castsi256_si128(data_int16);
  _mm_storeu_si128(reinterpret_cast<__m128i*>(d_ptr), data_result);
}

inline __m256i AbsMax(int16* d_ptr, __m256i max) {
  // load 16xint16 data
  // TODO(ypfeng): Not sure if this is the fastest
  __m256i d =
      _mm256_abs_epi16(_mm256_loadu_si256(reinterpret_cast<__m256i*>(d_ptr)));
  return _mm256_max_epi16(d, max);
}

// find out the max value inside a register by permutation
inline int16 MaxInsideYmm(__m256i maxes0) {
  __m256i perm_mask = _mm256_setr_epi32(4, 5, 6, 7, 0, 1, 2, 3);
  __m256i maxes1 = _mm256_permutevar8x32_epi32(maxes0, perm_mask);
  maxes0 = _mm256_max_epi16(maxes0, maxes1);
  perm_mask = _mm256_setr_epi32(2, 3, 0, 1, 4, 5, 6, 7);
  maxes1 = _mm256_permutevar8x32_epi32(maxes0, perm_mask);
  maxes0 = _mm256_max_epi16(maxes0, maxes1);
  perm_mask = _mm256_setr_epi32(1, 0, 2, 3, 4, 5, 6, 7);
  maxes1 = _mm256_permutevar8x32_epi32(maxes0, perm_mask);
  maxes0 = _mm256_max_epi16(maxes0, maxes1);
  int16 max0 = _mm256_extract_epi16(maxes0, 0);
  int16 max1 = _mm256_extract_epi16(maxes0, 1);
  return std::max(max0, max1);
}

void WaveFile::NormalizeWaveAVX2(vector<int16>* data, float volume,
                                 float ratio) {
  if (data->empty()) {
    return;
  }
  int16* d_ptr = data->data();
  int size = data->size();
  // 32 - 1 = 31
  int postamble_start = size - (size & 31);

  __m256i maxes0 = _mm256_set1_epi16(kint16min);
  __m256i maxes1 = _mm256_set1_epi16(kint16min);
  for (int i = 0; i < postamble_start; i += 32, d_ptr += 32) {
    maxes0 = AbsMax(d_ptr, maxes0);
    maxes1 = AbsMax(d_ptr + 16, maxes1);
  }
  if (postamble_start <= size - 16) {
    maxes0 = AbsMax(d_ptr, maxes0);
    postamble_start += 16;
  }
  maxes0 = _mm256_max_epi16(maxes0, maxes1);

  int16 data_max = MaxInsideYmm(maxes0);
  for (size_t i = postamble_start; i < data->size(); ++i) {
    auto abs_value = std::abs((*data)[i]);
    data_max = abs_value > data_max ? abs_value : data_max;
  }
  // avoid plosive in silence data
  if (data_max == 0) return;

  float threshold = kint16max;
  float factor = threshold / data_max;
  ratio = ratio == kNoNormalizeFactor ? factor : std::min(ratio, factor);
  volume = volume > kDefaultVolume ? kDefaultVolume : volume;
  d_ptr = data->data();
  const __m256 ratio_ps = _mm256_set1_ps(ratio);
  const __m256 volume_ps = _mm256_set1_ps(volume);
  postamble_start = size - (size & 31);
  for (int i = 0; i < postamble_start; i += 32, d_ptr += 32) {
    Normalize(d_ptr, ratio_ps, volume_ps);
    Normalize(d_ptr + 8, ratio_ps, volume_ps);
    Normalize(d_ptr + 16, ratio_ps, volume_ps);
    Normalize(d_ptr + 24, ratio_ps, volume_ps);
  }
  if (postamble_start <= size - 16) {
    Normalize(d_ptr, ratio_ps, volume_ps);
    Normalize(d_ptr + 8, ratio_ps, volume_ps);
    postamble_start += 16;
    d_ptr += 16;
  }
  if (postamble_start <= size - 8) {
    Normalize(d_ptr, ratio_ps, volume_ps);
    postamble_start += 8;
  }
  for (size_t i = postamble_start; i < data->size(); ++i) {
    float temp = (*data)[i] * ratio;
    (*data)[i] = static_cast<int16>(temp * volume);
  }
}
#endif  // TTS_USE_AVX2

#ifdef __ARM_NEON
inline int16x8_t AbsMax(int16* d_ptr, int16x8_t max) {
  // load 8xint16 data
  int16x8_t d = vld1q_s16(d_ptr);
  int16x8_t abs_d = vabsq_s16(d);
  return vmaxq_s16(abs_d, max);
}

inline int16 MaxInsideReg(int16x8_t max) {
#ifdef __aarch64__
  return vmaxvq_s16(max);
#else
  int16 arr[8];
  vst1q_s16(arr, max);
  int16 res = arr[0];
  for (int i = 1; i < 8; ++i) {
    res = arr[i] > res ? arr[i] : res;
  }
  return res;
#endif  // __aarch64__
}

inline void Normalize(int16* d_ptr, float ratio, float volume) {
  // load 4xint16 data --> 4xint32 --> 4xfloat32
  int16x4_t d_s16 = vld1_s16(d_ptr);
  int32x4_t d_s32 = vmovl_s16(d_s16);
  float32x4_t d_f32 = vcvtq_f32_s32(d_s32);
  float32x4_t data_norm = vmulq_n_f32(d_f32, ratio);
  float32x4_t data_vol = vmulq_n_f32(data_norm, volume);
  d_s32 = vcvtq_s32_f32(data_vol);
  d_s16 = vmovn_s32(d_s32);
  vst1_s16(d_ptr, d_s16);
}

void WaveFile::NormalizeWaveNeon(vector<int16>* data, float volume,
                                 float ratio) {
  if (data->empty()) {
    return;
  }

  int16* d_ptr = data->data();
  int size = data->size();
  // 16 - 1 = 15
  int postamble_start = size - (size & 15);

  int16x8_t maxes0 = vmovq_n_s16(kint16min);
  int16x8_t maxes1 = vmovq_n_s16(kint16min);
  for (int i = 0; i < postamble_start; i += 16, d_ptr += 16) {
    maxes0 = AbsMax(d_ptr, maxes0);
    maxes1 = AbsMax(d_ptr + 8, maxes1);
  }
  if (postamble_start <= size - 8) {
    maxes0 = AbsMax(d_ptr, maxes0);
    postamble_start += 8;
  }
  maxes0 = vmaxq_s16(maxes0, maxes1);
  int16 data_max = MaxInsideReg(maxes0);
  for (size_t i = postamble_start; i < data->size(); ++i) {
    auto abs_value = std::abs((*data)[i]);
    data_max = abs_value > data_max ? abs_value : data_max;
  }
  // avoid plosive in silence data
  if (data_max == 0) return;

  float threshold = kint16max;
  float factor = threshold / data_max;
  ratio = ratio == kNoNormalizeFactor ? factor : std::min(ratio, factor);
  volume = volume > kDefaultVolume ? kDefaultVolume : volume;
  d_ptr = data->data();
  postamble_start = size - (size & 15);
  for (int i = 0; i < postamble_start; i += 16, d_ptr += 16) {
    Normalize(d_ptr, ratio, volume);
    Normalize(d_ptr + 4, ratio, volume);
    Normalize(d_ptr + 8, ratio, volume);
    Normalize(d_ptr + 12, ratio, volume);
  }
  if (postamble_start <= size - 8) {
    Normalize(d_ptr, ratio, volume);
    Normalize(d_ptr + 4, ratio, volume);
    postamble_start += 8;
    d_ptr += 8;
  }
  if (postamble_start <= size - 4) {
    Normalize(d_ptr, ratio, volume);
    postamble_start += 4;
  }
  for (size_t i = postamble_start; i < data->size(); ++i) {
    float temp = (*data)[i] * ratio;
    (*data)[i] = static_cast<int16>(temp * volume);
  }
}
#endif  // __ARM_NEON

void WaveFile::NormalizeWave(vector<int16>* data, float volume, float ratio) {
  if (IsSilence(*data)) return;
#ifdef TTS_USE_AVX2
  NormalizeWaveAVX2(data, volume, ratio);
#elif defined __ARM_NEON
  NormalizeWaveNeon(data, volume, ratio);
#else
  NormalizeWaveVanilla(data, volume, ratio);
#endif  // TTS_USE_AVX2
}

#ifndef FOR_PORTABLE
// https://en.wikipedia.org/wiki/High-pass_filter
void WaveFile::HighPassFilterFixedPoint(const vector<int16>& signal_in,
                                        vector<int16>* signal_out) {
  const int16 b0_Q14 = 15915, b1_Q14 = -15915;
  const int16 a1_Q14 = -15446;
  int32 filter_state0 = 0, filter_state1 = 0;
  CHECK(!signal_in.empty()) << "signal input is empty";
  filter_state1 += b0_Q14 * signal_in[0];
  filter_state0 = filter_state1 - a1_Q14 * (filter_state0 >> 14);
  signal_out->push_back(filter_state0 >> 14);
  for (size_t i = 1; i < signal_in.size(); ++i) {
    int32 tmp = b0_Q14 * signal_in[i] + b1_Q14 * signal_in[i - 1];
    filter_state0 = tmp - a1_Q14 * (filter_state0 >> 14);
    signal_out->push_back(filter_state0 >> 14);
  }
}

void WaveFile::LowPassFilterFixedPoint(const vector<int16>& input, int cut_off,
                                       int sample_rate, vector<int16>* output) {
  double rc = 1.0 / (cut_off * 2 * 3.14);
  double dt = 1.0 / sample_rate;
  double alpha = dt / (rc + dt);
  output->reserve(input.size());
  output->push_back(input[0]);
  int pre = input[0];
  for (size_t i = 1; i < input.size(); ++i) {
    int cur = static_cast<int16>(pre + (alpha * (input[i] - pre)));
    output->push_back(cur);
    pre = cur;
  }
}
#endif
}  // namespace tts
