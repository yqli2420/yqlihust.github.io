// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_UTIL_TTS_UTIL_TEST_PERF_H_
#define TTS_UTIL_TTS_UTIL_TEST_PERF_H_

#include "mobvoi/base/basictypes.h"

namespace tts {

class TestPerf {
 public:
  TestPerf() : tp_(0), tn_(0), fp_(0), fn_(0) {}
  ~TestPerf() {}

  void add_tp(int n = 1) { tp_ += n; }
  void add_tn(int n = 1) { tn_ += n; }
  void add_fp(int n = 1) { fp_ += n; }
  void add_fn(int n = 1) { fn_ += n; }

  float Accuracy() const;
  float Precise() const;
  float Recall() const;

 private:
  int tp_;  // true positive
  int tn_;  // true negative
  int fp_;  // false positive
  int fn_;  // false negative
  DISALLOW_COPY_AND_ASSIGN(TestPerf);
};

}  // namespace tts

#endif  // TTS_UTIL_TTS_UTIL_TEST_PERF_H_
