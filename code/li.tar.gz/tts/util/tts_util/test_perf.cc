// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/util/tts_util/test_perf.h"
#include "mobvoi/base/log.h"

namespace tts {

float TestPerf::Accuracy() const {
  int all = tp_ + tn_ + fp_ + fn_;
  if (all) {
    LOG(INFO) << tp_ + tn_ << " / " << all;
    return static_cast<float>(tp_ + tn_) / all;
  }
  return 0.0;
}

float TestPerf::Precise() const {
  int tpfp = tp_ + fp_;
  if (tpfp) {
    LOG(INFO) << tp_ << " / " << tpfp;
    return static_cast<float>(tp_) / tpfp;
  }
  return 0.0;
}

float TestPerf::Recall() const {
  int tpfn = tp_ + fn_;
  if (tpfn) {
    LOG(INFO) << tp_ << " / " << tpfn;
    return static_cast<float>(tp_) / tpfn;
  }
  return 0.0;
}

}  // namespace tts
