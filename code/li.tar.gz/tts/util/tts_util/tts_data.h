// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_UTIL_TTS_UTIL_TTS_DATA_H_
#define TTS_UTIL_TTS_UTIL_TTS_DATA_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "third_party/jsoncpp/json.h"
#include "tts/synthesizer/proto/tts.pb.h"

namespace tts {

struct TnMapping {
  TnMapping(int _offset, const string& _input, const string& _output,
            const string& _name)
      : offset(_offset), input(_input), output(_output), name(_name) {}
  int offset;
  string input;
  string output;
  string name;
  map<string, string> candidates;
};

struct TnDetail {
  void Display();
  void Format();
  string tn_input;
  string tn_output;
  vector<TnMapping> tn_mappings;
};

struct RawData {
  vector<int16> data;
  vector<string> phonemes;
  vector<int> durations;
  vector<float> feature;
  vector<Json::Value> debug_infos;
  vector<TnDetail> tn_details;
};

void AppendRawData(const RawData& from, RawData* to);
void JsonWrapper(const RawData& raw_data, const TTSOption& tts_option,
                 string* data_res);

template <class T>
void VecFastAppend(const vector<T>& from, vector<T>* to) {
  to->reserve(to->size() + from.size());
  to->insert(to->end(), from.begin(), from.end());
}
}  // namespace tts
#endif  // TTS_UTIL_TTS_UTIL_TTS_DATA_H_
