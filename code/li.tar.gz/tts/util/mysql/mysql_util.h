// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_UTIL_MYSQL_MYSQL_UTIL_H_
#define TTS_UTIL_MYSQL_MYSQL_UTIL_H_

#include "mobvoi/base/basictypes.h"

namespace sql {
class ResultSet;
}  // namespace sql

namespace Json {
class Value;
}  // namespace Json

namespace util {

class MysqlUtil {
 public:
  static void MysqlRecordToJson(sql::ResultSet* res, Json::Value* data);

 private:
  DECLARE_STATIC_CLASS(MysqlUtil);
};
}  // namespace util
#endif  // TTS_UTIL_MYSQL_MYSQL_UTIL_H_
