// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaoqin.feng@mobvoi.com

#ifndef TTS_UTIL_CRF_CRF_H_
#define TTS_UTIL_CRF_CRF_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "third_party/crf/crfpp.h"
#include "third_party/crf/tagger.h"

namespace CRFPP {
class TaggerImpl;
class DecoderFeatureIndex;
}  // namespace CRFPP

namespace crf {

class CrfModel {
 public:
  explicit CrfModel(const string& crf_file);
  ~CrfModel();

  void LoadModel(const string& crf_file);
  void LoadCrfModel(const int size, const char* model,
                    CRFPP::DecoderFeatureIndex* decoder_feature) const;
  bool DoCrfPred(const int model_level, const vector<string> feat_lines,
                 vector<string>* pred_result) const;
  bool DoCrfPred(const int model_level, const vector<string> feat_lines,
                 vector<string>* pred_resul,
                 vector<map<string, float>>* top_result) const;

  CRFPP::DecoderFeatureIndex* DecoderFeatureIndex(int model_level) const {
    return decoder_feature_list_[model_level].get();
  }
  double DecoderModelFactor(const int model_level) const {
    return decoder_model_factor_[model_level];
  }
  int GetModelLevel() const { return total_model_level_; }

 private:
  vector<unique_ptr<CRFPP::DecoderFeatureIndex>> decoder_feature_list_;
  vector<double> decoder_model_factor_;
  int total_model_level_;
  vector<char*> model_string_;
  vector<int> model_size_;
  DISALLOW_COPY_AND_ASSIGN(CrfModel);
};

}  // namespace crf
#endif  // TTS_UTIL_CRF_CRF_H_
