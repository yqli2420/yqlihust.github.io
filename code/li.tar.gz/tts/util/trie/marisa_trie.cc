// Copyright 2016 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/util/trie/marisa_trie.h"

#include "mobvoi/base/log.h"
#include "mobvoi/base/file/simple_line_reader.h"

namespace trie {

MarisaTrie::MarisaTrie(const string& trie_file) {
  if (mobvoi::File::Exists(trie_file)) {
    trie_ = new marisa::Trie;
    trie_->load(trie_file.c_str());
    VLOG(2) << "marisa trie num keys :" << trie_->num_keys()
            << ", num nodes :" << trie_->num_nodes();
  }
  CHECK(trie_);
}

MarisaTrie::MarisaTrie(const vector<vector<util::Rune>>& marisa_words,
                       vector<int>* words_id) {
  trie_ = new marisa::Trie;
  marisa::Keyset keyset;
  for (auto& marisa_word : marisa_words) {
    string word;
    util::UnicodeToUtf8(marisa_word, &word);
    marisa::Key key;
    key.set_str(word.c_str());
    keyset.push_back(key);
  }
  trie_->build(keyset);
  words_id->resize(marisa_words.size());
  for (size_t i = 0; i < keyset.size(); ++i) {
    words_id->at(i) = keyset[i].id() + 1;
  }
  CHECK(trie_);
}

MarisaTrie::MarisaTrie(const vector<string>& marisa_words) {
  trie_ = new marisa::Trie;
  marisa::Keyset keyset;
  for (auto& marisa_word : marisa_words) {
    marisa::Key key;
    key.set_str(marisa_word.c_str());
    keyset.push_back(key);
  }

  trie_->build(keyset);
  CHECK(trie_);
}

MarisaTrie::~MarisaTrie() { delete trie_; }

int MarisaTrie::Find(vector<util::Rune>::const_iterator begin,
                     vector<util::Rune>::const_iterator end) const {
  marisa::Agent agent;
  string word_tmp;
  if (!util::UnicodeToUtf8(begin, end, &word_tmp)) {
    LOG(ERROR) << "Unicode convert to Utf8 failed !";
  }
  agent.set_query(word_tmp.c_str());
  if (!trie_->lookup(agent)) {
    return kNotFound;
  }
  return agent.key().id();
}

bool MarisaTrie::FindPrefix(vector<util::Rune>::const_iterator begin,
                            vector<util::Rune>::const_iterator end,
                            vector<DagNode>* dag) const {
  string words;
  if (!util::UnicodeToUtf8(begin, end, &words)) {
    LOG(ERROR) << "Unicode convert to Utf8 failed !";
    return false;
  }
  marisa::Agent agent;
  marisa::Keyset keyset;
  agent.set_query(words.c_str());
  while (trie_->common_prefix_search(agent)) {
    keyset.push_back(agent.key());
  }

  for (size_t i = 0; i < keyset.size(); ++i) {
    auto key = keyset[i];
    const string key_word = string(key.ptr(), key.length());
    dag->push_back(DagNode(key.id(), util::utflen(key_word.c_str())));
  }
  VLOG(3) << "Num of prefixes found = " << keyset.size();
  return dag->size();
}

void MarisaTrie::Save(const string& save_path) const {
  trie_->save(save_path.c_str());
}

MarisaTrie* ReadWordListToMarisa(const string& word_file) {
  if (!mobvoi::File::Exists(word_file)) {
    LOG(FATAL) << word_file << " not exist!";
    return nullptr;
  }
  vector<string> words;
  file::SimpleLineReader file_reader(word_file, true, "#");
  file_reader.ReadLines(&words);
  return new MarisaTrie(words);
}

}  // namespace trie
