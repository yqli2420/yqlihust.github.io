// Copyright 2016 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_UTIL_TRIE_MARISA_TRIE_H_
#define TTS_UTIL_TRIE_MARISA_TRIE_H_

#include "mobvoi/base/compat.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/util/utf8/utf8_util.h"
#include "third_party/marisa/trie.h"

namespace trie {

static const int kNotFound = -1;

struct DagNode {
  DagNode(int idx, int len) : id(idx), u_len(len) {}
  int id;
  int u_len;
};

class MarisaTrie {
 public:
  explicit MarisaTrie(const string& marisa_dict);
  // marisa trie will disorder input words, so if word id is nesessary, use
  // this construct function
  MarisaTrie(const vector<vector<util::Rune>>& marisa_words,
             vector<int>* words_id);
  explicit MarisaTrie(const vector<string>& marisa_words);
  ~MarisaTrie();

  int Find(vector<util::Rune>::const_iterator begin,
           vector<util::Rune>::const_iterator end) const;
  bool FindPrefix(vector<util::Rune>::const_iterator begin,
                  vector<util::Rune>::const_iterator end,
                  vector<DagNode>* dag) const;
  void Save(const string& save_path) const;

 private:
  marisa::Trie* trie_;
  string data_;
  DISALLOW_COPY_AND_ASSIGN(MarisaTrie);
};

// create trie from a word list file
MarisaTrie* ReadWordListToMarisa(const string& word_file);

}  // namespace trie
#endif  // TTS_UTIL_TRIE_MARISA_TRIE_H_
