// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com

#include "tts/util/ssml/tts_ssml_processor.h"

#include "mobvoi/base/log.h"
#include "mobvoi/util/url/encode/url_encode.h"
#include "third_party/xml2/libxml/parser.h"
#include "tts/util/ssml/tts_ssml_entity.h"

namespace mobvoi {

TtsSsmlProcessor::TtsSsmlProcessor() {}

TtsSsmlProcessor::~TtsSsmlProcessor() {}

bool TtsSsmlProcessor::Analyze(
    const std::string& synth_ssml,
    std::list<TtsSsmlEntity>* tts_ssml_entity_list) {
  if (synth_ssml.empty() || tts_ssml_entity_list == nullptr) return false;

  std::string synth_text = ReplaceString(synth_ssml, "\n", "");
  synth_text = ReplaceString(synth_text, "\r", "");
  VLOG(1) << "receive xml: " << synth_text;

  if (synth_text.find("<speak") == std::string::npos) {
    synth_text = "<speak>" + synth_text + "</speak>";
  }
  xmlKeepBlanksDefault(0);
  xmlDocPtr xml_doc = xmlParseMemory(synth_text.c_str(), synth_text.length());

  if (xml_doc == nullptr) {
    LOG(INFO) << "xml format parse error, process as text";
    TtsSsmlEntity ssml_entity;
    ssml_entity.SetSsmlText(synth_text);
    ssml_entity.SetSsmlLabel("text");
    tts_ssml_entity_list->push_back(ssml_entity);
    return true;
  }

  xmlNodePtr xml_cur = xmlDocGetRootElement(xml_doc);
  if (xml_cur == nullptr) {
    LOG(ERROR) << "xml get root element error!";
    return false;
  }

  if (xmlStrcmp(xml_cur->name, (const xmlChar *)"speak")) {
    LOG(ERROR) << "root name error, must be speak: " << xml_cur->name;
    return false;
  }

  SetAudioSaveUrl(GetPropFromSsml(xml_cur, "grammar"));
  AnalyzeSsmlText(xml_doc, xml_cur, nullptr, tts_ssml_entity_list);
  xmlFreeDoc(xml_doc);

  VLOG(1) << "ssml value before process: ";
  for (auto& it : *tts_ssml_entity_list) {
    VLOG(1) << "label: " << it.GetSsmlLabel()
            << ", speed: " << it.GetProsodyRate()
            << ", volume: " << it.GetProsodyVolume()
            << ", text: " << it.GetSsmlText()
            << ", ssml: " << it.GetValueAsSsml()
            << ", src: " << it.GetAudioSrc();
  }

  VLOG(1) << "ssml value after process: ";
  // 将挨在一起的tts类型的entity合并成一个，避免多次请求
  for (auto it1 = tts_ssml_entity_list->begin();
      it1 != tts_ssml_entity_list->end(); ++it1) {
    if (it1->GetSsmlLabel().compare("text") != 0) continue;
    auto it2 = it1;
    it2++;
    while (it2 != tts_ssml_entity_list->end()) {
      if (it2->GetSsmlLabel().compare("text") != 0
          || it2->GetProsodyRate().compare(it1->GetProsodyRate()) != 0
          || it2->GetProsodyVolume().compare(it1->GetProsodyVolume()) != 0
          || it2->GetVoiceName().compare(it1->GetVoiceName()) != 0) {
        break;
      }
      *it1 += *it2;
      it2 = tts_ssml_entity_list->erase(it2);
    }
  }

  for (auto& it : *tts_ssml_entity_list) {
    VLOG(1) << "label: " << it.GetSsmlLabel()
            << ", speed: " << it.GetProsodyRate()
            << ", volume: " << it.GetProsodyVolume()
            << ", text: " << it.GetSsmlText()
            << ", ssml: " << it.GetValueAsSsml()
            << ", src: " << it.GetAudioSrc();
  }

  return true;
}

bool TtsSsmlProcessor::AnalyzeSsmlText(
    xmlDocPtr xml_doc,
    xmlNodePtr xml_cur,
    TtsSsmlEntity* entity,
    std::list<TtsSsmlEntity>* tts_text_info_list) {
  if (xml_doc == nullptr ||
      xml_cur == nullptr) {
    return false;
  }
  xml_cur = xml_cur->xmlChildrenNode;
  if (xml_cur == nullptr) {
    return false;
  }

  while (xml_cur) {
    TtsSsmlEntity ssml_entity;
    if (entity != nullptr) {
      ssml_entity = *entity;
    } else {
      ssml_entity.SetProsodyRate(request_speed_);
      ssml_entity.SetVoiceName(request_speaker_);
      ssml_entity.SetResampleRate(request_sample_rate_);
    }
    TtsSsmlEntity* tts_ssml_entity = &ssml_entity;
    std::string ssml_label = GetNameFromSsml(xml_cur);
    tts_ssml_entity->SetSsmlLabel(ssml_label);
    tts_ssml_entity->SetSsmlContent(GetContentFromSsml(xml_doc, xml_cur));
    if (ssml_label.compare("text") == 0) {
      tts_ssml_entity->SetSsmlText(GetContentFromSsml(xml_doc, xml_cur));
    } else if (ssml_label.compare("audio") == 0) {
      tts_ssml_entity->SetAudioSrc(GetPropFromSsml(xml_cur, "src"));
    } else if (ssml_label.compare("break") == 0) {
      tts_ssml_entity->SetBreakStrength(GetPropFromSsml(xml_cur, "strength"));
      tts_ssml_entity->SetBreakTime(GetPropFromSsml(xml_cur, "time"));
    } else if (ssml_label.compare("emphasis") == 0) {
      tts_ssml_entity->SetEmphasisLevel(GetPropFromSsml(xml_cur, "level"));
    } else if (ssml_label.compare("lang") == 0) {
      tts_ssml_entity->SetLanguage(GetPropFromSsml(xml_cur, "xml:lang"));
    } else if (ssml_label.compare("p") == 0) {
    } else if (ssml_label.compare("phoneme") == 0) {
      tts_ssml_entity->SetPhonemeAlphabet(GetPropFromSsml(xml_cur, "alphabet"));
      tts_ssml_entity->SetPhonemePh(GetPropFromSsml(xml_cur, "ph"));
    } else if (ssml_label.compare("prosody") == 0) {
      tts_ssml_entity->SetProsodyRate(
          GetPropFromSsml(xml_cur, "rate", request_speed_));
      tts_ssml_entity->SetProsodyPitch(GetPropFromSsml(xml_cur, "pitch"));
      tts_ssml_entity->SetProsodyVolume(GetPropFromSsml(xml_cur, "volume"));
    } else if (ssml_label.compare("s") == 0) {
    } else if (ssml_label.compare("say-as") == 0) {
      tts_ssml_entity->SetSayAsInterpretAs(
          GetPropFromSsml(xml_cur, "interpret-as"));
      tts_ssml_entity->SetSayAsFormat(GetPropFromSsml(xml_cur, "format"));
    } else if (ssml_label.compare("sub") == 0) {
      tts_ssml_entity->SetSubAlias(GetPropFromSsml(xml_cur, "alias"));
    } else if (ssml_label.compare("voice") == 0) {
      tts_ssml_entity->SetVoiceName(
          GetPropFromSsml(xml_cur, "name", request_speaker_));
    } else if (ssml_label.compare("w") == 0) {
      tts_ssml_entity->SetWRole(GetPropFromSsml(xml_cur, "role"));
      tts_ssml_entity->SetWPhoneme(GetPropFromSsml(xml_cur, "phoneme"));
    }
    if (!tts_ssml_entity->GetSsmlText().empty() ||
        !tts_ssml_entity->GetAudioSrc().empty() ||
        !tts_ssml_entity->GetBreakTime().empty()) {
      tts_text_info_list->push_back(*tts_ssml_entity);
      tts_ssml_entity->SetSsmlText("");
      tts_ssml_entity->SetAudioSrc("");
      tts_ssml_entity->SetBreakTime("");
    }
    AnalyzeSsmlText(xml_doc, xml_cur, tts_ssml_entity, tts_text_info_list);
    xml_cur = xml_cur->next;
  }
  return true;
}

std::string TtsSsmlProcessor::GetPropFromSsml(
    xmlNodePtr xml_cur, const char* key, const std::string& default_value) {
  if (xml_cur == nullptr || key == nullptr) return "";
  std::string result = default_value;
  xmlChar* tmp = xmlGetProp(xml_cur, reinterpret_cast<const xmlChar*>(key));
  if (tmp != nullptr)  {
    result = TrimString(std::string(reinterpret_cast<const char*>(tmp)));
  } else {
    LOG(WARNING) << "get prop nullptr: key: " << key;
  }
  xmlFree(tmp);
  return result;
}

std::string TtsSsmlProcessor::GetStringFromSsml(
    xmlDocPtr xml_doc, xmlNodePtr xml_cur) {
  if (xml_doc == nullptr || xml_cur == nullptr) return "";
  std::string result = "";
  xmlChar* tmp = xmlNodeListGetString(xml_doc, xml_cur->xmlChildrenNode, 1);
  if (tmp != nullptr)  {
    result = TrimString(std::string(reinterpret_cast<const char*>(tmp)));
  }
  xmlFree(tmp);
  return result;
}

std::string TtsSsmlProcessor::GetContentFromSsml(
    xmlDocPtr xml_doc, xmlNodePtr xml_cur) {
  if (xml_doc == nullptr || xml_cur == nullptr) return "";
  std::string result = "";
  xmlChar* tmp = xmlNodeGetContent(xml_cur);
  if (tmp != nullptr) {
    result = TrimString(std::string(reinterpret_cast<const char*>(tmp)));
  }
  xmlFree(tmp);
  return result;
}

std::string TtsSsmlProcessor::GetNameFromSsml(xmlNodePtr xml_cur) {
  if (xml_cur == nullptr) return "";
  return std::string((const char*)xml_cur->name);
}

std::string TtsSsmlProcessor::ReplaceString(
    const std::string& str,
    const std::string& str_src,
    const std::string& str_dst) {
  std::string::size_type pos = 0;
  std::string::size_type len_src = str_src.size();
  std::string::size_type len_dst = str_dst.size();

  std::string result = str;
  pos = result.find(str_src, pos);
  while (pos != std::string::npos) {
    result.replace(pos, len_src, str_dst);
    pos = result.find(str_src, pos + len_dst);
  }
  return result;
}

void TtsSsmlProcessor::SetRequestSpeed(const std::string& value) {
  request_speed_ = value;
}

void TtsSsmlProcessor::SetRequestSpeaker(const std::string& value) {
  request_speaker_ = value;
}

void TtsSsmlProcessor::SetRequestSampleRate(int sample_rate) {
  request_sample_rate_ = sample_rate;
}

void TtsSsmlProcessor::SetAudioSaveUrl(const std::string& audio_save_url) {
  if (audio_save_url.empty()) {
    VLOG(1) << "audio save url is set empty";
    return;
  }
  if (audio_save_url.find("http://") != 0) {
    LOG(ERROR) << "audio save url format error: must begin with 'http://': "
               << audio_save_url;
    return;
  } else {
    LOG(INFO) << "set audio save url: " << audio_save_url;
  }
  std::string url = audio_save_url;
  std::size_t index1 = url.find("question=");
  if (index1 != std::string::npos) {
    std::size_t index2 = url.find("&", index1);
    if (index2 != std::string::npos) {
      url = url.substr(0, index1 + 9)
          + util::UrlEncodeString(url.substr(index1 + 9, index2 - index1 - 9))
          + url.substr(index2);
    } else {
      url = url.substr(0, index1 + 9)
          + util::UrlEncodeString(url.substr(index1 + 9));
    }
  }
  audio_save_url_ = url;
  LOG(INFO) << "wav save url: " << audio_save_url_;
}

std::string TtsSsmlProcessor::GetAudioSaveUrl() {
  return audio_save_url_;
}

std::string TtsSsmlProcessor::TrimString(const std::string& str) {
  int start_pos = 0;
  int end_pos = str.length() - 1;
  for (int i = 0; i < str.length(); ++i) {
    if (str[i] != ' ') {
      start_pos = i;
      break;
    }
  }
  for (int i = str.length() - 1; i >= start_pos; --i) {
    if (str[i] != ' ') {
      end_pos = i;
      break;
    }
  }
  if (start_pos <= end_pos) {
    return str.substr(start_pos, end_pos - start_pos + 1);
  }
  return "";
}

}  // namespace mobvoi
