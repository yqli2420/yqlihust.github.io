// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com

#include "tts/util/ssml/tts_ssml_entity.h"

#include <math.h>

#include "mobvoi/base/log.h"
#include "tts/server/grpc/synth_config.h"

DEFINE_string(synth_rate_default, "1.0", "synth rate default");
DEFINE_string(synth_rate_x_slow, "1.0", "synth rate x-slow value");
DEFINE_string(synth_rate_slow, "1.0", "synth rate slow value");
DEFINE_string(synth_rate_medium, "1.0", "synth rate medium value");
DEFINE_string(synth_rate_fast, "1.0", "synth rate flst value");
DEFINE_string(synth_rate_x_fast, "1.0", "synth rate x-fast value");

DEFINE_string(synth_volume_default, "1.0", "synth volume default ");
DEFINE_string(synth_volume_silent, "1.0", "synth volume silent value");
DEFINE_string(synth_volume_x_soft, "1.0", "synth volume x-soft value");
DEFINE_string(synth_volume_soft, "1.0", "synth volume soft value");
DEFINE_string(synth_volume_medium, "1.0", "synth volume medium value");
DEFINE_string(synth_volume_loud, "1.0", "synth volume loud value");
DEFINE_string(synth_volume_x_loud, "1.0", "synth volume loud value");

DEFINE_string(synth_break_default, "0.0", "synth break default");
DEFINE_string(synth_break_weak, "0.0", "synth break weak value");
DEFINE_string(synth_break_medium, "0.0", "synth break medium value");
DEFINE_string(synth_break_strong, "0.0", "synth break strong value");
DEFINE_string(synth_break_x_strong, "0.0", "synth break x-strong value");

DEFINE_string(synth_voice_name, "cissy", "synth volume loud value");

namespace mobvoi {

TtsSsmlEntity::TtsSsmlEntity()
    : audio_output_index_(0),
      audio_append_finished_(false),
      resample_rate_(0),
      error_flag_(false),
      valid_flag_(true) {
  prosody_rate_ = FLAGS_synth_rate_default;
  prosody_volume_ = FLAGS_synth_volume_default;
  voice_name_ = FLAGS_synth_voice_name;
}

TtsSsmlEntity::~TtsSsmlEntity() {}

bool TtsSsmlEntity::operator==(const TtsSsmlEntity& entity) const {
  return (audio_data_.compare(entity.audio_data_) == 0 &&
          audio_src_.compare(entity.audio_src_) == 0 &&
          break_strength_.compare(entity.break_strength_) == 0 &&
          break_time_.compare(entity.break_time_) == 0 &&
          emphasis_level_.compare(entity.emphasis_level_) == 0 &&
          language_.compare(entity.language_) == 0 &&
          phoneme_alphabet_.compare(entity.phoneme_alphabet_) == 0 &&
          phoneme_ph_.compare(entity.phoneme_ph_) == 0 &&
          prosody_pitch_.compare(entity.prosody_pitch_) == 0 &&
          prosody_rate_.compare(entity.prosody_rate_) == 0 &&
          prosody_volume_.compare(entity.prosody_volume_) == 0 &&
          say_as_format_.compare(entity.say_as_format_) == 0 &&
          say_as_interpret_as_.compare(entity.say_as_interpret_as_) == 0 &&
          ssml_label_.compare(entity.ssml_label_) == 0 &&
          ssml_text_.compare(entity.ssml_text_) == 0
          // && ssml_content_.compare(entity.ssml_content_) == 0
          && sub_alias_.compare(entity.sub_alias_) == 0 &&
          voice_name_.compare(entity.voice_name_) == 0 &&
          w_role_.compare(entity.w_role_) == 0);
}

TtsSsmlEntity& TtsSsmlEntity::operator+=(const TtsSsmlEntity& entity) {
  std::string ssml_text = entity.GetValueAsSsml();
  if (ssml_label_.compare("text") != 0 ||
      entity.ssml_label_.compare("text") != 0 ||
      prosody_rate_.compare(entity.prosody_rate_) != 0 ||
      prosody_volume_.compare(entity.prosody_volume_) != 0)
    return *this;

  std::string ssml_value1 = this->GetValueAsSsml();
  std::string ssml_value2 = entity.GetValueAsSsml();
  MutexLock lock(&mutex_);
  this->ssml_value_list_.clear();
  this->text_value_list_.clear();
  ssml_value_list_.push_back(ssml_value1);
  ssml_value_list_.push_back(ssml_value2);
  text_value_list_.push_back(this->ssml_text_);
  text_value_list_.push_back(entity.ssml_text_);
  ssml_text_ += entity.ssml_text_;
  return *this;
}

std::string TtsSsmlEntity::GetOutputAudioData(int length) {
  if (length <= 0) return "";
  if (GetAudioLength() < audio_output_index_) {
    LOG(INFO) << "audio output index overflow!";
    return "";
  }
  int tmp = GetAudioLength() - audio_output_index_;
  this->Lock();
  int len = std::min(length, tmp);
  std::string result = audio_data_.substr(audio_output_index_, len);
  this->Unlock();
  audio_output_index_ += len;
  return result;
}

void TtsSsmlEntity::AppendAudioData(const std::string& audio_data) {
  if (audio_data.empty()) return;
  this->Lock();
  this->audio_data_ += audio_data;
  this->Unlock();
}

void TtsSsmlEntity::SetAppendAudioFinished(bool audio_append_finished) {
  this->Lock();
  this->audio_append_finished_ = audio_append_finished;
  this->Unlock();
}

std::string TtsSsmlEntity::GetValueAsSsml() const {
  MutexLock lock(&mutex_);
  if (ssml_label_.compare("audio") == 0 || ssml_label_.compare("break") == 0 ||
      ssml_text_.empty())
    return "";

  std::stringstream result;
  if (!ssml_value_list_.empty()) {
    for (const auto& val : ssml_value_list_) {
      result << val;
    }
    return result.str();
  }

  std::list<std::string> begin_list;
  std::list<std::string> end_list;

  if (!(say_as_interpret_as_.empty() && say_as_format_.empty())) {
    std::stringstream ss;
    ss << "<say-as";
    if (!say_as_interpret_as_.empty()) {
      ss << " interpret-as='" << say_as_interpret_as_ << "'";
    }
    if (!say_as_format_.empty()) {
      ss << " format='" << say_as_format_ << "'";
    }
    ss << ">";
    begin_list.push_back(ss.str());
    end_list.push_front("</say-as>");
  }

  if (!(w_phoneme_.empty() && w_role_.empty())) {
    std::stringstream ss;
    ss << "<w";
    if (!w_phoneme_.empty()) {
      ss << " phoneme='" << w_phoneme_ << "'";
    }
    if (!w_role_.empty()) {
      ss << " role='" << w_role_ << "'";
    }
    ss << ">";
    begin_list.push_back(ss.str());
    end_list.push_front("</w>");
  }
  // result << "<speak>";
  if (!begin_list.empty()) {
    for (const auto& it : begin_list) {
      result << it;
    }
  }
  result << ssml_text_;
  if (!end_list.empty()) {
    for (const auto& it : end_list) {
      result << it;
    }
  }
  ssml_value_list_.push_back(result.str());
  // result << "</speak>";
  return result.str();
}

void TtsSsmlEntity::Lock() { mutex_.Lock(); }

void TtsSsmlEntity::Unlock() { mutex_.Unlock(); }

const TtsSsmlEntity& TtsSsmlEntity::Clear() {
  audio_data_ = "";

  ssml_label_ = "";
  ssml_text_ = "";
  ssml_content_ = "";

  audio_src_ = "";
  amazon_effect_name_ = "";
  break_strength_ = "";
  break_time_ = "";
  emphasis_level_ = "";
  language_ = "";
  phoneme_alphabet_ = "";
  phoneme_ph_ = "";
  prosody_rate_ = FLAGS_synth_rate_default;
  prosody_pitch_ = "";
  prosody_volume_ = FLAGS_synth_volume_default;
  say_as_interpret_as_ = "";
  say_as_format_ = "";
  sub_alias_ = "";
  voice_name_ = FLAGS_synth_voice_name;
  w_role_ = "";

  ssml_value_list_.clear();
  text_value_list_.clear();
  audio_output_index_ = 0;
  error_flag_ = false;
  return *this;
}

int TtsSsmlEntity::GetAudioLength() {
  this->Lock();
  int result = this->audio_data_.length();
  this->Unlock();
  return result;
}

bool TtsSsmlEntity::IsAudioOutputFinished() {
  this->Lock();
  bool result = false;
  if (error_flag_) {
    result = true;
  } else if (audio_data_.empty()) {
    result = false;
  } else {
    result = audio_append_finished_ &&
        (audio_output_index_ >= audio_data_.length() - 1);
  }
  this->Unlock();
  return result;
}

void TtsSsmlEntity::SetResampleRate(int resample_rate) {
  MutexLock lock(&mutex_);
  resample_rate_ = resample_rate;
}

int TtsSsmlEntity::GetResampleRate() {
  MutexLock lock(&mutex_);
  return resample_rate_;
}

void TtsSsmlEntity::SetErrorFlag(bool error_flag) {
  this->Lock();
  this->error_flag_ = error_flag;
  this->Unlock();
}

bool TtsSsmlEntity::GetErrorFlag() {
  this->Lock();
  bool result = error_flag_;
  this->Unlock();
  return result;
}

int TtsSsmlEntity::GetAudioOutputIndex() {
  this->Lock();
  int result = audio_output_index_;
  this->Unlock();
  return result;
}

std::string TtsSsmlEntity::GetAudioData() {
  MutexLock lock(&mutex_);
  return audio_data_;
}

bool TtsSsmlEntity::GetValidFlag() {
  MutexLock lock(&mutex_);
  return valid_flag_;
}

void TtsSsmlEntity::SetValidFlag(bool flag) {
  MutexLock lock(&mutex_);
  valid_flag_ = flag;
}

std::string TtsSsmlEntity::GetDefaultVoiceName() {
  MutexLock lock(&mutex_);
  return FLAGS_synth_voice_name;
}

std::string TtsSsmlEntity::GetDefaultSynthRate() {
  MutexLock lock(&mutex_);
  return FLAGS_synth_rate_default;
}

std::string TtsSsmlEntity::GetSsmlLabel() {
  MutexLock lock(&mutex_);
  return ssml_label_;
}

std::string TtsSsmlEntity::GetSsmlText() {
  MutexLock lock(&mutex_);
  std::string res = "";
  if (!text_value_list_.empty()) {
    for (const auto& val : text_value_list_) {
      res += val;
    }
    return res;
  }
  return ssml_text_;
}

std::string TtsSsmlEntity::GetSsmlContent() {
  MutexLock lock(&mutex_);
  return ssml_content_;
}

std::string TtsSsmlEntity::GetAudioSrc() {
  MutexLock lock(&mutex_);
  return audio_src_;
}

std::string TtsSsmlEntity::GetBreakStrength() {
  MutexLock lock(&mutex_);
  return break_strength_;
}

std::string TtsSsmlEntity::GetBreakTime() {
  MutexLock lock(&mutex_);
  return break_time_;
}

std::string TtsSsmlEntity::GetEmphasisLevel() {
  MutexLock lock(&mutex_);
  return emphasis_level_;
}

std::string TtsSsmlEntity::GetLanguage() {
  MutexLock lock(&mutex_);
  return language_;
}

std::string TtsSsmlEntity::GetPhonemeAlphabet() {
  MutexLock lock(&mutex_);
  return phoneme_alphabet_;
}

std::string TtsSsmlEntity::GetPhonemePh() {
  MutexLock lock(&mutex_);
  return phoneme_ph_;
}

std::string TtsSsmlEntity::GetProsodyRate() {
  MutexLock lock(&mutex_);
  return prosody_rate_;
}

std::string TtsSsmlEntity::GetProsodyPitch() {
  MutexLock lock(&mutex_);
  return prosody_pitch_;
}

std::string TtsSsmlEntity::GetProsodyVolume() {
  MutexLock lock(&mutex_);
  return prosody_volume_;
}

std::string TtsSsmlEntity::GetSayAsInterpretAs() {
  MutexLock lock(&mutex_);
  return say_as_interpret_as_;
}

std::string TtsSsmlEntity::GetSayAsFormat() {
  MutexLock lock(&mutex_);
  return say_as_format_;
}

std::string TtsSsmlEntity::GetSubAlias() {
  MutexLock lock(&mutex_);
  return sub_alias_;
}

std::string TtsSsmlEntity::GetVoiceName() {
  MutexLock lock(&mutex_);
  return voice_name_;
}

std::string TtsSsmlEntity::GetWRole() {
  MutexLock lock(&mutex_);
  return w_role_;
}

void TtsSsmlEntity::SetAudioData(const std::string& value) {
  MutexLock lock(&mutex_);
  audio_data_ = value;
}

void TtsSsmlEntity::SetSsmlLabel(const std::string& value) {
  MutexLock lock(&mutex_);
  ssml_label_ = value;
}

void TtsSsmlEntity::SetSsmlText(const std::string& value) {
  MutexLock lock(&mutex_);
  ssml_text_ = value;
  text_value_list_.push_back(value);
}

void TtsSsmlEntity::SetSsmlContent(const std::string& value) {
  MutexLock lock(&mutex_);
  ssml_content_ = value;
}

void TtsSsmlEntity::SetAudioSrc(const std::string& value) {
  MutexLock lock(&mutex_);
  audio_src_ = value;
}

void TtsSsmlEntity::SetBreakStrength(const std::string& value) {
  MutexLock lock(&mutex_);
  if (value.compare("weak") == 0) {
    break_time_ = FLAGS_synth_break_weak;
  } else if (value.compare("medium") == 0) {
    break_time_ = FLAGS_synth_break_medium;
  } else if (value.compare("strong") == 0) {
    break_time_ = FLAGS_synth_break_strong;
  } else if (value.compare("x-strong") == 0) {
    break_time_ = FLAGS_synth_break_x_strong;
  }
  if (atoi(break_time_.c_str()) <= 0) {
    break_time_ = "";
  }
  break_strength_ = value;
}

void TtsSsmlEntity::SetBreakTime(const std::string& value) {
  MutexLock lock(&mutex_);
  int break_time = 0;  // ms
  int index = 0;
  if ((index = value.find("ms")) != std::string::npos) {
    std::string val = value.substr(0, index);
    break_time = atoi(val.c_str());
  } else if ((index = value.find("s")) != std::string::npos) {
    std::string val = value.substr(0, index);
    break_time = static_cast<int>(atof(val.c_str()) * 1000);
  } else {
    break_time = static_cast<int>(atof(value.c_str()) * 1000);
  }

  if (break_time > 0) {
    std::stringstream ss;
    ss << break_time;
    break_time_ = ss.str();
  } else {
    break_time_ = "";
  }
}

void TtsSsmlEntity::SetEmphasisLevel(const std::string& value) {
  MutexLock lock(&mutex_);
  emphasis_level_ = value;
}

void TtsSsmlEntity::SetLanguage(const std::string& value) {
  MutexLock lock(&mutex_);
  language_ = value;
}

void TtsSsmlEntity::SetPhonemeAlphabet(const std::string& value) {
  MutexLock lock(&mutex_);
  phoneme_alphabet_ = value;
}

void TtsSsmlEntity::SetPhonemePh(const std::string& value) {
  MutexLock lock(&mutex_);
  phoneme_ph_ = value;
}

void TtsSsmlEntity::SetProsodyRate(const std::string& value) {
  MutexLock lock(&mutex_);
  if (value.empty()) {
    prosody_rate_ = SynthConfig::GetValueAsString("synth_rate_default");
    if (prosody_rate_.empty()) {
      prosody_rate_ = FLAGS_synth_rate_default;
    }
  } else if (value.compare("x-slow") == 0) {
    prosody_rate_ = SynthConfig::GetValueAsString("synth_rate_x_slow");
    if (prosody_rate_.empty()) {
      prosody_rate_ = FLAGS_synth_rate_x_slow;
    }
  } else if (value.compare("slow") == 0) {
    prosody_rate_ = SynthConfig::GetValueAsString("synth_rate_slow");
    if (prosody_rate_.empty()) {
      prosody_rate_ = FLAGS_synth_rate_slow;
    }
  } else if (value.compare("medium") == 0) {
    prosody_rate_ = SynthConfig::GetValueAsString("synth_rate_medium");
    if (prosody_rate_.empty()) {
      prosody_rate_ = FLAGS_synth_rate_medium;
    }
  } else if (value.compare("fast") == 0) {
    prosody_rate_ = SynthConfig::GetValueAsString("synth_rate_fast");
    if (prosody_rate_.empty()) {
      prosody_rate_ = FLAGS_synth_rate_fast;
    }
  } else if (value.compare("x-fast") == 0) {
    prosody_rate_ = SynthConfig::GetValueAsString("synth_rate_x_fast");
    if (prosody_rate_.empty()) {
      prosody_rate_ = FLAGS_synth_rate_x_fast;
    }
  } else {
    int index = 0;
    std::string tmp = "";
    if ((index = value.find_first_of("%")) != std::string::npos) {
      tmp = value.substr(0, index);
    } else {
      tmp = value;
    }
    double val = atof(tmp.c_str());
    if (val < 0) {
      LOG(ERROR) << "prosody rate set error: " << value;
      prosody_rate_ = FLAGS_synth_rate_default;
    } else {
      prosody_rate_ = value;
    }
  }
}

void TtsSsmlEntity::SetProsodyPitch(const std::string& value) {
  MutexLock lock(&mutex_);
  prosody_pitch_ = value;
}

void TtsSsmlEntity::SetProsodyVolume(const std::string& value) {
  MutexLock lock(&mutex_);
  if (value.empty()) {
    prosody_volume_ = SynthConfig::GetValueAsString("synth_volume_default");
    if (prosody_volume_.empty()) {
      prosody_volume_ = FLAGS_synth_volume_default;
    }
  } else if (value.compare("silent") == 0) {
    prosody_volume_ = SynthConfig::GetValueAsString("synth_volume_silent");
    if (prosody_volume_.empty()) {
      prosody_volume_ = FLAGS_synth_volume_silent;
    }
  } else if (value.compare("x-soft") == 0) {
    prosody_volume_ = SynthConfig::GetValueAsString("synth_volume_x_soft");
    if (prosody_volume_.empty()) {
      prosody_volume_ = FLAGS_synth_volume_x_soft;
    }
  } else if (value.compare("soft") == 0) {
    prosody_volume_ = SynthConfig::GetValueAsString("synth_volume_soft");
    if (prosody_volume_.empty()) {
      prosody_volume_ = FLAGS_synth_volume_soft;
    }
  } else if (value.compare("medium") == 0) {
    prosody_volume_ = SynthConfig::GetValueAsString("synth_volume_medium");
    if (prosody_volume_.empty()) {
      prosody_volume_ = FLAGS_synth_volume_medium;
    }
  } else if (value.compare("loud") == 0) {
    prosody_volume_ = SynthConfig::GetValueAsString("synth_volume_loud");
    if (prosody_volume_.empty()) {
      prosody_volume_ = FLAGS_synth_volume_loud;
    }
  } else if (value.compare("x-loud") == 0) {
    prosody_volume_ = SynthConfig::GetValueAsString("synth_volume_x_loud");
    if (prosody_volume_.empty()) {
      prosody_volume_ = FLAGS_synth_volume_x_loud;
    }
  } else {
    int index1 = 0;
    int index2 = 0;
    std::string tmp = "";

    if ((index2 = value.find_first_of("db")) != std::string::npos) {
      // convert from db to amplification
      if ((index1 = value.find_last_of("+")) != std::string::npos) {
        tmp = value.substr(index1 + 1, index2 - index1 - 1);
        double tmp_value_db = atof(tmp.c_str());
        double tmp_value = pow(10, tmp_value_db / 20);
        tmp = std::to_string(tmp_value);
      } else if ((index1 = value.find_last_of("-")) != std::string::npos) {
        tmp = value.substr(index1 + 1, index2 - index1 - 1);
        double tmp_value_db = atof(tmp.c_str());
        double tmp_value = pow(10, -tmp_value_db / 20);
        tmp = std::to_string(tmp_value);
      } else {
        tmp = value.substr(0, index2);
        double tmp_value_db = atof(tmp.c_str());
        double tmp_value = pow(10, tmp_value_db / 20);
        tmp = std::to_string(tmp_value);
      }
    } else {
      tmp = value;
    }
    double val = atof(tmp.c_str());
    if (val < 0) {
      LOG(ERROR) << "prosody rate set error: " << value;
      prosody_volume_ = FLAGS_synth_rate_default;
    } else {
      prosody_volume_ = value;
    }
  }
}

void TtsSsmlEntity::SetSayAsInterpretAs(const std::string& value) {
  MutexLock lock(&mutex_);
  say_as_interpret_as_ = value;
}

void TtsSsmlEntity::SetSayAsFormat(const std::string& value) {
  MutexLock lock(&mutex_);
  say_as_format_ = value;
}

void TtsSsmlEntity::SetSubAlias(const std::string& value) {
  MutexLock lock(&mutex_);
  sub_alias_ = value;
}

void TtsSsmlEntity::SetVoiceName(const std::string& value) {
  MutexLock lock(&mutex_);
  if (value.empty()) {
    voice_name_ = SynthConfig::GetValueAsString("synth_voice_name");
    if (voice_name_.empty()) {
      voice_name_ = FLAGS_synth_voice_name;
    }
  } else {
    voice_name_ = value;
  }
}

void TtsSsmlEntity::SetWRole(const std::string& value) {
  MutexLock lock(&mutex_);
  w_role_ = value;
}

void TtsSsmlEntity::SetWPhoneme(const std::string& value) {
  MutexLock lock(&mutex_);
  w_phoneme_ = value;
}

}  // namespace mobvoi
