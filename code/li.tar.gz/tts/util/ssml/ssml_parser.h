// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_UTIL_SSML_SSML_PARSER_H_
#define TTS_UTIL_SSML_SSML_PARSER_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "third_party/gtest/gtest_prod.h"
#include "third_party/jsoncpp/json.h"
#include "third_party/xml2/libxml/parser.h"

namespace tts {

// TODO(zhengzhang): add switch to control ssml parser on or off
struct SsmlTag {
  explicit SsmlTag(const string& _name = "") : name(_name) {}
  void clear() {
    name.clear();
    attrs.clear();
  }
  string name;
  std::map<string, string> attrs;
};
string LogSsmlTag(const SsmlTag& tag);

struct SsmlText {
  explicit SsmlText(const string& _text, const SsmlTag& _tag = SsmlTag())
      : text(_text), tag(_tag) {}
  string text;
  SsmlTag tag;
};
string LogOneSsml(const SsmlText& ssml_text);
string NodeToString(const xmlNode& node);

class SsmlParser {
 public:
  static SsmlParser& Instance();

  // ssml parser api
  void ParseText(const string& text, vector<SsmlText>* ssml_texts);
  void ParseText(const string& text, const string& key_name,
                 vector<SsmlText>* ssml_texts);
  SsmlText GenBreakSsmlText(int ms = 1000);

  void LogSsml(const vector<SsmlText>& ssml_texts);
  string JoinText(const vector<SsmlText>& ssml_texts);
  bool IsSsmlFast(const string& text);
  bool IsSsml(const string& text, xmlDocPtr* doc);
  int CountWordNum(const string& text);

 private:
  SsmlParser() = default;
  void ParseSsml(const xmlDocPtr& doc, vector<SsmlText>* ssml_texts);
  void ParseSsml(const xmlDocPtr& doc, const string& key_name,
                 vector<SsmlText>* ssml_texts);
  // replace <::> to ssml and so on
  void ReplaceBreakTag(const vector<SsmlText>& input, vector<SsmlText>* result);
  void RestrictSsmlTag(vector<SsmlText>* result);
  void RemoveUnsupportedTag(string* result) const;
  void RemoveUnusedTag(vector<SsmlText>* result);
  FRIEND_TEST(IsSsml, IsSsmlCase);

  DISALLOW_COPY_AND_ASSIGN(SsmlParser);
};

float ParseBreakTime(const tts::SsmlText& ssml_text);

}  // namespace tts

#endif  // TTS_UTIL_SSML_SSML_PARSER_H_
