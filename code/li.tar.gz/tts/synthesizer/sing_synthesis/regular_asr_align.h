// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng yang)

#ifndef TTS_SYNTHESIZER_SING_SYNTHESIS_REGULAR_ASR_ALIGN_H_
#define TTS_SYNTHESIZER_SING_SYNTHESIS_REGULAR_ASR_ALIGN_H_

#include <string>
#include <vector>

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/log.h"

namespace sing_synthesizer {

double *RegularPcmWithAlign(double *x, string *_sym, int x_length);
}  // namespace sing_synthesizer
#endif  // TTS_SYNTHESIZER_SING_SYNTHESIS_REGULAR_ASR_ALIGN_H_
