// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng yang)

#ifndef TTS_SYNTHESIZER_SING_SYNTHESIS_SING_SYNTHESIS_H_
#define TTS_SYNTHESIZER_SING_SYNTHESIS_SING_SYNTHESIS_H_

#include "mobvoi/base/log.h"
#include "tts/synthesizer/sing_synthesis/sing_mysql_utils.h"
#include "tts/synthesizer/sing_synthesis/stretch_features.h"
#include "tts/synthesizer/vocoder/world_vocoder/world/world_vocoder.h"

namespace sing_synthesizer {

struct SongParameters {
  int start_point;
  int end_point;
  string tar_str;
  string force_voice_seq;
  int tar_len;
  string bgm_id;
  double *ori_f0;
  double *male_f0;
  double *female_f0;
  double *f0;
  int f0_length;
  int start_end_flag;
  int bgm_length;
};

struct BgmParameters {
  double *data;
  int length;
};

struct Song {
  // double *bgm[];
  int start;
  int end;
};

class SingingSyntheszer {
 public:
  SingingSyntheszer(const string base_fn, int fs, bool use_mgc);
  SingingSyntheszer(int fs, bool use_mgc);
  ~SingingSyntheszer();
  double *sing_synthesis(void *x_v, int x_length, int *y_length, string asr_dur,
                         string tar_dur, string sent_id);
  double *sing_synthesis(void *x_v, int x_length, int *y_length, string asr_dur,
                         string tar_dur, string sent_id, double f0_rate,
                         double bgm_rate, double voice_rate);
  void SetPagamsFromFs(int fs, bool use_mgc);

 private:
  double frame_period_;
  int ap_order_;
  int sp_order_;
  int fs_;
  vector<vector<double> > mgc_pau_;
  vector<vector<double> > bap_pau_;
  string force_voice_seq_;
  string resource_;
  map<string, SongParameters> song_map_;
  map<string, BgmParameters> bgm_map_;
  map<string, Song> stime_map_;
  bool use_mgc_;
  bool use_sql_;
  SingMysqlUtils smu_;

  void GetParamsFromFs(int fs, int *ap_order, int *sp_order) const;
  double GetConfigDouble(const char *key) const;
  BgmParameters ReadBgm(const char *bgm_fn) const;
  double *GetBgm(string sent_id, int *sent_start, int *sent_end,
                 int *song_bgm_length, int *song_start, int *song_end);
  double *GetF0(string song_id, int *len);
  double *SongMix(double *y, string sent_id, int *y_length, double bgm_rate);
  double *FixF0ByAsrUV(string asr_dur, double *f0, int f0_length) const;
  bool NoiseRate(const string asr_dur, const double *x, int x_length) const;
  void ReadFeature(vector<vector<double> > *feature, int pau_order,
                   bool is_ap) const;
  double *GetF0(string song_id);
  string GetForceUV(string song_id) const;
  int GetTime(string song_id, int *start, int *end);
  double *ReadF0(string f0_fn, int len) const;
  string GetTar(string song_id, int *len);
  double *CutSilence(double *x, string *_sym, int *x_length) const;
  void NormalizeVolume(double *x, int x_length, double rate) const;
  void InterpTf0Seq(const double *f0, int f0_length, double *cf0) const;
};
}  // namespace sing_synthesizer
#endif  //  TTS_SYNTHESIZER_SING_SYNTHESIS_SING_SYNTHESIS_H_
