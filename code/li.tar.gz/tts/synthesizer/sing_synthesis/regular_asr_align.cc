// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng yang)

#include "tts/synthesizer/sing_synthesis/regular_asr_align.h"

#include "mobvoi/base/log.h"

#include "tts/synthesizer/sing_synthesis/stretch_features.h"

namespace sing_synthesizer {

inline string IntToString(const int &int_temp) {
  return std::to_string(int_temp);
}

//获取帧数据能量
double *CalEnergy(double *pcm_data, int pcm_len, int *energy_len) {
  int frame_count = 80;
  int en_len = pcm_len / frame_count;
  if (pcm_len / frame_count - en_len != 0) {
    en_len++;
  }
  double *energy = new double[en_len];
  std::vector<double> v_d;
  double sum = 0;
  int en_idx = 0;
  for (int i = 0; i < pcm_len && en_idx < en_len; i++) {
    sum = sum + pcm_data[i] * pcm_data[i] * 32768 * 32768;
    if ((i + 1) % frame_count == 0) {
      energy[en_idx] = sum;
      v_d.push_back(sum);
      en_idx++;
      sum = 0;
    } else if (i == pcm_len - 1) {
      energy[en_idx] == sum;
    }
  }
  *energy_len = en_len;
  return energy;
}

inline bool isNum(string str) {
  stringstream sin(str);
  double d;
  char c;
  if (!(sin >> d)) {
    return false;
  }
  if (sin >> c) {
    return false;
  }
  return true;
}

int AnalysisSym(const string &_sym, vector<vector<string> > *_src_phn,
                vector<vector<int> > *_src_dur, vector<int> *_syl_dur,
                vector<string> *_src_syl, vector<vector<int> > *_src_dur_sum) {
  vector<string> v_items = StringSplitToVector(_sym, " ");
  if (v_items.size() <= 1) {
    return -1;
  }
  int pho_sum = 0;
  int sum = 0;
  for (int i = 0; i < v_items.size(); i++) {
    vector<string> v_it = StringSplitToVector(v_items[i], ":");
    if (v_it[0] != "") {
      _src_syl->push_back(v_it[0]);
      vector<int> tmp_dur;
      vector<int> tmp_pho_dur;
      vector<string> tmp_phn;
      _syl_dur->push_back(sum);
      for (int j = 1; j < v_it.size(); j++) {
        vector<string> v = StringSplitToVector(v_it[j], "_");
        tmp_dur.push_back(atoi(v[1].c_str()));
        tmp_phn.push_back(v[0]);
        sum += atoi(v[1].c_str());
        pho_sum += atoi(v[0].c_str());
        tmp_pho_dur.push_back(pho_sum);
      }
      _src_dur_sum->push_back(tmp_pho_dur);
      _src_dur->push_back(tmp_dur);
      _src_phn->push_back(tmp_phn);
    }
  }
  return 0;
}

int GetIdxFromDurs(vector<int> durs, int value) {
  int mid = durs.size() / 2;
  int start = 0;
  int end = durs.size() - 1;
  int ret = -1;
  if (value >= durs[end]) {
    return end;
  }
  while (start < end) {
    if (mid + 1 < durs.size() && value >= durs[mid] && value < durs[mid + 1]) {
      ret = mid;
      break;
    } else {
      if (value < durs[mid]) {
        end = mid;
        mid = (mid + start) / 2;

      } else {
        start = mid;
        mid = (mid + end) / 2;
      }
    }
  }
  return ret;
}

int CutSyls(vector<int> *syl, int pos, int flag) {
  int len = syl->size();
  if (pos < 0) return -1;
  if (flag == 0) {  // flag == 0 为前 flag == 1 为后 flag == 2 直接赋值
    if (pos < (*syl)[0]) {
      (*syl)[0] = (*syl)[0] - pos;
    } else {
      return 0;
    }
  } else if (flag == 1) {
    if (pos < (*syl)[len - 1]) {
      (*syl)[len - 1] = (*syl)[len - 1] - pos;
    } else {
      return 0;
    }
  } else if (flag == 2) {
    if (pos > (*syl)[len - 1]) {
      (*syl)[0] = pos;
    } else {
      return 0;
    }
  }
  return pos;
}

double *RegularPcmWithAlign(double *x, string *_sym, int x_length) {
  int offset = 0;
  int en_len;
  int windows = 5;
  double threshold = 15000000 * windows;
  double sum_5energy = 0;
  vector<int> sil_start_pos;
  vector<int> sil_end_pos;
  bool flag = false;
  bool is_energy_success = true;
  double *energy = CalEnergy(x, x_length, &en_len);
  vector<vector<string> > phos;
  vector<vector<int> > pho_dur;
  vector<vector<int> > pho_dur_sum;
  vector<string> syls;
  vector<int> syl_dur;

  if (AnalysisSym(*_sym, &phos, &pho_dur, &syl_dur, &syls, &pho_dur_sum) < 0) {
    delete[] energy;
    return x;
  }

  for (int i = 0; i < en_len; i++) {
    sum_5energy = sum_5energy + energy[i];
    if ((i + 1) % windows == 0) {
      if (sum_5energy < threshold && !flag) {
        if (i < 10) {
          sil_start_pos.push_back(0);
        } else {
          sil_start_pos.push_back(i - windows / 2);
        }
        flag = true;
      } else if (flag && sum_5energy > threshold) {
        sil_end_pos.push_back(i - windows / 2);
        flag = false;
      }
      sum_5energy = 0;
    }
    if (i == en_len - 1) {
      if (flag) {
        sil_end_pos.push_back(en_len);
      }
    }
  }

  //规整 start pos 和 end pos 的位置，sil小于10的和两个段距离小于10的处理
  for (int i = 0;
       i < sil_start_pos.size() && i < sil_end_pos.size() && is_energy_success;
       i++) {
    if (sil_start_pos[i] >= sil_end_pos[i]) {
      is_energy_success = false;
    }
    if (i < sil_start_pos.size() - 1 &&
        sil_start_pos[i + 1] - sil_end_pos[i] < 10) {
      sil_start_pos.erase(sil_start_pos.begin() + i + 1);
      sil_end_pos.erase(sil_end_pos.begin() + i);
      i--;
    } else if (sil_end_pos[i] - sil_start_pos[i] < 10) {
      sil_start_pos.erase(sil_start_pos.begin() + i);
      sil_end_pos.erase(sil_end_pos.begin() + i);
      i--;
    }
  }

  if (sil_start_pos.size() != sil_end_pos.size()) {
    delete[] energy;
    is_energy_success = false;
  }
  int sil_idx = 0;
  int current_pos = 0;
  *_sym = "";
  string _sym_addstr = "";
  int sil_pos_start_idx;
  int sil_pos_end_idx;
  int pos_start;
  int pos_end;
  vector<int> v_sil_pos_start;
  vector<int> v_sil_pos_end;
  for (int i = 0; i < sil_start_pos.size(); i++) {
    sil_pos_start_idx = GetIdxFromDurs(syl_dur, sil_start_pos[i]);
    if (sil_pos_start_idx != -1) {
      v_sil_pos_start.push_back(sil_pos_start_idx);
    }
    sil_pos_end_idx = GetIdxFromDurs(syl_dur, sil_end_pos[i]);
    if (sil_pos_end_idx != -1) {
      v_sil_pos_end.push_back(sil_pos_end_idx);
    }
  }
  for (int i = 0; i < syls.size(); i++) {
    current_pos = syl_dur[i];
    /*int pos_start = GetIdxFromDurs(syl_dur, sil_start_pos[sil_idx]);
    int pos_end = GetIdxFromDurs(syl_dur, sil_end_pos[sil_idx]);*/
    if (sil_idx < v_sil_pos_end.size() && sil_idx < v_sil_pos_start.size()) {
      sil_pos_start_idx = v_sil_pos_start[sil_idx];
      sil_pos_end_idx = v_sil_pos_end[sil_idx];
      pos_start = sil_start_pos[sil_idx];
      pos_end = sil_end_pos[sil_idx];
    }

    if (i == 0 && current_pos == pos_start && current_pos < pos_end &&
        syls[i] == "sil" && sil_pos_end_idx == sil_pos_start_idx + 1) {
      if (i < syls.size() - 1) {
        int ret_cut =
            CutSyls(&pho_dur[i + 1], pos_end - current_pos - syl_dur[i + 1], 0);
        if (ret_cut != 0) {
          CutSyls(&pho_dur[i], pos_end - current_pos, 2);
        }
      }
      sil_idx++;
    } else if (i + 1 < syls.size() && syl_dur[i + 1] > pos_start) {
      if (i < syls.size() - 1 && syls[i] != "sil" && syls[i + 1] != "sil" &&
          sil_pos_end_idx <= sil_pos_start_idx + 1) {
        int ret_cut = 0;
        if (sil_pos_end_idx == sil_pos_start_idx && sil_pos_start_idx == i &&
            pos_start - syl_dur[i] < syl_dur[i + 1] - pos_end) {
          pos_start = syl_dur[i];
          ret_cut = CutSyls(&pho_dur[i], pos_end - pos_start, 0);
          if (ret_cut != 0) {
            *_sym += "sil:sil_" + IntToString(ret_cut) + " ";
            _sym_addstr = "";
          }
        } else {
          if (sil_pos_start_idx == sil_pos_start_idx) {
            pos_end = syl_dur[i + 1];
          }
          ret_cut = CutSyls(&pho_dur[i + 1], pos_end - syl_dur[i + 1], 0);
          if (ret_cut == -1) {
            ret_cut = 0;
          } else {
            ret_cut += CutSyls(&pho_dur[i], syl_dur[i + 1] - pos_start, 1);
          }
          if (ret_cut != 0) {
            _sym_addstr = "sil:sil_" + IntToString(ret_cut) + " ";
          }
        }
      }
      sil_idx++;
    } else if (pos_start < current_pos && i == syls.size() - 1 &&
               syls[i] == "sil") {
      if (i > 0) {
        int ret_cut = CutSyls(&pho_dur[i - 1], current_pos - pos_start, 1);
        if (ret_cut != 0) {
          CutSyls(&pho_dur[i], current_pos - pos_start, 0);
        }
      }
      sil_idx++;
    }
    string pho_tmp_str = "";
    for (int j = 0; j < pho_dur[i].size(); j++) {
      pho_tmp_str += phos[i][j] + "_" + IntToString(pho_dur[i][j]);
      if (j != pho_dur[i].size() - 1) pho_tmp_str += ":";
    }
    *_sym += syls[i] + ":" + pho_tmp_str + " ";
    if (_sym_addstr != "") {
      *_sym += _sym_addstr;
      _sym_addstr = "";
    }
  }
  return x;
}
}  // namespace sing_synthesizer
