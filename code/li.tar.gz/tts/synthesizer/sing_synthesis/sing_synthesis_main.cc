// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng yang)

#include <fstream>  // NOLINT

#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"

#include "tts/synthesizer/sing_synthesis/sing_synthesis.h"
#include "tts/synthesizer/vocoder/world_vocoder/world/world_vocoder.h"

static const int kSamplingRate = 16000;

DEFINE_string(base_dir, "tts/synthesizer/sing_synthesis/data/",
              "base_dir file path");
DEFINE_string(res_dir, "tts/synthesizer/sing_synthesis/data/resource/",
              "resource path");
DEFINE_string(dur_file, "tts/synthesizer/sing_synthesis/data/dur.txt",
              "dur_file path");
DEFINE_string(sing_file_format, "wav", "wav | mp3 ,default wav");

DEFINE_bool(if_use_mgc, true, "");
DEFINE_double(bgm_volume_rate, 1.0, "");
DEFINE_double(song_volume_rate, 0.3, "");
DEFINE_double(f0_adjust_rate, 0, "");

int main(int argc, char *argv[]) {
  google::ParseCommandLineFlags(&argc, &argv, false);
  std::ifstream fin(FLAGS_dur_file.c_str());
  if (!fin.is_open()) {
    LOG(ERROR) << "asr_durs init failed" << endl;
    return -1;
  }
  sing_synthesizer::SingingSyntheszer sing_syn(FLAGS_res_dir, kSamplingRate,
                                               FLAGS_if_use_mgc);
  int y_length = 0;
  double *y;
  string line;
  while (getline(fin, line)) {
    vector<string> v_s = sing_synthesizer::StringSplitToVector(line, ";");
    string speaker_id = v_s[0];
    string asr_dur = v_s[1];
    string wav_file = FLAGS_base_dir + "/" + speaker_id + ".wav";
    string out_file = FLAGS_base_dir + "/trans_" + speaker_id;
    int x_length = world_vocoder::GetAudioLength(wav_file.c_str());
    double *pcm = new double[x_length];
    int fs = 0, nbit = 0;
    world_vocoder::wavread(wav_file.c_str(), &fs, &nbit, pcm);
    double *tmp;
    int tmp_len;
    sing_syn.SetPagamsFromFs(fs, FLAGS_if_use_mgc);
    void *wav = reinterpret_cast<void *>(pcm);
    y = sing_syn.sing_synthesis(wav, x_length, &y_length, asr_dur, "",
                                speaker_id, FLAGS_f0_adjust_rate,
                                FLAGS_bgm_volume_rate, FLAGS_song_volume_rate);
    if (FLAGS_sing_file_format == "wav") {
      out_file += ".wav";
      world_vocoder::WavWriteUtils(y, y_length, fs, nbit, out_file.c_str());
    } else if (FLAGS_sing_file_format == "mp3") {
      out_file += ".mp3";
      world_vocoder::Mp3WriteUtils(y, y_length, fs, nbit, out_file.c_str());
    } else {
      LOG(ERROR) << "error set output file format : << FLAGS_sing_file_format";
    }

    delete[] y;
  }
  fin.close();
  return 0;
}
