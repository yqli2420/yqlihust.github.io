// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng Yang)

#ifndef TTS_SYNTHESIZER_SING_SYNTHESIS_STRETCH_FEATURES_H_
#define TTS_SYNTHESIZER_SING_SYNTHESIS_STRETCH_FEATURES_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/log.h"

namespace sing_synthesizer {

vector<string> StringSplitToVector(const string &str, const string &pattern);

class StreathingFeature {
 public:
  StreathingFeature(const vector<vector<double> > &mgc_pau,
                    const vector<vector<double> > &bap_pau,
                    double frame_period);
  StreathingFeature(const vector<vector<double> > &mgc_pau,
                    const vector<vector<double> > &bap_pau, int mgc_order,
                    int bap_order, double frame_period, int vuv_order);
  StreathingFeature(int mgc_order, int bap_order, double frame_period,
                    int vuv_order);
  ~StreathingFeature();

  int Process(const string &_tar, string _sym,
              const vector<vector<double> > &_mgc,
              const vector<vector<double> > &_bap,
              const vector<vector<double> > &_vuv, double **_tmgc,
              double **_tbap, double **_tvuv);

 private:
  vector<vector<double> > mgc_pau_;
  vector<vector<double> > bap_pau_;
  vector<string> initial_;
  bool is_mgc_;
  int mgc_order_;
  int bap_order_;
  double frame_period_;
  int vuv_order_;
  int working_order_;
  double offset_;

  vector<vector<double> > Interp(int im, const vector<double> left,
                                 const vector<double> right) const;
  int InterpFunc(int tar, int src, int idx,
                 const vector<vector<double> > &source,
                 vector<vector<double> > *data) const;
  vector<vector<double> > StrethSyllables(
      const vector<vector<int> > &_tar_dur, const vector<string> &_tar_syl,
      const vector<vector<int> > &_src_dur, const vector<string> &_src_syl,
      const vector<vector<string> > &_src_phn,
      const vector<vector<double> > &_source) const;
  int InitialProcess(int tar, int src_states, int idx,
                     const vector<vector<double> > &_source, string py,
                     vector<vector<double> > *data) const;
  int MidStreth(int tar, int states, int idx,
                const vector<vector<double> > &_source,
                vector<vector<double> > *data) const;
  int FinalsProcess(int tar, vector<int> src_states, int idx,
                    const vector<vector<double> > &_source,
                    vector<string> _src_phn,
                    vector<vector<double> > *data) const;
};
}  // namespace sing_synthesizer
#endif  // TTS_SYNTHESIZER_SING_SYNTHESIS_STRETCH_FEATURES_H_
