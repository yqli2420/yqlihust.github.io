// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include <malloc.h>

#include "mobvoi/base/file.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/time.h"
#include "mobvoi/util/utf8/utf.h"
#include "third_party/perftools/heap-profiler.h"
#include "third_party/perftools/malloc_extension.h"
#include "third_party/perftools/profiler.h"
#include "tts/synthesizer/synthesizer.h"

DEFINE_string(text_file, "tts/synthesizer/testdata/tts.text", "");
DEFINE_int32(sampling_frequency, 16000, "");
DEFINE_string(save_file_format, "wav", "pcm | mp3 | speex-wb-10");
DEFINE_int32(test_sentence_num, 200, "");
DEFINE_string(speaker, "cissy", " speaker");
DEFINE_bool(enable_heap_profile, true, "If true, enable heap profile");
DEFINE_bool(save_audio, false, "If true, save audio");
DEFINE_string(audio_dir, "wave_data/", "");
DEFINE_bool(trim_memory, true, "");
DEFINE_bool(for_portable, true, "If true, use portable resource");
DEFINE_bool(enable_cpu_profile, true, "");
DEFINE_string(offline_speaker_info_file,
              "portable/resource/config_file/portable_speakers.json",
              "speaker for portable tts.");
DEFINE_string(speaker_info_file, "external/config/config_file/speakers.json",
              "tts info json file");

int main(int argc, char** argv) {
  char* buf = new char[5000];
  google::ParseCommandLineFlags(&argc, &argv, false);
  if (FLAGS_enable_heap_profile) {
    google::InitGoogleLogging(argv[0]);
  }

  vector<string> lines;
  file::SimpleLineReader reader(FLAGS_text_file);
  reader.ReadLines(&lines);

  if (FLAGS_enable_heap_profile) {
    LOG(INFO) << "enable heap profile...";
    HeapProfilerStart("t.mem");
  }

  tts::TTSOption tts_option;
  tts::SetDefaultTTSOption(&tts_option);

  string speaker_file = FLAGS_for_portable ? FLAGS_offline_speaker_info_file
                                           : FLAGS_speaker_info_file;
  tts::Synthesizer tts(speaker_file);

  MallocExtension::instance()->GetStats(buf, 5000);
  LOG(INFO) << buf;
  for (size_t i = 0; i < 20; ++i) {
    // unload mandarin speakers
    auto speakers = tts.GetSpeakers(tts::kMandarinTypeString);
    for (auto speaker : speakers) {
      LOG(INFO) << "unload speaker: " << speaker.first;
      tts.UnloadSpeaker(speaker.first);
    }
    MallocExtension::instance()->GetStats(buf, 5000);
    LOG(INFO) << buf;
    for (auto speaker : speakers) {
      LOG(INFO) << "load speaker: " << speaker.first;
      tts.LoadSpeaker(speaker.first);
    }
    MallocExtension::instance()->GetStats(buf, 5000);
    LOG(INFO) << buf;
  }

  // Dump after model loaded.
  if (FLAGS_enable_heap_profile) {
    LOG(INFO) << "Dump memory profiler.";
    HeapProfilerDump("model loaded");
  }
  if (FLAGS_enable_cpu_profile) {
    ProfilerStart("tts.cpu");
  }

  tts_option.set_speaker(FLAGS_speaker);

  int test_word_num = 0;
  int64_t begin = mobvoi::GetTimeInMs();
  int sent_len = static_cast<int>(lines.size()) > FLAGS_test_sentence_num
                     ? FLAGS_test_sentence_num
                     : lines.size();
  string data;
  MallocExtension::instance()->GetStats(buf, 5000);
  LOG(INFO) << buf;
  for (int i = 0; i < sent_len; ++i) {
    vector<string> segs;
    SplitString(lines[i], '\t', &segs);
    if (segs.size() != 2UL) {
      LOG(ERROR) << "Bad line:" << lines[i];
      continue;
    }
    test_word_num += util::utflen(segs[1].c_str());
    data.clear();
    tts.Synthesize(segs[1], tts_option, &data);
    data.clear();
    VLOG(2) << "Synthesize for line: " << lines[i];

    if (FLAGS_save_audio) {
      string path = FLAGS_audio_dir + IntToString(i) + ".wav";
      mobvoi::File::WriteStringToFile(data, path);
    }

    if (FLAGS_enable_heap_profile) {
      LOG(INFO) << "Dump memory profiler.";
      HeapProfilerDump(StringPrintf("sentence_%d", i).c_str());
    }
    if (FLAGS_trim_memory) {
      malloc_trim(0);
    }
  }
  MallocExtension::instance()->GetStats(buf, 5000);
  LOG(INFO) << buf;

  if (FLAGS_enable_heap_profile) {
    HeapProfilerStop();
  }
  if (FLAGS_enable_cpu_profile) {
    ProfilerStop();
  }
  int64_t end_time = mobvoi::GetTimeInMs();
  int64_t used_time = end_time - begin;
  double sen_per_sec = static_cast<double>(sent_len * 1000) / used_time;
  double word_per_sec = static_cast<double>(test_word_num * 1000) / used_time;
  LOG(INFO) << "Test sentences :" << sent_len
            << ", used time in Ms:" << used_time
            << ", test_word_num:" << test_word_num
            << ", performance:" << sen_per_sec << " sentences/sec"
            << ", " << word_per_sec << " words/sec";
  delete[] buf;
  return 0;
}
