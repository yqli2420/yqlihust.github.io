// Copyright 2017 Mobvoi Inc. All Rights Reserved.
// Author: ranzhang@mobvoi.com (Dylan Zhang)

#include "tts/synthesizer/interface/synthesizer_interface.h"

namespace tts {
SynthesizerInterface::SynthesizerInterface() {}

SynthesizerInterface::~SynthesizerInterface() {}
}  // namesapce tts
