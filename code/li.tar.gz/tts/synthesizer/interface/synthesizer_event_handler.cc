// Copyright 2016 Mobvoi Inc. All Rights Reserved.
// Author: ylchen@mobvoi.com (Yunlin Chen)

#include "tts/synthesizer/interface/synthesizer_event_handler.h"

namespace tts {
SynthesizerEventHandler::SynthesizerEventHandler(util::HttpResponse* response)
    : response_(response) {}

SynthesizerEventHandler::~SynthesizerEventHandler() {}

void SynthesizerEventHandler::OnStart() {
  response_->SendHeader();
  started_ = true;
  finished_ = false;
}

void SynthesizerEventHandler::OnFinish() {
  response_->EndResponse();
  finished_ = true;
  started_ = false;
}

bool SynthesizerEventHandler::OnSynthesizeData(const string& data) {
  if (response_ != NULL) {
    response_->SendChunk(data);
  }
  return true;
}

string GetResult() { return string(); }

}  // namespace tts
