// Copyright 2016 Mobvoi Inc. All Rights Reserved.
// Author: ylchen@mobvoi.com (Yunlin Chen)

#ifndef TTS_SYNTHESIZER_INTERFACE_SYNTHESIZER_EVENT_HANDLER_H_
#define TTS_SYNTHESIZER_INTERFACE_SYNTHESIZER_EVENT_HANDLER_H_

#include "mobvoi/base/compat.h"
#include "mobvoi/util/net/http_server/http_response.h"
#include "tts/synthesizer/interface/synthesizer_event_interface.h"

namespace tts {
class SynthesizerEventHandler : public SynthesizerEventInterface {
 public:
  explicit SynthesizerEventHandler(util::HttpResponse* response);
  virtual ~SynthesizerEventHandler();

  virtual void OnStart();
  virtual bool OnSynthesizeData(const string& data);
  virtual void OnFinish();
  virtual string GetResult();
  bool started() const { return started_; }

  bool finished() const { return finished_; }

 private:
  util::HttpResponse* response_;
  bool started_ = false;
  bool finished_ = false;
  DISALLOW_COPY_AND_ASSIGN(SynthesizerEventHandler);
};
}  // namespace tts

#endif  // TTS_SYNTHESIZER_INTERFACE_SYNTHESIZER_EVENT_HANDLER_H_
