// Copyright 2017 Mobvoi Inc. All Rights Reserved.
// Author: zalu@mobvoi.com (Ziang Lu)

#include "tts/synthesizer/label_generator/label_util.h"

#include "mobvoi/base/string_util.h"
#include "third_party/gtest/gtest.h"

namespace tts {

void FormWordToken(const string& word_str, const string& prosody_str,
                   vector<WordToken>* word_token) {
  vector<string> words;
  vector<string> pause_levels;
  SplitString(word_str, ' ', &words);
  SplitString(prosody_str, ' ', &pause_levels);
  if (words.size() != pause_levels.size()) return;
  for (size_t i = 0; i < words.size(); ++i) {
    WordToken word_tmp;
    word_tmp.word = words[i];
    word_tmp.pause_level = StringToInt(pause_levels[i]);
    word_token->emplace_back(word_tmp);
  }
}

TEST(LabelUtilTest, RemoveFrontEndBreak) {
  {
    vector<int> result = {4, 4, 2, 1, 4, 1, 2, 4, 4};
    RemoveFrontEndBreak(&result);
    int pause_level_expect[] = {3, 3, 2, 1, 4, 1, 2, 3, 4};
    for (size_t i = 0; i < result.size(); ++i) {
      EXPECT_EQ(result[i], pause_level_expect[i]);
    }
  }
}

// Test RevisePuncByMono
TEST(LabelUtilTest, RevisePuncByMono) {
  const string& source_str = "读书就要破万卷书,行万里路";
  const string& syl_str =
      "SIL du shu sp jiu yao sp po wan jvan shu lp xing wan li lu SIL";
  const string& target_str = "读书@就要@破万卷书,行万里路";
  string norm_str;
  vector<string> syls;
  SplitString(syl_str, ' ', &syls);
  RevisePuncByMono(source_str, syls, &norm_str);
  EXPECT_EQ(norm_str, target_str);
}

// Test ParseMandSyllable
TEST(LabelUtilTest, ParseMandSyllable) {
  const string syl_strs[2] = {"yao4", "A"};
  const string target_monos_strs[2] = {"y ao", "A"};
  const string vowel_strs[2] = {"ao", "X"};
  const int target_tones[2] = {4, 7};
  for (int i = 0; i < 2; ++i) {
    int tone = 0;
    string vowel;
    vector<string> monos, target_monos;
    SplitString(target_monos_strs[i], ' ', &target_monos);
    ParseMandSyllable(syl_strs[i], &monos, &vowel, &tone);
    ASSERT_EQ(target_monos.size(), monos.size());
    EXPECT_EQ(target_tones[i], tone);
    EXPECT_EQ(vowel_strs[i], vowel);
    for (size_t j = 0; j < monos.size(); ++j) {
      EXPECT_EQ(target_monos[j], monos[j]);
    }
  }
}
// Test RestrictLevel
TEST(LabelUtilTest, RestrictLevel) {
  const string& text_str = "哦 哦 哦 哦 哦 哦 哦 哦 哦 哦 哦 哦 哦 哦 哦 哦 哦";
  const string& prosody_str = "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 5";
  vector<WordToken> word_token;
  FormWordToken(text_str, prosody_str, &word_token);
  RestrictLevel(&word_token);
  const vector<int> expect_result = {0, 0, 2, 0, 0, 2, 0, 0, 2,
                                     0, 0, 3, 0, 0, 2, 0, 5};
  EXPECT_EQ(expect_result.size(), word_token.size());
  for (size_t i = 0; i < expect_result.size(); ++i) {
    EXPECT_EQ(expect_result[i], word_token[i].pause_level);
  }
}

TEST(LabelUtilTest, IsCanVowel) {
  const string& phoneme1 = "waan1";
  EXPECT_FALSE(IsCanVowel(phoneme1[0]));

  const string& phoneme2 = "yaan1";
  EXPECT_TRUE(IsCanVowel(phoneme2[0]));
}

TEST(LabelUtilTest, ErhuayinProcess) {
  const string erhua_file = "external/config/front_end/dict/erhua_dict";
  mobvoi::unordered_set<string> erhua_set;
  LoadSetFromFile(erhua_file, &erhua_set);

  vector<WordToken> word_tokens;
  WordToken token_tmp;
  token_tmp.word = "小孩儿";
  token_tmp.prons = {"xiao3", "hai2", "er5"};
  const vector<string> expect_pron = {"xiao3", "hai2", "xr2"};
  word_tokens.emplace_back(token_tmp);

  ErhuayinProcess(erhua_set, &word_tokens);
  EXPECT_EQ(expect_pron, word_tokens[0].prons);
}

}  // namespace tts
