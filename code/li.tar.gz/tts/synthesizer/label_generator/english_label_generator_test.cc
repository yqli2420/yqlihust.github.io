// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "mobvoi/base/compat.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "third_party/gtest/gtest.h"
#include "tts/synthesizer/label_generator/label_generator.h"
#include "tts/synthesizer/label_generator/label_generator_manager.h"

namespace tts {

static const string kTestDataDir =  // NOLINT
    "tts/synthesizer/label_generator/testdata";
// expect file
static const string kOnlineServer = "eng_online_server.lab";        // NOLINT
static const string kOnlinePortable = "eng_online_portable.lab";    // NOLINT
static const string kOfflineServer = "eng_offline_server.lab";      // NOLINT
static const string kOfflinePortable = "eng_offline_portable.lab";  // NOLINT

static const char kLabelSep = '\t';
enum FileFormat {
  kName = 0,
  kContent,
  kTestAllNum,
};

static bool ProcessLine(const string& line, string* name, string* content) {
  vector<string> segs;
  SplitString(line, kLabelSep, &segs);
  if (segs.size() < FileFormat::kTestAllNum) return false;
  *name = segs[FileFormat::kName];
  *content = segs[FileFormat::kContent];
  for (size_t i = FileFormat::kContent + 1; i < segs.size(); ++i) {
    *content += kLabelSep + segs[i];
  }
  return true;
}

string GetExpect(bool is_online) {
  string expect;
  if (is_online) {
#ifndef FOR_PORTABLE
    expect = kOnlineServer;
#else
    expect = kOnlinePortable;
#endif
  } else {
#ifndef FOR_PORTABLE
    expect = kOfflineServer;
#else
    expect = kOfflinePortable;
#endif
  }
  return expect;
}

class EnglishLabelGeneratorTest : public ::testing::Test {
 protected:
  virtual void SetUp() {
    const string resource_file = "external/config/front_end/eng_frontend.conf";
    LabelGeneratorManager manager;
    en_label_generator_ =
        manager.CreateLabelGenerator(kEnglishTypeString, resource_file);
  }

  void GenLabelsCaseTest(const string& content, bool is_online,
                         const string& expect) const {
    vector<string> expect_labels;
    file::SimpleLineReader label_reader(expect, false, "#");
    label_reader.ReadLines(&expect_labels);

    vector<SsmlText> input;
    SsmlParser::Instance().ParseText(content, &input);

    LabelOption label_option;
    tts::SetDefaultLabelOption(&label_option);
    label_option.set_language(kEnglishTypeString);

    vector<string> labels;
    en_label_generator_->GenLabels(input, label_option, is_online, &labels,
                                   nullptr);

    ASSERT_EQ(expect_labels.size(), labels.size()) << content;
    for (size_t i = 0; i < labels.size(); ++i) {
      EXPECT_EQ(expect_labels[i], labels[i]);
    }
  }

  void GenLabelsFileTest(const string& test_file, bool is_online) const {
    file::SimpleLineReader reader(test_file, false, "#");
    vector<string> lines;
    reader.ReadLines(&lines);
    string expect_suffix = GetExpect(is_online);
    for (const auto& line : lines) {
      string name, content;
      if (!ProcessLine(line, &name, &content)) continue;
      string expect_file = name + "_" + expect_suffix;
      expect_file = mobvoi::File::JoinPath(kTestDataDir, expect_file);
      GenLabelsCaseTest(content, is_online, expect_file);
    }
  }

  std::shared_ptr<LabelGenerator> en_label_generator_;
};

TEST_F(EnglishLabelGeneratorTest, GenLabels) {
  const string test_file =
      mobvoi::File::JoinPath(kTestDataDir, "eng_label_online_test.txt");
  GenLabelsFileTest(test_file, true);
}

}  // namespace tts
