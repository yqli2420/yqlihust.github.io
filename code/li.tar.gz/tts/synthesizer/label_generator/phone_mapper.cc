// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaoqin.feng@mobvoi.com

#include "tts/synthesizer/label_generator/phone_mapper.h"

#include "mobvoi/base/log.h"
#include "mobvoi/base/string_util.h"
#include "tts/nlp/g2p/g2p_util.h"
#include "tts/synthesizer/label_generator/label_def.h"
#include "tts/util/tts_util/util.h"

namespace tts {

enum PhoneMappingDictFormat {
  kPhoneType = 0,
  kTonePron = 1,
  kPinyinPron = 2,
  kPhoneMappingDictAllNum,
};

PhoneMapper::PhoneMapper(const string& phone_mapping_path) {
  LoadPhoneMappingDict(phone_mapping_path);
}

PhoneMapper::~PhoneMapper() {}

void PhoneMapper::LoadPhoneMappingDict(const string& phone_mapping_path) {
  vector<string> lines;
  vector<string> values;
  tts::GetConfigCenterLines(phone_mapping_path, &lines);
  for (auto line : lines) {
    mobvoi::SplitStringToVector(line, "\t", false, &values);
    if (values.size() == PhoneMappingDictFormat::kPhoneMappingDictAllNum) {
      string frontend_type = values[PhoneMappingDictFormat::kPhoneType];
      if (pinyin_to_tone_[frontend_type].find(
              values[PhoneMappingDictFormat::kPinyinPron]) ==
          pinyin_to_tone_[frontend_type].end()) {
        pinyin_to_tone_[frontend_type]
                       [values[PhoneMappingDictFormat::kPinyinPron]] =
                           values[PhoneMappingDictFormat::kTonePron];
      }
      tone_to_pinyin_[frontend_type]
                     [values[PhoneMappingDictFormat::kTonePron]] =
                         values[PhoneMappingDictFormat::kPinyinPron];
    }
  }
}
// HH AH 7_L OW 8  -> hʌ`lth
// ni2 ->  ní
// ㄋ丨ˇ -> nǐ
bool PhoneMapper::PinyinToTone(const string& frontend_type,
                               const string& pinyin, string* tone) {
  *tone = pinyin;
  if (frontend_type == kFrontendTypeEng) {
    string temp_pinyin = string();
    vector<string> pinyin_slices;
    mobvoi::SplitStringToVector(pinyin, "_", false, &pinyin_slices);
    for (auto pinyin_slice : pinyin_slices) {
      vector<string> single_pinyin_slices;
      mobvoi::SplitStringToVector(pinyin_slice, " ", false,
                                  &single_pinyin_slices);
      string single_tone_slice = string();
      for (auto single_pinyin_slice : single_pinyin_slices) {
        if (pinyin_to_tone_[kLanguageEnglish].find(single_pinyin_slice) !=
            pinyin_to_tone_[kLanguageEnglish].end()) {
          const auto iter =
              pinyin_to_tone_[kLanguageEnglish].find(single_pinyin_slice);
          single_tone_slice += iter->second;
        }
      }
      if (single_pinyin_slices.back() == IntToString(Stress::kStress) ||
          single_pinyin_slices.back() == IntToString(Stress::kSubStress)) {
        if (temp_pinyin.front() == '`') temp_pinyin.front() = '.';
        temp_pinyin += "`" + single_tone_slice;
      } else {
        temp_pinyin += single_tone_slice;
      }
    }
    *tone = temp_pinyin;
    return true;
  } else {
    if (pinyin_to_tone_[frontend_type].find(pinyin) !=
        pinyin_to_tone_[frontend_type].end()) {
      const auto iter = pinyin_to_tone_[frontend_type].find(pinyin);
      *tone = iter->second;
      return true;
    }
  }
  return false;
}

void PhoneMapper::PinyinToTone(const string& frontend_type,
                               const vector<string>& pinyins,
                               vector<string>* tones) {
  for (const auto& pinyin : pinyins) {
    string temp_tone;
    PinyinToTone(frontend_type, pinyin, &temp_tone);
    tones->emplace_back(temp_tone);
  }
}

int PhoneMapper::GetEngMaxToneWordSize(std::unordered_set<string>* eng_tones) {
  int max_length = 0;
  for (const auto& tone_to_pinyin : tone_to_pinyin_[kLanguageEnglish]) {
    eng_tones->insert(tone_to_pinyin.first);
    int key_word_length =
        static_cast<int>(util::utflen(tone_to_pinyin.first.c_str()));
    if (key_word_length > max_length) max_length = key_word_length;
  }
  return max_length;
}

bool PhoneMapper::SplitByPrefixMax(const string& tone,
                                   vector<string>* tone_split) {
  std::unordered_set<string> eng_tones;
  string temp_tone = tone;
  vector<util::Rune> token_unicodes;
  util::Utf8ToUnicode(tone, &token_unicodes);
  int eng_tone_maxlen = GetEngMaxToneWordSize(&eng_tones);
  VLOG(2) << "Dict max length : " << eng_tone_maxlen;
  if (util::RuneToWord(token_unicodes[0]) == ".") {
    token_unicodes.erase(token_unicodes.begin(), token_unicodes.begin() + 1);
  }
  while (!token_unicodes.empty()) {
    bool find_flag = false;
    for (size_t i = eng_tone_maxlen; i > 0; i--) {
      string temp_tone_slice;
      for (size_t j = 0; j < i; j++) {
        temp_tone_slice += util::RuneToWord(token_unicodes[j]);
      }
      if (find_flag == false &&
          eng_tones.find(temp_tone_slice) != eng_tones.end()) {
        tone_split->emplace_back(temp_tone_slice);
        token_unicodes.erase(token_unicodes.begin(),
                             token_unicodes.begin() + i);
        find_flag = true;
      }
      if (i == 1 && !find_flag) {
        VLOG(2) << "find no tone prefix: " << temp_tone_slice;
        return false;
      }
    }
  }
  return true;
}

// hʌ`lth -> HH AH0_L OW1
// ní -> ni2
// nǐ -> ㄋ丨ˇ
bool PhoneMapper::ToneToPinyin(const string& frontend_type, const string& tone,
                               string* pinyin) {
  *pinyin = tone;
  if (frontend_type == kLanguageEnglish) {
    vector<string> tone_slices;
    char head_tone = tone.front();
    SplitString(tone, '`', &tone_slices);
    vector<string> temp_pinyin;
    bool stress_flag = true;
    for (size_t i = 0; i < tone_slices.size(); ++i) {
      if (i == 0 && head_tone != '`' && head_tone != '.') {
        stress_flag = false;
      } else {
        stress_flag = true;
      }
      string tone_slice = tone_slices[i];
      vector<string> tone_split_slices;
      if (!SplitByPrefixMax(tone_slice, &tone_split_slices)) return false;
      vector<string> temp_pinyin_slice;
      for (auto tone_split_slice : tone_split_slices) {
        if (tone_to_pinyin_[kLanguageEnglish].find(tone_split_slice) !=
            tone_to_pinyin_[kLanguageEnglish].end()) {
          const auto iter =
              tone_to_pinyin_[kLanguageEnglish].find(tone_split_slice);
          if (tts::IsEngVowel(iter->second)) {
            if (stress_flag) {
              temp_pinyin.emplace_back(iter->second + "1");
              stress_flag = false;
            } else {
              temp_pinyin.emplace_back(iter->second + "0");
            }
          } else {
            temp_pinyin.emplace_back(iter->second);
          }
        } else {
          VLOG(2) << "no english pinyin for tone : " << tone_split_slice;
          return false;
        }
      }
    }
    if (!temp_pinyin.empty()) {
      vector<string> syl_prons;
      nlp::g2p::JoinSyllable(temp_pinyin, &syl_prons);
      *pinyin = JoinVector(syl_prons, '_');
      return true;
    }
  }
  string tone_number = string();
  string tmp_tone = tone;
  if (frontend_type == "asr") {
    size_t t_index = tone.find_first_of("12345");
    if (t_index != string::npos) {
      tone_number = tmp_tone[t_index];
    }
    re2::RE2::GlobalReplace(&tmp_tone, tone_number, "");
  }
  if (tone_to_pinyin_[frontend_type].find(tmp_tone) !=
      tone_to_pinyin_[frontend_type].end()) {
    const auto iter = tone_to_pinyin_[frontend_type].find(tmp_tone);
    *pinyin = iter->second + tone_number;
    return true;
  } else {
    if (tts::IsChinesePron(*pinyin)) return true;
  }
  return false;
}

bool PhoneMapper::ToneToPinyin(const string& frontend_type,
                               const vector<string>& tones,
                               vector<string>* pinyins) {
  for (const auto& tone : tones) {
    string temp_pinyin;
    if (ToneToPinyin(frontend_type, tone, &temp_pinyin))
      pinyins->emplace_back(temp_pinyin);
    else
      return false;
  }
  return true;
}

}  // namespace tts
