// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaoqin.feng@mobvoi.com

#ifndef TTS_SYNTHESIZER_LABEL_GENERATOR_PHONE_MAPPER_H_
#define TTS_SYNTHESIZER_LABEL_GENERATOR_PHONE_MAPPER_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"

namespace tts {
class PhoneMapper {
 public:
  explicit PhoneMapper(const string& phone_mapping_path);
  virtual ~PhoneMapper();

  void LoadPhoneMappingDict(const string& phone_mapping_path);
  bool SplitByPrefixMax(const string& tone, vector<string>* tone_split);
  int GetEngMaxToneWordSize(std::unordered_set<string>* eng_tones);
  bool PinyinToTone(const string& frontend_type, const string& pinyin,
                    string* tone);
  void PinyinToTone(const string& frontend_type, const vector<string>& pinyins,
                    vector<string>* tones);
  bool ToneToPinyin(const string& frontend_type, const string& tone,
                    string* pinyin);
  bool ToneToPinyin(const string& frontend_type, const vector<string>& tones,
                    vector<string>* pinyins);

 private:
  map<string, std::unordered_map<string, string>> pinyin_to_tone_;
  map<string, std::unordered_map<string, string>> tone_to_pinyin_;

 private:
  DISALLOW_COPY_AND_ASSIGN(PhoneMapper);
};

}  // namespace tts
#endif  // TTS_SYNTHESIZER_LABEL_GENERATOR_PHONE_MAPPER_H_
