// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: ranzhang@mobvoi.com (Dylan)

#include "tts/synthesizer/label_generator/label_util.h"

#include <cctype>
#include <string>
#include <utility>
#include <vector>

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/util/utf8/utf8_util.h"
#include "re2/re2.h"
#include "tts/nlp/segmenter/impl/pinyin_encoder.h"
#include "tts/util/ssml/ssml_parser.h"

DEFINE_bool(use_phrases_sandhi_rules, true, "");
DEFINE_bool(use_soft_tone_rules, true, "");
DEFINE_bool(use_sandhi, true,
            "true/false: use sandhi/use predict tone in prosodyfile");
DEFINE_bool(use_yi_postprocess, true,
            "true/false: use yi post process in portable");

namespace tts {

bool GenWordInfos(const vector<WordToken>& word_tokens,
                  const map<int, int> polyphone_prob,
                  const mobvoi::unordered_set<string>& soft_word,
                  const LabelOption& label_option, bool is_online,
                  vector<WordInfo>* word_infos) {
  if (!GenWordInfo(word_tokens, polyphone_prob, label_option.language(),
                   word_infos)) {
    LOG(WARNING) << "No word in word_infos!";
    return false;
  }
  if (is_online && label_option.language() != kCantoneseTypeString &&
      label_option.language() != kEnglishTypeString &&
      label_option.language() != kSichuaneseTypeString &&
      !label_option.use_robot() && label_option.tone_rule()) {
    UpdateWordTone(soft_word, word_infos);
  }
  return true;
}

bool GenWordInfo(const vector<WordToken>& word_tokens,
                 const map<int, int> polyphone_prob, const string& language,
                 vector<WordInfo>* word_info) {
  word_info->reserve(word_tokens.size());
  int man_phone_num = 0;
  for (const WordToken& cur_word : word_tokens) {
    if (IsSeperator(cur_word.word) && !word_info->empty()) {
      if (word_info->back().pause_level < PauseMark2Level(cur_word.word) &&
          !cur_word.pause_fixed)
        word_info->back().pause_level = PauseMark2Level(cur_word.word);
      word_info->back().punc = true;
    } else {
      WordInfo word_info_tmp;
      word_info_tmp.word = cur_word.word;
      word_info_tmp.pron_fixed = cur_word.pron_fixed;
      word_info_tmp.p_pron_fixeds = cur_word.p_pron_fixeds;
      word_info_tmp.pause_level = cur_word.pause_level;
      int phone_num = 0;
      if (!SplitSyllable(cur_word.prons, polyphone_prob, cur_word.pos,
                         cur_word.language, language, &word_info_tmp.syllables,
                         &phone_num, &man_phone_num)) {
        LOG(WARNING) << "No pron for word!";
        if (!word_info->empty() &&
            word_info_tmp.pause_level > word_info->back().pause_level &&
            !cur_word.pause_fixed) {
          word_info->back().pause_level = word_info_tmp.pause_level;
        }
        continue;
      }
      word_info_tmp.phone_num = phone_num;
      if (cur_word.language == WordLanguage::kMandarinWord) {
        vector<util::Rune> word_unicode;
        util::Utf8ToUnicode(cur_word.word, &word_unicode);
        for (size_t i = 0; i < word_info_tmp.syllables.size(); ++i) {
          if (i < word_unicode.size()) {
            word_info_tmp.syllables[i].character =
                util::RuneToWord(word_unicode[i]);
          }
        }
      }
      if (!word_info_tmp.syllables.empty())
        word_info->emplace_back(std::move(word_info_tmp));
    }
  }
  if (word_info->empty()) return false;
  word_info->back().pause_level = kPauseLevelLP;
  return true;
}

// input prons have three types:
// 1. Mandarin : zhang1 san1 (2 strings)
// 2. English  : HH EH1 L OW0 (4 strings)
// 3. SingleABC: EH1_S EH1_F (2 strings)
bool SplitSyllable(const vector<string>& prons,
                   const map<int, int> polyphone_prob, const string& pos,
                   const WordLanguage& word_language, const string& language,
                   vector<SyllableInfo>* syllable_infos, int* phone_num,
                   int* man_phone_num) {
  vector<vector<string>> syllable_prons;
  vector<string> vowels;
  vector<int> tones;
  if (word_language == WordLanguage::kMandarinWord) {
    SplitMandOrCanSyllable(prons, language, &syllable_prons, &vowels, &tones);
  } else {  // word_language == WordLanguage::kEnglishWord
    SplitEnSyllable(prons, &syllable_prons, &vowels, &tones);
  }
  for (size_t i = 0; i < syllable_prons.size(); ++i) {
    int pron_prob = 100;
    if (tts::IsChinesePron(prons[i])) {
      if (polyphone_prob.find(*man_phone_num) != polyphone_prob.end()) {
        auto find_prob = polyphone_prob.find(*man_phone_num);
        pron_prob = find_prob->second;
      }
      (*man_phone_num)++;
    }
    SyllableInfo syllable_info_tmp;
    syllable_info_tmp.prons.insert(syllable_info_tmp.prons.begin(),
                                   syllable_prons[i].begin(),
                                   syllable_prons[i].end());
    syllable_info_tmp.vowel = vowels[i];
    syllable_info_tmp.tone = tones[i];
    syllable_info_tmp.pron_prob = pron_prob;
    syllable_info_tmp.pos = pos;
    *phone_num += syllable_prons[i].size();
    syllable_infos->emplace_back(std::move(syllable_info_tmp));
  }
  if (syllable_infos->empty()) {
    return false;
  }
  return true;
}

void UpdateWordTone(const mobvoi::unordered_set<string>& soft_word,
                    vector<WordInfo>* word_info) {
  // TODO(zhengzhang) add update tone to ignore english words
  if (word_info->empty() || word_info->at(0).syllables[0].character.empty())
    return;
  // See document
  // https://docs.google.com/document/d/1hw1Zil9bldYHtlcqej2Nf2SqRLlLv6Mg4lNw7-W6iCw
  for (size_t word_idx = 0; word_idx < word_info->size(); ++word_idx) {
    WordInfo& cur_word = word_info->at(word_idx);
    vector<SyllableInfo> origin_syllables = cur_word.syllables;
    // Rule1, 不的变调, 在4声前变为2声 不怕 不够 不看 不像,
    // 不的前后字相同的话, 不读轻声
    for (size_t i = 0; i < cur_word.syllables.size() - 1; ++i) {
      if (cur_word.syllables[i].character == "不") {
        if (cur_word.syllables[i + 1].tone == 4) {
          cur_word.syllables[i].tone = 2;
        } else {
          cur_word.syllables[i].tone = 4;
        }
      }
    }
    // between words
    if (word_idx < word_info->size() - 1 &&
        cur_word.syllables.back().character == "不") {
      if (word_info->at(word_idx + 1).syllables[0].tone == 4) {
        cur_word.syllables.back().tone = 2;
      } else {
        cur_word.syllables.back().tone = 4;
      }
    }
    if (cur_word.syllables.size() == 3 &&
        cur_word.syllables[1].character == "不" &&
        cur_word.syllables[0].character == cur_word.syllables[2].character) {
      cur_word.syllables[1].tone = 5;
    }
    // Rule2, 一的变调
    // 出现在相同的动词中间，读轻声 想一想 拖一拖 管一管 谈一谈
    // 在4声前变为2声,前为‘第’字则不变 一样 一向 一定 一块儿 第一个
    // 在非4声前，变为4声  一般 一边 一年  一成 一手 一两
    // 一前面的字如果是kYiPreWord里的字则读一声
    // 一后面的字如果是kYiPostWord里的字则读一声
    // 一一道来，一一细数 保持原来的声调.
    // 如果一是一个单独的词，则读一声
    const string kYiExceptions = "日月零壹一二三四五六七八九广茜";
    // 以一当十
    const string kYiPreWord =
        "以壹一二三四五六七八九零十第其点统之第张期唯惟加减乘除之初";
    const string kYiPostWord =
        "壹一二三四五六七八九零月至日流号是百千十万亿和加减乘除区厂阁汽院秒期级"
        "郎";
    const string kNumberWord = "壹一二三四五六七八九零十";
    const string KNumberLevel = "千万亿百度";
    if (FLAGS_use_yi_postprocess) {
      if (cur_word.syllables.size() == 3 &&
          cur_word.syllables[1].character == "一" &&
          cur_word.syllables[0].character == cur_word.syllables[2].character) {
        cur_word.syllables[1].tone = 5;
      }
      for (size_t i = 0; i < cur_word.syllables.size(); ++i) {
        if (cur_word.syllables[i].character == "一") {
          if (cur_word.syllables.size() == 1) {
            // single word 一
            cur_word.syllables[i].tone = 1;
          } else if ((i < cur_word.syllables.size() - 1 &&
                      KNumberLevel.find(cur_word.syllables[i + 1].character) !=
                          string::npos) &&
                     (i == 0 ||
                      kNumberWord.find(cur_word.syllables[i - 1].character) ==
                          string::npos)) {
            if (cur_word.syllables[i + 1].tone != 4)
              cur_word.syllables[i].tone = 4;
            else
              cur_word.syllables[i].tone = 2;
          } else if ((i > 0 &&
                      kYiPreWord.find(cur_word.syllables[i - 1].character) !=
                          string::npos) ||
                     (i < cur_word.syllables.size() - 1 &&
                      kYiPostWord.find(cur_word.syllables[i + 1].character) !=
                          string::npos)) {
            cur_word.syllables[i].tone = 1;
          } else if (cur_word.syllables.size() >= 3 && i == 0 &&
                     cur_word.syllables[1].character == "点" &&
                     IsChineseNumber(cur_word.syllables[2].character)) {
            cur_word.syllables[i].tone = 1;
          } else if (i < cur_word.syllables.size() - 1 &&
                     kYiExceptions.find(cur_word.syllables[i + 1].character) ==
                         string::npos &&
                     !IsChineseNumber(cur_word.syllables[i + 1].character)) {
            if (cur_word.syllables[i + 1].tone == 4 &&
                cur_word.syllables[i + 1].character != "度" &&
                (word_idx == 0 ||
                 word_info->at(word_idx - 1).syllables.size() != 1 ||
                 word_info->at(word_idx - 1).word != "第")) {
              cur_word.syllables[i].tone = 2;
            } else if (cur_word.syllables[i + 1].tone != 4 &&
                       cur_word.syllables[i + 1].tone != 5 &&
                       cur_word.syllables[i + 1].character != "甲") {
              cur_word.syllables[i].tone = 4;
            }
          } else if (i == cur_word.syllables.size() - 1 &&
                     word_idx < word_info->size() - 1) {
            if (word_info->at(word_idx + 1).syllables.size() > 0) {
              if ((word_info->at(word_idx + 1).syllables[0].tone != 4 &&
                   word_info->at(word_idx + 1).syllables[0].tone != 5 &&
                   word_info->at(word_idx + 1).syllables[0].character !=
                       "甲")) {
                cur_word.syllables[i].tone = 4;
              } else {
                if (word_info->at(word_idx + 1).syllables[0].tone == 4) {
                  cur_word.syllables[i].tone = 2;
                }
              }
            }
          }
        }
      }
    }

    // Rule3, 3声的变调, n * 214 → (n-1) * 35 + 214
    // eg:水果 了解 领导 马虎 指甲
    if (FLAGS_use_sandhi) {
      if (CONTAINS_WORD(kSandhiWord, cur_word.word)) {
        cur_word.syllables[1].tone = 6;
      } else {
        for (size_t syl_idx = 0; syl_idx < cur_word.syllables.size() - 1;
             ++syl_idx) {
          if (cur_word.syllables[syl_idx].tone == 3 &&
              cur_word.syllables[syl_idx + 1].tone == 3 &&
              cur_word.syllables[syl_idx + 1].character != "儿") {
            cur_word.syllables[syl_idx].tone = 6;
          }
        }
      }
    }
    // Rule4, 叠词的轻声变调
    // eg: 奶奶 爸爸 笑眯眯 婆婆妈妈
    if (FLAGS_use_soft_tone_rules) {
      // 格格不入
      string find_word = string();
      if (cur_word.syllables[cur_word.syllables.size() - 1].character == "的" ||
          cur_word.syllables[cur_word.syllables.size() - 1].character == "地") {
        for (size_t s_index = 0; s_index < cur_word.syllables.size() - 1;
             ++s_index)
          find_word.append(cur_word.syllables[s_index].character);
      } else {
        find_word = cur_word.word;
      }
      if (soft_word.find(find_word) != soft_word.end() &&
          cur_word.syllables.size() > 1) {
        LOG(INFO) << cur_word.word << " not need use soft tone rule.";
      } else {
        for (size_t syl_idx = 0; syl_idx < cur_word.syllables.size() - 1;
             ++syl_idx) {
          SyllableInfo& csyllable = cur_word.syllables[syl_idx];
          SyllableInfo& nsyllable = cur_word.syllables[syl_idx + 1];
          if (soft_word.find(csyllable.character) != soft_word.end() &&
              csyllable.character == nsyllable.character &&
              csyllable.prons.size() == nsyllable.prons.size()) {
            bool reduplication = true;
            for (size_t phone_idx = 0; phone_idx < csyllable.prons.size();
                 ++phone_idx) {
              if (csyllable.prons[phone_idx] != nsyllable.prons[phone_idx]) {
                reduplication = false;
                break;
              }
              if (csyllable.tone != nsyllable.tone) {
                reduplication = false;
                break;
              }
            }
            if (reduplication) nsyllable.tone = 5;
          }
          // 早早儿、远远儿、好好儿
          if (csyllable.character == nsyllable.character) {
            if (syl_idx < cur_word.syllables.size() - 2) {
              SyllableInfo& nnsyllable = cur_word.syllables[syl_idx + 2];
              if (nnsyllable.character == "儿" &&
                  nnsyllable.prons.size() == 1 &&
                  nnsyllable.prons[0] == kPhoneRhotic) {
                nsyllable.tone = 1;
                nnsyllable.tone = 1;
              }
            }
          }
        }
        //大哥哥、大妈妈、大猩猩、好妈妈、我妈妈、爹、盼星星、老公公、老哥哥、胡姑姑、艾窝窝、香饽饽
        // 笑眯眯的
        const string kRupExceptions = "哥妈星猩爹公哥姑窝叔听饽";
        size_t cur_len = cur_word.syllables.size();
        size_t pre_index = cur_len - 2;
        size_t post_index = cur_len - 1;
        if (cur_word.syllables[post_index].character == "的" ||
            cur_word.syllables[post_index].character == "地") {
          pre_index -= 1;
          post_index -= 1;
          cur_len -= 1;
        }
        if (cur_len == 3 || cur_len == 4) {
          SyllableInfo& csyllable = cur_word.syllables[post_index];
          SyllableInfo& nsyllable = cur_word.syllables[pre_index];
          if (csyllable.character == nsyllable.character) {
            if (nsyllable.tone == 1 ||
                (nsyllable.tone == 5 && nsyllable.tone == csyllable.tone)) {
              if (cur_len == 4 &&
                  cur_word.syllables[0].character ==
                      cur_word.syllables[1].character) {
                csyllable.tone = 1;
                nsyllable.tone = 1;
              }
              if (cur_len == 3 &&
                  kRupExceptions.find(csyllable.character) == string::npos) {
                csyllable.tone = 1;
                nsyllable.tone = 1;
              }
            }
          }
        }
      }
    }
    // Rule5, 5声的变调
    // TODO(zhengzhang): remove me later
    // update word pron for 鹙鹙 kiu1 kiu1
    for (size_t syl_idx = 0; syl_idx < cur_word.syllables.size(); ++syl_idx) {
      if (cur_word.syllables[syl_idx].character == "鹙") {
        cur_word.syllables[syl_idx].prons = {"k", "iu"};
        cur_word.syllables[syl_idx].tone = 1;
      }
    }
    // pron update for special words '地'
    if (cur_word.syllables.back().character == "地" &&
        cur_word.syllables.back().pos == "u") {
      cur_word.syllables.back().prons[0] = "d";
      cur_word.syllables.back().prons[1] = "e";
      cur_word.syllables.back().tone = 5;
    }
    // 33 sandhi cross words
    if (FLAGS_use_sandhi && FLAGS_use_phrases_sandhi_rules) {
      // Rule3, 3声的变调, n * 214 → (n-1) * 35 + 214
      // eg:水果 了解 领导 马虎 指甲
      if (cur_word.pause_level < kPauseLevelPhrase &&
          cur_word.syllables.back().tone == 3 &&
          word_info->at(word_idx + 1).syllables[0].tone == 3) {
        cur_word.syllables.back().tone = 6;
      }
    }
    for (auto pro : cur_word.p_pron_fixeds) {
      if (pro.first < cur_word.syllables.size())
        if (cur_word.syllables[pro.first].tone != 6)
          cur_word.syllables[pro.first] = origin_syllables[pro.first];
    }
  }
}

void RemoveFrontEndBreak(vector<int>* result) {
  int remove_num = 2;
  for (size_t i = 0; i < result->size() - 1; ++i) {
    if (i < (size_t)remove_num && (*result)[i] == kPauseLevelSP) {
      (*result)[i] = kPauseLevelPhrase;
      continue;
    }
    if (i >= result->size() - remove_num - 1 && (*result)[i] == kPauseLevelSP) {
      (*result)[i] = kPauseLevelPhrase;
      continue;
    }
  }
}

string GetDebugPauseFromPauseLevel(int pause_level) {
  switch (pause_level) {
    case kPauseLevelWord:
      return "#1";
    case kPauseLevelPhrase:
      return "#2";
    case kPauseLevelSP:
      return "#3";
    case kPauseLevelLP:
      return "#3";
    case kPauseLevelSilence:
      return "#4";
  }
  return "";
}

int PauseMark2Level(const string& s) {
  if (s == kSepMarkNone) return kPauseLevelSyl;
  if (s == kSepMarkWord) return kPauseLevelWord;
  if (s == kSepMarkPhrase) return kPauseLevelPhrase;
  if (s == kSepMarkSP) return kPauseLevelSP;
  if (s == kSepMarkLP) return kPauseLevelLP;
  if (s == kSepMarkSilence) return kPauseLevelSilence;
  return kPauseLevelNotFound;
}

void RevisePuncByMono(const string norm, const vector<string> mono_syl,
                      string* output) {
  vector<util::Rune> norm_unicode;
  util::Utf8ToUnicode(norm, &norm_unicode);
  int mono_syl_id = 1;
  // add punctuation according to monolabel
  for (size_t i = 0; i < norm_unicode.size(); ++i) {
    string utf8 = util::RuneToWord(norm_unicode[i]);
    if (!IsSeperator(utf8)) {
      // 间 sp jian
      if (mono_syl[mono_syl_id] == kPhoneSP) {
        *output += kSepMarkSP;
        VLOG(1) << kSepMarkSP << mono_syl[mono_syl_id];
        ++mono_syl_id;
      }
      VLOG(1) << utf8 << mono_syl[mono_syl_id];
      *output += utf8;
      ++mono_syl_id;
    } else {
      // Seperator
      // change break seperator to phrase seperater
      // if mono do not has sp and sil or pause label has word sep
      if (mono_syl[mono_syl_id] != kPhoneSP &&
          mono_syl[mono_syl_id] != kPhoneLP &&
          mono_syl[mono_syl_id] != kPhoneSilence && utf8 != kSepMarkWord) {
        *output += kSepMarkPhrase;
        VLOG(1) << kSepMarkPhrase;
      } else {
        *output += utf8;
        VLOG(1) << utf8;
      }
    }
  }
  // remove repeat punctuation
  // fix silence in scripts but sp in mono
  static re2::RE2 obj1("\\.");
  re2::RE2::GlobalReplace(output, obj1, kSepMarkLP);
  static re2::RE2 obj2("[\\^,@`]*,+[\\^,@`]*");
  re2::RE2::GlobalReplace(output, obj2, kSepMarkLP);
  static re2::RE2 obj3("[\\^@`]*@+[\\^@`]*");
  re2::RE2::GlobalReplace(output, obj3, kSepMarkSP);
  VLOG(1) << *output;
}

bool IsSeperator(const string& ch) {
  if (ch == kSepMarkWord || ch == kSepMarkPhrase || ch == kSepMarkSP ||
      ch == kSepMarkLP || ch == kSepMarkSilence) {
    return true;
  }
  return false;
}

void ParseMandSyllable(const string& pron, vector<string>* phonemes,
                       string* vowel, int* tone) {
  if (pron == "sil0") return;
  string syl;
  *vowel = "X";
  // default tone is 5
  if (std::isdigit(pron[pron.size() - 1])) {
    syl = pron.substr(0, pron.size() - 1);
    *tone = pron[pron.size() - 1] - '0';
  } else {
    syl = pron;
    *tone = 5;
  }

  if (syl == "ng") syl = "en";
  if (syl == kPhoneRhotic) {
    phonemes->push_back(syl);
    return;
  }

  // single ABC
  if (syl[0] >= 'A' && syl[0] <= 'Z') {
    vector<string> segs;
    SplitString(pron, ' ', &segs);
    // ABC tone
    *tone = 7;
    static re2::RE2 obj("\\d+");
    for (string phone : segs) {
      // remove stress
      re2::RE2::GlobalReplace(&phone, obj, kSepMarkNone);
      phonemes->push_back(phone);
    }
    return;
  }

  for (size_t i = 0; i < syl.length(); ++i) {
    if (IsManVowel(syl[i])) {
      if (i == 0) {
        // single final
        phonemes->push_back(syl);
        *vowel = syl;
      } else {
        // consonant and final
        *vowel = syl.substr(i);
        phonemes->push_back(syl.substr(0, i));
        phonemes->push_back(syl.substr(i));
      }
      return;
    }
  }
  LOG(ERROR) << "g2p no such syllable:" << syl;
}

// TODO(yongqiangli): Refactor this
void ParseCanSyllable(const string& pron, vector<string>* phonemes,
                      string* vowel, int* tone) {
  if (pron == "sil0") return;
  string syl;
  *vowel = "X";
  // default tone is 5
  if (std::isdigit(pron[pron.size() - 1])) {
    syl = pron.substr(0, pron.size() - 1);
    *tone = pron[pron.size() - 1] - '0';
  } else {
    syl = pron;
    *tone = 7;
  }

  if (syl == kPhoneRhotic) {
    phonemes->push_back(syl);
    return;
  }

  // single ABC
  if (syl[0] >= 'A' && syl[0] <= 'Z') {
    vector<string> segs;
    SplitString(pron, ' ', &segs);
    // ABC tone
    *tone = 7;
    static re2::RE2 obj("\\d+");
    for (string phone : segs) {
      // remove stress
      re2::RE2::GlobalReplace(&phone, obj, kSepMarkNone);
      phonemes->push_back(phone);
    }
    return;
  }
  if (syl == "m" || syl == "ng") {
    phonemes->push_back(syl);
    *vowel = syl;
    return;
  }

  for (size_t i = 0; i < syl.length(); ++i) {
    if (IsCanVowel(syl[i])) {
      if (i == 0) {
        // single final
        phonemes->push_back(syl);
        *vowel = syl;
      } else {
        // consonant and final
        *vowel = syl.substr(i);
        phonemes->push_back(syl.substr(0, i));
        phonemes->push_back(syl.substr(i));
      }
      return;
    }
  }
  LOG(ERROR) << "g2p no such syllable:" << syl;
}

void SplitMandOrCanSyllable(const vector<string>& prons, const string& language,
                            vector<vector<string>>* syllable_prons,
                            vector<string>* vowels, vector<int>* tones) {
  for (const string& pron : prons) {
    vector<string> prons_tmp;
    string vowel_tmp;
    int tone_tmp;
    // english words
    if (!pron.empty() && pron[0] >= 'A' && pron[0] <= 'Z') {
      vector<string> prons_tmp;
      prons_tmp.push_back(pron);
      SplitEnSyllable(prons_tmp, syllable_prons, vowels, tones);
      continue;
    }
    if (language == kMandarinTypeString || language == kTaiwaneseTypeString ||
        language == kSichuaneseTypeString) {
      ParseMandSyllable(pron, &prons_tmp, &vowel_tmp, &tone_tmp);
    }
    if (language == kCantoneseTypeString) {
      ParseCanSyllable(pron, &prons_tmp, &vowel_tmp, &tone_tmp);
    }
    if (!prons_tmp.empty()) {
      if (prons_tmp.size() == 1 && !IsSingleAbc(prons_tmp[0]) &&
          prons_tmp[0] != kPhoneRhotic) {
        // syllable_info->prons[0] += "z";
      }
      syllable_prons->push_back(prons_tmp);
      vowels->push_back(vowel_tmp);
      tones->push_back(tone_tmp);
    }
  }
}

void SplitEnSyllable(const vector<string>& prons,
                     vector<vector<string>>* syllable_prons,
                     vector<string>* vowels, vector<int>* tones) {
  for (const string& pron : prons) {
    vector<string> phonemes;
    SplitString(pron, ' ', &phonemes);
    int tone;
    string vowel;
    for (string& phoneme : phonemes) {
      if (IsEngVowel(phoneme)) {
        if (std::isdigit(phoneme[phoneme.size() - 1])) {
          tone = phoneme[phoneme.size() - 1] - '0';
          phoneme = phoneme.substr(0, phoneme.size() - 1);
          if (tone == 0) {
            tone = Stress::kNonStress;
          } else if (tone == 2) {
            tone = Stress::kSubStress;
          } else {
            tone = Stress::kStress;
          }
        } else {
          tone = Stress::kNonStress;
        }
        vowel = phoneme;
      }
    }
    tones->push_back(tone);
    vowels->push_back(vowel);
    syllable_prons->push_back(phonemes);
  }
}

void ErhuayinProcess(const mobvoi::unordered_set<string>& erhua_set,
                     vector<WordToken>* word_token) {
  VLOG(2) << "Start to process erhua ...";
  for (WordToken& cur_word : *word_token) {
    if (cur_word.pron_fixed ||
        cur_word.p_pron_fixeds.size() ==
            (size_t)util::utflen(cur_word.word.c_str()))
      continue;
    if (cur_word.word.find("儿") != std::string::npos) {
      vector<util::Rune> word_unicode;
      util::Utf8ToUnicode(cur_word.word, &word_unicode);
      for (size_t j = 1; j < word_unicode.size(); ++j) {
        if (util::RuneToWord(word_unicode[j]) == "儿") {
          string keyword1, keyword2;
          keyword1 = util::RuneToWord(word_unicode[j - 1]);
          if (static_cast<int>(j) - 2 >= 0)
            keyword2 = util::RuneToWord(word_unicode[j - 2]) + keyword1;
          if ((erhua_set.find(keyword1) != erhua_set.end() ||
               erhua_set.find(keyword2) != erhua_set.end()) &&
              cur_word.p_pron_fixeds.find(j) == cur_word.p_pron_fixeds.end()) {
            cur_word.prons[j] =
                string() + kPhoneRhotic + cur_word.prons[j - 1].back();
          }
        }
      }
    }
  }
  VLOG(2) << "Erhua process finished";
}

void RemoveWordLP(vector<WordToken>* word_tokens) {
  for (auto it = word_tokens->begin(); it != word_tokens->end(); ++it) {
    if (it->word == kSepMarkPhrase) {
      if (it != word_tokens->begin() &&
          (it - 1)->pause_level < kPauseLevelPhrase) {
        (it - 1)->pause_level = kPauseLevelPhrase;
      }
    } else if (it->word == kSepMarkWord) {
      if (it != word_tokens->begin() &&
          (it - 1)->pause_level < kPauseLevelWord) {
        (it - 1)->pause_level = kPauseLevelWord;
      }
    } else if (it->word == kSepMarkLP || it->word == kSepMarkSilence) {
      if (it != word_tokens->begin() && (it - 1)->pause_level < kPauseLevelLP) {
        (it - 1)->pause_level = kPauseLevelLP;
      }
      word_tokens->erase(it);
      --it;
    }
  }
}

void RestrictLevel(vector<WordToken>* word_tokens) {
  RestrictTargetLevel(kPauseLevelWord, kWordMin, kWordMax, word_tokens);
  RestrictTargetLevel(kPauseLevelPhrase, kPhraseMin, kPhraseMax, word_tokens);
  RestrictTargetLevel(kPauseLevelSP, kBreakMin, kBreakMax, word_tokens);
}

void ProcessSsmlLevel(vector<WordToken>* word_token) {
  VLOG(2) << "Start to set ssml pause level ...";
  vector<WordToken> word_token_temp;
  int last_set_pause = -1;
  for (auto it = word_token->begin(); it != word_token->end(); ++it) {
    if (it->seted_pauses.empty()) {
      if (last_set_pause != -1 && IsSeperator(it->word)) {
        it->pause_level = last_set_pause;
        it->pause_fixed = true;
      }
      word_token_temp.emplace_back(*it);
      last_set_pause = -1;
    } else {
      vector<string> chars;
      util::SplitUtf8String(it->word, &chars);
      vector<string> prons = it->prons;
      if (chars.size() != it->prons.size()) {
        if (tts::IsEnglishWord(it->word) && it->seted_pauses.size() == 1) {
          WordToken token_tmp;
          token_tmp.word = it->word;
          token_tmp.language = it->language;
          token_tmp.word_id = 0;
          token_tmp.pause_level = MapSsmlPause(it->seted_pauses.at(0).second);
          token_tmp.pos = it->pos;
          token_tmp.prons = prons;
          token_tmp.pause_fixed = true;
          word_token_temp.emplace_back(token_tmp);
        } else {
          VLOG(2) << "word pron mismatch: " << it->word;
          word_token_temp.emplace_back(*it);
        }
        continue;
      }
      WordToken token_tmp;
      token_tmp.language = it->language;
      token_tmp.word_id = 0;
      token_tmp.pause_level = it->pause_level;
      token_tmp.pos = it->pos;
      size_t start = 0, end = 0;
      for (auto p_it : it->seted_pauses) {
        end = p_it.first;
        while (start <= end) {
          token_tmp.word += chars[start];
          token_tmp.prons.emplace_back(prons[start]);
          start++;
        }
        token_tmp.pause_level = MapSsmlPause(p_it.second);
        token_tmp.pause_fixed = true;
        word_token_temp.emplace_back(token_tmp);
        token_tmp.word.clear();
        token_tmp.prons.clear();
      }
      // while the last word was seted, then change next symbol pause level
      if (end == chars.size() - 1) {
        last_set_pause = token_tmp.pause_level;
        continue;
      }
      end = chars.size() - 1;
      while (start <= end) {
        token_tmp.word += chars[start];
        token_tmp.prons.emplace_back(prons[start]);
        start++;
      }
      if (!token_tmp.word.empty()) {
        token_tmp.pause_level = it->pause_level;
        word_token_temp.emplace_back(token_tmp);
      }
    }
  }
  *word_token = word_token_temp;
  VLOG(2) << "Ssml pause level set finished";
}

// restrict word number limit of target pause level
void RestrictTargetLevel(int restrict_level, int min, int max,
                         vector<WordToken>* word_tokens) {
  if (min > max) return;
  // -1 stands for no last setted break word
  static int default_offset = -1;
  static int default_level = 0;
  int last_offset = default_offset;
  int last_level = default_level;
  int word_num = 0;
  for (size_t i = 0; i < word_tokens->size(); ++i) {
    WordToken& word_token = word_tokens->at(i);
    word_num += 1;
    if (word_token.pause_level >= restrict_level) {
      // if len less than min limit, set to original level
      if (word_token.pause_level <= kPauseLevelLP && word_num < min &&
          last_offset != default_offset) {
        word_tokens->at(last_offset).pause_level = last_level;
      }
      last_offset = default_offset;
      last_level = default_level;
      word_num = 0;
    } else {
      int target_level =
          restrict_level == kPauseLevelWord ? 0 : restrict_level - 1;
      // if len large than max limit, set to restrict level
      if (word_token.pause_level == target_level && word_num >= max) {
        last_level = word_token.pause_level;
        last_offset = i;
        word_token.pause_level = restrict_level;
        word_num = 0;
      }
    }
  }
}

void MergeWord(vector<WordToken>* word_token) {
  VLOG(2) << "Start to Merge prosody words ...";
  for (auto it = word_token->begin(); it != word_token->end(); ++it) {
    if (it == word_token->end() - 1) continue;
    if (it->pause_level == 0) {
      auto next = it + 1;
      // avoid merge english word with mandarin word
      if (next->word == kSepMarkWord || next->word == kSepMarkPhrase ||
          next->word == kSepMarkSP || next->word == kSepMarkLP ||
          (next->language != it->language && next->word != "的") ||
          util::utflen(it->word.c_str()) + util::utflen(next->word.c_str()) >
              kMaxProsodyWordLen) {
        continue;
      }
      next->word = it->word + next->word;
      next->word_id = 0;
      next->pos = it->pos;
      next->prons.insert(next->prons.begin(), it->prons.begin(),
                         it->prons.end());
      if (!next->p_pron_fixeds.empty()) {
        for (auto pro : next->p_pron_fixeds) {
          it->p_pron_fixeds[util::utflen(it->word.c_str()) + pro.first] = true;
        }
      }
      next->p_pron_fixeds = it->p_pron_fixeds;
      word_token->erase(it);
      --it;
    }
  }
  VLOG(2) << "Prosody words merge finished";
}

bool IsChineseNumber(const string& ch) {
  if (ch == "一" || ch == "二" || ch == "三" || ch == "四" || ch == "五" ||
      ch == "六" || ch == "七" || ch == "八" || ch == "九" || ch == "十") {
    return true;
  }
  return false;
}

bool IsManVowel(const char& ch) {
  if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' ||
      ch == 'v') {
    return true;
  }
  return false;
}

bool IsCanVowel(const char& ch) {
  if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' ||
      ch == 'y') {
    return true;
  }
  return false;
}

bool IsSingleAbc(const string& phoneme) {
  if (phoneme.length() == 1 && std::isupper(phoneme[0])) {
    return true;
  }
  return false;
}

bool IsEnglishPhone(const string& phoneme) {
  if (std::isupper(phoneme[0])) {
    return true;
  }
  return false;
}

}  // namespace tts
