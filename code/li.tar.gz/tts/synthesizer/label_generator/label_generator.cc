// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/synthesizer/label_generator/label_generator.h"

#include "mobvoi/base/log.h"
#include "tts/synthesizer/label_generator/label_creator.h"

namespace tts {

LabelGenerator::LabelGenerator() {}
LabelGenerator::~LabelGenerator() {}

bool LabelGenerator::GenLabels(const vector<SsmlText>& text,
                               const LabelOption& label_option, bool is_online,
                               vector<string>* labels,
                               Json::Value* debug_info) {
  TnDetail detail;
  return GenLabels(text, label_option, is_online, labels, debug_info, &detail);
}

bool LabelGenerator::GenLabels(const vector<SsmlText>& text,
                               const LabelOption& label_option, bool is_online,
                               vector<string>* labels, Json::Value* debug_info,
                               TnDetail* detail) {
  SentInfo sent_info;
  if (!TextAnalysis(text, label_option, is_online, &sent_info, detail)) {
    if (label_option.only_frontend()) {
      if (detail->tn_input.empty()) {
        detail->tn_input = SsmlParser::Instance().JoinText(text);
      }
      ConstructDefaultSentInfo(*detail, label_option, debug_info);
    }
    return false;
  }

  LabelCreator creator;
  creator.CreateLabels(label_option, sent_info, labels);

  if (debug_info) {
    *debug_info = sent_info.debug_info;
    VLOG(2) << debug_info->toStyledString();
  }
  return true;
}

bool LabelGenerator::TextAnalysis(const vector<SsmlText>& input,
                                  const LabelOption& label_option,
                                  bool is_online, SentInfo* sentence,
                                  TnDetail* detail) const {
  vector<WordInfo> word_infos;

  if (!is_online) {
    if (!OfflineTextAnalysis(SsmlParser::Instance().JoinText(input),
                             label_option, &word_infos))
      return false;
  } else {
    if (!OnlineTextAnalysis(input, label_option, &word_infos, detail)) {
      return false;
    }
  }
  return GenSentInfo(*detail, word_infos, label_option, is_online, sentence);
}

}  // namespace tts
