// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaoqin.feng@mobvoi.com

#include "tts/synthesizer/label_generator/phone_mapper.h"

#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/string_util.h"
#include "third_party/gtest/gtest.h"

DEFINE_string(phone_mapper_dict,
              "external/config/front_end/dict/phone_mapping.dict",
              "phone mapping dict");

namespace tts {

class Phone_Mapper_Test : public ::testing::Test {
 protected:
  virtual void SetUp() {
    phone_mapper_.reset(new PhoneMapper(FLAGS_phone_mapper_dict));
  }

  void PinyinToToneTest(const string& frontend_type, const string& pinyin,
                        const string& actual_tone) const {
    string expect_tone;
    phone_mapper_->PinyinToTone(frontend_type, pinyin, &expect_tone);
    EXPECT_EQ(expect_tone, actual_tone);
  }
  void ToneToPinyinTest(const string& frontend_type, const string& tone,
                        const string& actual_pinyin) const {
    string expect_pinyin;
    phone_mapper_->ToneToPinyin(frontend_type, tone, &expect_pinyin);
    EXPECT_EQ(expect_pinyin, actual_pinyin);
  }
  std::unique_ptr<tts::PhoneMapper> phone_mapper_;
};

TEST_F(Phone_Mapper_Test, ManPinyinToTone) {
  vector<string> man_pinyin = {"ni2", "yvn2", "lv2"};
  vector<string> man_tone = {"ní", "yún", "lǘ"};
  for (size_t i = 0; i < man_pinyin.size(); ++i) {
    PinyinToToneTest("man", man_pinyin[i], man_tone[i]);
  }
}

TEST_F(Phone_Mapper_Test, EngPinyinToTone) {
  vector<string> eng_pinyin = {"HH AH 7_L OW 8"};
  vector<string> eng_tone = {"hʌ`ləʊ"};
  for (size_t i = 0; i < eng_pinyin.size(); ++i) {
    PinyinToToneTest("eng", eng_pinyin[i], eng_tone[i]);
  }
}

TEST_F(Phone_Mapper_Test, ManToneToPinyin) {
  vector<string> man_pinyin = {"ni2", "yvn2", "lv2"};
  vector<string> man_tone = {"ní", "yún", "lǘ"};
  for (size_t i = 0; i < man_tone.size(); ++i) {
    ToneToPinyinTest("man", man_tone[i], man_pinyin[i]);
  }
}

TEST_F(Phone_Mapper_Test, EngToneToPinyin) {
  vector<string> eng_pinyin = {"HH AH0_L OW1"};
  vector<string> eng_tone = {"hʌ`ləu"};
  for (size_t i = 0; i < eng_tone.size(); ++i) {
    ToneToPinyinTest("eng", eng_tone[i], eng_pinyin[i]);
  }
}

}  // namespace tts
