// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_SYNTHESIZER_LABEL_GENERATOR_LABEL_GENERATOR_H_
#define TTS_SYNTHESIZER_LABEL_GENERATOR_LABEL_GENERATOR_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "tts/synthesizer/label_generator/label_generator_def.h"
#include "tts/synthesizer/label_generator/sent_info.h"
#include "tts/util/ssml/ssml_parser.h"
#include "tts/util/tts_util/util.h"

namespace tts {

class LabelGenerator {
 public:
  LabelGenerator();
  virtual ~LabelGenerator();
  bool GenLabels(const vector<SsmlText>& input, const LabelOption& label_option,
                 bool is_online, vector<string>* labels,
                 Json::Value* debug_info);
  bool GenLabels(const vector<SsmlText>& input, const LabelOption& label_option,
                 bool is_online, vector<string>* labels,
                 Json::Value* debug_info, TnDetail* detail);

 protected:
  bool TextAnalysis(const vector<SsmlText>& input,
                    const LabelOption& label_opton, bool is_online,
                    SentInfo* sentence, TnDetail* detail) const;
  virtual bool OnlineTextAnalysis(const vector<SsmlText>& input,
                                  const LabelOption& label_option,
                                  vector<WordInfo>* word_infos,
                                  TnDetail* detail) const = 0;
  virtual bool OfflineTextAnalysis(const string& input,
                                   const LabelOption& label_option,
                                   vector<WordInfo>* word_infos) const = 0;

 private:
  DISALLOW_COPY_AND_ASSIGN(LabelGenerator);
};
}  // namespace tts

#endif  // TTS_SYNTHESIZER_LABEL_GENERATOR_LABEL_GENERATOR_H_
