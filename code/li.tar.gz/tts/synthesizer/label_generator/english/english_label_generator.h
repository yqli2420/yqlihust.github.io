// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_SYNTHESIZER_LABEL_GENERATOR_ENGLISH_ENGLISH_LABEL_GENERATOR_H_
#define TTS_SYNTHESIZER_LABEL_GENERATOR_ENGLISH_ENGLISH_LABEL_GENERATOR_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "tts/nlp/g2p/g2p.h"
#include "tts/nlp/pause_level/pause_predictor.h"
#include "tts/nlp/segmenter/en_segmenter.h"
#include "tts/nlp/tn/text_normalizer.h"
#include "tts/synthesizer/label_generator/label_generator.h"

namespace tts {
class EnglishLabelGenerator : public LabelGenerator {
 public:
  EnglishLabelGenerator(const string& language, const string& resource_file);
  virtual ~EnglishLabelGenerator();

 private:
  bool OnlineTextAnalysis(const vector<SsmlText>& input,
                          const LabelOption& label_option,
                          vector<WordInfo>* word_infos,
                          TnDetail* detail) const override;

  bool OfflineTextAnalysis(const string& input, const LabelOption& label_option,
                           vector<WordInfo>* word_infos) const override;
  void TextNormalize(const vector<SsmlText>& input,
                     const LabelOption& label_option,
                     vector<SsmlText>* output) const;
  void NormMandarinCharacter(const string& input, string* output) const;
  bool G2P(vector<WordToken>* word_tokens) const;
  void MarkPauseLevel(vector<WordToken>* word_tokens) const;

  std::unique_ptr<nlp::tn::TextNormalizer> text_normalizer_;
  std::unique_ptr<nlp::g2p::G2p> eng_g2p_;
  std::unique_ptr<nlp::prosody::PausePredictor> pause_predictor_;
  std::unique_ptr<nlp::segmenter::EnglishSegmenter> segmenter_;
  mobvoi::unordered_map<string, string> mandarin_english_map_;

  DISALLOW_COPY_AND_ASSIGN(EnglishLabelGenerator);
};
}  // namespace tts

#endif  // TTS_SYNTHESIZER_LABEL_GENERATOR_ENGLISH_ENGLISH_LABEL_GENERATOR_H_
