// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/synthesizer/label_generator/english/english_label_generator.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/file/proto_util.h"
#include "mobvoi/base/log.h"
#include "tts/synthesizer/label_generator/label_util.h"
#include "tts/synthesizer/label_generator/proto/frontend.pb.h"

namespace tts {

EnglishLabelGenerator::EnglishLabelGenerator(const string& language,
                                             const string& resource_file) {
  FrontendResource fe_res;
  CHECK(mobvoi::ReadProtoFromTextFile(resource_file, &fe_res))
      << resource_file << " load failed!";
  string dir = mobvoi::File::FindFileDir(resource_file);
  if (!fe_res.tn().empty())
    text_normalizer_.reset(
        new nlp::tn::TextNormalizer(language, dir + fe_res.tn()));
  if (!fe_res.eng_dict().empty())
    segmenter_.reset(
        new nlp::segmenter::EnglishSegmenter(dir + fe_res.eng_dict()));
  if (!fe_res.g2p().empty())
    eng_g2p_.reset(new nlp::g2p::G2p(dir + fe_res.g2p()));
  if (!fe_res.pause().empty())
    pause_predictor_.reset(
        new nlp::prosody::PausePredictor(dir + fe_res.pause()));
  LoadMapFromFile(dir + fe_res.mand_eng_map(), &mandarin_english_map_);
}

EnglishLabelGenerator::~EnglishLabelGenerator() {}

bool EnglishLabelGenerator::OfflineTextAnalysis(
    const string& input, const LabelOption& label_option,
    vector<WordInfo>* word_infos) const {
  return true;
}

bool EnglishLabelGenerator::OnlineTextAnalysis(const vector<SsmlText>& input,
                                               const LabelOption& label_option,
                                               vector<WordInfo>* word_infos,
                                               TnDetail* detail) const {
  vector<WordToken> word_tokens;
  vector<SsmlText> norm;
  TextNormalize(input, label_option, &norm);
  // TODO(zhengzhang): process ssml tags in other module in the future
  string joined_string = SsmlParser::Instance().JoinText(norm);
  string english_text;
  NormMandarinCharacter(joined_string, &english_text);
  vector<nlp::segmenter::SegmentWord> segmentwords;
  if (!segmenter_->WordSegmentation(english_text, &segmentwords)) {
    LOG(WARNING) << "Segment word empty!";
    return false;
  }
  for (const auto& segmentword : segmentwords) {
    WordToken word_token_tmp;
    word_token_tmp.word = segmentword.word;
    word_token_tmp.pos = segmentword.pos;
    word_token_tmp.word_id = segmentword.word_id;
    word_token_tmp.language = WordLanguage::kEnglishWord;
    word_tokens.push_back(word_token_tmp);
  }
  if (!G2P(&word_tokens)) {
    LOG(WARNING) << "G2P error!";
    return false;
  }
  MarkPauseLevel(&word_tokens);
  map<int, int> polyphone_prob;
  mobvoi::unordered_set<string> soft_word;
  if (!GenWordInfos(word_tokens, polyphone_prob, soft_word, label_option, true,
                    word_infos)) {
    return false;
  }
  return true;
}

void EnglishLabelGenerator::NormMandarinCharacter(const string& input,
                                                  string* output) const {
  vector<string> utf8;
  util::SplitUtf8String(input, &utf8);
  for (const auto& character : utf8) {
    auto it = mandarin_english_map_.find(character);
    if (it != mandarin_english_map_.end()) {
      *output += kSepMarkWord + kPinyinTag + it->second + kSepMarkWord;
    } else {
      *output += character;
    }
  }
}

void EnglishLabelGenerator::TextNormalize(const vector<SsmlText>& input,
                                          const LabelOption& label_option,
                                          vector<SsmlText>* output) const {
  text_normalizer_->Normalize(input, label_option.domain(), output);
}

bool EnglishLabelGenerator::G2P(vector<WordToken>* word_tokens) const {
  VLOG(2) << "Start g2p ...";
  for (auto& word : *word_tokens) {
    eng_g2p_->GetPron(word.word, &(word.prons));
  }
  return true;
}

void EnglishLabelGenerator::MarkPauseLevel(
    vector<WordToken>* word_tokens) const {
  VLOG(2) << "Start Pause prediction ...";
  vector<nlp::prosody::InputToken> token;
  // TODO(zhengzhang): merge token position into InputToken
  vector<int> token_position;
  static re2::RE2 token_pattern("([a-zA-Z'-]+)");

  if (!word_tokens->empty()) word_tokens->back().pause_level = kPauseLevelLP;
  RemoveWordLP(word_tokens);

  for (size_t i = 0; i < word_tokens->size(); ++i) {
    WordToken cur_word = word_tokens->at(i);
    if (RE2::FullMatch(cur_word.word, token_pattern)) {
      nlp::prosody::InputToken token_tmp;
      token_tmp.word = cur_word.word;
      token_tmp.word_id = cur_word.word_id;
      token_tmp.pos = cur_word.pos;
      token.push_back(token_tmp);
      token_position.push_back(i);
    }
    if (cur_word.pause_level == kPauseLevelLP) {
      if (!token.empty()) {
        vector<int> cur_result;
        pause_predictor_->Predict(token, &cur_result);
        RemoveFrontEndBreak(&cur_result);
        for (size_t j = 0; j < cur_result.size(); ++j) {
          word_tokens->at(token_position[j]).pause_level =
              (cur_result[j] != 0) ? kPauseLevelSP : kPauseLevelWord;
        }
        token.clear();
        token_position.clear();
      }
    }
  }
  for (auto& word_token : *word_tokens) {
    if (word_token.word == kSepMarkWord) {
      word_token.pause_level = kPauseLevelWord;
    } else if (word_token.word == kSepMarkPhrase) {
      word_token.pause_level = kPauseLevelPhrase;
    } else if (word_token.word == kSepMarkSP) {
      word_token.pause_level = kPauseLevelSP;
    }
  }
}

}  // namespace tts
