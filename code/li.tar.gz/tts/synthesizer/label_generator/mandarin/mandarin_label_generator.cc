// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/synthesizer/label_generator/mandarin/mandarin_label_generator.h"

#include "tts/synthesizer/label_generator/proto/frontend.pb.h"

#include "mobvoi/base/file.h"
#include "mobvoi/base/file/proto_util.h"
#include "mobvoi/base/log.h"
#include "tts/synthesizer/label_generator/label_util.h"
#include "tts/synthesizer/label_generator/mandarin/frontend_manager.h"
#include "tts/util/tts_util/util.h"

namespace tts {

MandarinLabelGenerator::MandarinLabelGenerator(const string& language,
                                               const string& resource_file)
    : language_(language) {
  FrontendResource fe_res;
  CHECK(mobvoi::ReadProtoFromTextFile(resource_file, &fe_res))
      << resource_file << " load failed!";
  string dir = mobvoi::File::FindFileDir(resource_file);
  if (!fe_res.trad_to_simp().empty())
    trad_simp_converter_.reset(
        new nlp::t2s::Trad2SimpConverter(dir + fe_res.trad_to_simp()));
  if (!fe_res.tn().empty())
    text_normalizer_.reset(
        new nlp::tn::TextNormalizer(language, dir + fe_res.tn()));
  if (!fe_res.segmenter().empty())
    segmenter_.reset(new nlp::segmenter::Segmenter(dir + fe_res.segmenter()));
  if (!fe_res.g2p().empty())
    eng_g2p_.reset(new nlp::g2p::G2p(dir + fe_res.g2p()));
  if (!fe_res.polyphone().empty()) {
#ifndef FOR_PORTABLE
    FrontendManager::Instance().DoExtractFrontendModel(dir, language,
                                                       tts::kFrontendPolyphone);
#endif
    FrontendManager::Instance().InitPolyphone(
        language, dir + fe_res.polyphone(), false /* reset flag*/);
  }
  if (!fe_res.phone_mapping().empty())
    phone_mapper_.reset(new tts::PhoneMapper(dir + fe_res.phone_mapping()));
  if (!fe_res.pause().empty()) {
    FrontendManager::Instance().InitProsody(language, dir + fe_res.pause(),
                                            false);
  }
  mobvoi::unordered_set<string> erhua_set;
  if (!fe_res.erhua().empty()) {
    LoadSetFromFile(dir + fe_res.erhua(), &erhua_set);
  }
  erhua_set_ = std::make_shared<mobvoi::unordered_set<string>>(erhua_set);
  mobvoi::unordered_set<string> soft_word;
  if (!fe_res.soft_word().empty()) {
    LoadSetFromFile(dir + fe_res.soft_word(), &soft_word);
  }
  soft_word_ = std::make_shared<mobvoi::unordered_set<string>>(soft_word);
#ifndef FOR_PORTABLE
  FrontendManager::Instance().LoadAllPolyphoneDict();
  FrontendManager::Instance().LoadModelPolyphoneDict(language);
#endif
}

MandarinLabelGenerator::~MandarinLabelGenerator() {
  FrontendManager::Instance().UnloadModel(language_);
  trad_simp_converter_.reset(nullptr);
  text_normalizer_.reset(nullptr);
  segmenter_.reset(nullptr);
  eng_g2p_.reset(nullptr);
  phone_mapper_.reset(nullptr);
}

void MandarinLabelGenerator::TradToSimp(vector<SsmlText>* output) const {
  for (auto& text : *output) {
    trad_simp_converter_->Convert(text.text, &text.text);
  }
}
// support ní hǎo -> ni2 hao3
// TODO(xiaoqin.feng) support english type
void MandarinLabelGenerator::ToneToPinyin(const string& frontend_type,
                                          vector<SsmlText>* norm_ssml) const {
  if (phone_mapper_ == nullptr) return;
  for (auto& norm : *norm_ssml) {
    if (norm.tag.name != kSsmlPhoneKey && norm.tag.name != kSsmlWordKey)
      continue;
    for (auto& attr : norm.tag.attrs) {
      if (attr.first == kSsmlWordPhone && norm.tag.name == kSsmlWordKey)
        continue;
      VLOG(2) << attr.first << " : " << attr.second;
      vector<string> phones;
      vector<string> phones_re;
      bool convert_flag = false;
      if (attr.first == kSsmlWordPhone && norm.tag.name == kSsmlPhoneKey) {
        if (tts::IsChineseWord(norm.text)) {
          SplitString(attr.second, ' ', &phones);
          convert_flag =
              phone_mapper_->ToneToPinyin(frontend_type, phones, &phones_re);
        } else {
          phones.emplace_back(attr.second);
          convert_flag =
              phone_mapper_->ToneToPinyin(kFrontendTypeEng, phones, &phones_re);
        }
      }
      if (attr.first == kSsmlAsrWordPhone && norm.tag.name == kSsmlWordKey) {
        SplitString(attr.second, ',', &phones);
        convert_flag = phone_mapper_->ToneToPinyin("asr", phones, &phones_re);
      }
      VLOG(2) << JoinVector(phones_re, ' ') << ":" << phones_re.size() << ":"
              << convert_flag;
      if (convert_flag) {
        norm.tag.attrs[attr.first] = JoinVector(phones_re, ' ');
      } else {
        norm.tag.attrs[attr.first] = "";
      }
    }
  }
}

void MandarinLabelGenerator::AddTonePronInfo(
    const string& frontend_type, vector<WordInfo>* word_infos) const {
  if (phone_mapper_ == nullptr) return;
  for (auto& word_info : *word_infos) {
    vector<string> prons;
    vector<string> eng_prons;
    for (auto& sym : word_info.syllables) {
      string pron;
      vector<string> eng_pron;
      for (auto& character : sym.prons) {
        if (IsEnglishPhone(character)) {
          eng_pron.emplace_back(character);
        }
        pron += character;
      }
      int tone = sym.tone;
      if (!eng_pron.empty()) {
        eng_pron.emplace_back(std::to_string(tone));
        eng_prons.emplace_back(JoinVector(eng_pron, ' '));
      }
      if (tone < 7) {
        tone = (tone != 6 ? tone : 2);
        pron += std::to_string(tone);
        if (!eng_prons.empty()) {
          prons.emplace_back(JoinVector(eng_prons, '_'));
          eng_prons.clear();
        }
        prons.emplace_back(pron);
      }
    }
    if (!eng_prons.empty()) {
      prons.emplace_back(JoinVector(eng_prons, '_'));
      eng_prons.clear();
    }
    vector<string> pron_of_tones;
    for (auto pron : prons) {
      string pron_of_tone;
      if (IsEnglishPhone(pron)) {
        phone_mapper_->PinyinToTone(kFrontendTypeEng, pron, &pron_of_tone);
      } else {
        phone_mapper_->PinyinToTone(frontend_type, pron, &pron_of_tone);
      }
      pron_of_tones.emplace_back(pron_of_tone);
    }
    word_info.pron_of_tones = pron_of_tones;
  }
}

void MandarinLabelGenerator::TextNormalize(const vector<SsmlText>& input,
                                           const LabelOption& label_option,
                                           vector<SsmlText>* output,
                                           TnDetail* detail) const {
  text_normalizer_->Normalize(input, label_option.domain(), output, detail);
}

void MandarinLabelGenerator::WordSegmentation(
    const vector<SsmlText>& input, const LabelOption& label_option,
    vector<WordToken>* word_token) const {
  VLOG(2) << "Start word segmentation ...";
  vector<nlp::segmenter::SegmentWord> segment_words;
  segmenter_->WordSegmentation(input, label_option.user_dict(), &segment_words);
  if (VLOG_IS_ON(1)) {
    for (const auto& segment_word : segment_words) {
      VLOG(2) << "segment words: " << segment_word.word
              << " id: " << segment_word.word_id
              << " pron: " << segment_word.pron << " pos: " << segment_word.pos;
    }
  }
  for (auto& cur_seg_word : segment_words) {
    WordToken word_token_tmp;
    word_token_tmp.word = cur_seg_word.word;
    word_token_tmp.language = WordLanguage::kMandarinWord;
    word_token_tmp.word_id = cur_seg_word.word_id;
    word_token_tmp.pos = cur_seg_word.pos;
    vector<string> prons;
    SplitString(cur_seg_word.pron, ' ', &prons);
    size_t len = util::utflen(word_token_tmp.word.c_str());
    if (prons.size() < len && !cur_seg_word.pron_fixed) {
      LOG(WARNING) << "no pron for word, fake sil0 for it : "
                   << cur_seg_word.word
                   << ", original pro : " << cur_seg_word.pron
                   << ", vec size : " << prons.size() << ", utf len : " << len;
      int miss_num = len - prons.size();
      for (int i = 0; i < miss_num; ++i) {
        prons.push_back(kPausePron);
      }
    } else if (prons.size() > len) {
      LOG(WARNING) << "over pron for word, delete pron for it : "
                   << cur_seg_word.word
                   << ", original pro : " << cur_seg_word.pron
                   << ", vec size : " << prons.size() << ", utf len : " << len;
      int over_num = prons.size() - len;
      for (int i = 0; i < over_num; ++i) {
        prons.pop_back();
      }
    }
    if (cur_seg_word.pron_fixed && tts::IsEnglishWord(cur_seg_word.word)) {
      SplitString(cur_seg_word.pron, '_', &prons);
    }
    word_token_tmp.prons = prons;
    word_token_tmp.language = WordLanguage::kMandarinWord;
    word_token_tmp.pron_fixed = cur_seg_word.pron_fixed;
    word_token_tmp.p_pron_fixeds = cur_seg_word.p_pron_fixeds;
    word_token_tmp.seted_pauses = cur_seg_word.seted_pauses;
    word_token->push_back(word_token_tmp);
  }
  VLOG(2) << "Word segmentation finished";
}

void MandarinLabelGenerator::G2PForEng(vector<WordToken>* word_tokens) const {
  vector<WordToken> eng_word_tokens;
  for (auto word_token : *word_tokens) {
    for (size_t i = 0; i < word_token.prons.size(); ++i) {
      WordToken temp_word;
      if (tts::IsEnglishWord(word_token.word)) {
        word_token.prons.clear();
        eng_word_tokens.emplace_back(word_token);
        continue;
      }
      temp_word.word_id = word_token.word_id;
      if (tts::IsChinesePron(word_token.prons[i])) {
        string eng_word =
            kPinyinTag +
            word_token.prons[i].substr(0, word_token.prons[i].size() - 1);
        temp_word.word = eng_word;
      } else {
        temp_word.word = kSepMarkWord;
      }
      if (i != word_token.prons.size() - 1)
        temp_word.pause_level = 0;
      else
        temp_word.pause_level = word_token.pause_level;
      eng_word_tokens.emplace_back(temp_word);
    }
  }
  *word_tokens = eng_word_tokens;
  for (auto& word_token : *word_tokens) {
    eng_g2p_->GetPron(word_token.word, &word_token.prons);
  }
}

void MandarinLabelGenerator::G2P(vector<WordToken>* word_tokens) const {
  for (auto& word_token : *word_tokens) {
    if (word_token.pos == kEnglishPos && !word_token.pron_fixed) {
      word_token.prons.clear();
      eng_g2p_->GetPron(word_token.word, &word_token.prons);
    }
  }
}

void MandarinLabelGenerator::PolyphoneProcess(
    const string& language, vector<WordToken>* word_tokens,
    map<int, int>* polyphone_prob) const {
  VLOG(2) << "Start process Polyphone ...";
  vector<nlp::polyphone::PolyphoneToken> polyphone_tokens;
  polyphone_tokens.reserve(word_tokens->size());

  for (const auto& word_token : *word_tokens) {
    nlp::polyphone::PolyphoneToken polyphone_token(
        word_token.word, word_token.pos, word_token.prons,
        word_token.pron_fixed);
    polyphone_token.p_pron_fixeds = word_token.p_pron_fixeds;
    polyphone_tokens.push_back(polyphone_token);
  }
  FrontendManager::Instance().PolyphoneProcess(language, &polyphone_tokens,
                                               polyphone_prob);
  for (size_t i = 0; i < polyphone_tokens.size(); ++i) {
    word_tokens->at(i).prons = polyphone_tokens[i].prons;
    word_tokens->at(i).p_pron_fixeds = polyphone_tokens[i].p_pron_fixeds;
  }
}

void MandarinLabelGenerator::MarkPauseLevel(
    const LabelOption& label_option, vector<WordToken>* word_token) const {
  VLOG(2) << "Start Pause prediction ...";
  vector<int> pause_result;
  if (!word_token->empty()) word_token->back().pause_level = kPauseLevelLP;
  RemoveWordLP(word_token);

#if not defined FOR_PORTABLE
  vector<int> token;
  for (auto cur_word : *word_token) {
    token.push_back(cur_word.word_id);
    if (cur_word.pause_level == kPauseLevelLP) {
      vector<int> cur_result;
      FrontendManager::Instance().ProsodyProcess(label_option.language(), token,
                                                 &cur_result);
      RemoveFrontEndBreak(&cur_result);
      pause_result.insert(pause_result.end(), cur_result.begin(),
                          cur_result.end());
      token.clear();
    }
  }
#else
  vector<nlp::prosody::InputToken> token;
  for (auto cur_word : *word_token) {
    nlp::prosody::InputToken token_tmp;
    token_tmp.word = cur_word.word;
    token_tmp.word_id = cur_word.word_id;
    token_tmp.pos = cur_word.pos;
    token.push_back(token_tmp);
    if (cur_word.pause_level == kPauseLevelLP) {
      vector<int> cur_result;
      FrontendManager::Instance().ProsodyProcess(label_option.language(), token,
                                                 &cur_result);
      // remove front end sp to avoid too short break
      RemoveFrontEndBreak(&cur_result);
      pause_result.insert(pause_result.end(), cur_result.begin(),
                          cur_result.end());
      token.clear();
    }
  }
#endif

  if (VLOG_IS_ON(2)) {
    for (size_t i = 0; i < pause_result.size(); ++i) {
      LOG(INFO) << word_token->at(i).word_id << " " << pause_result[i];
    }
  }
  for (size_t i = 0; i < pause_result.size(); ++i) {
    if (word_token->at(i).word == kSpecTimeWord) {
      word_token->at(i).pause_level = kPauseLevelSP;
    }
    if (!word_token->at(i).pause_level) {
      if (label_option.domain() == kDomainNavigation &&
          (pause_result[i] >= kPauseLevelSP)) {
        word_token->at(i).pause_level = kPauseLevelSilence;
      } else {
        word_token->at(i).pause_level = pause_result[i];
      }
    }
  }
  if (!word_token->empty()) word_token->back().pause_level = kPauseLevelSilence;
  VLOG(2) << "Pause prediction finished";
}

bool GenPron(const vector<string>& prons, vector<WordToken>* word_token) {
  size_t pron_off = 0;
  for (WordToken& word_token_tmp : *word_token) {
    for (string& c_pron : word_token_tmp.prons) {
      if (c_pron != kPausePron && pron_off < prons.size()) {
        c_pron = prons[pron_off];
        pron_off += 1;
      }
    }
  }
  if (pron_off != prons.size()) return false;
  return true;
}

int MandarinLabelGenerator::GetEnglishWordPron(const string pron_str,
                                               vector<string>* prons) const {
  vector<string> syllables;
  SplitString(pron_str, '+', &syllables);
  for (auto syl : syllables) {
    mobvoi::ReplaceAllAfterOffset(&syl, 0, "_", " ");
    prons->push_back(syl);
  }
  return 0;
}

bool MandarinLabelGenerator::GetEnglishWordToken(
    const string word, const string pron, vector<WordToken>* w_token) const {
  vector<string> prons;
  SplitString(pron, ' ', &prons);
  string english_word = "";
  int word_count = 0;
  for (char ch : word) {
    string word_str = string(1, ch);
    if (IsSeperator(word_str)) {
      // generate a wordtoken for english word
      if (english_word != "") {
        WordToken wt_eng;
        wt_eng.language = WordLanguage::kEnglishWord;
        wt_eng.word = english_word;
        string word_pron = prons[word_count];
        GetEnglishWordPron(word_pron, &wt_eng.prons);
        w_token->push_back(wt_eng);
        english_word = "";
        word_count++;
      }

      // generate a wordtoken for separator
      WordToken wt_sep;
      wt_sep.word = word_str;
      wt_sep.pos = "";
      vector<string> pron;
      pron.push_back(kPausePron);
      wt_sep.prons = pron;
      w_token->push_back(wt_sep);
    } else {
      english_word += word_str;
    }
  }
  if ((size_t)word_count != prons.size()) return false;
  return true;
}

bool MandarinLabelGenerator::GetWordTokens(const LabelOption& label_option,
                                           const vector<string>& word_segs,
                                           const vector<string>& pron_segs,
                                           vector<WordToken>* w_token) const {
  size_t seg_size = word_segs.size();
  for (size_t i = 0; i < seg_size; i++) {
    string word = word_segs[i];
    string pron = pron_segs[i];
    vector<WordToken> tmp_word_token;
    char first_char = word[0];
    if ((first_char >= 'A' && first_char <= 'Z') ||
        (first_char >= 'a' && first_char <= 'z')) {  // English
      if (!GetEnglishWordToken(word, pron, &tmp_word_token)) return false;
    } else {  // Chinese
      vector<SsmlText> ssml_word;
      SsmlParser::Instance().ParseText(word, &ssml_word);
      WordSegmentation(ssml_word, label_option, &tmp_word_token);
      vector<string> prons;
      SplitString(pron, ' ', &prons);
      if (!GenPron(prons, &tmp_word_token)) return false;
    }
    w_token->insert(w_token->end(), tmp_word_token.begin(),
                    tmp_word_token.end());
  }
  return true;
}

bool MandarinLabelGenerator::OfflineTextAnalysis(
    const string& input, const LabelOption& label_option,
    vector<WordInfo>* word_infos) const {
  vector<WordToken> word_token;
  vector<string> segs;
  SplitString(input, '\t', &segs);
  // cout << "offline analysis..." << endl;
  if (segs.size() != 2) {
    LOG(ERROR) << "wrong format:" << input;
    return false;
  }
  vector<string> word_segs, pron_segs;
  SplitString(segs[0], '~', &word_segs);
  SplitString(segs[1], '~', &pron_segs);
  if (GetWordTokens(label_option, word_segs, pron_segs, &word_token)) {
    map<int, int> polyphone_prob;
    return GenWordInfos(word_token, polyphone_prob, *soft_word_, label_option,
                        false, word_infos);
  }
  return false;
}

bool MandarinLabelGenerator::OnlineTextAnalysis(const vector<SsmlText>& input,
                                                const LabelOption& label_option,
                                                vector<WordInfo>* word_infos,
                                                TnDetail* detail) const {
  vector<WordToken> word_token;
  vector<SsmlText> simp(input);
  TradToSimp(&simp);
  vector<SsmlText> norm;
  TextNormalize(simp, label_option, &norm, detail);
  ToneToPinyin(label_option.frontend_type(), &norm);
  WordSegmentation(norm, label_option, &word_token);
  G2P(&word_token);
  map<int, int> polyphone_prob;
  PolyphoneProcess(label_option.language(), &word_token, &polyphone_prob);
  // rules for robot tts
  if (label_option.use_robot())
    for (WordToken& cur_word : word_token)
      for (string& pron : cur_word.prons) pron.back() = '1';
  // pause level prediction
  MarkPauseLevel(label_option, &word_token);
  RestrictLevel(&word_token);
  ProcessSsmlLevel(&word_token);
  MergeWord(&word_token);
  if (label_option.speaker() == kSpeakerAngelaMix ||
      label_option.speaker() == kSpeakerAngelaLpcnetMix) {
    G2PForEng(&word_token);
  }
  if (label_option.use_erhua()) {
    ErhuayinProcess(*erhua_set_, &word_token);
  }
  if (!GenWordInfos(word_token, polyphone_prob, *soft_word_, label_option, true,
                    word_infos)) {
    return false;
  }
  if (label_option.only_frontend()) {
    AddTonePronInfo(label_option.frontend_type(), word_infos);
  }
  return true;
}

}  // namespace tts
