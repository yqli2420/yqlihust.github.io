// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_SYNTHESIZER_LABEL_GENERATOR_MANDARIN_MANDARIN_LABEL_GENERATOR_H_
#define TTS_SYNTHESIZER_LABEL_GENERATOR_MANDARIN_MANDARIN_LABEL_GENERATOR_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "tts/nlp/g2p/g2p.h"
#include "tts/synthesizer/label_generator/phone_mapper.h"

#include "tts/nlp/segmenter/segmenter.h"
#include "tts/nlp/t2s/trad_simp_converter.h"
#include "tts/nlp/tn/text_normalizer.h"
#include "tts/synthesizer/label_generator/label_generator.h"

namespace tts {

class MandarinLabelGenerator : public LabelGenerator {
 public:
  MandarinLabelGenerator(const string& language, const string& resource_file);
  ~MandarinLabelGenerator();

 private:
  bool OnlineTextAnalysis(const vector<SsmlText>& input,
                          const LabelOption& label_option,
                          vector<WordInfo>* word_infos,
                          TnDetail* detail) const override;
  bool OfflineTextAnalysis(const string& input, const LabelOption& label_option,
                           vector<WordInfo>* word_infos) const override;

  int GetEnglishWordPron(const string pron_str, vector<string>* prons) const;
  bool GetEnglishWordToken(const string word, const string pron,
                           vector<WordToken>* w_token) const;
  void TradToSimp(vector<SsmlText>* output) const;
  void ToneToPinyin(const string& frontend_type,
                    vector<SsmlText>* norm_ssml) const;
  void AddTonePronInfo(const string& frontend_type,
                       vector<WordInfo>* word_infos) const;
  void TextNormalize(const vector<SsmlText>& input,
                     const LabelOption& label_option, vector<SsmlText>* output,
                     TnDetail* detail) const;
  void WordSegmentation(const vector<tts::SsmlText>& input,
                        const LabelOption& label_option,
                        vector<WordToken>* word_token) const;
  // g2p for english words
  void G2P(vector<WordToken>* word_tokens) const;
  // g2p for mix mandarin/english words to english pron
  void G2PForEng(vector<WordToken>* word_tokens) const;
  void PolyphoneProcess(const string& language,
                        vector<WordToken>* word_tokens) const;
  void PolyphoneProcess(const string& language, vector<WordToken>* word_tokens,
                        map<int, int>* polyphone_prob) const;

  void MarkPauseLevel(const LabelOption& label_option,
                      vector<WordToken>* word_token) const;
  bool GetWordTokens(const LabelOption& label_option,
                     const vector<string>& word_segs,
                     const vector<string>& pron_segs,
                     vector<WordToken>* w_token) const;

  std::unique_ptr<nlp::t2s::Trad2SimpConverter> trad_simp_converter_;
  std::unique_ptr<nlp::tn::TextNormalizer> text_normalizer_;
  std::unique_ptr<nlp::segmenter::Segmenter> segmenter_;
  std::unique_ptr<nlp::g2p::G2p> eng_g2p_;
  std::unique_ptr<tts::PhoneMapper> phone_mapper_;
  string language_;

  std::shared_ptr<mobvoi::unordered_set<string>> soft_word_;
  std::shared_ptr<mobvoi::unordered_set<string>> erhua_set_;

  DISALLOW_COPY_AND_ASSIGN(MandarinLabelGenerator);
};

}  // namespace tts

#endif  // TTS_SYNTHESIZER_LABEL_GENERATOR_MANDARIN_MANDARIN_LABEL_GENERATOR_H_
