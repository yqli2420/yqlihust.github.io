// Copyright 2019 Mobvoi Inc.All Rights Reserved.
// Author : yongqiangli @mobvoi.com yongqiangli

#include "mobvoi/base/compat.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/file/proto_util.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "tts/synthesizer/label_generator/label_generator_manager.h"

DEFINE_string(input_file, "", "test file");
DEFINE_string(output_file, "out.txt", "");
DEFINE_string(error_word_file, "error.txt", "");
DEFINE_string(label_option_conf, "external/config/front_end/label_option.conf",
              "label option config");
DEFINE_string(resource_file, "external/config/front_end/man_frontend.conf",
              "tts param config");
static const char kSegSepMark = '\t';

// record the frequency & accuracy of error pron
void WriteErrorWordToFile(map<string, int>* error_word,
                          map<string, int>* all_word) {
  vector<pair<string, int>> word_v(all_word->begin(), all_word->end());
  std::sort(word_v.begin(), word_v.end(),
            [](const pair<string, int>& left, const pair<string, int>& right)
                -> bool { return left.second > right.second; });
  vector<string> result;
  string header = "word,all_count,err_size,acc";
  result.emplace_back(header);
  for (auto it : word_v) {
    auto err = error_word->find(it.first);
    if (err != error_word->end()) {
      result.emplace_back(
          it.first + "," + std::to_string(it.second) + "," +
          std::to_string((*err).second) + "," +
          std::to_string(static_cast<double>(it.second - (*err).second) /
                         static_cast<double>(it.second)));
    } else {
      result.emplace_back(it.first + "," + std::to_string(it.second) + ",0,1");
    }
  }
  mobvoi::File::WriteStringToFile(JoinVector(result, '\n'),
                                  FLAGS_error_word_file);
}

void WriteAccuracyInfoToFile(const vector<string>& info, int sum, int acy) {
  LOG(INFO) << "sum: " << sum << " acy: " << acy << " accuracy: "
            << static_cast<double>(acy) / static_cast<double>(sum);
  string accuracy_info =
      "sum: " + std::to_string(sum) + " true: " + std::to_string(acy) +
      " accuracy: " +
      std::to_string(static_cast<double>(acy) / static_cast<double>(sum)) +
      "\n";
  accuracy_info += "sentence  word  true  error\n";
  accuracy_info += JoinVector(info, '\n');
  mobvoi::File::WriteStringToFile(accuracy_info, FLAGS_output_file);
}

void GetPron(std::shared_ptr<tts::LabelGenerator> generator,
             const tts::LabelOption& label_option, string* text,
             string* phone) {
  vector<string> labels;

  vector<tts::SsmlText> ssml_texts;
  tts::SsmlParser::Instance().ParseText(*text, &ssml_texts);

  tts::TnDetail detail;
  Json::Value debug_infos;
  generator->GenLabels(ssml_texts, label_option, true, &labels, &debug_infos,
                       &detail);

  vector<string> g2p_info;
  for (auto g2p : debug_infos["g2pTnJson"]) {
    g2p_info.emplace_back(g2p["pron_of_alpha"].asString());
  }
  *phone = JoinVector(g2p_info, ' ');
  *text = debug_infos["tnText"].asString();
}

bool JudgeAlignment(vector<string>* utf_8, vector<string>* result_pron,
                    vector<string>* expect_pron) {
  vector<string> temp_utf_8_result;
  vector<string> temp_result_pron_result;
  vector<string> temp_expect_pron_result;
  for (size_t i = 0; i < utf_8->size(); ++i) {
    if (tts::IsChineseWord((*utf_8)[i]))
      temp_utf_8_result.emplace_back(utf_8->at(i));
  }
  for (size_t i = 0; i < result_pron->size(); ++i) {
    if (tts::IsChinesePron((*result_pron)[i]))
      temp_result_pron_result.emplace_back(result_pron->at(i));
  }
  for (size_t i = 0; i < expect_pron->size(); ++i) {
    if (tts::IsChinesePron((*expect_pron)[i]))
      temp_expect_pron_result.emplace_back(expect_pron->at(i));
  }
  if (temp_utf_8_result.size() == temp_result_pron_result.size() &&
      temp_result_pron_result.size() == temp_expect_pron_result.size()) {
    *utf_8 = temp_utf_8_result;
    *result_pron = temp_result_pron_result;
    *expect_pron = temp_expect_pron_result;
    return true;
  }
  return false;
}

void StatisticsAccuracyInfo(const string& text, const string& gen_phone,
                            const string& src_phone, int* sum, int* acy,
                            vector<string>* error_info,
                            map<string, int>* all_word,
                            map<string, int>* error_word) {
  vector<string> dst_segs;
  vector<string> src_segs;
  SplitString(gen_phone, ' ', &dst_segs);
  SplitString(src_phone, ' ', &src_segs);
  vector<string> norm_unicode;
  util::SplitUtf8String(text, &norm_unicode);
  if (!JudgeAlignment(&norm_unicode, &dst_segs, &src_segs)) return;
  map<string, int>::iterator iter;
  for (size_t i = 0; i < src_segs.size(); ++i) {
    (*sum)++;
    string utf8 = norm_unicode[i];
    iter = all_word->find(utf8);
    if (iter != all_word->end()) {
      iter->second++;
    } else {
      all_word->insert(pair<string, int>(utf8, 1));
    }
    if (dst_segs[i] == src_segs[i]) {
      (*acy)++;
      continue;
    }
    iter = error_word->find(utf8);
    if (iter != error_word->end()) {
      iter->second++;
    } else {
      error_word->insert(pair<string, int>(utf8, 1));
    }
    VLOG(2) << "word: " << utf8 << " error phone, error: " << dst_segs[i]
            << " true: " << src_segs[i];
    string err = text + "," + std::to_string(i) + "," + utf8 + "," +
                 src_segs[i] + "," + dst_segs[i];
    error_info->emplace_back(err);
  }
}

void CaculateAccuracy(std::shared_ptr<tts::LabelGenerator> generator,
                      const tts::LabelOption& label_option) {
  vector<string> lines;
  file::SimpleLineReader reader(FLAGS_input_file, true, "#");
  reader.ReadLines(&lines);

  vector<string> error_info;
  map<string, int> error_word;
  map<string, int> all_word;

  int sum = 0, acy = 0;
  for (size_t i = 0; i < lines.size(); i += 1) {
    vector<string> segs;
    SplitString(lines[i], kSegSepMark, &segs);
    string text = segs[0];
    string src_phone = segs[1];
    string gen_phone;
    GetPron(generator, label_option, &text, &gen_phone);
    StatisticsAccuracyInfo(text, gen_phone, src_phone, &sum, &acy, &error_info,
                           &all_word, &error_word);
  }

  WriteErrorWordToFile(&error_word, &all_word);
  WriteAccuracyInfoToFile(error_info, sum, acy);
}

int main(int argc, char** argv) {
  google::ParseCommandLineFlags(&argc, &argv, false);
  tts::LabelGeneratorManager manager;
  std::shared_ptr<tts::LabelGenerator> label_generator;
  label_generator = manager.CreateLabelGenerator(tts::kMandarinTypeString,
                                                 FLAGS_resource_file);
  tts::LabelOption label_option;
  CHECK(mobvoi::ReadProtoFromTextFile(FLAGS_label_option_conf, &label_option))
      << "failed to load label_option.config";
  label_option.set_only_frontend(true);
  CaculateAccuracy(label_generator, label_option);
  return 0;
}
