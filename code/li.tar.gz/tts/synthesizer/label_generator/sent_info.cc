// Copyright 2016 Mobvoi Inc. All Rights Reserved.
// Author: ranzhang@mobvoi.com (Dylan)

#include "tts/synthesizer/label_generator/sent_info.h"

#include <math.h>
#include "mobvoi/base/log.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/util/utf8/utf8_util.h"
#include "tts/nlp/tn/common_pattern_handler.h"
#include "tts/synthesizer/label_generator/label_util.h"
#include "tts/synthesizer/label_generator/mandarin/frontend_manager.h"

DEFINE_bool(use_break_subsen, false, "if true, use break as subsen");

static const re2::RE2 blank_obj("\\s+");
static const re2::RE2 merge_symbol_obj("[`]+");
static re2::RE2 tn_symbol_pattern_obj("[\\.|\\:|\\-|\\~|\\/]");
static re2::RE2 eng_number_pattern_obj1("([a-zA-Z]+)([0-9]+)");
static re2::RE2 eng_number_pattern_obj2("([0-9]+)([a-zA-Z]+)");

namespace tts {

void GenBreakInfo(const vector<PhraseInfo>& phrase_info,
                  vector<BreakInfo>* break_info) {
  BreakInfo tmp_break;
  for (size_t i = 0; i < phrase_info.size(); ++i) {
    tmp_break.phrases.push_back(phrase_info[i]);
    tmp_break.phone_num += phrase_info[i].phone_num;
    tmp_break.syl_num += phrase_info[i].syl_num;
    tmp_break.word_num += phrase_info[i].words.size();
    // Todo::add pause_level to each struct
    if (phrase_info[i].pause_level >= kPauseLevelSP ||
        i == phrase_info.size() - 1) {
      if (phrase_info[i].words.back().punc) {
        tmp_break.break_type = kBreakTypePunc;
      } else {
        tmp_break.break_type = kBreakTypePredict;
      }
      tmp_break.pause_level = phrase_info[i].pause_level;
      break_info->push_back(tmp_break);
      // TODO(zhengzhang): change following into inner function
      tmp_break.phone_num = 0;
      tmp_break.syl_num = 0;
      tmp_break.word_num = 0;
      tmp_break.phrases.clear();
    }
  }
}

void JudgeStrType(const string last_str, bool is_tn, string* last_symbol_flag) {
  if (last_str.empty()) {
    if (is_tn)
      *last_symbol_flag = "symbol";
    else
      *last_symbol_flag = "last";
  } else if (tts::IsEnglishWord(last_str)) {
    *last_symbol_flag = "english";
  } else {
    *last_symbol_flag = "none";
  }
}

void ExtractPronAndPause(const WordInfo& word_info, vector<string> prons,
                         vector<WordDetailInfo>* word_detail_infos) {
  string pause_level = GetDebugPauseFromPauseLevel(word_info.pause_level);
  if (pause_level.empty()) pause_level = kSepMarkNonePauseLevel;
  if (tts::IsEnglishWord(word_info.word) &&
      word_info.pron_of_tones.size() == 1) {
    word_detail_infos->emplace_back(
        WordDetailInfo("", word_info.pron_of_tones[0], JoinVector(prons, ' '),
                       kSepMarkNonePauseLevel, 100));
  } else {
    vector<string> re_prons;
    vector<string> temp;
    if (word_info.pron_of_tones.size() != prons.size()) {
      for (size_t i = 0; i < prons.size(); i++) {
        if (tts::IsChinesePron(prons[i])) {
          if (!temp.empty()) {
            re_prons.emplace_back(JoinVector(temp, ' '));
            temp.clear();
          }
          re_prons.emplace_back(prons[i]);
        } else {
          temp.emplace_back(prons[i]);
          if (i == prons.size() - 1) {
            re_prons.emplace_back(JoinVector(temp, ' '));
          }
        }
      }
    }
    if (re_prons.size() != word_info.pron_of_tones.size()) {
      re_prons = prons;
    }
    for (size_t i = 0; i < word_info.pron_of_tones.size(); ++i) {
      if (tts::IsChinesePron(prons[i])) {
        word_detail_infos->emplace_back(WordDetailInfo(
            "", word_info.pron_of_tones[i], re_prons[i], kSepMarkNonePauseLevel,
            word_info.syllables[i].pron_prob));
      } else {
        word_detail_infos->emplace_back(
            WordDetailInfo("", word_info.pron_of_tones[i], re_prons[i],
                           kSepMarkNonePauseLevel, 100));
      }
    }
  }
  if (!word_detail_infos->empty())
    word_detail_infos->back().pause_level = pause_level;
}

void DoSplitNumSlice(const string& input, const string& split_word,
                     vector<string>* split_slices) {
  vector<string> characters;
  util::SplitUtf8String(input, &characters);
  string tar_slice = string();
  string oth_slice = string();
  for (const auto& character : characters) {
    if (split_word.find(character) != string::npos) {
      if (!oth_slice.empty()) {
        split_slices->emplace_back(oth_slice);
        oth_slice.clear();
      }
      tar_slice += character;
    } else {
      if (!tar_slice.empty()) {
        split_slices->emplace_back(tar_slice);
        tar_slice.clear();
      }
      oth_slice += character;
    }
  }
  if (!oth_slice.empty()) split_slices->emplace_back(oth_slice);
  if (!tar_slice.empty()) split_slices->emplace_back(tar_slice);
}

void DoSplitSlice(const vector<string>& characters, size_t offset,
                  vector<string>* split_slices) {
  size_t char_index = 0;
  string temp_string = string();
  while (char_index < offset) {
    string character = characters[char_index];
    if (tts::IsChineseWord(character)) {
      if (!temp_string.empty()) {
        split_slices->emplace_back(temp_string);
        temp_string.clear();
      }
      split_slices->emplace_back(character);
    } else if (IsEnglishWord(character)) {
      if (!temp_string.empty() && !tts::IsEnglishWord(temp_string)) {
        split_slices->emplace_back(temp_string);
        temp_string.clear();
      }
      temp_string += character;
    } else {
      if (!temp_string.empty()) {
        split_slices->emplace_back(temp_string);
        temp_string.clear();
      }
      split_slices->emplace_back(character);
    }
    ++char_index;
  }
  if (!temp_string.empty()) {
    split_slices->emplace_back(temp_string);
  }
}

bool DoAlignment(size_t offset, string last_symbol_flag,
                 vector<string>* characters,
                 vector<WordDetailInfo>* word_detail_infos,
                 vector<PlatformInfo>* out,
                 vector<WordDetailInfo>* tn_g2p_infos) {
  string temp_string = string();
  vector<string> temp_pron_info;
  size_t man_index = 0;
  DoSplitSlice(*characters, offset, &temp_pron_info);
  string pron_info_slice;
  for (size_t i = 0; i < temp_pron_info.size(); ++i) {
    pron_info_slice = temp_pron_info[i];
    if (tts::IsEnglishWord(pron_info_slice)) {
      if (last_symbol_flag != "none" && i == 0 && !tn_g2p_infos->empty() &&
          !out->empty()) {
        tn_g2p_infos->back().word += pron_info_slice;
        out->back().word += pron_info_slice;
        out->back().tn_candidates.clear();
        if (out->back().pron_of_alpha.empty() &&
            man_index < word_detail_infos->size()) {
          WordDetailInfo tmp =
              WordDetailInfo(tn_g2p_infos->back().word + pron_info_slice,
                             word_detail_infos->at(man_index).pron_of_tone,
                             word_detail_infos->at(man_index).pron_of_alpha,
                             word_detail_infos->at(man_index).pause_level,
                             word_detail_infos->at(man_index).pron_prob);
          tn_g2p_infos->back() = tmp;
          out->back().pron_of_tone = tmp.pron_of_tone;
          out->back().pron_of_alpha = tmp.pron_of_alpha;
          out->back().pause_level = tmp.pause_level;
          man_index += 1;
        }
      } else {
        if (man_index < word_detail_infos->size()) {
          tn_g2p_infos->emplace_back(WordDetailInfo(
              pron_info_slice, word_detail_infos->at(man_index).pron_of_tone,
              word_detail_infos->at(man_index).pron_of_alpha,
              word_detail_infos->at(man_index).pause_level,
              word_detail_infos->at(man_index).pron_prob));
          out->emplace_back(PlatformInfo(
              pron_info_slice, word_detail_infos->at(man_index).pron_of_tone,
              word_detail_infos->at(man_index).pron_of_alpha, "",
              word_detail_infos->at(man_index).pause_level,
              word_detail_infos->at(man_index).pron_prob));
          man_index++;
        } else {
          return false;
        }
      }
    } else if (tts::IsChineseWord(pron_info_slice)) {
      if (man_index < word_detail_infos->size()) {
        string pron_alpha_slice =
            word_detail_infos->at(man_index).pron_of_alpha;
        string pron_alpha_tmp =
            pron_alpha_slice.substr(0, pron_alpha_slice.size() - 1);
        string tone_tmp = pron_alpha_slice.substr(pron_alpha_slice.size() - 1,
                                                  pron_alpha_slice.size());
        string tone_tmp_recover = (tone_tmp != "6" ? tone_tmp : "2");
        tn_g2p_infos->emplace_back(WordDetailInfo(
            pron_info_slice, word_detail_infos->at(man_index).pron_of_tone,
            pron_alpha_tmp + tone_tmp,
            word_detail_infos->at(man_index).pause_level,
            word_detail_infos->at(man_index).pron_prob));
        out->emplace_back(PlatformInfo(
            pron_info_slice, word_detail_infos->at(man_index).pron_of_tone,
            pron_alpha_tmp, tone_tmp_recover,
            word_detail_infos->at(man_index).pause_level,
            word_detail_infos->at(man_index).pron_prob));
        man_index++;
      } else {
        return false;
      }
    } else {
      string tmp_pau = kSepMarkNonePauseLevel;
      if (!out->empty()) {
        tmp_pau = out->back().pause_level;
      }
      tn_g2p_infos->emplace_back(
          WordDetailInfo(pron_info_slice, "", "", tmp_pau, 100));
      out->emplace_back(
          PlatformInfo(pron_info_slice, "", "", "", tmp_pau, 100));
    }
  }
  if (man_index > word_detail_infos->size()) {
    return false;
  }
  characters->erase(characters->begin(), characters->begin() + offset);
  word_detail_infos->erase(word_detail_infos->begin(),
                           word_detail_infos->begin() + man_index);
  return true;
}

// Generate decare set for TN candidates.
void GenTnDecare(const vector<vector<string>>& split_tn_candidates,
                 vector<string>* tn_result) {
  vector<vector<string>> tmp_result;
  int tn_size = split_tn_candidates.size();
  vector<string> tmp;
  for (int i = 0; i < tn_size; ++i) {
    tmp.push_back(split_tn_candidates[i][0]);
  }
  tmp_result.push_back(tmp);
  for (int i = tn_size - 1; i >= 0; --i) {
    int nRsSize = tmp_result.size();
    for (int k = 1; k < split_tn_candidates[i].size(); ++k) {
      for (int j = 0; j < nRsSize; ++j) {
        tmp = tmp_result[j];
        tmp[i] = split_tn_candidates[i][k];
        tmp_result.push_back(tmp);
      }
    }
  }
  for (const auto& res : tmp_result) {
    string tmp = string();
    for (const auto& r : res) tmp += r;
    tn_result->emplace_back(tmp);
  }
}

// 123 -> 一二三 幺二三 一百二十三
void GenerateNumberTn(const string& number,
                      vector<TnCandidate>* tn_candidates) {
  tn_candidates->emplace_back(tts::kSsmlTnAsValueEr,
                              nlp::tn::mandarin::ReadAsDecimalValueEr(number),
                              false);
  tn_candidates->emplace_back(
      tts::kSsmlTnAsValueLiang,
      nlp::tn::mandarin::ReadAsDecimalValueLiang(number), false);
  tn_candidates->emplace_back(tts::kSsmlTnAsDigitYao,
                              nlp::tn::mandarin::ReadAsDigitYao(number), false);
  tn_candidates->emplace_back(tts::kSsmlTnAsDigitYi,
                              nlp::tn::mandarin::ReadAsDigitYi(number), false);
  if (number.length() >= 7) {
    tn_candidates->emplace_back(tts::kSsmlTnAsTelephone,
                                nlp::tn::mandarin::ReadAsTelephone(number),
                                false);
  }
}
// hello -> `hello` `H`E`L`L`O`
void GenerateEnglishTn(const string& english,
                       vector<TnCandidate>* tn_candidates) {
  // n -> `N`
  if (english.length() > 1) {
    tn_candidates->emplace_back(tts::kSsmlTnAsWord,
                                nlp::tn::mandarin::ReadAsWord(english), false);
  }
  tn_candidates->emplace_back(tts::kSsmlTnAsAlphabet,
                              nlp::tn::mandarin::ReadAsAlphabet(english),
                              false);
}

void GenerateEnglishNumberTn(const string& input,
                             vector<TnCandidate>* tn_candidates) {
  if (AllDigit(input)) GenerateNumberTn(input, tn_candidates);
  if (AllLetter(input)) GenerateEnglishTn(input, tn_candidates);
  vector<vector<TnCandidate>> tmp_candidates;
  tmp_candidates.resize(2);
  vector<vector<string>> candidate_slices;
  string slice1, slice2, slice3, slice4;
  if (RE2::FullMatch(input, eng_number_pattern_obj1, &slice1, &slice2) ||
      RE2::FullMatch(input, eng_number_pattern_obj2, &slice1, &slice2)) {
    if (AllDigit(slice1)) {
      GenerateNumberTn(slice1, &tmp_candidates[0]);
      GenerateEnglishTn(slice2, &tmp_candidates[1]);
    } else {
      GenerateEnglishTn(slice1, &tmp_candidates[0]);
      GenerateNumberTn(slice2, &tmp_candidates[1]);
    }
    vector<string> tmp;
    for (const auto& tmp_candidate : tmp_candidates) {
      for (const auto& candidate : tmp_candidate)
        tmp.emplace_back(candidate.value);
      if (!tmp.empty()) {
        candidate_slices.emplace_back(tmp);
        tmp.clear();
      }
    }
    vector<string> tn_result;
    GenTnDecare(candidate_slices, &tn_result);
    string name = string();
    for (size_t i = 0; i < tn_result.size(); ++i) {
      name = "now_" + IntToString(i);
      tn_candidates->emplace_back(name, tn_result[i], false);
    }
  }
}

// / -> 每 分之 除 比 
// : -> 比
// - -> 减/到/比
// ~ -> 到/比
// . -> 点
void GenerateSymbolTn(const string& symbol,
                      vector<TnCandidate>* tn_candidates) {
  if (symbol == "/") {
    tn_candidates->emplace_back(kSsmlTnAsFraction, "分之", false);
    tn_candidates->emplace_back(kSsmlTnAsMath, "除", false);
    tn_candidates->emplace_back(kSsmlTnAsRatio, "比", false);
    tn_candidates->emplace_back(kSsmlTnAsFraction, "每", false);
  }
  if (symbol == ":") {
    tn_candidates->emplace_back(kSsmlTnAsRatio, "比", false);
  }
  if (symbol == "-" || symbol == "~") {
    tn_candidates->emplace_back(kSsmlTnAsRatio, "比", false);
    tn_candidates->emplace_back(kSsmlTnAsScale, "到", false);
    if (symbol == "-") {
      tn_candidates->emplace_back(kSsmlTnAsBuilding, "杠", false);
      tn_candidates->emplace_back(kSsmlTnAsMath, "减", false);
    }
  }
  if (symbol == ".") {
    tn_candidates->emplace_back(kSsmlTnAsMath, "点", false);
  }
}

// hello -> `hello` HELLO -> `H`E`L`L`O` Hello -> `hello`
void DoTnoutputProcess(string* tn_output) {
  re2::RE2::GlobalReplace(tn_output, "\\^", kSepMarkNone);
  vector<string> tn_character;
  util::SplitUtf8String(*tn_output, &tn_character);
  vector<string> temp_pron_info;
  DoSplitSlice(tn_character, tn_character.size(), &temp_pron_info);
  string temp_result = string();
  for (const auto& tmp_tn_ouput : temp_pron_info) {
    if (tts::AllLetter(tmp_tn_ouput)) {
      if (tts::AllUpper(tmp_tn_ouput)) {
        vector<string> tn_character_slices;
        util::SplitUtf8String(tmp_tn_ouput, &tn_character_slices);
        tn_output->clear();
        for (size_t i = 0; i < tn_character_slices.size(); ++i) {
          temp_result += kSepMarkWord + tn_character_slices[i];
        }
        temp_result += kSepMarkWord;
      } else {
        temp_result += kSepMarkWord + tts::ToLower(tmp_tn_ouput) + kSepMarkWord;
      }
    } else {
      temp_result += tmp_tn_ouput;
    }
  }
  re2::RE2::GlobalReplace(&temp_result, blank_obj, kSepMarkWord);
  re2::RE2::GlobalReplace(&temp_result, merge_symbol_obj, kSepMarkWord);
  *tn_output = temp_result;
}

// TODO(xiaoqin.feng) refactor after
bool DoTnmappingAligment(const TnMapping tn_map, string last_symbol_flag,
                         vector<string>* characters,
                         vector<WordDetailInfo>* word_detail_infos,
                         vector<PlatformInfo>* out,
                         vector<WordDetailInfo>* tn_g2p_infos) {
  vector<string> tn_character;
  util::SplitUtf8String(tn_map.output, &tn_character);
  size_t man_index = 0;
  if (last_symbol_flag != "none" && tts::IsEnglishWord(tn_map.output) &&
      out->size() > 1 && !tts::IsChineseWord(out->back().word)) {
    tn_g2p_infos->back().word += tn_map.input;
    out->back().word += tn_map.input;
    out->back().tn_candidates.clear();
    if (out->back().pron_of_alpha.empty() &&
        man_index < word_detail_infos->size()) {
      WordDetailInfo tmp =
          WordDetailInfo(tn_g2p_infos->back().word + tn_map.input,
                         word_detail_infos->at(man_index).pron_of_tone,
                         word_detail_infos->at(man_index).pron_of_alpha,
                         word_detail_infos->at(man_index).pause_level,
                         word_detail_infos->at(man_index).pron_prob);
      tn_g2p_infos->back() = tmp;
      out->back().pron_of_tone = tmp.pron_of_tone;
      out->back().pron_of_alpha = tmp.pron_of_alpha;
      out->back().pause_level = tmp.pause_level;
      man_index += 1;
    }
  } else {
    string temp_string = string();
    vector<string> tn_pron_tone, tn_pron_alpha;
    if (tn_map.output == kSepMarkNone || tn_map.output == kSepMarkLP ||
        tn_map.output == kSepMarkSilence || tn_map.output == kSepMarkPhrase ||
        tn_map.output == kSepMarkSP || tn_map.output == kSepMarkWord) {
      if (tn_map.output == kSepMarkNone && !tn_g2p_infos->empty() &&
          tts::IsEnglishWord(tn_g2p_infos->back().word)) {
        tn_g2p_infos->back().word += tn_map.input;
      } else {
        string tmp_pau = kSepMarkNonePauseLevel;
        if (!tn_g2p_infos->empty()) tmp_pau = tn_g2p_infos->back().pause_level;
        if (re2::RE2::FullMatch(tn_map.input, blank_obj)) {
          tn_g2p_infos->emplace_back(
              WordDetailInfo(tn_map.output, "", "", tmp_pau, 100));
        } else {
          tn_g2p_infos->emplace_back(
              WordDetailInfo(tn_map.input, "", "", tmp_pau, 100));
        }
      }
    } else {
      vector<string> temp_pron_info;
      DoSplitSlice(tn_character, tn_character.size(), &temp_pron_info);
      string pron_info_slice;
      for (size_t i = 0; i < temp_pron_info.size(); ++i) {
        pron_info_slice = temp_pron_info[i];
        if (tts::IsEnglishWord(pron_info_slice) ||
            tts::IsChineseWord(pron_info_slice)) {
          if (man_index < word_detail_infos->size()) {
            tn_pron_alpha.emplace_back(
                word_detail_infos->at(man_index).pron_of_alpha);
            tn_pron_tone.emplace_back(
                word_detail_infos->at(man_index).pron_of_tone);
            tn_g2p_infos->emplace_back(WordDetailInfo(
                pron_info_slice, word_detail_infos->at(man_index).pron_of_tone,
                word_detail_infos->at(man_index).pron_of_alpha,
                word_detail_infos->at(man_index).pause_level,
                word_detail_infos->at(man_index).pron_prob));
            man_index++;
          } else {
            return false;
          }
        } else {
          string tmp_pau = kSepMarkNonePauseLevel;
          if (!tn_g2p_infos->empty())
            tmp_pau = tn_g2p_infos->back().pause_level;
          tn_g2p_infos->emplace_back(
              WordDetailInfo(pron_info_slice, "", "", tmp_pau, 100));
        }
      }
    }
    vector<TnCandidate> tmp_tn_candidates;
    // generate candidates tn while number/english have no candidates
    GenerateEnglishNumberTn(tn_map.input, &tmp_tn_candidates);
    for (const auto& candidate : tn_map.candidates) {
      if (candidate.second == tn_map.input) continue;
      tmp_tn_candidates.emplace_back(
          TnCandidate(candidate.first, candidate.second, false));
    }
    vector<TnCandidate> tn_candidates;
    string tn_output = tn_map.output;
    DoTnoutputProcess(&tn_output);
    mobvoi::unordered_set<string> candidate_values;
    for (const auto& candidate : tmp_tn_candidates) {
      string tmp_candidate = candidate.value;
      DoTnoutputProcess(&tmp_candidate);
      if (candidate_values.find(tmp_candidate) == candidate_values.end()) {
        if (tmp_candidate == tn_output) {
          tn_candidates.emplace_back(
              TnCandidate(candidate.key, tmp_candidate, true));
        } else {
          tn_candidates.emplace_back(
              TnCandidate(candidate.key, tmp_candidate, false));
        }
        candidate_values.insert(tmp_candidate);
      }
    }
    if (candidate_values.find(tn_output) == candidate_values.end() &&
        !tn_output.empty()) {
      string tn_name = tn_map.name;
      if (tn_name.empty()) tn_name = "now";
      tn_candidates.emplace_back(TnCandidate(tn_name, tn_output, true));
    }
    string tn_pron_tones = string();
    string tn_pron_alphas = string();
    if (tts::IsEnglishWord(tn_map.input)) {
      for (size_t i = 0; i < tn_pron_tone.size(); ++i) {
        tn_pron_tones += tn_pron_tone[i];
        tn_pron_alphas += tn_pron_alpha[i];
      }
    } else {
      tn_pron_tones = JoinVector(tn_pron_tone, ' ');
      tn_pron_alphas = JoinVector(tn_pron_alpha, ' ');
    }
    vector<string> origin_slices;
    if (tn_map.output == kSepMarkNone || tn_map.output == kSepMarkLP ||
        tn_map.output == kSepMarkSilence || tn_map.output == kSepMarkPhrase ||
        tn_map.output == kSepMarkSP || tn_map.output == kSepMarkWord) {
      util::SplitUtf8String(tn_map.input, &origin_slices);
    } else {
      origin_slices.emplace_back(tn_map.input);
    }
    for (const auto& tn_input_slice : origin_slices) {
      if (!out->empty()) {
        out->emplace_back(
            PlatformInfo(tn_input_slice, tn_pron_tones, tn_pron_alphas, "",
                         out->back().pause_level, 100, tn_candidates));
      } else {
        out->emplace_back(
            PlatformInfo(tn_input_slice, tn_pron_tones, tn_pron_alphas, "",
                         kSepMarkNonePauseLevel, 100, tn_candidates));
      }
    }
  }
  if (man_index > word_detail_infos->size()) {
    return false;
  }
  characters->erase(characters->begin(),
                    characters->begin() + util::utflen(tn_map.input.c_str()));
  word_detail_infos->erase(word_detail_infos->begin(),
                           word_detail_infos->begin() + man_index);
  return true;
}

void DoJudgeDislocation(int offset, vector<PlatformInfo>* out,
                        vector<WordDetailInfo>* tn_g2p_infos) {
  if (offset == 0) return;
  string word;
  for (auto& pt : *out) {
    word = pt.word;
    pt = PlatformInfo(pt.word, "", "", "", kSepMarkNonePauseLevel, 100);
  }
  for (auto& tg : *tn_g2p_infos) {
    word = tg.word;
    tg = WordDetailInfo(tg.word, "", "", kSepMarkNonePauseLevel, 100);
  }
}

bool RecoverSentence(const TnDetail& detail,
                     vector<WordDetailInfo>* word_detail_infos,
                     vector<PlatformInfo>* out,
                     vector<WordDetailInfo>* tn_g2p_infos) {
  vector<string> origin_character, temp_origin_character;
  util::SplitUtf8String(detail.tn_input, &origin_character);
  temp_origin_character = origin_character;
  size_t start_index = 0;
  size_t offset;
  string last_symbol_flag = "none";
  for (size_t tn_map_index = 0; tn_map_index < detail.tn_mappings.size();
       ++tn_map_index) {
    TnMapping tn_map = detail.tn_mappings[tn_map_index];
    offset = tn_map.offset - start_index;
    string tmp_string = string();
    for (size_t i = 0; i < offset; ++i) {
      tmp_string += origin_character[i];
    }
    if (!DoAlignment(offset, last_symbol_flag, &origin_character,
                     word_detail_infos, out, tn_g2p_infos)) {
      return false;
    }
    JudgeStrType(tmp_string, false, &last_symbol_flag);
    if (last_symbol_flag == "last") {
      if (tn_map_index != 0) {
        JudgeStrType(detail.tn_mappings[tn_map_index - 1].output, true,
                     &last_symbol_flag);
      } else {
        last_symbol_flag = "none";
      }
    }
    if (!DoTnmappingAligment(tn_map, last_symbol_flag, &origin_character,
                             word_detail_infos, out, tn_g2p_infos)) {
      return false;
    }
    JudgeStrType(tn_map.output, true, &last_symbol_flag);
    start_index += offset;
    start_index += util::utflen(tn_map.input.c_str());
  }
  offset = origin_character.size();
  if (!DoAlignment(offset, last_symbol_flag, &origin_character,
                   word_detail_infos, out, tn_g2p_infos)) {
    return false;
  }
  // while pron offset is error， set none
  DoJudgeDislocation(word_detail_infos->size(), out, tn_g2p_infos);
  return true;
}

void OriginInfoJsonWrapper(const string& frontend_type,
                           const vector<PlatformInfo>& out,
                           Json::Value* origin_infos) {
  Json::Value temp_g2p_infos(Json::arrayValue);
  string last_t = string();
  for (size_t o_index = 0; o_index < out.size(); ++o_index) {
    auto pt = out[o_index];
    Json::Value word_infos;
    size_t w_len = util::utflen(pt.word.c_str());
    if (w_len == 1) {
      word_infos["w"] = pt.word;
      bool in_model = false;
      if (FrontendManager::Instance().IsContainInPolyDict(frontend_type,
                                                          pt.word, &in_model)) {
        word_infos["t"] = pt.pron_of_tone;
        if (in_model) {
          word_infos["f"] = true;
        }
      }
      if (o_index + 1 < out.size() && out[o_index + 1].word == "儿") {
        word_infos["t"] = pt.pron_of_tone;
      }
      if (!pt.pause_level.empty() && pt.pause_level != kSepMarkNonePauseLevel)
        word_infos["p"] = StringToInt(pt.pause_level.substr(1, 2));
      temp_g2p_infos.append(word_infos);
    } else {
      vector<string> characters;
      util::SplitUtf8String(pt.word, &characters);
      for (size_t i = 0; i < w_len; ++i) {
        word_infos["w"] = characters[i];
        if (i == w_len - 1 && !pt.pause_level.empty() &&
            pt.pause_level != kSepMarkNonePauseLevel)
          word_infos["p"] = StringToInt(pt.pause_level.substr(1, 2));
        temp_g2p_infos.append(word_infos);
      }
    }
  }
  *origin_infos = temp_g2p_infos;
}

// while sentence contain number  or english -> enable tn
bool JudgeEnbleTN(const TnDetail& detail) {
  if (re2::RE2::FullMatch(detail.tn_input, tn_symbol_pattern_obj)) return true;
  vector<string> origin_character;
  util::SplitUtf8String(detail.tn_input, &origin_character);
  for (const auto& character : origin_character) {
    if (tts::IsEnglishWord(character) || tts::AllDigit(character)) return true;
  }
  return false;
}

// Generate TN candidates for frontendTN API
void TnCandidatesJsonWrapper(const TnDetail& detail,
                             Json::Value* tncandidate_infos) {
  VLOG(2) << "start TnCandidatesJsonWrapper";
  Json::Value tn_candidates;
  (*tncandidate_infos)["text"] = detail.tn_input;
  (*tncandidate_infos)["candidates"] = tn_candidates;
  if (!JudgeEnbleTN(detail)) {
    VLOG(2) << "There is no tn result.";
    return;
  }
  int name_index = 1;
  string tn_output = detail.tn_output;
  DoTnoutputProcess(&tn_output);
  mobvoi::unordered_set<string> candidate_values;
  string tn_name = string();
  if (detail.tn_mappings.size() == 1 &&
      detail.tn_output == detail.tn_mappings[0].output) {
    if (!detail.tn_mappings[0].name.empty()) {
      tn_name = detail.tn_mappings[0].name;
    }
  }
  if (!tn_name.empty()) {
    tn_candidates[tn_name] = tn_output;
    candidate_values.insert(tn_output);
  }
  if (detail.tn_mappings.size() >= 1) {
    size_t size_count = 1;
    size_t name_flag = 0;
    for (size_t i = 0; i < detail.tn_mappings.size(); ++i) {
      if (detail.tn_mappings[i].candidates.size() > 1) {
        size_count = size_count * detail.tn_mappings[i].candidates.size();
        name_flag += 1;
      }
    }
    // max support
    if (size_count <= kMaxTnCandidatesLen) {
      vector<vector<string>> split_tn_candidates;
      vector<string> tn_names;
      vector<string> tn_character;
      util::SplitUtf8String(detail.tn_output, &tn_character);
      size_t start = 0, tn_start = 0;
      vector<string> split_tn_slices;
      for (const auto& tn_map : detail.tn_mappings) {
        string tmp = string();
        for (size_t j = start; j < tn_map.offset; ++j) {
          if (tn_start < tn_character.size()) tmp += tn_character[tn_start++];
        }
        if (!tmp.empty()) split_tn_slices.emplace_back(tmp);
        if (!split_tn_slices.empty()) {
          split_tn_candidates.emplace_back(split_tn_slices);
          split_tn_slices.clear();
        }
        if (tn_map.candidates.empty()) {
          split_tn_slices.emplace_back(tn_map.output);
        } else {
          for (const auto& candidate : tn_map.candidates) {
            split_tn_slices.emplace_back(candidate.second);
            if (name_flag <= 1 && tn_map.candidates.size() == size_count) {
              tn_names.emplace_back(candidate.first);
            }
          }
        }
        if (!split_tn_slices.empty()) {
          split_tn_candidates.emplace_back(split_tn_slices);
          split_tn_slices.clear();
        }
        tn_start += util::utflen(tn_map.output.c_str());
        start = tn_map.offset + util::utflen(tn_map.input.c_str());
      }
      if (tn_start < tn_character.size()) {
        string tmp = string();
        for (size_t j = tn_start; j < tn_character.size(); ++j) {
          tmp += tn_character[j];
        }
        if (!tmp.empty()) split_tn_slices.emplace_back(tmp);
        if (!split_tn_slices.empty()) {
          split_tn_candidates.emplace_back(split_tn_slices);
        }
      }
      vector<string> tn_result;
      GenTnDecare(split_tn_candidates, &tn_result);
      for (size_t i = 0; i < tn_result.size(); ++i) {
        string tmp_candidate = tn_result[i];
        DoTnoutputProcess(&tmp_candidate);
        if (candidate_values.find(tmp_candidate) == candidate_values.end()) {
          string name;
          if (name_flag <= 1 && size_count == tn_names.size() &&
              i < tn_names.size()) {
            name = tn_names[i];
          } else {
            name = "now_" + IntToString(name_index++);
          }
          tn_candidates[name] = tmp_candidate;
          candidate_values.insert(tmp_candidate);
        }
      }
    }
  }

  vector<TnCandidate> tmp_candidates;
  GenerateEnglishNumberTn(detail.tn_input, &tmp_candidates);
  if (re2::RE2::FullMatch(detail.tn_input, tn_symbol_pattern_obj)) {
    GenerateSymbolTn(detail.tn_input, &tmp_candidates);
  }
  for (const auto& tmp_candidate : tmp_candidates) {
    string candidate_value = tmp_candidate.value;
    DoTnoutputProcess(&candidate_value);
    if (candidate_values.find(candidate_value) == candidate_values.end()) {
      string tn_name = tmp_candidate.key;
      if (tn_name.find("now") != string::npos)
        tn_name = "now_" + IntToString(name_index++);
      tn_candidates[tn_name] = candidate_value;
      candidate_values.insert(candidate_value);
    }
  }
  if (candidate_values.find(tn_output) == candidate_values.end() &&
      !tn_output.empty()) {
    tn_candidates["now_" + IntToString(name_index++)] = tn_output;
    candidate_values.insert(tn_output);
  }
  (*tncandidate_infos)["candidates"] = tn_candidates;
}

void TnG2pInfoJsonWrapper(const vector<WordDetailInfo>& tn_g2p_infos,
                          Json::Value* tn_g2p_json_infos) {
  Json::Value temp_tn_g2p_json_infos(Json::arrayValue);
  for (const auto& temp_tn_g2p_info_slice : tn_g2p_infos) {
    Json::Value word_infos;
    word_infos["word"] = temp_tn_g2p_info_slice.word;
    word_infos["pron_of_tone"] = temp_tn_g2p_info_slice.pron_of_tone;
    word_infos["pron_of_alpha"] = temp_tn_g2p_info_slice.pron_of_alpha;
    word_infos["pause_level"] = temp_tn_g2p_info_slice.pause_level;
    word_infos["pron_prob"] = temp_tn_g2p_info_slice.pron_prob;
    temp_tn_g2p_json_infos.append(word_infos);
  }
  *tn_g2p_json_infos = temp_tn_g2p_json_infos;
}

void ConstructDefaultSentInfo(const TnDetail& detail,
                              const LabelOption& label_option,
                              Json::Value* frontend_data) {
  vector<PlatformInfo> origin;
  vector<string> split_units;
  if (!detail.tn_input.empty()) {
    vector<string> origin_slices;
    util::SplitUtf8String(detail.tn_input, &origin_slices);
    DoSplitSlice(origin_slices, origin_slices.size(), &split_units);
  }
  for (const auto& split_unit : split_units) {
    origin.emplace_back(
        PlatformInfo(split_unit, "", "", "", kSepMarkNonePauseLevel, 100));
  }
  Json::Value origin_infos(Json::arrayValue);
  OriginInfoJsonWrapper(label_option.frontend_type(), origin, &origin_infos);
  (*frontend_data)["originJson"] = origin_infos;
  if (label_option.only_frontend_tn()) {
    Json::Value tncandidate_infos;
    TnCandidatesJsonWrapper(detail, &tncandidate_infos);
    (*frontend_data)["originTnlistJson"] = tncandidate_infos;
  }
}

Json::Value GetDebugInfo(const TnDetail& detail,
                         const vector<WordInfo>& word_info,
                         const LabelOption& label_option) {
  VLOG(2) << "Start GetDebugInfo.....";
  vector<WordDetailInfo> word_detail_infos;
  Json::Value frontend_data = InitialFrontendDataInfo(string());
  string tn_g2p_info = string();
  string prosody_info = string();
  string tntext_info = string();
  for (size_t i = 0; i < word_info.size(); ++i) {
    vector<string> prons;
    for (const auto& word : word_info[i].syllables) {
      string pron;
      vector<string> eng_pron;
      for (const auto& character : word.prons) {
        if (tts::AllUpper(character)) {
          string eng_tone = word.tone == Stress::kNonStress ? "0" : "1";
          if (tts::IsEngVowel(character)) {
            eng_pron.emplace_back(character + eng_tone);
          } else {
            eng_pron.emplace_back(character);
          }
        }
        pron += character;
      }
      int tone = word.tone;
      pron += std::to_string(tone);
      if (label_option.only_frontend() && !eng_pron.empty()) {
        prons.emplace_back(JoinVector(eng_pron, ' '));
      } else {
        prons.emplace_back(pron);
      }
    }
    prosody_info += word_info[i].word;
    prosody_info += GetDebugPauseFromPauseLevel(word_info[i].pause_level);
    if (label_option.only_frontend()) {
      ExtractPronAndPause(word_info[i], prons, &word_detail_infos);
    } else {
      tn_g2p_info += word_info[i].word;
      tn_g2p_info += "(" + JoinVector(prons, ' ') + ")";
    }
  }
  if (label_option.only_frontend()) {
    if (VLOG_IS_ON(2)) {
      VLOG(2) << "Start RecoverSentence....";
      VLOG(2) << "extract size : " << word_detail_infos.size();
      vector<string> temp;
      for (const auto& w : word_detail_infos) {
        temp.emplace_back(w.pron_of_tone);
      }
      VLOG(2) << JoinVector(temp, ' ');
    }
    vector<PlatformInfo> out;
    vector<WordDetailInfo> temp_tn_g2p_infos;
    if (RecoverSentence(detail, &word_detail_infos, &out, &temp_tn_g2p_infos)) {
      Json::Value origin_infos(Json::arrayValue);
      OriginInfoJsonWrapper(label_option.frontend_type(), out, &origin_infos);
      frontend_data["originJson"] = origin_infos;
      // add tn candidates handler
      if (label_option.only_frontend_tn()) {
        Json::Value tncandidate_infos;
        TnCandidatesJsonWrapper(detail, &tncandidate_infos);
        frontend_data["originTnlistJson"] = tncandidate_infos;
      }
      if (!label_option.for_voice_maker()) {
        Json::Value tn_g2p_json_infos(Json::arrayValue);
        TnG2pInfoJsonWrapper(temp_tn_g2p_infos, &tn_g2p_json_infos);
        frontend_data["g2pTnJson"] = tn_g2p_json_infos;
      }
      VLOG(2) << "End RecoverSentence....";
      for (const auto& tp : temp_tn_g2p_infos) {
        tntext_info += tp.word;
      }
    } else {
      ConstructDefaultSentInfo(detail, label_option, &frontend_data);
    }
  }
  frontend_data["g2pTnText"] = tn_g2p_info;
  frontend_data["prosodyText"] = prosody_info;
  frontend_data["tnText"] = tntext_info;
  VLOG(2) << "End GetDebugInfo.....";
  return frontend_data;
}

bool GenSentInfo(const TnDetail& detail, const vector<WordInfo>& word_infos,
                 const LabelOption& label_option, bool is_online,
                 SentInfo* sentence) {
  // Get DebugInfo
  sentence->debug_info = GetDebugInfo(detail, word_infos, label_option);
  if (VLOG_IS_ON(2)) {
    string words;
    for (size_t i = 0; i < word_infos.size(); ++i)
      words.append(word_infos[i].word + " ");
    VLOG(2) << words;
  }
  // Construct PhraseInfo
  vector<PhraseInfo> phrase_info;
  GenPhraseInfo(word_infos, &phrase_info);

  // Construct BreakInfo
  vector<BreakInfo> break_info;
  GenBreakInfo(phrase_info, &break_info);

  // Construt SubSenInfo
  vector<SubSen> subsen_info;
  GenSubSenInfo(break_info, label_option.last_seg(), &subsen_info);

  // Construct SentInfo
  sentence->sub_sens.insert(sentence->sub_sens.end(), subsen_info.begin(),
                            subsen_info.end());
  if (VLOG_IS_ON(2)) sentence->Aplay(0);
  return true;
}

void GenPhraseInfo(const vector<WordInfo>& word_info,
                   vector<PhraseInfo>* phrase_info) {
  PhraseInfo tmp_phrase;
  for (size_t i = 0; i < word_info.size(); ++i) {
    tmp_phrase.words.push_back(word_info[i]);
    tmp_phrase.phone_num += word_info[i].phone_num;
    tmp_phrase.syl_num += word_info[i].syllables.size();
    if (word_info[i].pause_level >= kPauseLevelPhrase ||
        i == word_info.size() - 1) {
      tmp_phrase.pause_level = word_info[i].pause_level;
      phrase_info->push_back(tmp_phrase);
      // To do change following into inner function
      tmp_phrase.phone_num = 0;
      tmp_phrase.syl_num = 0;
      tmp_phrase.words.clear();
    }
  }
}

void GenSubSenInfo(const vector<BreakInfo>& break_info, bool last_seg,
                   vector<SubSen>* subsen_info) {
  SubSen tmp_sub_sen;
  for (size_t i = 0; i < break_info.size(); ++i) {
    tmp_sub_sen.phone_num += break_info[i].phone_num;
    tmp_sub_sen.syl_num += break_info[i].syl_num;
    tmp_sub_sen.word_num += break_info[i].word_num;
    tmp_sub_sen.phrase_num += break_info[i].phrases.size();
    tmp_sub_sen.breaks.push_back(break_info[i]);
  }
  subsen_info->push_back(tmp_sub_sen);
  if (last_seg) {
    subsen_info->back().breaks.back().phrases.back().words.back().pause_level =
        kPauseLevelSilence;
  }
}

// LOGING FUNCTION
void GetLogFormat(int level, int flevel, string* format) {
  int tmp = 1;
  while (level > tmp) {
    if (flevel % 2) {
      *format += "    ";
    } else {
      *format += "│   ";
    }
    flevel /= 2;
    ++tmp;
  }
  if (flevel) {
    *format += "└── ";
  } else {
    *format += "├── ";
  }
}

void SyllableInfo::Aplay(int level, int flevel) {
  string log_info;
  GetLogFormat(level, flevel, &log_info);
  log_info += "prons: " + JoinVector(prons, ' ') + " " + IntToString(tone) +
              " pos: " + pos;
  VLOG(1) << log_info;
}

void WordInfo::Aplay(int level, int flevel) {
  string log_info;
  GetLogFormat(level, flevel, &log_info);
  log_info += StringPrintf("word(%d): %-15spause level: %d(punc? %d)", word_id,
                           word.c_str(), pause_level, punc);
  VLOG(1) << log_info;
  for (size_t i = 0; i < syllables.size(); ++i) {
    if (i == syllables.size() - 1) flevel += pow(2, level);
    syllables[i].Aplay(level + 1, flevel);
  }
}

void PhraseInfo::Aplay(int level, int flevel) {
  string log_info;
  GetLogFormat(level, flevel, &log_info);
  log_info += "Phrase:";
  VLOG(1) << log_info;
  for (size_t i = 0; i < words.size(); ++i) {
    if (i == words.size() - 1) flevel += pow(2, level);
    words[i].Aplay(level + 1, flevel);
  }
}

BreakInfo::BreakInfo() { Reset(); }

BreakInfo::~BreakInfo() {}

void BreakInfo::Reset() {
  phone_num = 0;
  syl_num = 0;
  word_num = 0;
  break_type = 0;
  pause_level = 0;
  phrases.clear();
}

void BreakInfo::GetTextString(string* break_text) {
  for (size_t i = 0; i < phrases.size(); ++i) {
    for (size_t j = 0; j < phrases[i].words.size(); ++j) {
      *break_text += phrases[i].words[j].word;
      *break_text += kSepMarkWord;
    }
    *break_text += kSepMarkPhrase;
  }

  static re2::RE2 obj("\\`\\^");
  re2::RE2::GlobalReplace(break_text, obj, kSepMarkPhrase);
}

void BreakInfo::Aplay(int level, int flevel) {
  string break_text;
  GetTextString(&break_text);
  string log_info;
  GetLogFormat(level, flevel, &log_info);
  log_info += "Break(" + IntToString(break_type) + "): " + break_text;
  VLOG(1) << log_info;
  for (size_t i = 0; i < phrases.size(); ++i) {
    if (i == phrases.size() - 1) flevel += pow(2, level);
    phrases[i].Aplay(level + 1, flevel);
  }
}

SubSen::SubSen() { Reset(); }

SubSen::~SubSen() {}

void SubSen::Reset() {
  phone_num = 0;
  syl_num = 0;
  word_num = 0;
  phrase_num = 0;
  breaks.clear();
}

void SubSen::GetTextString(string* sub_sen_text) {
  for (size_t i = 0; i < breaks.size(); ++i) {
    for (size_t j = 0; j < breaks[i].phrases.size(); ++j) {
      for (size_t k = 0; k < breaks[i].phrases[j].words.size(); ++k) {
        *sub_sen_text += breaks[i].phrases[j].words[k].word;
        *sub_sen_text += kSepMarkWord;
      }
      *sub_sen_text += kSepMarkPhrase;
    }
    *sub_sen_text += kSepMarkSP;
  }
  static re2::RE2 obj1("\\`\\^\\,");
  re2::RE2::GlobalReplace(sub_sen_text, obj1, kSepMarkSP);
  static re2::RE2 obj2("\\`\\^");
  re2::RE2::GlobalReplace(sub_sen_text, obj2, kSepMarkPhrase);
}

void SubSen::Aplay(int level, int flevel) {
  string subsen_text;
  GetTextString(&subsen_text);
  string log_info;
  GetLogFormat(level, flevel, &log_info);
  log_info += "Subsen: " + subsen_text;
  VLOG(1) << log_info;
  for (size_t i = 0; i < breaks.size(); ++i) {
    if (i == breaks.size() - 1) flevel += pow(2, level);
    breaks[i].Aplay(level + 1, flevel);
  }
}

void SentInfo::Aplay(int level) {
  VLOG(1) << "sentence";
  int flevel = 0;
  for (size_t i = 0; i < sub_sens.size(); ++i) {
    if (i == sub_sens.size() - 1) flevel += pow(2, level);
    sub_sens[i].Aplay(level + 1, flevel);
  }
}

}  // namespace tts
