// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_SYNTHESIZER_SPEAKER_MANAGER_H_
#define TTS_SYNTHESIZER_SPEAKER_MANAGER_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/mutex.h"
#include "tts/synthesizer/engine/engine_factory.h"
#include "tts/synthesizer/label_generator/label_generator_manager.h"
#include "tts/synthesizer/proto/tts.pb.h"
#include "tts/synthesizer/vocoder/vocoder_factory.h"

namespace tts {
class SpeakerManager {
 public:
  explicit SpeakerManager(const string& speaker_json_files);
  ~SpeakerManager();

  vector<std::pair<string, bool>> GetSpeakers(const string& language) const;
  std::shared_ptr<LabelGenerator> GetLabelGenerator(
      const string& language) const;
  std::shared_ptr<engine::Engine> GetEngine(const string& speaker) const;
  std::shared_ptr<vocoder::Vocoder> GetVocoder(const string& speaker) const;
  void SetSpeakerCache(const string& speaker, const string& text,
                       const vector<int16>& cache_data);
  bool GetCacheData(const string& speaker,
                    map<string, vector<int16>>* cache_data);
  // check if a speaker exist or is loaded
  bool CheckSpeaker(const string& speaker) const;
  bool LoadSpeaker(const string& speaker);
  bool UnloadSpeaker(const string& speaker);
  vector<string> GetSupLanguages() const;
  bool IsSupportEn(const string& speaker) const;
  float GetVolume(const string& speaker) const;
  float GetSpeed(const string& speaker) const;
  string GetLanguage(const string& speaker) const;
  bool IsSupportErhua(const string& speaker) const;
  int IsUnloadLabel(const string& language) const;

 private:
  void LoadCacheData(const string& cache_config_file,
                     map<string, vector<int16>>* datas) const;

  unique_ptr<LabelGeneratorManager> label_generator_manager_;
  map<string, SpeakerInfo> speaker_infos_;
  map<string, std::shared_ptr<LabelGenerator>> speaker_label_generators_;
  map<string, std::shared_ptr<engine::Engine>> speaker_engines_;
  map<string, std::shared_ptr<vocoder::Vocoder>> speaker_vocoders_;
  map<string, map<string, vector<int16>>> speaker_cache_datas_;
  mobvoi::SharedMutex mutex_;
};
}  // namespace tts

#endif  // TTS_SYNTHESIZER_SPEAKER_MANAGER_H_
