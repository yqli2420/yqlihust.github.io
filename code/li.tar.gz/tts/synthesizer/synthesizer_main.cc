// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/synthesizer/synthesizer.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/file/proto_util.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/time.h"
#include "tts/util/tts_util/util.h"

DEFINE_string(text,
              "中国天气网讯\n "
              "今明天(二十四到二十五日),"
              "云南、广西至江汉、江淮的强降雨将持续。华北对流天气减弱,"
              "东北雷雨天气增多。I want to try something new",
              "");
DEFINE_string(save_filename, "test", "");
DEFINE_string(text_file, "tts/synthesizer/testdata/tts.text", "");
DEFINE_string(file_format, "wav", "wav | mp3 | speex | pcm");
DEFINE_string(save_dir, "wav", "");
DEFINE_string(speaker_info_file, "external/config/config_file/speakers.json",
              "speaker info json file");
DEFINE_string(domain, "", "tts_domain");
DEFINE_string(speaker, "cissy", "speaker name");
DEFINE_bool(only_frontend, false, "only frontend");

int main(int argc, char** argv) {
  mobvoi::ParseCommandLineFlags(&argc, &argv, false, "");
  tts::Synthesizer tts(FLAGS_speaker_info_file);

  tts::TTSOption tts_option;
  tts::SetDefaultTTSOption(&tts_option);
  tts_option.set_speaker(FLAGS_speaker);
  tts_option.set_file_format(FLAGS_file_format);
  tts_option.set_only_frontend(FLAGS_only_frontend);

  int64_t begin = mobvoi::GetTimeInMs();
  int word_num = 0;
  if (!FLAGS_text.empty()) {
    if (!FLAGS_domain.empty()) tts_option.set_domain(FLAGS_domain);
    if (!tts_option.only_frontend()) {
      string data;
      data.reserve(
          1);  // TODO(wei kang) is it really a android std::string bug?
      tts.Synthesize(FLAGS_text, tts_option, &data);
      string save_file = StringPrintf("%s.%s", FLAGS_save_filename.c_str(),
                                      tts_option.file_format().c_str());
      mobvoi::File::WriteStringToFile(data, save_file);
    } else {
      tts_option.set_only_frontend_tn(true);
      Json::Value frontend_data;
      tts.FrontendSynthesize(FLAGS_text, tts_option, &frontend_data);
    }
  } else if (!FLAGS_text_file.empty()) {
    vector<string> lines;
    file::SimpleLineReader reader(FLAGS_text_file);
    reader.ReadLines(&lines);
    vector<string> frontend_res;
    for (size_t i = 0; i < lines.size(); ++i) {
      vector<string> segs;
      SplitString(lines[i], '\t', &segs);
      if (segs.size() != 2UL) {
        LOG(ERROR) << "Bad line:" << lines[i];
        continue;
      }
      string text = segs[1];
      word_num += util::utflen(text.c_str());
      tts::CutOffText(&text, 500);
      string save_file = mobvoi::File::JoinPath(
          FLAGS_save_dir, StringPrintf("%s.%s", segs[0].c_str(),
                                       tts_option.file_format().c_str()));
      if (!tts_option.only_frontend()) {
        string data;
        tts.Synthesize(text, tts_option, &data);
        mobvoi::File::WriteStringToFile(data, save_file);
        LOG(INFO) << "Synthesize for line: " << lines[i];
      } else {
        Json::Value frontend_data;
        LOG(INFO) << "Frontend Synthesize for line: " << lines[i];
        tts.FrontendSynthesize(text, tts_option, &frontend_data);
        vector<string> g2p_info;
        for (auto g2p : frontend_data["g2pTnJson"]) {
          g2p_info.emplace_back(g2p["pron_of_tone"].asString());
        }
        frontend_res.emplace_back(text + "\t" + JoinVector(g2p_info, ' ') +
                                  "\t" +
                                  frontend_data["prosodyText"].asString());
      }
    }
    if (!frontend_res.empty()) {
      mobvoi::File::WriteStringToFile(JoinVector(frontend_res, '\n'),
                                      "frontend_systhesis.result");
    }
  } else {
    LOG(ERROR) << "Please input --text or --text_file";
  }
  int64_t end = mobvoi::GetTimeInMs();
  int64 used_time = end - begin;
  if (used_time) {
    LOG(INFO) << "Synthesize time: " << end - begin << "ms. Well Done!";
    LOG(INFO) << word_num * 1000.0 / used_time << " character/second";
  }
  return 0;
}
