// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: sxwang@mobvoi.com (Sixue Wang)

#ifndef TTS_SYNTHESIZER_ENGINE_TACOTRON_ONE_ENGINE_H_
#define TTS_SYNTHESIZER_ENGINE_TACOTRON_ONE_ENGINE_H_

#include <memory>
#include <string>
#include <vector>

#include "mobvoi/base/macros.h"
#include "third_party/one/taco_model.h"

#include "tts/synthesizer/engine/engine.h"
#include "tts/synthesizer/engine/tacotron/symbol.h"

namespace engine {
namespace tacotron {

class ONEEngine : public Engine {
 public:
  ONEEngine(const tts::LanguageType& language_type,
            const std::string& model_file, float speed,
            int n_parallel = 1);
  ~ONEEngine();
  bool SynthesizeFromLabel(const tts::TTSOption& tts_option,
                           const std::vector<std::string>& labels,
                           tts::RawData* raw_data) const override;
  mobvoi::one::TacoModel* model() { return model_.get(); }
  string GetEngineModelType() const override;

 private:
  void ReadSymbol();
  void InterpolateCMP(const std::vector<float> src, int src_dim, int dst_dim,
                      float speed, std::vector<float>* dst) const;
  std::string model_file_;
  tts::LanguageType language_;
  float default_speed_;
  std::string output_type_;
  std::unique_ptr<SymbolTable> symbol_table_;
  std::unique_ptr<mobvoi::one::TacoModel> model_;
  DISALLOW_COPY_AND_ASSIGN(ONEEngine);
};

}  // namespace tacotron
}  // namespace engine

#endif  // TTS_SYNTHESIZER_ENGINE_TACOTRON_ONE_ENGINE_H_
