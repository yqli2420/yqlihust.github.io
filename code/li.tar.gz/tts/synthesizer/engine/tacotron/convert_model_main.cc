// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: sxwang@mobvoi.com (Sixue Wang)

#include <fstream>
#include <memory>
#include <sstream>
#include <string>

#include <NvInfer.h>

#include "mobvoi/base/flags.h"

#include "trt/graph.h"
#include "trt/layers/all.h"
#include "trt/logger.h"
#include "trt/tf_loader.h"
#include "trt/utils.h"

DEFINE_string(tf_model, "/path/to/tf.pb", "TensorFlow's frozen model.");
DEFINE_string(trt_engine, "/path/to/engine.trt", "TensorRT serialized engine");
DEFINE_int32(max_batch_size, 32, "Max batch size");
DEFINE_int32(max_text_len, 180, "Max text len");
DEFINE_int32(reduction_factor, 5, "reduction factor");
DEFINE_int32(target_length, 43, "dimension of acoustic features");
DEFINE_bool(with_dropout, true, "With dropout");
DEFINE_bool(use_rnn_cell, false, "Use RNN cell");
DEFINE_string(output_type, "cmp",
              "acoustic feature type: cmp (mgc+f0) | mel | lpc");

namespace {

using trt::operator>>;
using nvinfer1::DataType;
using nvinfer1::Dims2;
using nvinfer1::ElementWiseOperation;

// model params
const int kEmbeddingDims = 512;
const int kMemoryDepth = 512;
const int kPrenetNumUnits = 256;
const float kZoneoutInFactor = 0.1;
const float kZoneoutOutFactor = 0.9;
const int kLocConvChannels = 32;  // Attention location convolution channels
const int kAttentionDepth = 128;
const int kDecLSTMNumUnits = 1024;
const float kKeepProb = 0.5;
const char kDelimiter = ',';

// trt engine params
const bool kVerbose = false;
const bool kFp16 = false;
const size_t kMaxWorkspaceSize = 2_GB;
const uint64_t kSeed = 19950214;

trt::Logger::ptr kLogger = std::make_shared<trt::Logger>(
    kVerbose ? trt::Logger::Severity::kINFO : trt::Logger::Severity::kWARNING);

Dropout::ptr kDropout1 = std::make_shared<Dropout>(kKeepProb, kSeed);
Dropout::ptr kDropout2 = std::make_shared<Dropout>(kKeepProb, kSeed);
Slice::ptr kSlice1 = std::make_shared<Slice>(FLAGS_reduction_factor);

void PrintDims(ITensors tensors) {
  for (auto tensor : tensors) {
    LOG(INFO) << tensor->getName();
    nvinfer1::Dims dim = tensor->getDimensions();
    for (uint32_t i = 0; i < dim.nbDims; ++i) {
      LOG(INFO) << "dim" << i << ":" << dim.d[i];
    }
  }
}

trt::Graph::ptr BuildEncoderGraph(trt::Loader::ptr loader) {
  loader->set_scope("model/inference/");

  auto graph = std::make_shared<trt::Graph>(kLogger, FLAGS_max_batch_size,
                                            kMaxWorkspaceSize, kFp16);
  graph->AsDefault();

  graph->set_scope("Encoder_");
  auto conv_feature =
      Input(DataType::kINT32, Dims1D(FLAGS_max_text_len), "Text") >>
      Embedding(loader->Embedding("inputs_embedding"), "Text_Embedding") >>
      Shuffle(TNToN1T(FLAGS_max_text_len, kEmbeddingDims),
              "Tx512_To_512x1xT") >>
      Conv1D(loader->Conv1DReLu(
                 "encoder_convolutions/conv_layer_1_encoder_convolutions/"),
             "Conv1D_1") >>
      Conv1D(loader->Conv1DReLu(
                 "encoder_convolutions/conv_layer_2_encoder_convolutions/"),
             "Conv1D_2") >>
      Conv1D(loader->Conv1DReLu(
                 "encoder_convolutions/conv_layer_3_encoder_convolutions/"),
             "Conv1D_3") >>
      Shuffle(N1TToTN(FLAGS_max_text_len, kEmbeddingDims), "512x1xT_To_Tx512");

  ITensors text_len = Input(DataType::kINT32, Dims0D(), "Text_Length");

  // forget_bias = 0 for CudnnCompatibleLSTMCell
  auto lstm_params = loader->LSTM(
                         "encoder_LSTM/stack_bidirectional_rnn/cell_0/"
                         "bidirectional_rnn/fw/cudnn_compatible_lstm_cell/",
                         0) +
                     loader->LSTM(
                         "encoder_LSTM/stack_bidirectional_rnn/cell_0/"
                         "bidirectional_rnn/bw/cudnn_compatible_lstm_cell/",
                         0);
  lstm_params.max_seqlen = FLAGS_max_text_len;

  // [max_time, 512]
  auto memory = conv_feature >> Append(text_len) >>
                LSTM(lstm_params, "BLSTM") >> Keep({0}, "Keep_BLSTM_Output");

  graph->set_scope("Attention_");

  memory = memory >> Output("Memory");

  // [max_time, 128]
  auto keys = memory >> Dense(loader->Dense("memory_layer/"), "Memory_Layer") >>
              Output("Keys");
  return graph;
}

trt::Graph::ptr BuildDecoderGraph(trt::Loader::ptr loader,
                                  bool with_dropout = true,
                                  std::string output_type = "cmp",
                                  int target_length = 43) {
  loader->set_scope("model/inference/decoder/");

  auto graph = std::make_shared<trt::Graph>(kLogger, FLAGS_max_batch_size,
                                            kMaxWorkspaceSize, kFp16);
  graph->AsDefault();

  graph->set_scope("Decoder_");
  auto dtype = kFp16 ? DataType::kHALF : DataType::kFLOAT;

  // [1, 256]
  auto prenet_out =
      Input(dtype, Dims1N(target_length), "Input_Frame") >>
      Dense(loader->DenseReLu("decoder_prenet/dense_1/"), "Prenet_Dense_1");

  if (with_dropout) {
    prenet_out = prenet_out >> Custom(kDropout1, "Dropout1");
  }
  prenet_out = prenet_out >> Dense(loader->DenseReLu("decoder_prenet/dense_2/"),
                                   "Prenet_Dense_2");
  if (with_dropout) {
    prenet_out = prenet_out >> Custom(kDropout2, "Dropout2");
  }

  // [1, 512]
  graph->set_scope("Attention_");
  ITensors pre_context = Input(dtype, Dims1N(kMemoryDepth), "Pre_Context");

  graph->set_scope("Decoder_");

  // [1, 1024]
  ITensors lstm_out;

  // [1, 512+256];
  auto lstm_in = prenet_out >> Append(pre_context) >>
                 Concat(1, "Prenet_Out_Concat_Prenet_Context");

  if (FLAGS_use_rnn_cell) {
    auto lstm_cell_params_1 = loader->LSTMCell(
        "decoder_lstm/multi_rnn_cell/cell_0/decoder_LSTM_1/", 1.0);
    auto lstm_cell_params_2 = loader->LSTMCell(
        "decoder_lstm/multi_rnn_cell/cell_1/decoder_LSTM_2/", 1.0);

    // TODO(sxwang): We need zoneout LSTM cell.
    lstm_out = lstm_in >>
               ZoneoutLSTMCell(
                   lstm_cell_params_1, const_cast<float*>(&kZoneoutInFactor),
                   const_cast<float*>(&kZoneoutOutFactor),
                   const_cast<float*>(&kZoneoutInFactor),
                   const_cast<float*>(&kZoneoutOutFactor), "LSTMCell_1");
    lstm_out = ITensors{lstm_out[0]} >>
               ZoneoutLSTMCell(
                   lstm_cell_params_2, const_cast<float*>(&kZoneoutInFactor),
                   const_cast<float*>(&kZoneoutOutFactor),
                   const_cast<float*>(&kZoneoutInFactor),
                   const_cast<float*>(&kZoneoutOutFactor), "LSTMCell_2");
    lstm_out = ITensors{lstm_out[0]};
  } else {
    auto lstm_params =
        loader->LSTM("decoder_lstm/multi_rnn_cell/cell_0/decoder_LSTM_1/",
                     1.0) &
        loader->LSTM("decoder_lstm/multi_rnn_cell/cell_1/decoder_LSTM_2/", 1.0);
    lstm_params.max_seqlen = 1;

    lstm_out = lstm_in >> ZoneoutLSTM(lstm_params,
                                      const_cast<float*>(&kZoneoutInFactor),
                                      const_cast<float*>(&kZoneoutOutFactor),
                                      const_cast<float*>(&kZoneoutInFactor),
                                      const_cast<float*>(&kZoneoutOutFactor),
                                      "ZoneoutLSTM");
  }

  graph->set_scope("Attention_");
  // [1, 128]
  auto query = lstm_out >>
               Dense(loader->Dense("LocationSensitiveAttention/query_layer/"),
                     "Query_Layer");

  // [max_time, 1]
  ITensors pre_alignment =
      Input(dtype, DimsN1(FLAGS_max_text_len), "Pre_Alignment");

  // [max_time, 128]
  auto location_feature =
      pre_alignment >> Reshape(Dims11N(FLAGS_max_text_len), "Tx1_To_1x1xT") >>
      Conv1D(
          loader->Conv1D(
              "while/CustomDecoderStep/LocationSensitiveAttention/"
              "location_features_convolution/",
              "LocationSensitiveAttention/location_features_convolution/", ""),
          "Location_Conv1D") >>
      Shuffle(N1TToTN(FLAGS_max_text_len, kLocConvChannels),
              "32x1xT_To_Tx32") >>
      Dense(
          loader->Dense("LocationSensitiveAttention/location_features_layer/"),
          "Location_Layer");

  // [max_time, 128]
  ITensors keys =
      Input(dtype, Dims2(FLAGS_max_text_len, kAttentionDepth), "Keys");

  // [128]
  ITensors v = Const(
      loader->Const("LocationSensitiveAttention/attention_variable"), "v");

  // [128]
  ITensors b =
      Const(loader->Const("LocationSensitiveAttention/attention_bias"), "b");

  ITensors memory =
      Input(dtype, Dims2(FLAGS_max_text_len, kMemoryDepth), "Memory");

  ITensors memory_len =
      Input(DataType::kINT32, nvinfer1::Dims2(1, 1), "Memory_Length");

  // [max_time, 1]
  auto alignment =
      keys >> Append(query) >>
      Elementwise(ElementWiseOperation::kSUM, "Keys_Plus_Query") >>
      Append(location_feature) >>
      Elementwise(ElementWiseOperation::kSUM, "Plus_Loc_Feat") >> Append(b) >>
      Elementwise(ElementWiseOperation::kSUM, "Plus_b") >>
      Activation(nvinfer1::ActivationType::kTANH, "Tanh") >> Append(v) >>
      Elementwise(ElementWiseOperation::kPROD, "Mul_v") >>
      Reduce(ReduceParams{nvinfer1::ReduceOperation::kSUM, 1 << 1, true},
             "Reduce_Sum") >>
      Reshape(Dims1N(FLAGS_max_text_len), "Tx1_To_1xT") >> Append(memory_len) >>
      RaggedSoftmax("RaggedSoftmax") >>
      Reshape(DimsN1(FLAGS_max_text_len), "1xT_To_Tx1");

  auto cumulated_alignment =
      alignment >> Append(pre_alignment) >>
      Elementwise(ElementWiseOperation::kSUM, "Cumulate_Alignment") >>
      Output("Cumulated_Alignment");

  // [1, 512]
  auto context = alignment >> Append(memory) >>
                 Matmul(MatmulParams(true, false), "Alignment_Matmul_Memory") >>
                 Output("Context");

  // [1, 1024+512]
  auto projection_input =
      lstm_out >> Append(context) >> Concat(1, "LSTM_Out_Concat_Context");

  graph->set_scope("Decoder_");

  // [1, 5x43]
  auto output_frame =
      projection_input >>
      Dense(loader->Dense("linear_transform/projection_linear_transform/"),
            "Frame_Projection");

  loader->set_scope("model/");
  ITensors mean;
  ITensors stddev;
  if (output_type == "cmp") {
    mean = Const(loader->Const("add/y"), "Mean");
    stddev = Const(loader->Const("mul/y"), "Stddev");
  }
  loader->set_scope("model/inference/decoder/");

  // [1, 43]
  auto sliced_output =
      output_frame >> Custom(kSlice1, "Slice1") >> Output("SlicedOutput");

  // [1, 5]
  auto stop =
      projection_input >>
      Dense(loader->DenseSigmoid(
                "stop_token_projection/projection_stop_token_projection/"),
            "Stop_Projection");

  if (output_type == "cmp") {
    // [1, 5* 43+5]
    auto denorm_frame =
        output_frame >>
        Reshape(nvinfer1::Dims3(1, FLAGS_reduction_factor, target_length),
                "172x1x1_To_1x5x43") >>
        Append(stddev) >>
        Elementwise(ElementWiseOperation::kPROD, "Mul_Stddev") >>
        Append(mean) >> Elementwise(ElementWiseOperation::kSUM, "Plus_mean") >>
        Reshape(Dims1N(FLAGS_reduction_factor * target_length)) >>
        Append(stop) >> Concat(1, "Final_Output_Concat") >>
        Output("DecoderOutput");
    PrintDims(denorm_frame);
  } else {
    auto decoder_output =
        output_frame >>
        Reshape(Dims1N(FLAGS_reduction_factor * target_length)) >>
        Append(stop) >> Concat(1, "Final_Output_Concat") >>
        Output("DecoderOutput");
    PrintDims(decoder_output);
  }

  return graph;
}

std::string GetSymbols(trt::TFLoader::ptr loader) {
  auto node_map = loader->node_map();
  const auto& symbol_node = node_map.at("model/symbols");
  const auto& symbols = symbol_node.attr().at("value").tensor().string_val();
  std::stringstream ss;
  ss << symbols.Get(0);
  for (size_t i = 1; i < symbols.size(); ++i) {
    ss << kDelimiter << symbols.Get(i);
  }
  return ss.str();
}

void Save(const std::string& filepath, const std::string& symbols,
          trt::Graph::ptr encoder, trt::Graph::ptr decoder) {
  std::ofstream output(filepath, std::ios::binary);

  string reduction_factor = std::to_string(FLAGS_reduction_factor);
  size_t rf_size = reduction_factor.size();
  output.write(reinterpret_cast<char*>(&rf_size), sizeof(rf_size));
  output.write(reduction_factor.c_str(), rf_size);

  size_t type_size = FLAGS_output_type.size();
  output.write(reinterpret_cast<char*>(&type_size), sizeof(type_size));
  output.write(FLAGS_output_type.c_str(), type_size);

  size_t symbols_size = symbols.size();
  output.write(reinterpret_cast<char*>(&symbols_size), sizeof(symbols_size));
  output.write(symbols.c_str(), symbols_size);

  auto encoder_data = encoder->Save();
  size_t encoder_size = encoder_data->size();
  output.write(reinterpret_cast<char*>(&encoder_size), sizeof(encoder_size));
  output.write(static_cast<char*>(encoder_data->data()), encoder_size);

  auto decoder_data = decoder->Save();
  size_t decoder_size = decoder_data->size();
  output.write(reinterpret_cast<char*>(&decoder_size), sizeof(decoder_size));
  output.write(static_cast<char*>(decoder_data->data()), decoder_size);

  output.close();
}

}  // namespace

int main(int argc, char* argv[]) {
  mobvoi::ParseCommandLineFlags(&argc, &argv, false, "");

  CHECK(FLAGS_output_type == "cmp" || FLAGS_output_type == "mel" ||
        FLAGS_output_type == "lpc")
      << "unsupported output type:" << FLAGS_output_type;
  auto loader = std::make_shared<trt::TFLoader>(FLAGS_tf_model);
  auto symbols = GetSymbols(loader);
  LOG(INFO) << "Symbols:" << symbols << "$";
  auto encoder = BuildEncoderGraph(loader);
  auto decoder = BuildDecoderGraph(loader, FLAGS_with_dropout,
                                   FLAGS_output_type, FLAGS_target_length);
  Save(FLAGS_trt_engine, symbols, encoder, decoder);
  return 0;
}
