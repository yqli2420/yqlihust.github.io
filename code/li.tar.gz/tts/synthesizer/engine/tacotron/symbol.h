// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: sxwang@mobvoi.com (Sixue Wang)

#ifndef TTS_SYNTHESIZER_ENGINE_TACOTRON_SYMBOL_H_
#define TTS_SYNTHESIZER_ENGINE_TACOTRON_SYMBOL_H_

#include <map>
#include <memory>
#include <string>
#include <vector>

namespace engine {
namespace tacotron {

class SymbolTable {
 public:
  typedef std::shared_ptr<SymbolTable> ptr;
  SymbolTable() : size_(0) {}
  SymbolTable(int size, const char* symbols[]);
  explicit SymbolTable(const std::vector<const char*>& symbols);
  explicit SymbolTable(const std::vector<std::string>& symbols);
  explicit SymbolTable(const std::string& filepath);
  void Add(const std::string& s);
  int GetId(const std::string& s) const;
  const std::string& GetSymbol(int id) const;
  std::vector<int> ParseLabel(const std::vector<std::string>& labels,
                              const std::string& speaker_name) const;
  int size() const { return size_; }
  int unk_id() const { return unk_id_; }
  int pad_id() const { return pad_id_; }
  int end_id() const { return end_id_; }

 private:
  std::map<std::string, int> symbol_to_id_;
  std::vector<std::string> id_to_symbol_;
  int size_;

  static const char* unk_symbol_;
  static const char* pad_symbol_;
  static const char* end_symbol_;
  static const char* sil_symbol_;
  static const int unk_id_;
  static const int pad_id_;
  static const int end_id_;
};

}  // namespace tacotron
}  // namespace engine

#endif  // TTS_SYNTHESIZER_ENGINE_TACOTRON_SYMBOL_H_
