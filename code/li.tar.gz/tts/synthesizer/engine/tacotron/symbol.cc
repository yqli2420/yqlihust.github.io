// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: sxwang@mobvoi.com (Sixue Wang)

#include "tts/synthesizer/engine/tacotron/symbol.h"

#include <cctype>
#include <clocale>
#include <fstream>
#include <iterator>
#include <set>
#include <sstream>
#include <string>
#include <unordered_set>

#include "re2/re2.h"

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/log.h"

namespace {

static const int kMaxTextLen = 175;

static const char* kXR = "xr";

bool IsXR(const std::string& s) { return kXR == s; }

static const char* kLabelGroupRegexString =
    "(/A:)|(/B:)|(/C:)|(/D:)|(/E:)|(/F:)|(/G:)|(/H:)|(/I:)|(/J:)";

static const char* kPaus[] = {"pau", "sp", "lp"};

static const char* kInitals[] = {"b",  "p", "m", "f", "d", "t", "n",  "l",
                                 "g",  "k", "h", "j", "q", "x", "zh", "ch",
                                 "sh", "z", "c", "s", "y", "w", "r"};

static const char* kFinals[] = {
    "a",   "o",    "e",   "i",   "u",   "v",    "ai", "ei",  "ui",
    "ao",  "ou",   "iu",  "ie",  "ve",  "er",   "an", "en",  "in",
    "un",  "vn",   "ang", "eng", "ing", "ong",  "ia", "ian", "iang",
    "iao", "iong", "ua",  "uai", "uan", "uang", "uo", "van"};

static const char* kEnglishPhonemes[] = {
    "AA", "AH", "AY", "B",  "CH", "D",  "EH", "EY", "F",  "IY",
    "JH", "K",  "L",  "M",  "N",  "OW", "P",  "R",  "S",  "T",
    "UW", "V",  "W",  "Y",  "Z",  "UH", "AO", "ER", "IH", "SH",
    "G",  "NG", "AE", "AW", "HH", "DH", "TH", "OY", "ZH"};

static const char* kSharpKey[] = {"1", "2", "3", "4", "5", "6"};

static const char* kSharpValue[] = {"#1", "#2", "#3", "#4", "#5", "SIL"};

static const char kDelims[] = {'^', '-', '+', '=', '@', '_', '&', '#', '|'};

static const char kAEIOUV[] = {'a', 'e', 'i', 'o', 'u', 'v'};

class Matcher {
 public:
  static Matcher& Instance() {
    static Matcher instance;
    return instance;
  }

  const re2::RE2& LabelGroupRegex() const { return label_group_regex_; }

  bool IsPau(const std::string& s) { return paus_.find(s) != paus_.end(); }

  bool IsInital(const std::string& s) {
    return initals_.find(s) != initals_.end();
  }

  bool IsFinal(const std::string& s) {
    return finals_.find(s) != finals_.end();
  }

  bool IsEnglishPhoneme(const std::string& s) {
    return english_phonemes_.find(s) != english_phonemes_.end();
  }

  bool IsSharp(const std::string& s) { return sharp_.find(s) != sharp_.end(); }

  const std::string& Sharp(const std::string& s) {
    return sharp_.find(s)->second;
  }

  bool IsDelim(char c) { return delims_.find(c) != delims_.end(); }

  bool IsAEIOUV(char c) { return aeiouv_.find(c) != aeiouv_.end(); }

 private:
  Matcher() : label_group_regex_(kLabelGroupRegexString) {
    for (size_t i = 0; i < arraysize(kPaus); ++i) {
      paus_.insert(kPaus[i]);
    }
    for (size_t i = 0; i < arraysize(kInitals); ++i) {
      initals_.insert(kInitals[i]);
    }
    for (size_t i = 0; i < arraysize(kFinals); ++i) {
      finals_.insert(kFinals[i]);
    }
    for (size_t i = 0; i < arraysize(kEnglishPhonemes); ++i) {
      english_phonemes_.insert(kEnglishPhonemes[i]);
    }
    DCHECK(arraysize(kSharpKey) == arraysize(kSharpValue));
    for (size_t i = 0; i < arraysize(kSharpKey); ++i) {
      sharp_[kSharpKey[i]] = kSharpValue[i];
    }
    for (size_t i = 0; i < arraysize(kDelims); ++i) {
      delims_.insert(kDelims[i]);
    }
    for (size_t i = 0; i < arraysize(kAEIOUV); ++i) {
      aeiouv_.insert(kAEIOUV[i]);
    }
  }

  re2::RE2 label_group_regex_;
  std::unordered_set<std::string> paus_;
  std::unordered_set<std::string> initals_;
  std::unordered_set<std::string> finals_;
  std::unordered_set<std::string> english_phonemes_;
  std::map<std::string, std::string> sharp_;
  std::unordered_set<char> delims_;
  std::unordered_set<char> aeiouv_;
};

const re2::RE2& LabelGroupRegex() {
  return Matcher::Instance().LabelGroupRegex();
}

bool IsPau(const std::string& s) { return Matcher::Instance().IsPau(s); }

bool IsInital(const std::string& s) { return Matcher::Instance().IsInital(s); }

bool IsFinal(const std::string& s) { return Matcher::Instance().IsFinal(s); }

bool IsEnglishPhoneme(const std::string& s) {
  return Matcher::Instance().IsEnglishPhoneme(s);
}

bool IsSharp(const std::string& s) { return Matcher::Instance().IsSharp(s); }

const std::string& Sharp(const std::string& s) {
  return Matcher::Instance().Sharp(s);
}

bool IsDelim(char c) { return Matcher::Instance().IsDelim(c); }

bool IsAEIOUV(char c) { return Matcher::Instance().IsAEIOUV(c); }

const int kPhonIndex = 2;
const int kToneIndex = 11;
const int kBoundIndex = 20;

}  // namespace

namespace engine {
namespace tacotron {

const char* SymbolTable::unk_symbol_ = "";
const char* SymbolTable::pad_symbol_ = "_";
const char* SymbolTable::end_symbol_ = "~";
const char* SymbolTable::sil_symbol_ = "SIL";
const int SymbolTable::unk_id_ = -1;
const int SymbolTable::pad_id_ = 0;
const int SymbolTable::end_id_ = 1;

SymbolTable::SymbolTable(int size, const char* symbols[]) : size_(0) {
  for (int i = 0; i < size; ++i) {
    Add(symbols[i]);
  }
  DCHECK(pad_id_ == GetId(pad_symbol_)) << "Pad symbol is wrong.";
  DCHECK(end_id_ == GetId(end_symbol_)) << "End symbol is wrong.";
}

SymbolTable::SymbolTable(const std::vector<const char*>& symbols) : size_(0) {
  for (auto&& s : symbols) {
    Add(s);
  }
  DCHECK(pad_id_ == GetId(pad_symbol_)) << "Pad symbol is wrong.";
  DCHECK(end_id_ == GetId(end_symbol_)) << "End symbol is wrong.";
}

SymbolTable::SymbolTable(const std::vector<std::string>& symbols) : size_(0) {
  for (auto&& s : symbols) {
    Add(s);
  }
  DCHECK(pad_id_ == GetId(pad_symbol_)) << "Pad symbol is wrong.";
  DCHECK(end_id_ == GetId(end_symbol_)) << "End symbol is wrong.";
}

SymbolTable::SymbolTable(const std::string& filepath) : size_(0) {
  std::setlocale(LC_ALL, "en_US.UTF-8");
  std::ifstream input(filepath);
  for (std::string s; std::getline(input, s);) {
    Add(s);
  }
  DCHECK(pad_id_ == GetId(pad_symbol_)) << "Pad symbol is wrong.";
  DCHECK(end_id_ == GetId(end_symbol_)) << "End symbol is wrong.";
  input.close();
}

void SymbolTable::Add(const std::string& s) {
  if (symbol_to_id_.find(s) != symbol_to_id_.end()) {
    return;
  }
  symbol_to_id_[s] = size_;
  id_to_symbol_.push_back(s);
  size_++;
}

int SymbolTable::GetId(const std::string& s) const {
  auto it = symbol_to_id_.find(s);
  if (it != symbol_to_id_.end()) {
    return it->second;
  }
  return unk_id_;
}

const std::string& SymbolTable::GetSymbol(int id) const {
  return id_to_symbol_.at(id);
}

std::vector<int> SymbolTable::ParseLabel(
    const std::vector<std::string>& labels,
    const std::string& speaker_name) const {
  std::vector<int> seq;
  std::string phon;
  std::string tone;
  std::string bound;

  if (speaker_name != "billy_melgan") {
    seq.emplace_back(GetId(sil_symbol_));
  }
  for (size_t i = 0; i < labels.size(); ++i) {
    auto label = labels[i];
    re2::RE2::GlobalReplace(&label, LabelGroupRegex(), "|");
    for (size_t l = 0, r = 0, index = 0; r < label.size(); ++r) {
      if (IsDelim(*(label.c_str() + r))) {
        switch (index) {
          case kPhonIndex:
            phon = std::string(label, l, r - l);
            break;
          case kToneIndex:
            tone = std::string(label, l, r - l);
            break;
          case kBoundIndex:
            bound = std::string(label, l, r - l);
            break;
        }
        ++index;
        l = r + 1;
      }
    }
    if (IsPau(phon) || sil_symbol_ == phon) {
      continue;
    }
    VLOG(2) << label << " " << phon << " " << tone << " " << bound;
    seq.emplace_back(GetId(phon));
    if (IsSharp(bound)) {
      seq.emplace_back(GetId(tone));
      if (bound != "6" /* SIL */) {
        seq.emplace_back(GetId(Sharp(bound)));
      } else {
        seq.emplace_back(GetId(sil_symbol_));
      }
    }
  }
  if (seq.size() > kMaxTextLen) {
    LOG(WARNING) << "exceed max input len for taco" << seq.size();
    seq.resize(kMaxTextLen);
  }

  if (!seq.empty()) {
    seq.pop_back();
    if (speaker_name != "billy_melgan") {
      seq.emplace_back(GetId(sil_symbol_));
    }
  }

  seq.emplace_back(end_id_);
  if (VLOG_IS_ON(2)) {
    std::stringstream ss;
    ss << "seq(length " << seq.size() << "): ";
    for (auto&& v : seq) {
      ss << "[" << GetSymbol(v) << "] ";
    }
    DLOG(INFO) << ss.str();
  }
  return seq;
}

}  // namespace tacotron
}  // namespace engine
