// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: sxwang@mobvoi.com (Sixue Wang)

#ifndef TTS_SYNTHESIZER_ENGINE_ENGINE_FACTORY_H_
#define TTS_SYNTHESIZER_ENGINE_ENGINE_FACTORY_H_

#include "mobvoi/base/macros.h"

#include "tts/synthesizer/engine/engine.h"
#include "tts/synthesizer/proto/tts.pb.h"
#include "tts/util/tts_util/util.h"

namespace engine {

static const char kEngineTypeHts[] = "hts";
static const char kEngineTypeSpss[] = "spss";
static const char kEngineTypeTf[] = "tf";
static const char kEngineTypeTacotronOne[] = "tacotron_one";

class EngineFactory {
 public:
  static EngineFactory& Instance();
  Engine* Create(const tts::SpeakerInfo& speaker_info);

 private:
  EngineFactory() = default;
  DISALLOW_COPY_AND_ASSIGN(EngineFactory);
};

}  // namespace engine

#endif  // TTS_SYNTHESIZER_ENGINE_ENGINE_FACTORY_H_
