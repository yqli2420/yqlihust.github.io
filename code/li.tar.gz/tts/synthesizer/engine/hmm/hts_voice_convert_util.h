// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: fllin@mobvoi.com (FenglvLin)

#ifndef TTS_SYNTHESIZER_ENGINE_HMM_HTS_VOICE_CONVERT_UTIL_H_
#define TTS_SYNTHESIZER_ENGINE_HMM_HTS_VOICE_CONVERT_UTIL_H_

#include <stdio.h>
#include <map>
#include <string>
#include <vector>

#include "tts/synthesizer/engine/hmm/hts_model_util.h"
#include "tts/synthesizer/engine/hmm/hts_node.h"
#include "tts/synthesizer/engine/hmm/hts_question.h"
#include "tts/synthesizer/engine/hmm/hts_tree.h"
#include "tts/synthesizer/engine/hmm/hts_util.h"
#include "tts/synthesizer/engine/hmm/hts_window.h"
#include "tts/synthesizer/engine/hmm/proto/hts_model.pb.h"
#include "tts/synthesizer/engine/hmm/types.h"
#include "mobvoi/base/compat.h"

namespace hts {
// Load model set
// TODO(fllin) : refactor later.
static bool HtsVoiceConvert(const vector<string>& files, bool use_fixed_point,
                            hts::HtsModel* proto_model) {
  if (proto_model) {
    proto_model->set_num_voices(files.size());
  }
  //  options for each stream
  vector<string> option;
  //  [voice_index]
  vector<HTS_Model> duration;  //  duration PDFs and trees

  vector<HtsWindow> window;  //  window coefficients for delta
  //  [voice_index][stream_index]
  vector<vector<HTS_Model>> stream;  //  parameter PDFs and trees
  vector<vector<HTS_Model>> gv;      //  GV PDFs and trees
  HTS_Question gv_switch;
  string hts_voice_version;    //  version of HTS voice format
  string stream_type;          //  stream type
  string fullcontext_format;   //  fullcontext label format
  string fullcontext_version;  //  version of fullcontext label
  uint16 sampling_frequency;   //  sampling frequency
  uint16 frame_period;         //  frame period
  uint16 num_voices;           //  # of HTS voices
  uint16 num_streams;          //  # of streams
  uint32 num_states;           //  # of HMM states
  size_t k = 0;
  size_t i, j, s, e;
  bool error = false;
  HTS_File* fp;
  char buff1[kMaxBuffLen];
  char buff2[kMaxBuffLen];
  size_t matched_size;

  char** stream_type_list = NULL;

  size_t* vector_length = NULL;
  bool* is_msd = NULL;
  size_t* num_windows = NULL;
  bool* use_gv = NULL;

  char* gv_off_context = NULL;

  // temporary values
  char* temp_hts_voice_version;
  size_t temp_sampling_frequency;
  size_t temp_frame_period;
  size_t temp_num_states;
  size_t temp_num_streams;
  char* temp_stream_type;
  char* temp_fullcontext_format;
  char* temp_fullcontext_version;

  char* temp_gv_off_context;

  size_t* temp_vector_length;
  bool* temp_is_msd;
  size_t* temp_num_windows;
  bool* temp_use_gv;
  char** temp_option;

  char* temp_duration_pdf;
  char* temp_duration_tree;
  char*** temp_stream_win;
  char** temp_stream_pdf;
  char** temp_stream_tree;
  char** temp_gv_pdf;
  char** temp_gv_tree;

  int64 start_of_data;
  HTS_File* pdf_fp = NULL;
  HTS_File* tree_fp = NULL;
  HTS_File* gv_off_context_fp = NULL;

  if (files.empty()) {
    return false;
  }

  num_voices = files.size();

  for (i = 0; i < files.size() && error == false; i++) {
    // open file
    fp = HTS_File::Open(files[i].c_str(), "rb");
    if (fp == NULL) {
      error = true;
      break;
    }

    // reset GLOBAL options
    temp_hts_voice_version = NULL;
    temp_sampling_frequency = 0;
    temp_frame_period = 0;
    temp_num_states = 0;
    temp_num_streams = 0;
    temp_stream_type = NULL;
    temp_fullcontext_format = NULL;
    temp_fullcontext_version = NULL;
    temp_gv_off_context = NULL;
    if (fp->GetTokenFromFile(buff1, '\n') != true) {
      error = true;
      break;
    }

    // load GLOBAL options
    if (HtsModelUtil::HTS_strequal(buff1, "[GLOBAL]") != true) {
      error = true;
      break;
    }

    while (1) {
      if (fp->GetTokenFromFile(buff1, '\n') != true) {
        error = true;
        break;
      }

      if (HtsModelUtil::HtsModelUtil::HTS_strequal(buff1, "[STREAM]")) {
        break;
      } else if (HtsModelUtil::HTS_match_head_string(
                     buff1, "HTS_VOICE_VERSION:", &matched_size)) {
        if (temp_hts_voice_version != NULL) free(temp_hts_voice_version);
        temp_hts_voice_version = HtsStrdup(&buff1[matched_size]);
      } else if (HtsModelUtil::HTS_match_head_string(
                     buff1, "SAMPLING_FREQUENCY:", &matched_size)) {
        temp_sampling_frequency = (size_t)atoi(&buff1[matched_size]);
      } else if (HtsModelUtil::HTS_match_head_string(buff1, "FRAME_PERIOD:",
                                                     &matched_size)) {
        temp_frame_period = (size_t)atoi(&buff1[matched_size]);
      } else if (HtsModelUtil::HTS_match_head_string(buff1, "NUM_STATES:",
                                                     &matched_size)) {
        temp_num_states = (size_t)atoi(&buff1[matched_size]);
      } else if (HtsModelUtil::HTS_match_head_string(buff1, "NUM_STREAMS:",
                                                     &matched_size)) {
        temp_num_streams = (size_t)atoi(&buff1[matched_size]);
      } else if (HtsModelUtil::HTS_match_head_string(buff1, "STREAM_TYPE:",
                                                     &matched_size)) {
        if (temp_stream_type != NULL) free(temp_stream_type);
        temp_stream_type = HtsStrdup(&buff1[matched_size]);
      } else if (HtsModelUtil::HTS_match_head_string(
                     buff1, "FULLCONTEXT_FORMAT:", &matched_size)) {
        if (temp_fullcontext_format != NULL) free(temp_fullcontext_format);
        temp_fullcontext_format = HtsStrdup(&buff1[matched_size]);
      } else if (HtsModelUtil::HTS_match_head_string(
                     buff1, "FULLCONTEXT_VERSION:", &matched_size)) {
        if (temp_fullcontext_version != NULL) free(temp_fullcontext_version);
        temp_fullcontext_version = HtsStrdup(&buff1[matched_size]);
      } else if (HtsModelUtil::HTS_match_head_string(buff1, "GV_OFF_CONTEXT:",
                                                     &matched_size)) {
        if (temp_gv_off_context != NULL) free(temp_gv_off_context);
        temp_gv_off_context = HtsStrdup(&buff1[matched_size]);
      } else if (HtsModelUtil::HTS_match_head_string(buff1, "COMMENT:",
                                                     &matched_size)) {
      } else {
        HtsError(0, "ModelSet::load: Unknown option %s.\n", buff1);
      }
    }

    // check GLOBAL options
    if (i == 0) {
      hts_voice_version.assign(temp_hts_voice_version);
      sampling_frequency = temp_sampling_frequency;
      frame_period = temp_frame_period;
      num_states = temp_num_states;
      num_streams = temp_num_streams;
      stream_type.assign(temp_stream_type);
      fullcontext_format.assign(temp_fullcontext_format);
      fullcontext_version.assign(temp_fullcontext_version);

      if (proto_model) {
        proto_model->set_hts_voice_version(hts_voice_version);
        proto_model->set_sampling_frequency(sampling_frequency);
        proto_model->set_frame_period(frame_period);
        proto_model->set_num_states(num_states);
        proto_model->set_num_streams(num_streams);
        // proto_model->(stream_type);
        proto_model->set_fullcontext_format(fullcontext_format);
        proto_model->set_fullcontext_version(fullcontext_version);
      }
      gv_off_context = temp_gv_off_context;
    } else {
      if (!HtsModelUtil::HTS_strequal(hts_voice_version.c_str(),
                                      temp_hts_voice_version))
        error = true;
      if (sampling_frequency != temp_sampling_frequency) error = true;
      if (frame_period != temp_frame_period) error = true;
      if (num_states != temp_num_states) error = true;
      if (num_streams != temp_num_streams) error = true;
      if (HtsModelUtil::HTS_strequal(stream_type.c_str(), temp_stream_type) !=
          true)
        error = true;
      if (!HtsModelUtil::HTS_strequal(fullcontext_format.c_str(),
                                      temp_fullcontext_format))
        error = true;
      if (!HtsModelUtil::HTS_strequal(fullcontext_version.c_str(),
                                      temp_fullcontext_version))
        error = true;
      if (HtsModelUtil::HTS_strequal(gv_off_context, temp_gv_off_context) !=
          true)
        error = true;
      if (temp_hts_voice_version != NULL) free(temp_hts_voice_version);
      if (temp_stream_type != NULL) free(temp_stream_type);
      if (temp_fullcontext_format != NULL) free(temp_fullcontext_format);
      if (temp_fullcontext_version != NULL) free(temp_fullcontext_version);
      if (temp_gv_off_context != NULL) free(temp_gv_off_context);
    }

    // find stream names
    if (i == 0) {
      stream_type_list =
          reinterpret_cast<char**>(HtsCalloc(num_streams, sizeof(char*)));
      for (j = 0, matched_size = 0; j < num_streams; j++) {
        hts::HtsStream* hts_stream = NULL;
        if (proto_model) {
          hts_stream = proto_model->add_streams();
        }
        if (GetTokenFromStringWithSeperator(stream_type.c_str(), &matched_size,
                                            buff2, ',')) {
          stream_type_list[j] = HtsStrdup(buff2);
          if (proto_model) {
            hts_stream->set_stream_type(buff2);
          }
        } else {
          stream_type_list[j] = NULL;
          error = true;
        }
      }
    }

    if (error != false) {
      fp->Close();
      break;
    }

    // reset STREAM options
    temp_vector_length =
        reinterpret_cast<size_t*>(HtsCalloc(num_streams, sizeof(size_t)));
    for (j = 0; j < num_streams; j++) temp_vector_length[j] = 0;
    temp_is_msd = reinterpret_cast<bool*>(HtsCalloc(num_streams, sizeof(bool)));
    for (j = 0; j < num_streams; j++) temp_is_msd[j] = false;
    temp_num_windows =
        reinterpret_cast<size_t*>(HtsCalloc(num_streams, sizeof(size_t)));
    for (j = 0; j < num_streams; j++) temp_num_windows[j] = 0;
    temp_use_gv = reinterpret_cast<bool*>(HtsCalloc(num_streams, sizeof(bool)));
    for (j = 0; j < num_streams; j++) temp_use_gv[j] = false;
    temp_option =
        reinterpret_cast<char**>(HtsCalloc(num_streams, sizeof(char*)));
    for (j = 0; j < num_streams; j++) temp_option[j] = NULL;

    // load STREAM options
    while (1) {
      if (fp->GetTokenFromFile(buff1, '\n') != true) {
        error = true;
        break;
      }
      if (strcmp(buff1, "[POSITION]") == 0) {
        break;
      } else if (HtsModelUtil::HTS_match_head_string(buff1, "VECTOR_LENGTH[",
                                                     &matched_size)) {
        if (GetTokenFromStringWithSeperator(buff1, &matched_size, buff2, ']')) {
          if (buff1[matched_size++] == ':') {
            for (j = 0; j < num_streams; j++) {
              if (strcmp(stream_type_list[j], buff2) == 0) {
                temp_vector_length[j] = (size_t)atoi(&buff1[matched_size]);
                break;
              }
            }
          }
        }
      } else if (HtsModelUtil::HTS_match_head_string(buff1, "IS_MSD[",
                                                     &matched_size)) {
        if (GetTokenFromStringWithSeperator(buff1, &matched_size, buff2, ']')) {
          if (buff1[matched_size++] == ':') {
            for (j = 0; j < num_streams; j++)
              if (strcmp(stream_type_list[j], buff2) == 0) {
                temp_is_msd[j] = (buff1[matched_size] == '1') ? true : false;
                break;
              }
          }
        }
      } else if (HtsModelUtil::HTS_match_head_string(buff1, "NUM_WINDOWS[",
                                                     &matched_size)) {
        if (GetTokenFromStringWithSeperator(buff1, &matched_size, buff2, ']')) {
          if (buff1[matched_size++] == ':') {
            for (j = 0; j < num_streams; j++)
              if (strcmp(stream_type_list[j], buff2) == 0) {
                temp_num_windows[j] = (size_t)atoi(&buff1[matched_size]);
                break;
              }
          }
        }
      } else if (HtsModelUtil::HTS_match_head_string(buff1, "USE_GV[",
                                                     &matched_size)) {
        if (GetTokenFromStringWithSeperator(buff1, &matched_size, buff2, ']')) {
          if (buff1[matched_size++] == ':') {
            for (j = 0; j < num_streams; j++)
              if (strcmp(stream_type_list[j], buff2) == 0) {
                temp_use_gv[j] = (buff1[matched_size] == '1') ? true : false;
                break;
              }
          }
        }
      } else if (HtsModelUtil::HTS_match_head_string(buff1, "OPTION[",
                                                     &matched_size)) {
        if (GetTokenFromStringWithSeperator(buff1, &matched_size, buff2, ']')) {
          if (buff1[matched_size++] == ':') {
            for (j = 0; j < num_streams; j++) {
              if (strcmp(stream_type_list[j], buff2) == 0) {
                if (temp_option[j] != NULL) free(temp_option[j]);
                temp_option[j] = HtsStrdup(&buff1[matched_size]);
                break;
              }
            }
          }
        }
      } else {
        HtsError(0, "ModelSet::load: Unknown option %s.\n", buff1);
      }
    }

    // check STREAM options
    if (i == 0) {
      vector_length = temp_vector_length;
      is_msd = temp_is_msd;
      num_windows = temp_num_windows;
      use_gv = temp_use_gv;
      for (j = 0; j < num_streams; j++) {
        option.push_back(temp_option[j]);
      }

      if (proto_model) {
        for (j = 0; j < num_streams; j++) {
          proto_model->mutable_streams(j)->set_vector_length(vector_length[j]);
          proto_model->mutable_streams(j)->set_is_msd(is_msd[j]);
          proto_model->mutable_streams(j)->set_window_num(num_windows[j]);
          proto_model->mutable_streams(j)->set_use_gv(use_gv[j]);
          proto_model->mutable_streams(j)->set_option(option[j]);
        }
      }
    } else {
      for (j = 0; j < num_streams; j++)
        if (vector_length[j] != temp_vector_length[j]) error = true;
      for (j = 0; j < num_streams; j++)
        if (is_msd[j] != is_msd[j]) error = true;
      for (j = 0; j < num_streams; j++)
        if (num_windows[j] != temp_num_windows[j]) error = true;
      for (j = 0; j < num_streams; j++)
        if (use_gv[j] != temp_use_gv[j]) error = true;
      for (j = 0; j < num_streams; j++)
        if (HtsModelUtil::HTS_strequal(option[j].c_str(), temp_option[j]) !=
            true)
          error = true;
      free(temp_vector_length);
      free(temp_is_msd);
      free(temp_num_windows);
      free(temp_use_gv);
      for (j = 0; j < num_streams; j++)
        if (temp_option[j] != NULL) free(temp_option[j]);
      free(temp_option);
    }
    if (error != false) {
      fp->Close();
      break;
    }

    // reset POSITION
    temp_duration_pdf = NULL;
    temp_duration_tree = NULL;
    temp_stream_win =
        reinterpret_cast<char***>(HtsCalloc(num_streams, sizeof(char**)));
    for (j = 0; j < num_streams; j++) {
      temp_stream_win[j] =
          reinterpret_cast<char**>(HtsCalloc(num_windows[j], sizeof(char*)));
      for (k = 0; k < num_windows[j]; k++) temp_stream_win[j][k] = NULL;
    }
    temp_stream_pdf =
        reinterpret_cast<char**>(HtsCalloc(num_streams, sizeof(char*)));
    for (j = 0; j < num_streams; j++) temp_stream_pdf[j] = NULL;
    temp_stream_tree =
        reinterpret_cast<char**>(HtsCalloc(num_streams, sizeof(char*)));
    for (j = 0; j < num_streams; j++) temp_stream_tree[j] = NULL;
    temp_gv_pdf =
        reinterpret_cast<char**>(HtsCalloc(num_streams, sizeof(char*)));
    for (j = 0; j < num_streams; j++) temp_gv_pdf[j] = NULL;
    temp_gv_tree =
        reinterpret_cast<char**>(HtsCalloc(num_streams, sizeof(char*)));
    for (j = 0; j < num_streams; j++) temp_gv_tree[j] = NULL;

    // load POSITION
    while (1) {
      if (fp->GetTokenFromFile(buff1, '\n') != true) {
        error = true;
        break;
      }

      if (strcmp(buff1, "[DATA]") == 0) {
        break;
      } else if (HtsModelUtil::HTS_match_head_string(buff1, "DURATION_PDF:",
                                                     &matched_size)) {
        if (temp_duration_pdf != NULL) free(temp_duration_pdf);
        temp_duration_pdf = HtsStrdup(&buff1[matched_size]);
      } else if (HtsModelUtil::HTS_match_head_string(buff1, "DURATION_TREE:",
                                                     &matched_size)) {
        if (temp_duration_tree != NULL) free(temp_duration_tree);
        temp_duration_tree = HtsStrdup(&buff1[matched_size]);
      } else if (HtsModelUtil::HTS_match_head_string(buff1, "STREAM_WIN[",
                                                     &matched_size)) {
        if (GetTokenFromStringWithSeperator(buff1, &matched_size, buff2, ']')) {
          if (buff1[matched_size++] == ':') {
            for (j = 0; j < num_streams; j++) {
              if (strcmp(stream_type_list[j], buff2) == 0) {
                for (k = 0; k < num_windows[j]; k++) {
                  if (GetTokenFromStringWithSeperator(buff1, &matched_size,
                                                      buff2, ','))
                    temp_stream_win[j][k] = HtsStrdup(buff2);
                  else
                    error = true;
                }
                break;
              }
            }
          }
        }
      } else if (HtsModelUtil::HTS_match_head_string(buff1, "STREAM_PDF[",
                                                     &matched_size)) {
        if (GetTokenFromStringWithSeperator(buff1, &matched_size, buff2, ']')) {
          if (buff1[matched_size++] == ':') {
            for (j = 0; j < num_streams; j++) {
              if (strcmp(stream_type_list[j], buff2) == 0) {
                if (temp_stream_pdf[j] != NULL) free(temp_stream_pdf[j]);
                temp_stream_pdf[j] = HtsStrdup(&buff1[matched_size]);
                break;
              }
            }
          }
        }
      } else if (HtsModelUtil::HTS_match_head_string(buff1, "STREAM_TREE[",
                                                     &matched_size)) {
        if (GetTokenFromStringWithSeperator(buff1, &matched_size, buff2, ']')) {
          if (buff1[matched_size++] == ':') {
            for (j = 0; j < num_streams; j++) {
              if (strcmp(stream_type_list[j], buff2) == 0) {
                if (temp_stream_tree[j] != NULL) free(temp_stream_tree[j]);
                temp_stream_tree[j] = HtsStrdup(&buff1[matched_size]);
                break;
              }
            }
          }
        }
      } else if (HtsModelUtil::HTS_match_head_string(buff1, "GV_PDF[",
                                                     &matched_size)) {
        if (GetTokenFromStringWithSeperator(buff1, &matched_size, buff2, ']')) {
          if (buff1[matched_size++] == ':') {
            for (j = 0; j < num_streams; j++) {
              if (strcmp(stream_type_list[j], buff2) == 0) {
                if (temp_gv_pdf[j] != NULL) free(temp_gv_pdf[j]);
                temp_gv_pdf[j] = HtsStrdup(&buff1[matched_size]);
                break;
              }
            }
          }
        }
      } else if (HtsModelUtil::HTS_match_head_string(buff1, "GV_TREE[",
                                                     &matched_size)) {
        if (GetTokenFromStringWithSeperator(buff1, &matched_size, buff2, ']')) {
          if (buff1[matched_size++] == ':') {
            for (j = 0; j < num_streams; j++) {
              if (strcmp(stream_type_list[j], buff2) == 0) {
                if (temp_gv_tree[j] != NULL) free(temp_gv_tree[j]);
                temp_gv_tree[j] = HtsStrdup(&buff1[matched_size]);
                break;
              }
            }
          }
        }
      } else {
        HtsError(0, "ModelSet::load: Unknown option %s.\n", buff1);
      }
    }

    // check POSITION
    if (temp_duration_pdf == NULL) error = true;
    for (j = 0; j < num_streams; j++) {
      for (k = 0; k < num_windows[j]; k++) {
        if (temp_stream_win[j][k] == NULL) {
          error = true;
        }
      }
    }
    for (j = 0; j < num_streams; j++) {
      if (temp_stream_pdf[j] == NULL) {
        error = true;
      }
    }

    // prepare memory
    if (i == 0) {
      for (j = 0; j < files.size(); j++) {
        duration.push_back(HTS_Model());
      }
      for (j = 0; j < num_streams; j++) {
        window.push_back(HtsWindow());
      }

      stream.resize(files.size());
      for (j = 0; j < files.size(); j++) {
        stream[j].resize(num_streams);
      }
      gv.resize(files.size());
      for (j = 0; j < files.size(); j++) {
        gv[j].resize(num_streams);
      }
    }
    start_of_data = fp->TellOffset();

    // Load duration
    pdf_fp = NULL;
    tree_fp = NULL;
    matched_size = 0;
    if (GetTokenFromStringWithSeperator(temp_duration_pdf, &matched_size, buff2,
                                        '-')) {
      s = (size_t)atoi(buff2);
      e = (size_t)atoi(&temp_duration_pdf[matched_size]);
      fp->Seek(static_cast<int64>(s), SEEK_CUR);
      pdf_fp = HTS_File::Open(fp, e - s + 1);
      fp->Seek(start_of_data, SEEK_SET);
    }
    matched_size = 0;
    if (GetTokenFromStringWithSeperator(temp_duration_tree, &matched_size,
                                        buff2, '-')) {
      s = (size_t)atoi(buff2);
      e = (size_t)atoi(&temp_duration_tree[matched_size]);
      fp->Seek(static_cast<int64>(s), SEEK_CUR);
      tree_fp = HTS_File::Open(fp, e - s + 1);
      fp->Seek(start_of_data, SEEK_SET);
    }
    if (HtsModelUtil::HTS_Model_load(&duration[i], pdf_fp, tree_fp, num_states,
                                     1, false, false) != true) {
      error = true;
    }

    if (proto_model) {
      string pdf_content;
      if (!use_fixed_point) {
        pdf_fp->WriteFileToString(&pdf_content);
      } else {
        HtsModelUtil::ConvertToFixedPointModel(duration[i], false,
                                               &pdf_content);
      }
      proto_model->set_duration_pdf(pdf_content);
      string pdf_tree_content;
      tree_fp->WriteFileToString(&pdf_tree_content);
      LOG(INFO) << "duration pdf file size:"
                << pdf_content.size() / 1024.0 / 1024.0 << "MB"
                << ", tree file size:"
                << pdf_tree_content.size() / 1024.0 / 1024.0 << "MB";
      proto_model->set_duration_tree(pdf_tree_content);
    }
    pdf_fp->Close();
    tree_fp->Close();

    // load windows
    for (j = 0; j < num_streams; j++) {
      vector<HTS_File*> win_fp(num_windows[j]);
      for (k = 0; k < num_windows[j]; k++) {
        matched_size = 0;
        if (GetTokenFromStringWithSeperator(temp_stream_win[j][k],
                                            &matched_size, buff2, '-')) {
          s = (size_t)atoi(buff2);
          e = (size_t)atoi(&temp_stream_win[j][k][matched_size]);
          fp->Seek(static_cast<int64>(s), SEEK_CUR);
          win_fp[k] = HTS_File::Open(fp, e - s + 1);
          fp->Seek(start_of_data, SEEK_SET);
        }
      }
      if (window[j].Load(win_fp) != true) {
        error = true;
      }
      for (k = 0; k < num_windows[j]; k++) {
        if (proto_model) {
          string content;
          win_fp[k]->WriteFileToString(&content);
          proto_model->mutable_streams(j)->add_win_content(content);
        }
        win_fp[k]->Close();
      }
    }

    // load streams
    for (j = 0; j < num_streams; j++) {
      pdf_fp = NULL;
      tree_fp = NULL;
      matched_size = 0;
      if (GetTokenFromStringWithSeperator(temp_stream_pdf[j], &matched_size,
                                          buff2, '-')) {
        s = (size_t)atoi(buff2);
        e = (size_t)atoi(&temp_stream_pdf[j][matched_size]);
        fp->Seek(static_cast<int64>(s), SEEK_CUR);
        pdf_fp = HTS_File::Open(fp, e - s + 1);
        fp->Seek(start_of_data, SEEK_SET);
      }
      matched_size = 0;
      if (GetTokenFromStringWithSeperator(temp_stream_tree[j], &matched_size,
                                          buff2, '-')) {
        s = (size_t)atoi(buff2);
        e = (size_t)atoi(&temp_stream_tree[j][matched_size]);
        fp->Seek(static_cast<int64>(s), SEEK_CUR);
        tree_fp = HTS_File::Open(fp, e - s + 1);
        fp->Seek(start_of_data, SEEK_SET);
      }
      if (HtsModelUtil::HTS_Model_load(&stream[i][j], pdf_fp, tree_fp,
                                       vector_length[j], num_windows[j],
                                       is_msd[j], false) != true) {
        error = true;
      }
      if (proto_model) {
        string pdf_content;
        if (!use_fixed_point) {
          pdf_fp->WriteFileToString(&pdf_content);
        } else {
          HtsModelUtil::ConvertToFixedPointModel(stream[i][j], is_msd[j],
                                                 &pdf_content);
        }
        proto_model->mutable_streams(j)->set_pdf_content(pdf_content);

        string tree_content;
        tree_fp->WriteFileToString(&tree_content);
        proto_model->mutable_streams(j)->set_tree_content(tree_content);
        LOG(INFO) << "stream id:" << j
                  << ", pdf file size:" << pdf_content.size() / 1024.0 / 1024.0
                  << "MB"
                  << ", tree file size:"
                  << tree_content.size() / 1024.0 / 1024.0 << "MB";
      }
      pdf_fp->Close();
      tree_fp->Close();
    }

    // load GVs
    for (j = 0; j < num_streams; j++) {
      pdf_fp = NULL;
      tree_fp = NULL;
      matched_size = 0;
      if (GetTokenFromStringWithSeperator(temp_gv_pdf[j], &matched_size, buff2,
                                          '-')) {
        s = (size_t)atoi(buff2);
        e = (size_t)atoi(&temp_gv_pdf[j][matched_size]);
        fp->Seek(static_cast<int64>(s), SEEK_CUR);
        pdf_fp = HTS_File::Open(fp, e - s + 1);
        fp->Seek(start_of_data, SEEK_SET);
      }
      matched_size = 0;
      if (GetTokenFromStringWithSeperator(temp_gv_tree[j], &matched_size, buff2,
                                          '-')) {
        s = (size_t)atoi(buff2);
        e = (size_t)atoi(&temp_gv_tree[j][matched_size]);
        fp->Seek(static_cast<int64>(s), SEEK_CUR);
        tree_fp = HTS_File::Open(fp, e - s + 1);
        fp->Seek(start_of_data, SEEK_SET);
      }
      if (use_gv[j]) {
        if (HtsModelUtil::HTS_Model_load(&gv[i][j], pdf_fp, tree_fp,
                                         vector_length[j], 1, false,
                                         false) != true)
          error = true;
      }

      if (proto_model) {
        if (pdf_fp) {
          string pdf_content;
          pdf_fp->WriteFileToString(&pdf_content);
          proto_model->mutable_streams(j)->set_gv_pdf_content(pdf_content);
        }
        if (tree_fp) {
          string tree_content;
          tree_fp->WriteFileToString(&tree_content);
          proto_model->mutable_streams(j)->set_gv_tree_content(tree_content);
        }
      }
      if (pdf_fp) {
        pdf_fp->Close();
      }
      if (tree_fp) {
        tree_fp->Close();
      }
    }

    // free
    if (temp_duration_pdf != NULL) free(temp_duration_pdf);
    if (temp_duration_tree != NULL) free(temp_duration_tree);
    for (j = 0; j < num_streams; j++) {
      for (k = 0; k < num_windows[j]; k++)
        if (temp_stream_win[j][k] != NULL) free(temp_stream_win[j][k]);
      free(temp_stream_win[j]);
    }
    free(temp_stream_win);
    for (j = 0; j < num_streams; j++)
      if (temp_stream_pdf[j] != NULL) free(temp_stream_pdf[j]);
    free(temp_stream_pdf);
    for (j = 0; j < num_streams; j++)
      if (temp_stream_tree[j] != NULL) free(temp_stream_tree[j]);
    free(temp_stream_tree);
    for (j = 0; j < num_streams; j++)
      if (temp_gv_pdf[j] != NULL) free(temp_gv_pdf[j]);
    free(temp_gv_pdf);
    for (j = 0; j < num_streams; j++)
      if (temp_gv_tree[j] != NULL) free(temp_gv_tree[j]);
    free(temp_gv_tree);
    fp->Close();
    if (error != false) break;
  }

  if (gv_off_context != NULL) {
    snprintf(buff1, sizeof(buff1), "GV-Off { %s }", gv_off_context);
    gv_off_context_fp = HTS_File::OpenFromData(reinterpret_cast<void*>(buff1),
                                               strlen(buff1) + 1);
    HTS_Question_initialize(&gv_switch);
    HTS_Question_load(&gv_switch, gv_off_context_fp);
    if (proto_model) {
      proto_model->mutable_gv_off_context()->set_name(gv_switch.name);
      for (size_t i = k; k < gv_switch.patterns.size(); ++k) {
        proto_model->mutable_gv_off_context()->add_patterns(
            gv_switch.patterns[i]);
      }
    }
    gv_off_context_fp->Close();
  }

  if (stream_type_list != NULL) {
    for (i = 0; i < num_streams; i++)
      if (stream_type_list[i] != NULL) free(stream_type_list[i]);
    free(stream_type_list);
  }

  if (vector_length != NULL) free(vector_length);
  if (is_msd != NULL) free(is_msd);
  if (num_windows != NULL) free(num_windows);
  if (use_gv != NULL) free(use_gv);

  return !error;
}  // NOLINT
}  // namespace hts
#endif  // TTS_SYNTHESIZER_ENGINE_HMM_HTS_VOICE_CONVERT_UTIL_H_
