// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_SYNTHESIZER_ENGINE_HMM_HTS_SSTREAM_H_
#define TTS_SYNTHESIZER_ENGINE_HMM_HTS_SSTREAM_H_

#include <stdio.h>

#include "mobvoi/base/compat.h"
#include "tts/util/tts_util/util.h"

namespace hts {
class ModelSet;
class Label;

//  individual state stream
struct HTS_SStream {
  uint16 vector_length;  //  vector length (static features only)
  uint16 win_size;       //  # of windows (static + deltas)
  uint32 win_max_width;  //  maximum width of windows

  double** mean;             //  mean vector sequence
  double** vari;             //  variance vector sequence
  double* msd;               //  MSD parameter sequence
  int* win_l_width;          //  left width of windows
  int* win_r_width;          //  right width of windows
  double** win_coefficient;  //  window cofficients
  double* gv_mean;           //  mean vector of GV
  double* gv_vari;           //  variance vector of GV
  bool* gv_switch;           //  GV flag sequence
};

//  set of state stream
class SStreamSet {
 public:
  // initialize state stream set
  void Init();

  // parse label and determine state duration
  bool Create(const ModelSet& ms, const Label& label,
              bool phoneme_alignment_flag, double speed,
              vector<double>& duration_iw,           // NOLINT
              vector<vector<double>>& parameter_iw,  // NOLINT
              vector<vector<double>>& gv_iw,         // NOLINT
              tts::LanguageType language_type);

  // get number of stream
  size_t GetStreamNumber();

  // get currennt phoneme
  const string& GetCurPhoneme(size_t index) const;

  // get vector length
  size_t GetVectorLength(size_t stream_index);

  // get MSD flag
  bool IsMsd(size_t stream_index);

  // get total number of state
  size_t GetStateNumber();

  // get total number of frame
  size_t GetTotalFrame();

  // get msd parameter
  double GetMsd(size_t stream_index, size_t state_index);

  // get dynamic window size
  size_t GetWindowSize(size_t stream_index);

  // get left width of dynamic window
  int GetWindowLeftWidth(size_t stream_index, size_t window_index);

  // get right width of dynamic window
  int GetWindowRightWidth(size_t stream_index, size_t window_index);

  // get coefficient of dynamic window
  double GetWindowCofficient(size_t stream_index, size_t window_index,
                             int coefficient_index);

  // get max width of dynamic window
  size_t GetWindowMaxWidth(size_t stream_index);

  // get GV flag
  bool UseGv(size_t stream_index);

  // get state duration
  inline size_t GetDuration(size_t state_index) {
    return duration_[state_index];
  }

  // get mean parameter
  inline double GetMean(size_t stream_index, size_t state_index,
                        size_t vector_index) {
    return sstream_[stream_index].mean[state_index][vector_index];
  }
  // set mean parameter
  void SetMean(size_t stream_index, size_t state_index, size_t vector_index,
               double f);

  // get variance parameter
  inline double GetVariance(size_t stream_index, size_t state_index,
                            size_t vector_index) {
    return sstream_[stream_index].vari[state_index][vector_index];
  }
  // set variance parameter
  void SetVariance(size_t stream_index, size_t state_index, size_t vector_index,
                   double f);

  // get GV mean parameter
  double GetGvMean(size_t stream_index, size_t vector_index);

  // get GV variance parameter
  double GetGvVariance(size_t stream_index, size_t vector_index);

  // set GV switch
  void SetGvSwitch(size_t stream_index, size_t state_index, bool i);

  // get GV switch
  bool GetGvSwitch(size_t stream_index, size_t state_index);

  // free state stream set
  void Clear();

  vector<HTS_SStream> sstream_;  //  state streams
  size_t nstream_;               //  # of streams
  size_t nstate_;                //  # of states
  vector<size_t> duration_;      //  duration sequence
  size_t total_state_;           //  total state
  size_t total_frame_;           //  total frame
  vector<string> phonemes_;      //  currennt phoneme
};
}  // namespace hts
#endif  // TTS_SYNTHESIZER_ENGINE_HMM_HTS_SSTREAM_H_
