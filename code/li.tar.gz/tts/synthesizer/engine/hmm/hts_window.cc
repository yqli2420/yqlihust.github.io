// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/synthesizer/engine/hmm/hts_window.h"

#include "tts/synthesizer/engine/hmm/hts_file.h"
#include "tts/synthesizer/engine/hmm/hts_util.h"
#include "tts/synthesizer/engine/hmm/types.h"

namespace hts {

// HTS_Window_initialize: initialize dynamic window
HtsWindow::HtsWindow() {
  size = 0;
  l_width = NULL;
  r_width = NULL;
  coefficient = NULL;
  max_width = 0;
}

// HTS_Window_clear: free dynamic window
HtsWindow::~HtsWindow() {
  size_t i;

  if (coefficient != NULL) {
    for (i = 0; i < size; i++) {
      coefficient[i] += l_width[i];
      HtsFree(coefficient[i]);
    }
    HtsFree(coefficient);
  }
  if (l_width) HtsFree(l_width);
  if (r_width) HtsFree(r_width);
}

// HTS_Window_load: load dynamic windows
bool HtsWindow::Load(const vector<HTS_File*>& fp) {
  size_t i, j;
  size_t fsize, length;
  char buff[kMaxBuffLen];
  bool result = true;

  // check
  if (fp.empty()) {
    return false;
  }

  this->size = fp.size();
  l_width = reinterpret_cast<int*>(HtsCalloc(fp.size(), sizeof(int)));
  r_width = reinterpret_cast<int*>(HtsCalloc(fp.size(), sizeof(int)));
  coefficient =
      reinterpret_cast<double**>(HtsCalloc(fp.size(), sizeof(double*)));
  // set delta coefficents
  for (i = 0; i < fp.size(); i++) {
    if (fp[i]->GetTokenFromFile(buff) == false) {
      result = false;
      fsize = 1;
    } else {
      fsize = atoi(buff);
      if (fsize == 0) {
        result = false;
        fsize = 1;
      }
    }
    // read coefficients
    coefficient[i] =
        reinterpret_cast<double*>(HtsCalloc(fsize, sizeof(double)));
    for (j = 0; j < fsize; j++) {
      if (fp[i]->GetTokenFromFile(buff) == false) {
        result = false;
        coefficient[i][j] = 0.0;
      } else {
        coefficient[i][j] = static_cast<double>(atof(buff));
      }
    }
    // set pointer
    length = fsize / 2;
    coefficient[i] += length;
    l_width[i] = -1 * static_cast<int>(length);
    r_width[i] = static_cast<int>(length);
    if (fsize % 2 == 0) r_width[i]--;
  }
  // calcurate max_width to determine size of band matrix
  max_width = 0;
  for (i = 0; i < fp.size(); i++) {
    if (max_width < (size_t)abs(l_width[i])) max_width = abs(l_width[i]);
    if (max_width < (size_t)abs(r_width[i])) max_width = abs(r_width[i]);
  }

  if (result == false) {
    return false;
  }
  return true;
}
}  // namespace hts
