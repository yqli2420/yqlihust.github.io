// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_SYNTHESIZER_ENGINE_HMM_HTS_QUESTION_H_
#define TTS_SYNTHESIZER_ENGINE_HMM_HTS_QUESTION_H_

#include <stdio.h>

#include <vector>
#include <string>

#include "mobvoi/base/compat.h"

namespace hts {

class HTS_File;

struct HTS_Question {
  string name;  // name of this question
  vector<string> patterns;
};

void HTS_Question_initialize(HTS_Question* question);
bool HTS_Question_load(HTS_Question* question, HTS_File* fp);
bool HTS_Question_match(const HTS_Question& question,
                        const char* str, size_t len);
const HTS_Question* HTS_Question_find(const vector<HTS_Question>& questions,
                                      const char* string);

}  // namespace hts
#endif  // TTS_SYNTHESIZER_ENGINE_HMM_HTS_QUESTION_H_
