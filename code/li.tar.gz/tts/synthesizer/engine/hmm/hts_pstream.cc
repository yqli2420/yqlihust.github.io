// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: ranzhang@mobvoi.com (dylan)

#include "tts/synthesizer/engine/hmm/hts_pstream.h"

#include <math.h>

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"
#include "tts/synthesizer/engine/hmm/hts_util.h"
#include "tts/synthesizer/engine/hmm/types.h"

DEFINE_double(uv_threshold, 0.5, "");

namespace hts {

// check variance in finv()
#define INFTY ((double)1.0e+38)
#define INFTY2 ((double)1.0e+19)
#define INVINF ((double)1.0e-38)
#define INVINF2 ((double)1.0e-19)

// GV
#define STEPINIT 0.1
#define STEPDEC 0.5
#define STEPINC 1.2
#define W1 1.0
#define W2 1.0
#define GV_MAX_ITERATION 5

// calculate 1.0/variance function
double HTS_finv(const double x) {
  if (x >= INFTY2) return 0.0;
  if (x <= -INFTY2) return 0.0;
  if (x <= INVINF2 && x >= 0) return INFTY;
  if (x >= -INVINF2 && x < 0) return -INFTY;

  return (1.0 / x);
}

// calcurate W'U^{-1}W and W'U^{-1}M
inline static void HTS_PStream_calc_wuw_and_wum(HTS_PStream *pst, size_t m) {
  for (size_t t = 0; t < pst->length; t++) {
    // initialize
    pst->sm.wum[t] = 0.0;
    memset(pst->sm.wuw[t], 0, sizeof(double) * pst->width);

    // calc WUW & WUM
    for (size_t i = 0; i < pst->win_size; i++) {
      for (int shift = pst->win_l_width[i]; shift <= pst->win_r_width[i];
           ++shift) {
        // branch predict : about 593300 vs 91303
        if ((static_cast<int>(t) + shift >= 0) &&
            (static_cast<int>(t) + shift < static_cast<int>(pst->length)) &&
            pst->win_coefficient[i][-shift] != 0.0) {
          double wu = pst->win_coefficient[i][-shift] *
                      pst->sm.ivar[t + shift][i * pst->vector_length + m];
          pst->sm.wum[t] +=
              wu * pst->sm.mean[t + shift][i * pst->vector_length + m];
          for (size_t j = 0; (j < pst->width) && (t + j < pst->length); ++j) {
            // Branch predict : about 738159 vs 434616
            // TODO(spye): Try to improve branch prediction.
            if ((static_cast<int>(j) <= pst->win_r_width[i] + shift) &&
                pst->win_coefficient[i][j - shift] != 0.0) {
              pst->sm.wuw[t][j] += wu * pst->win_coefficient[i][j - shift];
            }
          }
        }
      }
    }
  }
}

// Factorize W'*U^{-1}*W to L*D*L' (L: lower triangular, D: diagonal)
static void HTS_PStream_ldl_factorization(HTS_PStream *pst) {
  size_t t, i, j;

  for (t = 0; t < pst->length; t++) {
    for (i = 1; (i < pst->width) && (t >= i); i++) {
      pst->sm.wuw[t][0] -=
          pst->sm.wuw[t - i][i] * pst->sm.wuw[t - i][i] * pst->sm.wuw[t - i][0];
    }

    for (i = 1; i < pst->width; i++) {
      for (j = 1; (i + j < pst->width) && (t >= j); j++) {
        pst->sm.wuw[t][i] -= pst->sm.wuw[t - j][j] * pst->sm.wuw[t - j][i + j] *
                             pst->sm.wuw[t - j][0];
      }
      pst->sm.wuw[t][i] /= pst->sm.wuw[t][0];
    }
  }
}

// forward subtitution for mlpg
static void HTS_PStream_forward_substitution(HTS_PStream *pst) {
  size_t t, i;

  for (t = 0; t < pst->length; t++) {
    pst->sm.g[t] = pst->sm.wum[t];
    for (i = 1; (i < pst->width) && (t >= i); i++) {
      pst->sm.g[t] -= pst->sm.wuw[t - i][i] * pst->sm.g[t - i];
    }
  }
}

// backward subtitution for mlpg
static void HTS_PStream_backward_substitution(HTS_PStream *pst, size_t m) {
  size_t rev, t, i;

  for (rev = 0; rev < pst->length; rev++) {
    t = pst->length - 1 - rev;
    pst->par[t][m] = pst->sm.g[t] / pst->sm.wuw[t][0];
    for (i = 1; (i < pst->width) && (t + i < pst->length); i++) {
      pst->par[t][m] -= pst->sm.wuw[t][i] * pst->par[t + i][m];
    }
  }
}

// subfunction for mlpg using GV
static void HTS_PStream_calc_gv(HTS_PStream *pst, size_t m, double *mean,
                                double *vari) {
  size_t t;

  *mean = 0.0;
  for (t = 0; t < pst->length; t++) {
    if (pst->gv_switch[t]) {
      *mean += pst->par[t][m];
    }
  }
  *mean /= pst->gv_length;
  *vari = 0.0;
  for (t = 0; t < pst->length; t++) {
    if (pst->gv_switch[t]) {
      *vari += (pst->par[t][m] - *mean) * (pst->par[t][m] - *mean);
    }
  }
  *vari /= pst->gv_length;
}

// subfunction for mlpg using GV
static void HTS_PStream_conv_gv(HTS_PStream *pst, size_t m) {
  double mean;
  double vari;
  HTS_PStream_calc_gv(pst, m, &mean, &vari);

  double ratio = sqrt(pst->gv_mean[m] / vari);
  for (size_t t = 0; t < pst->length; t++) {
    if (pst->gv_switch[t]) {
      pst->par[t][m] = ratio * (pst->par[t][m] - mean) + mean;
    }
  }
}

// subfunction for mlpg using GV
static double HTS_PStream_calc_derivative(HTS_PStream *pst, size_t m) {
  size_t t, i;
  double mean;
  double vari;
  double dv;
  double h;
  double gvobj;
  double hmmobj;
  double w = 1.0 / (pst->win_size * pst->length);

  HTS_PStream_calc_gv(pst, m, &mean, &vari);
  gvobj = -0.5 * W2 * vari * pst->gv_vari[m] * (vari - 2.0 * pst->gv_mean[m]);
  dv = -2.0 * pst->gv_vari[m] * (vari - pst->gv_mean[m]) / pst->length;

  for (t = 0; t < pst->length; t++) {
    pst->sm.g[t] = pst->sm.wuw[t][0] * pst->par[t][m];
    for (i = 1; i < pst->width; i++) {
      if (t + i < pst->length) {
        pst->sm.g[t] += pst->sm.wuw[t][i] * pst->par[t + i][m];
      }
      if (t + 1 > i) {
        pst->sm.g[t] += pst->sm.wuw[t - i][i] * pst->par[t - i][m];
      }
    }
  }

  for (t = 0, hmmobj = 0.0; t < pst->length; t++) {
    hmmobj += W1 * w * pst->par[t][m] * (pst->sm.wum[t] - 0.5 * pst->sm.g[t]);
    h = -W1 * w * pst->sm.wuw[t][1 - 1] -
        W2 * 2.0 / (pst->length * pst->length) *
            ((pst->length - 1) * pst->gv_vari[m] * (vari - pst->gv_mean[m]) +
             2.0 * pst->gv_vari[m] * (pst->par[t][m] - mean) *
                 (pst->par[t][m] - mean));
    if (pst->gv_switch[t]) {
      pst->sm.g[t] = 1.0 / h * (W1 * w * (-pst->sm.g[t] + pst->sm.wum[t]) +
                                W2 * dv * (pst->par[t][m] - mean));
    } else {
      pst->sm.g[t] = 1.0 / h * (W1 * w * (-pst->sm.g[t] + pst->sm.wum[t]));
    }
  }

  return (-(hmmobj + gvobj));
}

// function for mlpg using GV
static void HTS_PStream_gv_parmgen(HTS_PStream *pst, size_t m) {
  size_t t, i;
  double step = STEPINIT;
  double prev = 0.0;
  double obj;

  if (pst->gv_length == 0) {
    return;
  }

  HTS_PStream_conv_gv(pst, m);
  if (GV_MAX_ITERATION > 0) {
    HTS_PStream_calc_wuw_and_wum(pst, m);
    for (i = 1; i <= GV_MAX_ITERATION; i++) {
      obj = HTS_PStream_calc_derivative(pst, m);
      if (i > 1) {
        if (obj > prev) step *= STEPDEC;
        if (obj < prev) step *= STEPINC;
      }
      for (t = 0; t < pst->length; t++) {
        pst->par[t][m] += step * pst->sm.g[t];
      }
      prev = obj;
    }
  }
}

// Generate sequence of speech parameter vector
// maximizing its output probability for given pdf sequence
void HTS_PStream_mlpg(HTS_PStream *pst) {
  if (pst->length == 0) return;

  for (size_t m = 0; m < pst->vector_length; ++m) {
    // This function takes most time, make it inline.
    HTS_PStream_calc_wuw_and_wum(pst, m);
    // LDL factorization
    HTS_PStream_ldl_factorization(pst);
    // forward substitution
    HTS_PStream_forward_substitution(pst);
    // backward substitution
    HTS_PStream_backward_substitution(pst, m);
    if (pst->gv_length > 0) {
      HTS_PStream_gv_parmgen(pst, m);
    }
  }
}

// initialize parameter stream set
void PStreamSet::Init() {
  pstream_ = NULL;
  nstream_ = 0;
  total_frame_ = 0;
}

// Parameter generation using GV weight
bool PStreamSet::Create(SStreamSet *sss, const vector<double> &msd_threshold,
                        const vector<double> &gv_weight,
                        tts::LanguageType language_type) {
  size_t i, j, k, l, m;
  int shift;
  size_t frame;
  size_t msd_frame;
  size_t state;
  HTS_PStream *pst;
  bool not_bound;
  if (nstream_ != 0) {
    LOG(ERROR) << "HTS_PStreamSet should be clear.";
    return false;
  }

  // initialize
  nstream_ = sss->GetStreamNumber();
  pstream_ =
      reinterpret_cast<HTS_PStream *>(HtsCalloc(nstream_, sizeof(HTS_PStream)));
  total_frame_ = sss->GetTotalFrame();

  // create
  for (i = 0; i < nstream_; i++) {
    pst = &pstream_[i];
    if (sss->IsMsd(i)) {  //  for MSD
      pst->length = 0;
      for (state = 0; state < sss->GetStateNumber(); ++state) {
        if (IsVoicePhoneme(sss->GetCurPhoneme(state / sss->nstate_),
                           language_type) ||
            sss->GetMsd(i, state) >= FLAGS_uv_threshold) {
          pst->length += sss->GetDuration(state);
        }
      }

      pst->msd_flag =
          reinterpret_cast<bool *>(HtsCalloc(total_frame_, sizeof(bool)));
      for (state = 0, frame = 0; state < sss->GetStateNumber(); ++state) {
        if (IsVoicePhoneme(sss->GetCurPhoneme(state / sss->nstate_),
                           language_type) ||
            sss->GetMsd(i, state) >= FLAGS_uv_threshold) {
          for (j = 0; j < sss->GetDuration(state); j++) {
            pst->msd_flag[frame] = true;
            frame++;
          }
        } else {
          for (j = 0; j < sss->GetDuration(state); j++) {
            pst->msd_flag[frame] = false;
            frame++;
          }
        }
      }
    } else {  //  for non MSD
      pst->length = total_frame_;
      pst->msd_flag = NULL;
    }
    pst->vector_length = sss->GetVectorLength(i);
    // Band width of R
    pst->width = sss->GetWindowMaxWidth(i) * 2 + 1;
    pst->win_size = sss->GetWindowSize(i);
    if (pst->length > 0) {
      pst->sm.mean =
          AllocMatrix(pst->length, pst->vector_length * pst->win_size);
      pst->sm.ivar =
          AllocMatrix(pst->length, pst->vector_length * pst->win_size);
      pst->sm.wum =
          reinterpret_cast<double *>(HtsCalloc(pst->length, sizeof(double)));
      pst->sm.wuw = AllocMatrix(pst->length, pst->width);
      pst->sm.g =
          reinterpret_cast<double *>(HtsCalloc(pst->length, sizeof(double)));
      pst->par = AllocMatrix(pst->length, pst->vector_length);
    }

    // Copy dynamic window
    pst->win_l_width =
        reinterpret_cast<int *>(HtsCalloc(pst->win_size, sizeof(int)));
    pst->win_r_width =
        reinterpret_cast<int *>(HtsCalloc(pst->win_size, sizeof(int)));
    pst->win_coefficient =
        reinterpret_cast<double **>(HtsCalloc(pst->win_size, sizeof(double)));
    for (j = 0; j < pst->win_size; j++) {
      pst->win_l_width[j] = sss->GetWindowLeftWidth(i, j);
      pst->win_r_width[j] = sss->GetWindowRightWidth(i, j);
      if (pst->win_l_width[j] + pst->win_r_width[j] == 0) {
        pst->win_coefficient[j] = reinterpret_cast<double *>(
            HtsCalloc(-2 * pst->win_l_width[j] + 1, sizeof(double)));
      } else {
        pst->win_coefficient[j] = reinterpret_cast<double *>(
            HtsCalloc(-2 * pst->win_l_width[j], sizeof(double)));
      }

      pst->win_coefficient[j] -= pst->win_l_width[j];
      for (shift = pst->win_l_width[j]; shift <= pst->win_r_width[j]; shift++) {
        pst->win_coefficient[j][shift] = sss->GetWindowCofficient(i, j, shift);
      }
    }

    // Copy GV
    if (sss->UseGv(i)) {
      pst->gv_mean = reinterpret_cast<double *>(
          HtsCalloc(pst->vector_length, sizeof(double)));
      pst->gv_vari = reinterpret_cast<double *>(
          HtsCalloc(pst->vector_length, sizeof(double)));
      for (j = 0; j < pst->vector_length; j++) {
        pst->gv_mean[j] = sss->GetGvMean(i, j) * gv_weight[i];
        pst->gv_vari[j] = sss->GetGvVariance(i, j);
      }

      pst->gv_switch =
          reinterpret_cast<bool *>(HtsCalloc(pst->length, sizeof(bool)));
      if (sss->IsMsd(i)) {  //  for MSD
        for (state = 0, frame = 0, msd_frame = 0; state < sss->GetStateNumber();
             ++state) {
          for (j = 0; j < sss->GetDuration(state); j++, frame++) {
            if (pst->msd_flag[frame]) {
              pst->gv_switch[msd_frame++] = sss->GetGvSwitch(i, state);
            }
          }
        }
      } else {  // for non MSD
        for (state = 0, frame = 0; state < sss->GetStateNumber(); ++state) {
          for (j = 0; j < sss->GetDuration(state); j++) {
            pst->gv_switch[frame++] = sss->GetGvSwitch(i, state);
          }
        }
      }

      for (j = 0, pst->gv_length = 0; j < pst->length; j++) {
        if (pst->gv_switch[j]) {
          pst->gv_length++;
        }
      }
    } else {
      pst->gv_switch = NULL;
      pst->gv_length = 0;
      pst->gv_mean = NULL;
      pst->gv_vari = NULL;
    }
    // Copy pdfs
    if (sss->IsMsd(i)) {  // for MSD
      for (state = 0, frame = 0, msd_frame = 0; state < sss->GetStateNumber();
           ++state) {
        for (j = 0; j < sss->GetDuration(state); j++) {
          if (pst->msd_flag[frame]) {
            // check current frame is MSD boundary or not
            for (k = 0; k < pst->win_size; k++) {
              not_bound = true;
              for (shift = pst->win_l_width[k]; shift <= pst->win_r_width[k];
                   shift++)
                if (static_cast<int>(frame) + shift < 0 ||
                    static_cast<int>(total_frame_) <=
                        static_cast<int>(frame) + shift ||
                    !pst->msd_flag[frame + shift]) {
                  not_bound = false;
                  break;
                }
              for (l = 0; l < pst->vector_length; l++) {
                m = pst->vector_length * k + l;
                pst->sm.mean[msd_frame][m] = sss->GetMean(i, state, m);

                if (not_bound || k == 0)
                  pst->sm.ivar[msd_frame][m] =
                      HTS_finv(sss->GetVariance(i, state, m));
                else
                  pst->sm.ivar[msd_frame][m] = 0.0;
              }
            }
            msd_frame++;
          }
          frame++;
        }
      }
    } else {  //  for non MSD
      for (state = 0, frame = 0; state < sss->GetStateNumber(); ++state) {
        for (j = 0; j < sss->GetDuration(state); j++) {
          for (k = 0; k < pst->win_size; k++) {
            not_bound = true;
            for (shift = pst->win_l_width[k]; shift <= pst->win_r_width[k];
                 shift++) {
              if (static_cast<int>(frame) + shift < 0 ||
                  static_cast<int>(total_frame_) <=
                      static_cast<int>(frame) + shift) {
                not_bound = false;
                break;
              }
            }

            for (l = 0; l < pst->vector_length; l++) {
              m = pst->vector_length * k + l;
              pst->sm.mean[frame][m] = sss->GetMean(i, state, m);
              if (not_bound || k == 0) {
                pst->sm.ivar[frame][m] =
                    HTS_finv(sss->GetVariance(i, state, m));
              } else {
                pst->sm.ivar[frame][m] = 0.0;
              }
            }
          }
          frame++;
        }
      }
    }
    // parameter generation
    HTS_PStream_mlpg(pst);
  }

  return true;
}

// get number of stream
size_t PStreamSet::GetStreamNumber() { return nstream_; }

// get total number of frame
size_t PStreamSet::GetTotalFrame() { return total_frame_; }

// get parameter vector
double *PStreamSet::GetParameterVector(size_t stream_index,
                                       size_t frame_index) {
  return pstream_[stream_index].par[frame_index];
}

// get generated MSD flag per frame
bool PStreamSet::GetMsdFlag(size_t stream_index, size_t frame_index) {
  return pstream_[stream_index].msd_flag[frame_index];
}

// get MSD flag
bool PStreamSet::IsMsd(size_t stream_index) {
  return pstream_[stream_index].msd_flag ? true : false;
}

// free parameter stream set
void PStreamSet::Clear() {
  size_t i, j;
  if (pstream_) {
    for (i = 0; i < nstream_; i++) {
      HTS_PStream *p = &pstream_[i];
      if (p->sm.wum) HtsFree(p->sm.wum);
      if (p->sm.g) HtsFree(p->sm.g);
      if (p->sm.wuw) FreeMatrix(p->sm.wuw, p->length);
      if (p->sm.ivar) FreeMatrix(p->sm.ivar, p->length);
      if (p->sm.mean) FreeMatrix(p->sm.mean, p->length);
      if (p->par) FreeMatrix(p->par, p->length);
      if (p->msd_flag) HtsFree(p->msd_flag);
      if (p->win_coefficient) {
        for (j = 0; j < p->win_size; j++) {
          p->win_coefficient[j] += p->win_l_width[j];
          HtsFree(p->win_coefficient[j]);
        }
      }
      if (p->gv_mean) HtsFree(p->gv_mean);
      if (p->gv_vari) HtsFree(p->gv_vari);
      if (p->win_coefficient) HtsFree(p->win_coefficient);
      if (p->win_l_width) HtsFree(p->win_l_width);
      if (p->win_r_width) HtsFree(p->win_r_width);
      if (p->gv_switch) HtsFree(p->gv_switch);
    }
    HtsFree(pstream_);
  }
  Init();
}
}  // namespace hts
