// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)
//         qli@mobvoi.com (Qian Li)

#include "tts/synthesizer/engine/hmm/hts_util.h"

#include <ctype.h>

#include <stdlib.h>
#include <stdarg.h>
#include <string.h>

#include "mobvoi/base/compat.h"
#include "mobvoi/base/log.h"
#include "tts/synthesizer/engine/hmm/types.h"

namespace hts {
bool GetTokenFromString(const char* str, size_t* index, char* buff) {
  char c;
  size_t i;

  c = str[(*index)];
  if (c == '\0') return false;
  c = str[(*index)++];
  if (c == '\0') return false;
  while (c == ' ' || c == '\n' || c == '\t') {
    if (c == '\0') return false;
    c = str[(*index)++];
  }
  for (i = 0; c != ' ' && c != '\n' && c != '\t' && c != '\0'; i++) {
    buff[i] = c;
    c = str[(*index)++];
  }

  buff[i] = '\0';
  return true;
}

bool GetTokenFromStringWithSeperator(const char* str, size_t* index, char* buff,
                                     char separator) {
  char c;
  size_t len = 0;

  if (str == NULL) return false;

  c = str[(*index)];
  if (c == '\0') return false;
  while (c == separator) {
    if (c == '\0') return false;
    (*index)++;
    c = str[(*index)];
  }
  while (c != separator && c != '\0') {
    buff[len++] = c;
    (*index)++;
    c = str[(*index)];
  }
  if (c != '\0') (*index)++;

  buff[len] = '\0';

  if (len > 0)
    return true;
  else
    return false;
}

// Function and variables for uv adjust
static const char* kMandAndCanVoicePhone[] = {  // NOLINT
    "AA",  "AH",  "AY",  "EH",   "EY",  "IY",  "M",    "N",   "OW",   "UW",
    "W",   "Y",   "R",   "L",    "V",   "a",   "ai",   "an",  "ang",  "ao",
    "e",   "ei",  "en",  "eng",  "er",  "i",   "ia",   "ian", "iang", "iao",
    "ie",  "in",  "ing", "iong", "iu",  "l",   "m",    "n",   "o",    "ong",
    "ou",  "r",   "u",   "ua",   "uai", "uan", "uang", "ui",  "un",   "uo",
    "v",   "van", "ve",  "vn",   "y",   "aa",  "aang", "aap", "aat",  "aak",
    "au",  "am",  "ap",  "at",   "ak",  "eu",  "em",   "ep",  "ek",   "eoi",
    "eon", "eot", "im",  "ip",   "it",  "ik",  "ot",   "ok",  "oe",   "oeng",
    "oek", "oi",  "on",  "ung",  "ut",  "uk",  "yu",   "yun", "yut",  "ng"};

static const char* kEngVoicePhone[] = {  // NOLINT
    "a", "ae", "ah", "ao", "aw", "ay", "dh", "eh", "er", "ey", "ih", "iy",
    "l", "m",  "n",  "ng", "ow", "oy", "r",  "uh", "uw", "v",  "w",  "y"};

class VoicePhonemeMatcher {
 public:
  static VoicePhonemeMatcher& Instance() {
    static VoicePhonemeMatcher instance;
    return instance;
  }

  bool IsVoicePhoneme(const string& cur_pho, tts::LanguageType language_type) {
    if (language_type == tts::kMandarin) {
      if (mandarin_.find(cur_pho) != mandarin_.end()) {
        return true;
      }
    } else if (language_type == tts::kEnglish) {
      if (english_.find(cur_pho) != english_.end()) {
        return true;
      }
    }
    return false;
  }

 private:
  VoicePhonemeMatcher() {
    for (size_t i = 0; i < arraysize(kMandAndCanVoicePhone); ++i) {
      mandarin_.insert(kMandAndCanVoicePhone[i]);
    }
    for (size_t i = 0; i < arraysize(kEngVoicePhone); ++i) {
      english_.insert(kEngVoicePhone[i]);
    }
  }

  std::unordered_set<string> mandarin_;
  std::unordered_set<string> english_;

  DISALLOW_COPY_AND_ASSIGN(VoicePhonemeMatcher);
};

bool IsVoicePhoneme(const string& cur_pho, tts::LanguageType language_type) {
  return VoicePhonemeMatcher::Instance().IsVoicePhoneme(cur_pho, language_type);
}

void* HtsCalloc(const size_t num, const size_t size) {
  size_t n = num * size;

  DCHECK(n != 0) << "bad size, should not be 0";

  void* mem = reinterpret_cast<void*>(malloc(n));
  memset(mem, 0, n);

  if (UNLIKELY(mem == NULL)) {
    HtsError(1, "HTS_calloc: Cannot allocate memory.\n");
  }

  return mem;
}

/* HTS_Free: wrapper for free */
void HtsFree(void* ptr) { free(ptr); }

char* HtsStrdup(const char* string) {
  char* buff =
      reinterpret_cast<char*>(HtsCalloc(strlen(string) + 1, sizeof(char)));
  strcpy(buff, string);  // NOLINT
  return buff;
}

/* HTS_alloc_matrix: allocate double matrix */
double** AllocMatrix(size_t x, size_t y) {
  if (x == 0 || y == 0) return NULL;

  double** p = reinterpret_cast<double**>(HtsCalloc(x, sizeof(double*)));
  // Alloc continus memory for matrix.
  size_t xy = x * y;
  p[0] = reinterpret_cast<double*>(HtsCalloc(xy, sizeof(double)));
  for (size_t i = 1; i < x; i++) {
    p[i] = p[0] + y * i;
  }
  return p;
}

void FreeMatrix(double** p, size_t x) {
  HtsFree(p[0]);
  HtsFree(p);
}

void HtsError(int error, const char* message, ...) {
  va_list arg;

  fflush(stdout);
  fflush(stderr);

  if (error > 0)
    fprintf(stderr, "\nError: ");
  else
    fprintf(stderr, "\nWarning: ");

  va_start(arg, message);
  vfprintf(stderr, message, arg);
  va_end(arg);

  fflush(stderr);

  if (error > 0) exit(error);
}

void PrintDoubleVector(const vector<double>& vec) {
  for (size_t i = 0; i < vec.size(); ++i) {
    VLOG(3) << vec[i] << " ";
  }
  VLOG(3) << endl;
}

// HTS_dp_match: recursive matching
// TODO(spye) : remove recursive calling.
static bool HTS_dp_match(const char* str, const char* pattern,
                         size_t pattern_len, size_t pos, size_t max) {
  // Almost all pattern are '*'. 146916 / 146929 in my test.
  if (pattern_len == 1 && pattern[0] == '*') {
    return true;
  }
  if (pos > max) return false;
  if (str[0] == '\0' && pattern[0] == '\0') return true;
  if (pattern[0] == '*') {
    if (HTS_dp_match(str + 1, pattern, pattern_len, pos + 1, max)) {
      return true;
    } else {
      return HTS_dp_match(str, pattern + 1, pattern_len - 1, pos, max);
    }
  }

  if (str[0] == pattern[0] || pattern[0] == '?') {
    return HTS_dp_match(str + 1, pattern + 1, pattern_len - 1, pos + 1,
                        max + 1);
  }

  return false;
}

// HTS_pattern_match: pattern matching function
bool MatchPattern(const char* str, size_t str_len, const char* pattern,
                  size_t pattern_length) {
  size_t max = 0;
  size_t nstar = 0;
  size_t nquestion = 0;

  for (size_t i = 0; i < pattern_length; ++i) {
    switch (pattern[i]) {
      case '*':
        nstar++;
        break;
      case '?':
        nquestion++;
        max++;
        break;
      default:
        max++;
    }
  }

  // nquestion is always true in our question set, put it at last.
  if (nstar == 2 && pattern[0] == '*' && pattern[pattern_length - 1] == '*' &&
      nquestion == 0) {
    // only string matching is required
    size_t buff_length = pattern_length - 2;
    char buff[kMaxBuffLen];
    strncpy(buff, pattern + 1, buff_length);
    buff[buff_length] = '\0';
    if (strstr(str, buff) != NULL)
      return true;
    else
      return false;
  } else {
    return HTS_dp_match(str, pattern, pattern_length, 0, str_len - max);
  }
}

bool MatchPattern(const char* str, const char* pattern) {
  return MatchPattern(str, strlen(str), pattern, strlen(pattern));
}

// HTS_is_num: check given buffer is number or not
bool IsNumber(const char* buff) {
  size_t i;
  size_t length = strlen(buff);

  for (i = 0; i < length; i++)
    if (!(isdigit(static_cast<int>(buff[i])) || (buff[i] == '-'))) return false;

  return true;
}

// HTS_name2num: convert name of node to number
size_t NameToNumber(const char* buff) {
  size_t i;

  for (i = strlen(buff) - 1; '0' <= buff[i] && buff[i] <= '9'; i--)
    ;  // NOLINT
  i++;

  return (size_t)atoi(&buff[i]);
}

// HTS_get_state_num: return the number of state
size_t GetStateNumber(const char* string) {
  const char* left, *right;

  left = strchr(string, '[');
  if (left == NULL) return 0;
  left++;

  right = strchr(left, ']');
  if (right == NULL) return 0;

  return (size_t)atoi(left);
}
}  // namespace hts
