// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_SYNTHESIZER_ENGINE_HMM_HTS_GSTREAM_H_
#define TTS_SYNTHESIZER_ENGINE_HMM_HTS_GSTREAM_H_

#include <stdio.h>

#include <vector>

#include "mobvoi/base/compat.h"
#include "mobvoi/base/types.h"

namespace hts {
class PStreamSet;

// Generated parameter stream.
struct GeneratedParameterStream {
  // vector length (static features only)
  size_t vector_length;
  // Generated parameter, [frame_num][feature_vector]
  vector<vector<double>> par;
};

// Set of generated parameter stream.
class GStreamSet {
 public:
  GStreamSet();

  // Generate speech
  bool GenerateGStreamParameters(PStreamSet* pss, size_t fperiod);

  size_t GetSampleNumber();
  size_t GetFrameNumber();
  size_t GetVectorLength(size_t stream_index);
  double GetSpeech(size_t sample_index);
  double GetParameter(size_t stream_index, size_t frame_index,
                      size_t vector_index);

  void Clear();

  size_t total_nsample_;
  size_t total_frame_;
  size_t stream_number_;
  // Generated parameter streams
  vector<GeneratedParameterStream> gstream_;
  std::vector<double> generated_speech_;
};
}  // namespace hts

#endif  // TTS_SYNTHESIZER_ENGINE_HMM_HTS_GSTREAM_H_
