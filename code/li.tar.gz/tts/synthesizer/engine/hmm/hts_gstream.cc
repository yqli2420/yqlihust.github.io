// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: ranzhang@mobvoi.com (dylan)

#include "tts/synthesizer/engine/hmm/hts_gstream.h"

#include "mobvoi/base/log.h"
#include "tts/synthesizer/engine/hmm/hts_pstream.h"
#include "tts/synthesizer/engine/hmm/hts_util.h"
#include "tts/synthesizer/engine/hmm/types.h"

namespace {
static const double kNoData = (-1.0e+10);
static const int kPitchStreamIndex = 1;
}

namespace hts {
GStreamSet::GStreamSet()
    : total_nsample_(0), total_frame_(0), stream_number_(0) {}

bool GStreamSet::GenerateGStreamParameters(PStreamSet* pss, size_t fperiod) {
  // Initialize
  stream_number_ = pss->GetStreamNumber();
  total_frame_ = pss->GetTotalFrame();

  gstream_.resize(stream_number_);
  for (size_t i = 0; i < stream_number_; ++i) {
    gstream_[i].vector_length = pss->GetVectorLength(i);
    gstream_[i].par.resize(total_frame_);
    for (size_t j = 0; j < total_frame_; ++j) {
      gstream_[i].par[j].resize(gstream_[i].vector_length);
    }
  }

  // Copy generated parameter
  for (size_t i = 0; i < stream_number_; ++i) {
    if (pss->IsMsd(i)) {
      // For MSD
      size_t msd_frame = 0;
      for (size_t j = 0; j < total_frame_; ++j) {
        if (pss->GetMsdFlag(i, j)) {
          for (size_t k = 0; k < gstream_[i].vector_length; k++) {
            gstream_[i].par[j][k] = pss->GetParameter(i, msd_frame, k);
          }
          msd_frame++;
        } else {
          for (size_t k = 0; k < gstream_[i].vector_length; k++) {
            gstream_[i].par[j][k] = kNoData;
          }
        }
      }
    } else {
      // for non MSD
      for (size_t j = 0; j < total_frame_; ++j) {
        for (size_t k = 0; k < gstream_[i].vector_length; k++) {
          gstream_[i].par[j][k] = pss->GetParameter(i, j, k);
        }
      }
    }
  }

  // Check
  if (stream_number_ != 2 && stream_number_ != 3) {
    LOG(ERROR) << "The number of streams should be 2 or 3.";
    Clear();
    return false;
  }
  // Pitch
  if (pss->GetVectorLength(kPitchStreamIndex) != 1) {
    LOG(ERROR) << "The size of lf0 static vector should be 1.";
    Clear();
    return false;
  }
  // Post filtering
  if (stream_number_ >= 3 && gstream_[2].vector_length % 2 == 0) {
    LOG(ERROR) << "The number of low-pass filter coefficient"
               << " should be odd numbers.";
    Clear();
    return false;
  }
  total_nsample_ = fperiod * total_frame_;
  return true;
}

size_t GStreamSet::GetSampleNumber() { return total_nsample_; }

size_t GStreamSet::GetFrameNumber() { return total_frame_; }

size_t GStreamSet::GetVectorLength(size_t stream_index) {
  return gstream_[stream_index].vector_length;
}

double GStreamSet::GetSpeech(size_t sample_index) {
  return generated_speech_[sample_index];
}

double GStreamSet::GetParameter(size_t stream_index, size_t frame_index,
                                size_t vector_index) {
  return gstream_[stream_index].par[frame_index][vector_index];
}

void GStreamSet::Clear() {
  gstream_.clear();
  generated_speech_.clear();
  stream_number_ = 0;
  total_frame_ = 0;
  total_nsample_ = 0;
}
}  // namespace hts
