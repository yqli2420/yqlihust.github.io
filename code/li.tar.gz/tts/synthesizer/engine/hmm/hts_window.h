// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_SYNTHESIZER_ENGINE_HMM_HTS_WINDOW_H_
#define TTS_SYNTHESIZER_ENGINE_HMM_HTS_WINDOW_H_

#include <stdio.h>

#include "mobvoi/base/compat.h"

namespace hts {
class HTS_File;

//  window coefficients to calculate dynamic features.
struct HtsWindow {
  HtsWindow();
  ~HtsWindow();

  bool Load(const vector<HTS_File*>& fp);

  size_t size;                 //  # of windows (static + deltas)
  int* l_width;                //  left width of windows
  int* r_width;                //  right width of windows
  double** coefficient;        //  window coefficient
  size_t max_width;            //  maximum width of windows
};
}  // namespace hts

#endif  // TTS_SYNTHESIZER_ENGINE_HMM_HTS_WINDOW_H_
