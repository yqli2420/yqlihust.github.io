// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/synthesizer/engine/hmm/hts_util.h"

#include <fstream>

#include "mobvoi/base/log.h"
#include "third_party/gtest/gtest.h"

namespace hts {
TEST(UtilTest, GetTokenFromString) {
  const char* str = "  hello world  ";
  char buff[20];
  size_t index = 0;
  GetTokenFromString(str, &index, buff);
  EXPECT_EQ(string(buff), "hello");
  GetTokenFromString(str, &index, buff);
  EXPECT_EQ(string(buff), "world");
}

TEST(UtilTest, GetTokenFromStringWithSeperator) {
  const char* str = "  hello\tworld  ";
  char buff[20];
  size_t index = 0;
  GetTokenFromStringWithSeperator(str, &index, buff, '\t');
  EXPECT_EQ(string(buff), "  hello");
  GetTokenFromStringWithSeperator(str, &index, buff, '\t');
  EXPECT_EQ(string(buff), "world  ");
}

TEST(UtilTest, MatchPattern) {
  string pattern = "*^ang-*";
  EXPECT_TRUE(MatchPattern("b^ang-h", pattern.c_str()));
  EXPECT_FALSE(MatchPattern("b+ang-h", pattern.c_str()));
}

TEST(UtilTest, NameToNumber) {
  EXPECT_EQ(NameToNumber("lf0_s7_111"), 111U);
  EXPECT_EQ(NameToNumber("lf0_s2_1"), 1U);
  EXPECT_EQ(NameToNumber("gv_mgc_1"), 1U);
}

}  // namespace hts
