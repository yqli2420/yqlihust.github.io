// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: fllin@mobvoi.com (FenglvLin)

#include "tts/synthesizer/engine/hmm/hts_model_util.h"

#include <algorithm>

#include "tts/synthesizer/engine/hmm/hts_node.h"
#include "tts/synthesizer/engine/hmm/hts_util.h"
#include "tts/synthesizer/engine/hmm/types.h"

DEFINE_bool(use_fixed_point_model, false,
            "To judge if use fixed point model or not.");
DEFINE_double(mean_divided, 1000.0, "Divided by mean.");

namespace hts {
// HTS_Model_initialize: initialize model
// must call Init
HTS_Model::HTS_Model() {
  vector_length = 0;
  num_windows = 0;
  is_msd = false;
  ntree = 0;
  npdf = NULL;
  pdf = NULL;
  fixed_pdf = NULL;
  tree = NULL;
}

HTS_Model::~HTS_Model() {
  HTS_Tree *tree, *next_tree;

  for (tree = this->tree; tree; tree = next_tree) {
    next_tree = tree->next;
    delete tree;
  }
  VLOG(3) << "ntree: " << ntree;
  if (pdf) {
    HtsPdfFree(reinterpret_cast<void***>(pdf));
  }

  if (fixed_pdf) {
    HtsPdfFree(reinterpret_cast<void***>(fixed_pdf));
  }

  if (npdf) {
    npdf += 2;
    HtsFree(npdf);
  }
}

void HTS_Model::HtsPdfFree(void*** ptr) {
  for (size_t i = 2; i <= static_cast<size_t>(ntree + 1); i++) {
    for (size_t j = 1; j <= npdf[i]; j++) {
      HtsFree(ptr[i][j]);
    }
    ptr[i]++;
    HtsFree(ptr[i]);
  }
  ptr += 2;
  HtsFree(ptr);
}

bool HtsModelUtil::HTS_Model_load_tree(HTS_Model* model, HTS_File* fp) {
  char buff[kMaxBuffLen];
  HTS_Tree *tree, *last_tree;
  uint8_t state;

  // check
  if (model == NULL) {
    HtsError(0, "HTS_Model_load_tree: File for trees is not specified.\n");
    return false;
  }

  if (fp == NULL) {
    model->ntree = 1;
    return true;
  }

  model->ntree = 0;
  last_tree = NULL;
  while (!fp->Eof()) {
    fp->GetPatternToken(buff);
    // parse questions
    if (strcmp(buff, "QS") == 0) {
      HTS_Question question;
      HTS_Question_initialize(&question);
      if (HTS_Question_load(&question, fp) == false) {
        return false;
      }
      model->questions.emplace_back(question);
      model->mquestion[question.name] = model->questions.size() - 1;
    }

    // parse trees
    state = GetStateNumber(buff);
    if (state != 0) {
      // Use this trick to make sure size equal to capacity.
      model->questions.shrink_to_fit();
      tree = new HTS_Tree;
      tree->state = state;
      HTS_Tree_parse_pattern(tree, buff);
      if (HTS_Tree_load(tree, fp, model->mquestion) == false) {
        delete tree;
        return false;
      }

      if (model->tree) {
        last_tree->next = tree;
      } else {
        model->tree = tree;
      }
      tree->next = NULL;
      last_tree = tree;
      model->ntree++;
    }
  }

  CHECK_EQ(model->questions.size(), model->questions.capacity())
      << " vector size != capacity, memory is not compact.";
  // No Tree information in tree file
  if (model->tree == NULL) model->ntree = 1;
  // LOG(INFO) << "ntree = " << model->ntree + 1;
  return true;
}

void HtsModelUtil::AddInt16ToBinaryString(int val, string* result) {
  if (val > 0) {
    val = std::min(val, 32767);
  } else if (val < 0) {
    val = std::max(val, -32768);
  }

  int16 result_val = static_cast<int16>(val);
  unsigned char myVar[2];
  myVar[1] = (result_val >> 8) & 0xFF;
  myVar[0] = result_val & 0xFF;
  std::string res(myVar, myVar + 2);
  result->insert(result->end(), res.begin(), res.end());
}

void HtsModelUtil::ConvertToFixedPointModel(const HTS_Model& model, bool is_msd,
                                            string* result) {
  uint8 len = model.vector_length * model.num_windows;
  // read means and variances
  // model.pdf[j][k][m]
  int val;

  for (uint8 j = 2; j <= model.ntree + 1; j++) {
    // add number of pdfs
    AddInt16ToBinaryString(model.npdf[j], result);
  }

  for (uint8 j = 2; j <= model.ntree + 1; j++) {
    for (uint16 k = 1; k <= model.npdf[j]; k++) {
      for (uint8 m = 0; m < len; ++m) {
        // mean
        val = static_cast<int>(model.pdf[j][k][m] * FLAGS_mean_divided);
        AddInt16ToBinaryString(val, result);
      }

      if (is_msd) {
        // msd
        val = (model.pdf[j][k][2 * len] >= 0.5 ? 1 : 0);
        AddInt16ToBinaryString(val, result);
      }
    }
  }
}

bool HtsModelUtil::HTS_Model_load_pdf(HTS_Model* model, HTS_File* fp,
                                      size_t vector_length, size_t num_windows,
                                      bool is_msd, bool is_fixed_point) {
  uint16 i;
  size_t j, k;
  bool result = true;
  size_t len;

  // check
  if (model == NULL || fp == NULL || model->ntree <= 0) {
    LOG(ERROR) << "File for pdfs is not specified.";
    return false;
  }

  // read MSD flag
  model->vector_length = vector_length;
  model->num_windows = num_windows;
  model->is_msd = is_msd;
  VLOG(3) << "ntree : " << model->ntree << ", size of type :" << sizeof(size_t);
  model->npdf = reinterpret_cast<uint16*>(HtsCalloc(model->ntree, sizeof(i)));
  model->npdf -= 2;
  // Read the number of pdfs
  for (j = 2; j <= static_cast<size_t>(model->ntree + 1); j++) {
    if (!is_fixed_point) {
      uint32 i_temp;
      if (fp->ReadLittleEndian(&i_temp, sizeof(i_temp), 1) != 1) {
        result = false;
        LOG(ERROR) << "Fail to read pdf number.";
        break;
      }
      CHECK(i_temp < 65536) << "pdf number is incorrect, i = " << i_temp;
      i = static_cast<uint16>(i_temp);
    } else {
      if (fp->ReadLittleEndian(&i, sizeof(i), 1) != 1) {
        result = false;
        LOG(ERROR) << "Fail to read pdf number.";
        break;
      }
    }
    model->npdf[j] = i;
  }

  for (j = 2; j <= static_cast<size_t>(model->ntree + 1); j++) {
    if (model->npdf[j] <= 0) {
      LOG(ERROR) << "# of pdfs at " << j << "-th state should be positive.";
      result = false;
      break;
    }
  }

  if (result == false) {
    model->npdf += 2;
    free(model->npdf);
    return false;
  }

  if (!is_fixed_point) {
    model->pdf =
        reinterpret_cast<float***>(HtsCalloc(model->ntree, sizeof(float**)));
    model->pdf -= 2;
  } else {
    model->fixed_pdf =
        reinterpret_cast<int16***>(HtsCalloc(model->ntree, sizeof(int16**)));
    model->fixed_pdf -= 2;
  }
  // read means and variances
  if (!is_fixed_point) {
    len = model->vector_length * model->num_windows * 2;
  } else {
    // only mean is saved
    len = model->vector_length * model->num_windows;
  }

  if (is_msd) len += 1;

  for (j = 2; j <= static_cast<size_t>(model->ntree + 1); j++) {
    VLOG(3) << "npdf[j] : " << model->npdf[j] << ", j : " << j;
    if (!is_fixed_point) {
      model->pdf[j] =
          reinterpret_cast<float**>(HtsCalloc(model->npdf[j], sizeof(float*)));
      model->pdf[j]--;
      for (k = 1; k <= model->npdf[j]; k++) {
        model->pdf[j][k] =
            reinterpret_cast<float*>(HtsCalloc(len, sizeof(float)));
        if (fp->ReadLittleEndian(model->pdf[j][k], sizeof(float), len) != len) {
          LOG(FATAL) << "Fail to read pdf data with len:" << len;
          result = false;
        }
      }
    } else {
      model->fixed_pdf[j] =
          reinterpret_cast<int16**>(HtsCalloc(model->npdf[j], sizeof(int16*)));
      model->fixed_pdf[j]--;
      for (k = 1; k <= model->npdf[j]; k++) {
        model->fixed_pdf[j][k] =
            reinterpret_cast<int16*>(HtsCalloc(len, sizeof(int16)));
        if (fp->ReadLittleEndian(model->fixed_pdf[j][k], sizeof(int16), len) !=
            len) {
          LOG(FATAL) << "Fail to read fixed pdf data with len:" << len;
          result = false;
        }
      }
    }
  }

  if (result == false) {
    return false;
  }
  return true;
}

bool HtsModelUtil::HTS_Model_load(HTS_Model* model, HTS_File* pdf,
                                  HTS_File* tree, size_t vector_length,
                                  size_t num_windows, bool is_msd,
                                  bool is_fixed_point) {
  // check
  if (model == NULL || pdf == NULL || vector_length == 0 || num_windows == 0) {
    LOG(ERROR) << "Bad input.";
    return false;
  }

  // load tree
  if (HTS_Model_load_tree(model, tree) != true) {
    LOG(ERROR) << "Fail to load tree";
    return false;
  }

  // load pdf
  if (!HTS_Model_load_pdf(model, pdf, vector_length, num_windows, is_msd,
                          is_fixed_point)) {
    LOG(ERROR) << "Fail to load pdf";
    return false;
  }

  return true;
}

void HtsModelUtil::HTS_Model_get_index(const HTS_Model* model,
                                       size_t state_index, const char* str,
                                       size_t* tree_index, size_t* pdf_index) {
  HTS_Tree* tree;

  (*tree_index) = 2;
  (*pdf_index) = 1;

  DCHECK(model->tree) << "Tree is empty.";
  size_t str_len = strlen(str);

  for (tree = model->tree; tree; tree = tree->next) {
    if (tree->state == state_index) break;
    ++(*tree_index);
  }

  if (tree != NULL) {
    (*pdf_index) = HTS_Tree_search_node(tree, str, str_len, model->questions);
  } else {
    (*pdf_index) =
        HTS_Tree_search_node(model->tree, str, str_len, model->questions);
  }
  VLOG(3) << "tree_index = " << *tree_index << ", pdf_index = " << *pdf_index
          << ", pdfs size = " << model->tree->vnode.size();
}

bool HtsModelUtil::HTS_match_head_string(const char* str, const char* pattern,
                                         size_t* matched_size) {
  (*matched_size) = 0;
  while (1) {
    if (pattern[(*matched_size)] == '\0') return true;
    if (str[(*matched_size)] == '\0') return false;
    if (str[(*matched_size)] != pattern[(*matched_size)]) return false;
    (*matched_size)++;
  }
}

bool HtsModelUtil::HTS_strequal(const char* s1, const char* s2) {
  if (s1 == NULL && s2 == NULL)
    return true;
  else if (s1 == NULL || s2 == NULL)
    return false;
  else
    return strcmp(s1, s2) == 0 ? true : false;
}

void HtsModelUtil::HTS_Model_get_parameter(const HTS_Model* model,
                                           size_t state_index, const char* str,
                                           double* mean, double* vari,
                                           double* msd, double weight,
                                           bool is_fixed_point) {
  size_t tree_index;
  size_t pdf_index;
  HTS_Model_get_index(model, state_index, str, &tree_index, &pdf_index);
  VLOG(3) << "label str:" << str << ",\nstate index:" << state_index
          << ", tree index:" << tree_index << ", pdf index:" << pdf_index;

  size_t len = model->vector_length * model->num_windows;
  int start_idx = 0;
  if (model->is_msd) start_idx = 123;
  VLOG(3) << "vector length:" << model->vector_length
          << ", num windows:" << model->num_windows << ", len:" << len;
  if (!is_fixed_point) {
    for (size_t i = 0; i < len; i++) {
      mean[i] += weight * model->pdf[tree_index][pdf_index][i];
      // fix crash causd by too high delta
      if (model->is_msd && i > 0 && mean[i] > 0.1) {
        VLOG(2) << i << " delta is too large " << mean[i];
        mean[i] = 0.1;
      }
      vari[i] += weight * model->pdf[tree_index][pdf_index][i + len];
    }

    if (msd != NULL && model->is_msd) {
      *msd += weight * model->pdf[tree_index][pdf_index][len + len];
    }
  } else {
    for (size_t i = 0; i < len; i++) {
      mean[i] += static_cast<double>(
          (weight * model->fixed_pdf[tree_index][pdf_index][i]) /
          FLAGS_mean_divided);
      // fix crash causd by too high delta
      if (model->is_msd && i > 0 && mean[i] > 0.1) {
        VLOG(2) << i << " delta is too large " << mean[i];
        mean[i] = 0.1;
      }
      vari[i] += weight * global_var[start_idx + i];
    }

    if (msd != NULL && model->is_msd) {
      *msd += weight * model->fixed_pdf[tree_index][pdf_index][len];
    }
  }
  if (VLOG_IS_ON(3)) {
    VLOG(3) << "array content for ***mean***, length :" << len;
    PrintDoubleArray(mean, len);
    VLOG(3) << "array content for ***vari*** , length :" << len;
    PrintDoubleArray(vari, len);
  }
}
}  // namespace hts
