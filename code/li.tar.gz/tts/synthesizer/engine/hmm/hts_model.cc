// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/synthesizer/engine/hmm/hts_model.h"

#include <ctype.h>
#include <math.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <algorithm>

#include "mobvoi/base/file/proto_util.h"
#include "mobvoi/base/log.h"
#include "tts/synthesizer/engine/hmm/hts_engine.h"
#include "tts/synthesizer/engine/hmm/hts_file.h"
#include "tts/synthesizer/engine/hmm/hts_util.h"
#include "tts/synthesizer/engine/hmm/types.h"

namespace hts {
// Initialize model set
ModelSet::ModelSet() {
  sampling_frequency_ = 0;
  frame_period_ = 0;
  num_voices_ = 0;
  num_states_ = 0;
  num_streams_ = 0;
}

// ModelSet::clear: free model set
ModelSet::~ModelSet() {}

// TODO(dylan): inherit InitOnOff
bool ModelSet::Init(const string& proto_file, float default_speed,
                    bool is_fixed_point) {
  is_fixed_point_ = is_fixed_point;
  default_speed_ = default_speed;
  hts::HtsModel proto_model;
  proto_model.set_stage(1);
  proto_model.set_use_log_gain(true);
  proto_model.set_alpha(0.0);
  CHECK(mobvoi::ReadProtoFromFile(proto_file, &proto_model));
  LOG(INFO) << "Read proto binary done : " << proto_file;
  if (!LoadProtobufModel(proto_model)) {
    LOG(ERROR) << "Fail to load model file:" << proto_file;
    return false;
  }
  return true;
}

bool ModelSet::LoadProtobufModel(const hts::HtsModel& proto_model) {
  // load GLOBAL options
  num_voices_ = proto_model.num_voices();
  CHECK(num_voices_ == 1) << "Don't support more than one voice now.";
  hts_voice_version_ = proto_model.hts_voice_version();
  sampling_frequency_ = proto_model.sampling_frequency();
  frame_period_ = proto_model.frame_period();
  num_states_ = proto_model.num_states();
  num_streams_ = proto_model.num_streams();
  stage_ = proto_model.stage();
  use_log_gain_ = proto_model.use_log_gain();
  alpha_ = proto_model.alpha();

  // stream_type_ = proto_model.stream_type();
  fullcontext_format_ = proto_model.fullcontext_format();
  fullcontext_version_ = proto_model.fullcontext_version();

  // gv_off_context_
  gv_off_context_.name = proto_model.gv_off_context().name();
  for (int i = 0; i < proto_model.gv_off_context().patterns_size(); ++i) {
    gv_off_context_.patterns.push_back(
        proto_model.gv_off_context().patterns(i));
  }
  // option_

  // Load windows
  window_.resize(proto_model.streams_size());
  for (int k = 0; k < proto_model.streams_size(); ++k) {
    size_t win_size = proto_model.streams(k).win_content_size();
    vector<HTS_File*> win_fp(win_size);
    for (size_t i = 0; i < win_size; ++i) {
      HTS_File* fp = HTS_File::OpenFromData(
          (void*)proto_model.streams(k).win_content(i).data(),  // NOLINT
          proto_model.streams(k).win_content(i).size());
      win_fp[i] = fp;
    }
    if (!window_[k].Load(win_fp)) {
      LOG(ERROR) << "Fail to load window";
      return false;
    }
    for (size_t k = 0; k < win_size; k++) {
      win_fp[k]->Close();
    }
  }
  VLOG(3) << "Load window done.";

  // load STREAM options
  stream_.resize(num_voices_);
  gv_.resize(num_voices_);
  for (size_t k = 0; k < num_voices_; ++k) {
    // Load Stream
    stream_[k].resize(proto_model.streams_size());
    VLOG(3) << "stream number : " << proto_model.streams_size();
    for (int i = 0; i < proto_model.streams_size(); ++i) {
      HTS_File* pdf_fp = HTS_File::OpenFromData(
          (void*)proto_model.streams(i).pdf_content().data(),  // NOLINT
          proto_model.streams(i).pdf_content().size());
      HTS_File* tree_fp = HTS_File::OpenFromData(
          (void*)proto_model.streams(i).tree_content().data(),  // NOLINT
          proto_model.streams(i).tree_content().size());
      VLOG(3) << "vector length : " << proto_model.streams(i).vector_length()
              << ", win_content_size : "
              << proto_model.streams(i).win_content_size();
      if (!HtsModelUtil::HTS_Model_load(
              &stream_[k][i], pdf_fp, tree_fp,
              proto_model.streams(i).vector_length(),
              proto_model.streams(i).win_content_size(),
              proto_model.streams(i).is_msd(), is_fixed_point_)) {
        LOG(ERROR) << "Fail to load stream pdf & tree";
        pdf_fp->Close();
        tree_fp->Close();
        return false;
      }
      pdf_fp->Close();
      tree_fp->Close();
      VLOG(3) << "Load stream pdf & tree for stream " << i << " done.";
    }

    // Load gv
    gv_[k].resize(proto_model.streams_size());
    for (int i = 0; i < proto_model.streams_size(); ++i) {
      if (!proto_model.streams(i).use_gv()) {
        continue;
      }
      HTS_File* pdf_fp = HTS_File::OpenFromData(
          (void*)proto_model.streams(i).gv_pdf_content().data(),  // NOLINT
          proto_model.streams(i).gv_pdf_content().size());
      HTS_File* tree_fp = HTS_File::OpenFromData(
          (void*)proto_model.streams(i).gv_tree_content().data(),  // NOLINT
          proto_model.streams(i).gv_tree_content().size());
      if (!HtsModelUtil::HTS_Model_load(&gv_[k][i], pdf_fp, tree_fp,
                                        proto_model.streams(i).vector_length(),
                                        1, false, is_fixed_point_)) {
        LOG(ERROR) << "Fail to load gv";
        pdf_fp->Close();
        tree_fp->Close();
        return false;
      }
      pdf_fp->Close();
      tree_fp->Close();
      VLOG(3) << "Load gv pdf & tree for stream " << i << " done.";
    }
  }

  // Load duration
  duration_.resize(num_voices_);
  for (size_t i = 0; i < duration_.size(); ++i) {
    HTS_File* pdf_fp = HTS_File::OpenFromData(
        (void*)proto_model.duration_pdf().data(),  // NOLINT
        proto_model.duration_pdf().size());
    HTS_File* tree_fp = HTS_File::OpenFromData(
        (void*)proto_model.duration_tree().data(),  // NOLINT
        proto_model.duration_tree().size());
    if (!HtsModelUtil::HTS_Model_load(&duration_[i], pdf_fp, tree_fp,
                                      num_states_, 1, false, is_fixed_point_)) {
      LOG(ERROR) << "Fail to load duration";
      return false;
    }
    pdf_fp->Close();
    tree_fp->Close();
  }
  return true;
}

size_t ModelSet::SamplingFrequency() const { return sampling_frequency_; }

size_t ModelSet::FramePeriod() const { return frame_period_; }

const char* ModelSet::GetOption(size_t stream_index) const {
  return option_[stream_index].c_str();
}

bool ModelSet::GetGvFlag(const char* str, size_t len) const {
  if (HTS_Question_match(gv_off_context_, str, len))
    return false;
  else
    return true;
}

size_t ModelSet::GetStateNumber() const { return num_states_; }

string ModelSet::GetFullLabelFormat() const { return fullcontext_format_; }

string ModelSet::FullLabelVersion() const { return fullcontext_version_; }

size_t ModelSet::GetStreamNumber() const { return num_streams_; }

size_t ModelSet::GetVoiceNumber() const { return num_voices_; }

size_t ModelSet::VertorLenght(size_t stream_index) const {
  return stream_[0][stream_index].vector_length;
}

bool ModelSet::IsMsd(size_t stream_index) const {
  return stream_[0][stream_index].is_msd;
}

size_t ModelSet::GetWindowSize(size_t stream_index) const {
  return window_[stream_index].size;
}

int ModelSet::GetWindowLeftWidth(size_t stream_index,
                                 size_t window_index) const {
  return window_[stream_index].l_width[window_index];
}

int ModelSet::GetWindowRightWidth(size_t stream_index,
                                  size_t window_index) const {
  return window_[stream_index].r_width[window_index];
}

double ModelSet::GetWindowCofficient(size_t stream_index, size_t window_index,
                                     size_t coefficient_index) const {
  return window_[stream_index].coefficient[window_index][coefficient_index];
}

size_t ModelSet::MaxWidthOfWindow(size_t stream_index) const {
  return window_[stream_index].max_width;
}

bool ModelSet::UseGv(size_t stream_index) const {
  if (gv_[0][stream_index].vector_length != 0) {
    return true;
  } else {
    return false;
  }
}

size_t ModelSet::GetStage() const { return stage_; }

bool ModelSet::UseLogGain() const { return use_log_gain_; }

double ModelSet::GetAlpha() const { return alpha_; }

void ModelSet::GetDurationIndex(size_t voice_index, const char* full_label,
                                size_t* tree_index, size_t* pdf_index) const {
  HtsModelUtil::HTS_Model_get_index(&duration_[voice_index], 2, full_label,
                                    tree_index, pdf_index);
}

void ModelSet::GetDuration(const char* str, const vector<double>& iw,
                           double* mean, double* vari) const {
  for (size_t i = 0; i < num_states_; i++) {
    mean[i] = 0.0;
    vari[i] = 0.0;
  }

  for (size_t i = 0; i < num_voices_; i++) {
    if (iw[i] != 0.0) {
      HtsModelUtil::HTS_Model_get_parameter(&duration_[i], 2, str, mean, vari,
                                            NULL, iw[i], is_fixed_point_);
    }
  }
}

void ModelSet::GetParameterIndex(size_t voice_index, size_t stream_index,
                                 size_t state_index, const char* string,
                                 size_t* tree_index, size_t* pdf_index) const {
  HtsModelUtil::HTS_Model_get_index(&stream_[voice_index][stream_index],
                                    state_index, string, tree_index, pdf_index);
}

void ModelSet::GetParameter(size_t stream_index, size_t state_index,
                            const char* string, const vector<double>& iw,
                            double* mean, double* vari, double* msd) const {
  size_t i;
  size_t len = stream_[0][stream_index].vector_length *
               stream_[0][stream_index].num_windows;

  for (i = 0; i < len; i++) {
    mean[i] = 0.0;
    vari[i] = 0.0;
  }
  if (msd != NULL) *msd = 0.0;

  for (i = 0; i < num_voices_; i++) {
    if (iw[i] != 0.0) {
      HtsModelUtil::HTS_Model_get_parameter(&stream_[i][stream_index],
                                            state_index, string, mean, vari,
                                            msd, iw[i], is_fixed_point_);
    }
  }
}

void ModelSet::GetGvIndex(size_t voice_index, size_t stream_index,
                          const char* string, size_t* tree_index,
                          size_t* pdf_index) const {
  HtsModelUtil::HTS_Model_get_index(&gv_[voice_index][stream_index], 2, string,
                                    tree_index, pdf_index);
}

void ModelSet::GetGv(size_t stream_index, const char* string,
                     const vector<double>& iw, double* mean,
                     double* vari) const {
  size_t i;
  size_t len = stream_[0][stream_index].vector_length;

  for (i = 0; i < len; i++) {
    mean[i] = 0.0;
    vari[i] = 0.0;
  }
  for (i = 0; i < num_voices_; i++) {
    if (iw[i] != 0.0) {
      HtsModelUtil::HTS_Model_get_parameter(&gv_[i][stream_index], 2, string,
                                            mean, vari, NULL, iw[i],
                                            is_fixed_point_);
    }
  }
}

float ModelSet::CalculateKLD(const HTS_Model& model, size_t tree_index,
                             size_t pdf_index_A, size_t pdf_index_B) const {
  if (pdf_index_A == pdf_index_B) {
    return 0;
  }
  vector<float> meanA, meanB;
  vector<float> variA, variB;
  float msdA, msdB;
  float detA, detB;
  detA = detB = 1;
  size_t len = model.vector_length * model.num_windows;
  for (size_t i = 0; i < len; ++i) {
    meanA.push_back(model.pdf[tree_index][pdf_index_A][i]);
    variA.push_back(model.pdf[tree_index][pdf_index_A][i + len]);
    meanB.push_back(model.pdf[tree_index][pdf_index_B][i]);
    variB.push_back(model.pdf[tree_index][pdf_index_B][i + len]);
  }

  float kld = 0.0;
  if (model.is_msd) {
    msdA = model.pdf[tree_index][pdf_index_A][len + len];
    msdB = model.pdf[tree_index][pdf_index_B][len + len];
    kld += (msdA / msdB) * log(msdA / msdB) + (msdB / msdA) * log(msdB / msdA);
    for (size_t i = 0; i < len; ++i) {
      kld += (meanA[i] - meanB[i]) * (meanA[i] - meanB[i]) *
                 (msdA * variA[i] + msdB * variB[i]) +
             msdB * (variA[i] / variB[i] - 1) +
             msdA * (variB[i] / variA[i] - 1);
      detA *= variA[i];
      detB *= variB[i];
    }
    kld += (msdA - msdB) * log(detB / detA);
  } else {
    for (size_t i = 0; i < len; ++i) {
      kld += (meanA[i] - meanB[i]) * (meanA[i] - meanB[i]) *
                 (variA[i] + variB[i]) +
             variA[i] / variB[i] + variB[i] / variA[i] - 2;
    }
  }
  kld /= len;
  return kld;
}

// save KLD Matrix
void ModelSet::SaveKLDMatrix(FILE* fp) const {
  float kld;
  for (size_t i = 2; i < num_states_ + 2; ++i) {
    VLOG(3) << "State number of tree " << i
            << " in mgc: " << stream_[0][0].npdf[i];
    fwrite(&(stream_[0][0].npdf[i]), sizeof(size_t), 1, fp);
  }

  for (size_t i = 2; i < num_states_ + 2; ++i) {
    VLOG(3) << "State number of tree " << i
            << " in lf0: " << stream_[0][1].npdf[i];
    fwrite(&(stream_[0][1].npdf[i]), sizeof(size_t), 1, fp);
  }

  VLOG(3) << "calculate KLD Table of MGC";
  for (size_t i = 2; i < num_states_ + 2; ++i) {
    for (size_t j = 1; j <= stream_[0][0].npdf[i]; ++j) {
      for (size_t k = j + 1; k <= stream_[0][0].npdf[i]; ++k) {
        kld = CalculateKLD(stream_[0][0], i, j, k);
        VLOG(2) << 0 << i << j << k << kld;
        uint16_t kld_int = 65535;
        if (kld * 100 < 50000) {
          kld_int = kld * 100;
        }
        fwrite(&kld_int, sizeof(kld_int), 1, fp);
      }
    }
  }

  VLOG(3) << "calculate KLD Table of LF0";
  for (size_t i = 2; i < num_states_ + 2; ++i) {
    for (size_t j = 1; j <= stream_[0][1].npdf[i]; ++j) {
      for (size_t k = j + 1; k <= stream_[0][1].npdf[i]; ++k) {
        kld = CalculateKLD(stream_[0][1], i, j, k);
        VLOG(2) << 0 << i << j << k << kld;
        uint16_t kld_int = 65535;
        if (kld * 100 < 50000) {
          kld_int = kld * 100;
        }
        fwrite(&kld_int, sizeof(kld_int), 1, fp);
      }
    }
  }
}
}  // namespace hts
