// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_SYNTHESIZER_ENGINE_HMM_HTS_LABEL_H_
#define TTS_SYNTHESIZER_ENGINE_HMM_HTS_LABEL_H_

#include <string>
#include <vector>

#include "mobvoi/base/compat.h"

namespace hts {
class HTS_File;

// Individual label string with time information
struct LabelString {
  string name;   //  label string
  double start;  //  start frame specified in the given label
  double end;    //  end frame specified in the given label
};

// List of label strings
class Label {
 public:
  Label();
  ~Label();

  // Load label from file name
  void LoadFromFile(size_t sampling_rate, size_t fperiod, const char* fn);
  // Load label list from string list
  void LoadFromStringVector(size_t sampling_rate, size_t fperiod,
                            const vector<string>& lines);

  size_t Size() const;
  const char* GetString(size_t index) const;
  size_t GetStrLen(size_t index) const;
  // Get start frame
  double GetStartFrame(size_t index) const;
  // Get end frame
  double GetEndFrame(size_t index) const;

 private:
  void Load(size_t sampling_rate, size_t fperiod, HTS_File* fp);
  void CheckTime();

  vector<LabelString> labels_;
};
}  // namespace hts

#endif  // TTS_SYNTHESIZER_ENGINE_HMM_HTS_LABEL_H_
