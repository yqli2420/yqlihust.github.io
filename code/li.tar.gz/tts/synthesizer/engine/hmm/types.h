// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_SYNTHESIZER_ENGINE_HMM_TYPES_H_
#define TTS_SYNTHESIZER_ENGINE_HMM_TYPES_H_

#include "mobvoi/base/flags.h"

namespace hts {

#if !defined(WORDS_BIGENDIAN) && !defined(WORDS_LITTLEENDIAN)
#define WORDS_LITTLEENDIAN
#endif /* !WORDS_BIGENDIAN && !WORDS_LITTLEENDIAN */
#if defined(WORDS_BIGENDIAN) && defined(WORDS_LITTLEENDIAN)
#undef WORDS_BIGENDIAN
#endif /* WORDS_BIGENDIAN && WORDS_LITTLEENDIAN */

static const int kMaxBuffLen = 1024;
static const double kMaxLf0 =
    9.9034875525361280454891979401956; /* log(20000.0) */
static const double kMinLf0 = 2.9957322735539909934352235761425; /* log(20.0) */
static const double kHalfTone =
    0.05776226504666210911810267678818; /* log(2.0) / 12.0 */
static const double kDB =
    0.11512925464970228420089957273422; /* log(10.0) / 20.0 */

}  // namespace hts
#endif  // TTS_SYNTHESIZER_ENGINE_HMM_TYPES_H_
