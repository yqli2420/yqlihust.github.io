// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: fllin@mobvoi.com (FenglvLin)

#ifndef TTS_SYNTHESIZER_ENGINE_HMM_HTS_MODEL_UTIL_H_
#define TTS_SYNTHESIZER_ENGINE_HMM_HTS_MODEL_UTIL_H_

#include <map>
#include <string>
#include <vector>

#include "tts/synthesizer/engine/hmm/hts_file.h"
#include "tts/synthesizer/engine/hmm/hts_question.h"
#include "tts/synthesizer/engine/hmm/hts_tree.h"


namespace hts {
//  set of PDFs, decision trees and questions.
struct HTS_Model {
  HTS_Model();
  ~HTS_Model();
  void HtsPdfFree(void ***ptr);
  // range from 1 - 41
  uint8 vector_length;            //  vector length (static features only)
  // range from 1 - 3
  uint8 num_windows;              //  # of windows for delta

  bool is_msd : 8;                     //  flag for MSD
  // range from 1 - 7
  uint8 ntree;                    //  # of trees

  // valus <= 1631 for offline model, so we use short here.
  uint16* npdf;                    //  # of PDFs at each tree
  float*** pdf;                    //  PDFs
  int16*** fixed_pdf;              //  Fixed Point PDFs
  HTS_Tree* tree;                  //  pointer to the list of trees
  vector<HTS_Question> questions;  //  pointer to the list of questions
  map<string, int> mquestion;
};

class HtsModelUtil {
 public:
  HtsModelUtil() {}
  ~HtsModelUtil() {}
  // HTS_Model_load_tree: load trees
  static bool HTS_Model_load_tree(HTS_Model* model, HTS_File* fp);

  static void AddInt16ToBinaryString(int val, string* result);

  static void ConvertToFixedPointModel(const HTS_Model& model, bool is_msd,
                                      string* result);

  // HTS_Model_load_pdf: load pdfs
  static bool HTS_Model_load_pdf(HTS_Model* model, HTS_File* fp,
                                size_t vector_length, size_t num_windows,
                                bool is_msd, bool is_fixed_point);

  // Load pdf and tree
  static bool HTS_Model_load(HTS_Model* model, HTS_File* pdf, HTS_File* tree,
                            size_t vector_length, size_t num_windows,
                            bool is_msd, bool is_fixed_point);

  // Get index of tree and PDF
  static void HTS_Model_get_index(const HTS_Model* model, size_t state_index,
                                  const char* str, size_t* tree_index,
                                  size_t* pdf_index);

  // Return true if head of str is equal to pattern
  static bool HTS_match_head_string(const char* str, const char* pattern,
                                    size_t* matched_size);

  // Strcmp wrapper
  static bool HTS_strequal(const char* s1, const char* s2);

  // Get parameter using interpolation weight
  static void HTS_Model_get_parameter(const HTS_Model* model,
                                      size_t state_index,
                                      const char* str, double* mean,
                                      double* vari, double* msd,
                                      double weight, bool is_fixed_point);
};
}  // namespace hts
#endif  // TTS_SYNTHESIZER_ENGINE_HMM_HTS_MODEL_UTIL_H_
