// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: ranzhang@mobvoi.com (Dylan)

#include "tts/synthesizer/engine/hmm/hts_option.h"

#include <math.h>

#include "tts/synthesizer/engine/hmm/types.h"

namespace hts {
static const double kMinSpeed = 0.5;
static const double kMaxSpeed = 2.0;

HtsOption::HtsOption()
    : sampling_frequency(0),
      frame_period(0),
      audio_buff_size(0),
      stop(false),
      volume(1.0),
      phoneme_alignment_flag(false),
      speed(1.0),
      stage(0),
      use_log_gain(false),
      alpha(0.0),
      beta(0.0),
      additional_half_tone(0.0) {}

HtsOption::~HtsOption() {}

void HtsOption::PrintInfo() const {
  VLOG(1) << sampling_frequency << " " << frame_period << " " << audio_buff_size
          << " " << stop << " " << volume << " " << phoneme_alignment_flag
          << " " << speed << " " << stage << " " << use_log_gain << " " << alpha
          << " " << beta << " " << additional_half_tone;
}

void HtsOption::Init(const ModelSet* model_set) {
  static const int model_num = 1;
  VLOG(2) << "model number:" << model_num;
  // Global
  speed = model_set->GetDefaultSpeed();
  stage = model_set->GetStage();
  use_log_gain = model_set->UseLogGain();
  alpha = model_set->GetAlpha();
  sampling_frequency = model_set->SamplingFrequency();
  frame_period = model_set->FramePeriod();
  msd_threshold.resize(model_set->GetStreamNumber(), 0.5);
  gv_weight.resize(model_set->GetStreamNumber(), 1.0);

  // interpolation weights
  double average_weight = 1.0 / model_num;
  duration_iw.resize(model_num, average_weight);

  for (size_t i = 0; i < model_set->GetStreamNumber(); ++i) {
    vector<double> vec(model_num, average_weight);
    parameter_iw.push_back(vec);
    gv_iw.push_back(vec);
  }
}

void HtsOption::SetOption(const tts::TTSOption& tts_option) {
  // multiply default speed with option speed
  speed = speed * tts_option.speed();
  if (speed > kMaxSpeed) speed = kMaxSpeed;
  if (speed < kMinSpeed) speed = kMinSpeed;
}

void HtsOption::set_volume(double f) { volume = exp(f * kDB); }

double HtsOption::get_volume() const { return log(volume) / kDB; }
}  // namespace hts
