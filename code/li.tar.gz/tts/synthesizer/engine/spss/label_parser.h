// Copyright 2017 Mobvoi Inc. All Rights Reserved.
// Author: jbxiao@mobvoi.com (Jinba Xiao)

#ifndef TTS_SYNTHESIZER_ENGINE_SPSS_LABEL_PARSER_H_
#define TTS_SYNTHESIZER_ENGINE_SPSS_LABEL_PARSER_H_

#include <algorithm>
#include <list>
#include <map>
#include <string>
#include <vector>

#include "mobvoi/base/compat.h"
#include "mobvoi/base/string_util.h"

namespace engine {
namespace spss {

enum ElementType { ONEHOT, NUMERIC };

class LabelElement {
 public:
  LabelElement(const string& name, const string& pre_delim,
               const string& pos_delim, ElementType type)
      : name_(name),
        pre_delim_(pre_delim),
        pos_delim_(pos_delim),
        type_(type),
        ref_list_(nullptr) {}
  LabelElement(const string& name, const string& pre_delim,
               const string& pos_delim, ElementType type,
               const map<string, int>* ref_list)
      : name_(name),
        pre_delim_(pre_delim),
        pos_delim_(pos_delim),
        type_(type),
        ref_list_(ref_list) {}

 public:
  string name_;
  string pre_delim_;
  string pos_delim_;
  ElementType type_;
  const map<string, int>* ref_list_;  // Not null if type_ is ONEHOT
};

class LabelParser {
 public:
  explicit LabelParser(const string& phone_list);
  ~LabelParser() {}
  bool Parse(const string& label, string* phone, vector<float>* input) const;

 private:
  void GetBinaryVector(int value, vector<vector<float>>* input) const;
  void GetOneHotVector(const string& str, const map<string, int>* ref_list,
                       vector<vector<float>>* input) const;

 private:
  vector<LabelElement> elements_;
  map<string, int> phone_map_;  // all phonemes list
  map<string, int> tone_map_;   // all phonemes list
};

}  // namespace spss
}  // namespace engine

#endif  // TTS_SYNTHESIZER_ENGINE_SPSS_LABEL_PARSER_H_
