// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Authors: sxwang@mobvoi.com (Sixue Wang)
//          ypfeng@mobvoi.com (Yupu Feng)

#ifndef TTS_SYNTHESIZER_ENGINE_SPSS_SPSS_ENGINE_H_
#define TTS_SYNTHESIZER_ENGINE_SPSS_SPSS_ENGINE_H_

#include "mobvoi/base/platforms.h"

#if PLATFORM(GNU_LINUX_X86) || PLATFORM(NEON)

#include <memory>
#include <string>
#include <vector>

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/macros.h"
#include "third_party/one/spss_model.h"
#include "tts/synthesizer/engine/engine.h"
#include "tts/synthesizer/engine/spss/label_parser.h"
#include "tts/synthesizer/proto/tts.pb.h"

namespace engine {
namespace spss {

using UVType = uint8;

class SPSSEngine : public Engine {
 public:
  SPSSEngine(const tts::LanguageType& langauge, const string& model_file,
             float default_speed);
  virtual ~SPSSEngine() = default;
  bool SynthesizeFromLabel(const tts::TTSOption& tts_option,
                           const vector<string>& labels,
                           tts::RawData* raw_data) const override;
  string GetEngineModelType() const override;

 private:
  void GetDurationInput(const vector<int>& dur_input_dims,
                        const vector<string>& labels, vector<string>* phonemes,
                        vector<float>* duration_input) const;
  int InferenceDuration(float speed, const vector<int>& dur_input_dims,
                        const vector<float>& duration_input,
                        vector<int>* duration_output) const;
  vector<float> GetAcousticInput(const vector<int>& dur_input_dims,
                                 const vector<int>& aco_input_dims,
                                 const vector<float>& duration_input,
                                 const vector<int>& duration_output) const;
  vector<float> InferenceAcoustic(const vector<int>& aco_input_dims,
                                  const vector<float>& acoustic_input) const;
  vector<UVType> GetFrameUV(const vector<string>& phones,
                            const vector<int>& druation_output,
                            int total_duration) const;
  void GetFeature(const vector<int>& aco_input_dims,
                  const vector<float>& acoustic_output,
                  const vector<UVType>& frame_uv, vector<float>* fea) const;
  void SaveLabel(const vector<int>& duration, const vector<string>& phonemes,
                 tts::RawData* raw_data) const;

  tts::LanguageType language_;
  float default_speed_;
  int mgc_dim_;
  int frame_period_;
  mobvoi::one::SPSSModel model_;
  const vector<int> dur_input_dims_;
  const vector<int> aco_input_dims_;
  const LabelParser label_parser_;

  DISALLOW_COPY_AND_ASSIGN(SPSSEngine);
};

}  // namespace spss
}  // namespace engine

#endif  // PLATFORM(GNU_LINUX_X86) || PLATFORM(NEON)

#endif  // TTS_SYNTHESIZER_ENGINE_SPSS_SPSS_ENGINE_H_
