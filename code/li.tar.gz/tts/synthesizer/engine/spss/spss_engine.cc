// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Authors: sxwang@mobvoi.com (Sixue Wang)
//          ypfeng@mobvoi.com (Yupu Feng)

#include "mobvoi/base/platforms.h"

#if PLATFORM(GNU_LINUX_X86) || PLATFORM(NEON)

#include "tts/synthesizer/engine/spss/spss_engine.h"

#include "tts/synthesizer/engine/hmm/hts_util.h"
#include "tts/util/tts_util/util.h"

namespace {

const int kFramePeriod = 80;
const int kMgcDimension = 41;
const uint8 kVoice = 1;
const uint8 kUnvoice = 0;
const float kVoiceThreshold = 0.5;
const int kWinSize = 3;
const uint8 kMinPhoneDur = 8;
}  // namespace

namespace engine {
namespace spss {

SPSSEngine::SPSSEngine(const tts::LanguageType& language,
                       const string& model_file, float default_speed)
    : language_(language),
      default_speed_(default_speed),
      mgc_dim_(kMgcDimension),
      frame_period_(kFramePeriod),
      model_(model_file),
      dur_input_dims_(model_.GetInputDims(true)),
      aco_input_dims_(model_.GetInputDims(false)),
      label_parser_(model_.phone_list()) {}

string SPSSEngine::GetEngineModelType() const {
  return string();
}

// Decode directly
bool SPSSEngine::SynthesizeFromLabel(const tts::TTSOption& tts_option,
                                     const vector<string>& labels,
                                     tts::RawData* raw_data) const {
  float speed = tts_option.speed() * default_speed_;

  // Duration inference
  vector<int> dur_input_dims = dur_input_dims_;
  dur_input_dims[0] = labels.size();
  vector<float> duration_input;
  vector<string> phonemes;
  GetDurationInput(dur_input_dims, labels, &phonemes, &duration_input);
  vector<int> duration_output;
  int total_duration = InferenceDuration(speed, dur_input_dims, duration_input,
                                         &duration_output);

  // TODO(ypfeng): change spss_model api, avoid extra copy
  // Acoustic inference
  vector<int> aco_input_dims = aco_input_dims_;
  aco_input_dims[0] = total_duration;
  auto acoustic_input = GetAcousticInput(dur_input_dims, aco_input_dims,
                                         duration_input, duration_output);
  vector<float> acoustic_output =
      InferenceAcoustic(aco_input_dims, acoustic_input);

  // Get UV for every frame
  auto frame_uv = GetFrameUV(phonemes, duration_output, total_duration);
  GetFeature(aco_input_dims, acoustic_output, frame_uv, &(raw_data->feature));

  if (tts_option.detail_output()) {
    SaveLabel(duration_output, phonemes, raw_data);
  }

  return true;
}

void SPSSEngine::GetDurationInput(const vector<int>& dur_input_dims,
                                  const vector<string>& labels,
                                  vector<string>* phonemes,
                                  vector<float>* duration_input) const {
  phonemes->reserve(labels.size());
  duration_input->reserve(dur_input_dims[0] * dur_input_dims[1] *
                          dur_input_dims[2]);
  for (const auto& l : labels) {
    string phone;
    CHECK(label_parser_.Parse(l, &phone, duration_input))
        << "Parsing label: " << l << " failed";
    phonemes->push_back(phone);
  }
}

int SPSSEngine::InferenceDuration(float speed,
                                  const vector<int>& dur_input_dims,
                                  const vector<float>& duration_input,
                                  vector<int>* duration_output) const {
  vector<float> model_output =
      const_cast<mobvoi::one::SPSSModel*>(&model_)->Inference(
          dur_input_dims, duration_input, true);

  int total_duration = 0;
  duration_output->reserve(dur_input_dims[0]);
  for (const auto& output : model_output) {
    float adjust_dur = output / speed;
    if (UNLIKELY(adjust_dur < kMinPhoneDur)) {
      total_duration += kMinPhoneDur;
      duration_output->push_back(kMinPhoneDur);
    } else {
      int actual_dur = static_cast<int>(adjust_dur + 0.5);
      total_duration += actual_dur;
      duration_output->push_back(actual_dur);
    }
  }
  return total_duration;
}

// <TODO>ranzhang: merage duration and acoustic input
vector<float> SPSSEngine::GetAcousticInput(
    const vector<int>& dur_input_dims, const vector<int>& aco_input_dims,
    const vector<float>& duration_input,
    const vector<int>& duration_output) const {
  int dur_feat_dim = dur_input_dims.back();
  vector<float> acoustic_input;
  acoustic_input.reserve(aco_input_dims[0] * aco_input_dims[1] *
                         aco_input_dims[2]);
  auto iter = duration_input.begin();
  for (int i = 0; i < dur_input_dims[0]; ++i, iter += dur_feat_dim) {
    for (int j = 0; j < duration_output[i]; ++j) {
      acoustic_input.insert(acoustic_input.end(), iter, iter + dur_feat_dim);
      acoustic_input.push_back(j + 1);
      acoustic_input.push_back(duration_output[i] - j);
      acoustic_input.push_back(duration_output[i]);
    }
  }

  return acoustic_input;
}

vector<float> SPSSEngine::InferenceAcoustic(
    const vector<int>& aco_input_dims,
    const vector<float>& acoustic_input) const {
  return const_cast<mobvoi::one::SPSSModel*>(&model_)->Inference(
      aco_input_dims, acoustic_input, false);
}

vector<UVType> SPSSEngine::GetFrameUV(const vector<string>& phonemes,
                                      const vector<int>& duration_output,
                                      int total_duration) const {
  vector<UVType> frame_uv(total_duration, kUnvoice);
  auto iter = frame_uv.begin();
  for (size_t i = 0; i < phonemes.size(); ++i) {
    if (hts::IsVoicePhoneme(phonemes[i], language_)) {
      std::fill_n(iter, duration_output[i], kVoice);
    }
    iter += duration_output[i];
  }
  return frame_uv;
}

// mgc41 + pitch1 + uv1
void SPSSEngine::GetFeature(const vector<int>& aco_input_dims,
                            const vector<float>& acoustic_output,
                            const vector<UVType>& frame_uv,
                            vector<float>* fea) const {
  int seqlen = aco_input_dims[0];
  int output_dim = acoustic_output.size() / seqlen;
  fea->reserve(acoustic_output.size());
  fea->insert(fea->begin(), acoustic_output.begin(), acoustic_output.end());
  int uv_index = output_dim - 1;
  for (int i = 0; i < seqlen; ++i, uv_index += output_dim) {
    if (acoustic_output[uv_index] > kVoiceThreshold || frame_uv[i] == kVoice) {
      fea->at(uv_index) = kVoice;
    } else {
      fea->at(uv_index) = kUnvoice;
    }
  }
}

void SPSSEngine::SaveLabel(const vector<int>& durations,
                           const vector<string>& phonemes,
                           tts::RawData* raw_data) const {
  tts::VecFastAppend(phonemes, &(raw_data->phonemes));
  tts::VecFastAppend(durations, &(raw_data->durations));
}

}  // namespace spss
}  // namespace engine

#endif  // PLATFORM(GNU_LINUX_X86) || PLATFORM(NEON)
