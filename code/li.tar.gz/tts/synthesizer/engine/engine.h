// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: sxwang@mobvoi.com (Sixue Wang)

#ifndef TTS_SYNTHESIZER_ENGINE_ENGINE_H_
#define TTS_SYNTHESIZER_ENGINE_ENGINE_H_

#include <string>
#include <vector>

#include "mobvoi/base/macros.h"

#include "tts/synthesizer/proto/tts.pb.h"
#include "tts/util/tts_util/util.h"

namespace engine {

class Engine {
 public:
  Engine() {}

  // don't change this to "= default" to avoid build error in qnx
  // https://bugzilla.redhat.com/show_bug.cgi?id=831027
  virtual ~Engine() {}

  virtual bool SynthesizeFromLabel(const tts::TTSOption& tts_option,
                                   const std::vector<std::string>& labels,
                                   tts::RawData* raw_data) const = 0;

  virtual string GetEngineModelType() const = 0;

 private:
  DISALLOW_COPY_AND_ASSIGN(Engine);
};

}  // namespace engine

#endif  // TTS_SYNTHESIZER_ENGINE_ENGINE_H_
