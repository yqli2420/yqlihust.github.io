// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/synthesizer/speaker_manager.h"
#include "mobvoi/base/flags.h"

DEFINE_string(speaker_info, "external/config/config_file/tts.json",
              "speaker info json files");

int main(int argc, char** argv) {
  mobvoi::ParseCommandLineFlags(&argc, &argv, false, "");
  tts::SpeakerManager speaker(FLAGS_speaker_info);
}
