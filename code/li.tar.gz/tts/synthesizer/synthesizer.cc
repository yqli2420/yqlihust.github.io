// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/synthesizer/synthesizer.h"

#include <thread>  // NOLINT

#include "mobvoi/base/file.h"
#include "mobvoi/base/log.h"
#ifndef FOR_PORTABLE
#include "tts/server/server_util.h"
#include "tts/server/synthesizer_event.h"
#include "tts/util/soundtouch/sound_stretch.h"
#endif
DECLARE_double(lpc_sil_dur);
#ifndef FOR_PORTABLE
DECLARE_int32(flac_compression_level);
#endif

namespace tts {

DEFINE_bool(do_cache_syn, false, "if true, use prefix cache");
DEFINE_double(flac_silence, 0.6, "flac need to add 600ms silence");
DEFINE_double(mp3_silence, 0.01, "mp3 need to add 10ms silence");

static const int kBufferSize = 10240;

Synthesizer::Synthesizer(const string& speaker_info_file) {
  text_splitter_.reset(new nlp::splitter::TextSplitter());
  speaker_manager_.reset(new SpeakerManager(speaker_info_file));
  std::thread load_cache_thd(&Synthesizer::InitCacheDatas, this);
  load_cache_thd.detach();
}

Synthesizer::~Synthesizer() {}

void Synthesizer::FrontendSynthesize(const string& text,
                                     const TTSOption& tts_option,
                                     Json::Value* frontend_data) const {
  RawData raw_data;
  SynthesizeWorker(text, tts_option, &raw_data, nullptr);
  Json::Value res = InitialFrontendDataInfo(string());
  if (!raw_data.debug_infos.empty()) {
    // fixed  filter blank symbol
    string upper_text = tts::ToUpper(text);
    Json::Value blank_json(Json::arrayValue);
    size_t nonblank_head_offset = upper_text.find_first_not_of(" ");
    if (nonblank_head_offset != string::npos) {
      blank_json = ConstuctBlankOriginJson(nonblank_head_offset);
      Json::Value debug_info = raw_data.debug_infos[0];
      for (const auto origin_info : debug_info["originJson"]) {
        blank_json.append(origin_info);
      }
      raw_data.debug_infos[0]["originJson"] = blank_json;
    }
    size_t nonblank_tail_offset = upper_text.find_last_not_of(" ");
    if (nonblank_tail_offset != string::npos) {
      blank_json =
          ConstuctBlankOriginJson(text.length() - nonblank_tail_offset - 1);
      size_t debug_size = raw_data.debug_infos.size();
      Json::Value debug_info = raw_data.debug_infos[debug_size - 1];
      for (const auto origin_info : blank_json) {
        debug_info["originJson"].append(origin_info);
      }
      raw_data.debug_infos[debug_size - 1]["originJson"] =
          debug_info["originJson"];
    }
    Json::Value origin_infos(Json::arrayValue);
    Json::Value g2p_json_infos(Json::arrayValue);
    for (const auto& debug_info : raw_data.debug_infos) {
      if (!tts_option.only_frontend_tn()) {
        for (const auto& origin_info : debug_info["originJson"])
          origin_infos.append(origin_info);
      }
      if (!tts_option.for_voice_maker()) {
        res["tnText"] =
            res["tnText"].asString() + debug_info["tnText"].asString();
        res["prosodyText"] = res["prosodyText"].asString() +
                             debug_info["prosodyText"].asString();
        for (const auto& g2p_json_info : debug_info["g2pTnJson"])
          g2p_json_infos.append(g2p_json_info);
      }
    }
    // prosody of sentence end is end by #4
    res["originJson"] = origin_infos;
    for (size_t i = g2p_json_infos.size() - 1; i >= 0; i--) {
      g2p_json_infos[i]["pause_level"] = "#4";
      if (g2p_json_infos[i]["pron_of_alpha"] != "") {
        break;
      }
    }
    res["g2pTnJson"] = g2p_json_infos;
  } else {
    // ensure input & output alignment
    LOG(ERROR) << "text: " << text << " No frontend analysis result.";
  }
  if (!tts_option.for_voice_maker()) {
    res["originText"] = text;
  }
  if (tts_option.only_frontend_tn() && raw_data.debug_infos.size() == 1) {
    res["originTnlistJson"] = raw_data.debug_infos[0]["originTnlistJson"];
    res["originTnlistJson"]["text"] = text;
  }
  *frontend_data = res;
}

void Synthesizer::Synthesize(const string& text, const TTSOption& tts_option,
                             string* data_res,
                             shared_ptr<Engine> custom_engine) const {
  RawData raw_data;
  SynthesizeWorker(text, tts_option, &raw_data, nullptr, custom_engine);
  float volume =
      tts_option.volume() * speaker_manager_->GetVolume(tts_option.speaker());
  encoder::PostProcessOption pp_option(
      kDefaultSamplingFrequency, tts_option.sampling_frequency(),
      kNoNormalizeFactor, volume, tts_option.file_format());
#ifndef FOR_PORTABLE
  encoder::FlacEncoder encoder;
  FLAC__byte buffer[kBufferSize];
  encoder.Reset(buffer, kBufferSize, tts_option.sampling_frequency(),
                FLAGS_flac_compression_level);
  if (pp_option.file_format.find("flac") != string::npos &&
      raw_data.data.empty()) {
    raw_data.data.insert(raw_data.data.end(),
                         kDefaultSamplingFrequency * FLAGS_flac_silence, 0);
    encoder::PostProcessFlac(raw_data.data, pp_option, &encoder, data_res);
  } else {
    if (pp_option.file_format.find("mp3") != string::npos &&
        raw_data.data.empty()) {
      raw_data.data.insert(raw_data.data.end(),
                           kDefaultSamplingFrequency * FLAGS_mp3_silence, 0);
    }
    encoder::PostProcess(raw_data.data, pp_option, data_res);
  }
#else
  encoder::PostProcess(raw_data.data, pp_option, data_res);
#endif
  JsonWrapper(raw_data, tts_option, data_res);
}

void Synthesizer::Synthesize(const string& text, const TTSOption& tts_option,
                             vector<int16>* data) const {
  RawData raw_data;
  SynthesizeWorker(text, tts_option, &raw_data, nullptr);
  VecFastAppend(raw_data.data, data);
}

void Synthesizer::Synthesize(const std::string& text,
                             const TTSOption& tts_option,
                             SynthesizerEventInterface* callback,
                             shared_ptr<Engine> custom_engine) const {
  if (callback == nullptr) {
    LOG(ERROR) << "callback is nullptr";
    return;
  }
  callback->OnStart();
  if (tts_option.file_format() == "wav") {
    LOG(ERROR) << "Streaming play do not support wav format";
    callback->OnFinish();
    return;
  }

  RawData raw_data;
#ifndef FOR_PORTABLE
  if (tts_option.insert_audio()) {
    vector<int16> pcm_res_tmp;
    encoder::FlacEncoder encoder;
    FLAC__byte buffer[kBufferSize];
    encoder.Reset(buffer, kBufferSize, tts_option.sampling_frequency(),
                  FLAGS_flac_compression_level);
    RawData tmp_data;
    if (server::ServerUtil::GetAudio(
            server::AudioParams(text, tts_option.audio_volume(),
                                tts_option.audio_is_id()),
            &pcm_res_tmp)) {
      tmp_data.data = pcm_res_tmp;
    }
    CollectData(tts_option, &raw_data, &encoder, &tmp_data, callback);
  } else {
    SynthesizeWorker(text, tts_option, &raw_data, callback, custom_engine);
  }
#else
  SynthesizeWorker(text, tts_option, &raw_data, callback, custom_engine);
#endif
  if (tts_option.last_sentence()) callback->OnFinish();
}

vector<std::pair<string, bool>> Synthesizer::GetSpeakers(
    const string& language) const {
  return speaker_manager_->GetSpeakers(language);
}

bool Synthesizer::LoadSpeaker(const string& speaker) {
  if (!speaker_manager_->LoadSpeaker(speaker)) return false;
  PrepareCacheData(speaker);
  return true;
}

bool Synthesizer::CheckSpeaker(const string& speaker) {
  return speaker_manager_->CheckSpeaker(speaker);
}

bool Synthesizer::UnloadSpeaker(const string& speaker) {
  return speaker_manager_->UnloadSpeaker(speaker);
}

void Synthesizer::InitCacheDatas() {
  vector<string> languages = GetSupLanguages();
  for (const auto& language : languages) {
    vector<std::pair<string, bool>> speakers = GetSpeakers(language);
    for (const auto& speaker : speakers) {
      if (speaker.second) PrepareCacheData(speaker.first);
    }
  }
}

vector<string> Synthesizer::GetSupLanguages() const {
  return speaker_manager_->GetSupLanguages();
}

void Synthesizer::TextSplit(const vector<SsmlText>& text,
                            const TTSOption& tts_option,
                            vector<vector<SsmlText>>* split_texts) const {
  vector<SsmlText> text_append_sil(text);
  if (tts_option.append_sil()) {
    text_append_sil.insert(text_append_sil.begin(),
                           SsmlParser::Instance().GenBreakSsmlText());
    text_append_sil.insert(text_append_sil.end(),
                           SsmlParser::Instance().GenBreakSsmlText());
  }
  uint32_t text_size = kTextMaxBatchSize;
  if (tts_option.split_bylen()) {
    text_size = speaker_manager_->GetLanguage(tts_option.speaker()) ==
                        kEnglishTypeString
                    ? kEnglishTextBatchSize
                    : kMandarinTextBatchSize;
  }
  text_splitter_->TextSplit(text_append_sil, text_size, tts_option.break_time(),
                            split_texts);
}

void Synthesizer::CheckSpeakerForTacotron(
    const vector<vector<SsmlText>>& split_texts, TTSOption* tts_option) const {
  // text contain °C °F should not change to cissy_gru
  static re2::RE2 obj("(^|[^A-Za-z])[^°][A-Z]+([^A-Za-z]|$)");
  if (tts_option->speaker() == "cissy_taco") {
    for (const auto& split_text : split_texts) {
      for (const auto& ssml_text : split_text) {
        if (re2::RE2::PartialMatch(ssml_text.text, obj)) {
          VLOG(2) << "set speaker to cissy gru";
          tts_option->set_speaker("cissy");
          return;
        }
      }
    }
  }
}

void Synthesizer::PrepareCacheData(const string& speaker) {
  if (!FLAGS_do_cache_syn) return;
  LOG(INFO) << "prepare cache data: " << speaker;
  map<string, vector<int16>> cache_datas;
  if (!speaker_manager_->GetCacheData(speaker, &cache_datas)) return;

  for (auto it : cache_datas) {
    if (!it.second.empty()) continue;
    string text = it.first;
    VLOG(2) << "prepare cache text: " << text;
    vector<int16> cache_data;
    TTSOption tts_option;
    SetDefaultTTSOption(&tts_option);
    tts_option.set_speaker(speaker);
    Synthesize(text, tts_option, &cache_data);
    speaker_manager_->SetSpeakerCache(speaker, text, cache_data);
  }
  LOG(INFO) << "prepare cache data finish";
}

void Synthesizer::GetLabelOption(const TTSOption& tts_option, bool last_seg,
                                 LabelOption* label_option) const {
  // <TODO>:ranzhang support english
  label_option->set_speaker(tts_option.speaker());
  label_option->set_adjust_label(true);
  label_option->set_use_robot(tts_option.use_robot());
  label_option->set_domain(tts_option.domain());
  label_option->set_use_erhua(
      speaker_manager_->IsSupportErhua(label_option->speaker()));
  label_option->set_language(
      speaker_manager_->GetLanguage(label_option->speaker()));
  label_option->set_last_seg(last_seg);
  label_option->set_only_frontend(tts_option.only_frontend());
  label_option->set_only_frontend_tn(tts_option.only_frontend_tn());
  label_option->set_frontend_type(tts_option.frontend_type());
  label_option->set_for_voice_maker(tts_option.for_voice_maker());
  label_option->set_break_time(tts_option.break_time());
  label_option->set_user_dict(tts_option.user_dict());
  label_option->set_tone_rule(tts_option.tone_rule());
}

bool Synthesizer::GenLabels(const vector<SsmlText>& text,
                            const TTSOption& tts_option, bool last_seg,
                            vector<string>* label_data, Json::Value* debug_info,
                            TnDetail* detail) const {
  string language = speaker_manager_->GetLanguage(tts_option.speaker());
  std::shared_ptr<LabelGenerator> label_generator =
      speaker_manager_->GetLabelGenerator(language);
  LabelOption label_option;
  GetLabelOption(tts_option, last_seg, &label_option);
  return label_generator->GenLabels(text, label_option, true /*online*/,
                                    label_data, debug_info, detail);
}

bool Synthesizer::CollectData(const TTSOption& tts_option, RawData* raw_data,
#ifndef FOR_PORTABLE
                              encoder::FlacEncoder* encoder,
#endif
                              RawData* tmp_data,
                              SynthesizerEventInterface* callback) const {
  if (callback) {
#ifndef FOR_PORTABLE
    string duration = std::to_string(tmp_data->data.size() * 1000 /
                                     tts_option.sampling_frequency());
    callback->GetChunkDuration(duration);
    if (tts_option.pitch()) {
      tts::SoundStretch sound_stretch(tts_option.sampling_frequency(), 0,
                                      tts_option.pitch(), 0, true, false, true);
      sound_stretch.Process(&tmp_data->data);
    }
    vector<int16> bgm_data;
    int bgm_beg = tts_option.bgm_offset() + callback->GetBgmOffset();
    if (!tts_option.bgm().empty() && !tts_option.insert_audio() &&
        server::ServerUtil::GetBgm(tts_option.bgm(), &bgm_data)) {
      tts::WaveFile::AudioMix(bgm_data, tts_option.volume(),
                              tts_option.bgm_volume(), bgm_beg,
                              &tmp_data->data);
    }
#endif
    vector<int16> samples;
    samples.reserve(tmp_data->data.size());
    samples.insert(samples.begin(), tmp_data->data.begin(),
                   tmp_data->data.end());
    if (tts_option.speaker() == "billy" || tts_option.speaker() == "emily" ||
        tts_option.speaker() == "lucy" || tts_option.speaker() == "angela") {
      samples.resize(samples.size() -
                     FLAGS_lpc_sil_dur * tts::kDefaultSamplingFrequency);
    }
    string data_res;
    float volume = tts_option.insert_audio()
                       ? tts_option.audio_volume()
                       : tts_option.volume() *
                             speaker_manager_->GetVolume(tts_option.speaker());
    encoder::PostProcessOption pp_option(
        kDefaultSamplingFrequency, tts_option.sampling_frequency(),
        kNoNormalizeFactor, volume, tts_option.file_format());
#ifndef FOR_PORTABLE
    if (pp_option.file_format.find("flac") != string::npos) {
      encoder::PostProcessFlac(samples, pp_option, encoder, &data_res);
    } else {
      encoder::PostProcess(samples, pp_option, &data_res);
    }
    callback->SetBgmOffset(samples.size());
#else
    encoder::PostProcess(samples, pp_option, &data_res);
#endif
    return callback->OnSynthesizeData(data_res);
  } else {
    AppendRawData(*tmp_data, raw_data);
    return true;
  }
}

// return false to cancel
bool Synthesizer::TryPrefixCache(vector<SsmlText>* ssml_texts,
                                 const TTSOption& tts_option,
#ifndef FOR_PORTABLE
                                 encoder::FlacEncoder* encoder,
#endif
                                 RawData* raw_data,
                                 SynthesizerEventInterface* callback) const {
  // check ssml text valid
  if (ssml_texts->empty() || !ssml_texts->at(0).tag.name.empty()) return true;
  string first_context = ssml_texts->at(0).text;

  // check cache text exist
  string speaker = tts_option.speaker();
  map<string, vector<int16>> cache_datas;
  if (!speaker_manager_->GetCacheData(speaker, &cache_datas)) return true;
  for (auto try_it : cache_datas) {
    string try_text = try_it.first;
    auto index = first_context.find(try_text);
    if (index == 0) {
      if (try_it.second.empty()) continue;
      callback->set_use_cache(true);
      LOG(INFO) << "match prefix cache: " << try_it.first;
      ssml_texts->at(0).text = first_context.substr(try_text.size());
      RawData tmp_data;
      tmp_data.data = try_it.second;
#ifndef FOR_PORTABLE
      return CollectData(tts_option, raw_data, encoder, &tmp_data, callback);
#else
      return CollectData(tts_option, raw_data, &tmp_data, callback);
#endif
    }
  }
  return true;
}

void Synthesizer::SynthesizeWorker(const string& text,
                                   const TTSOption& tts_option,
                                   RawData* raw_data,
                                   SynthesizerEventInterface* callback,
                                   shared_ptr<Engine> custom_engine) const {
  string speaker = tts_option.speaker();
  if (!speaker_manager_->CheckSpeaker(speaker)) return;

  vector<SsmlText> ssml_texts;
  SsmlParser::Instance().ParseText(text, &ssml_texts);
#ifndef FOR_PORTABLE
  encoder::FlacEncoder encoder;
  FLAC__byte buffer[kBufferSize];
  encoder.Reset(buffer, kBufferSize, tts_option.sampling_frequency(),
                FLAGS_flac_compression_level);
#endif

  // prefix cache only for streaming tts
  if (callback != nullptr && custom_engine == nullptr &&
      !tts_option.use_robot() && tts_option.speed() == kDefaultSpeed) {
#ifndef FOR_PORTABLE
    if (!TryPrefixCache(&ssml_texts, tts_option, &encoder, raw_data, callback))
      return;
#else
    if (!TryPrefixCache(&ssml_texts, tts_option, raw_data, callback)) return;
#endif
  }

  vector<vector<SsmlText>> split_texts;
  TextSplit(ssml_texts, tts_option, &split_texts);
  // backdoor to choose gru instead of tacotron model to avoid lossing word
  TTSOption tts_option_tmp(tts_option);
  CheckSpeakerForTacotron(split_texts, &tts_option_tmp);

  for (size_t i = 0; i < split_texts.size(); ++i) {
    bool last_seg = (i == split_texts.size() - 1);
#ifndef FOR_PORTABLE
    if (!SynthesizeWorker(split_texts[i], tts_option_tmp, last_seg, &encoder,
                          raw_data, callback, custom_engine)) {
      return;
    }
#else
    if (!SynthesizeWorker(split_texts[i], tts_option_tmp, last_seg, raw_data,
                          callback, custom_engine)) {
      return;
    }
#endif
  }

#ifndef FOR_PORTABLE
  if (callback != nullptr &&
      (tts_option.file_format().find("flac") != string::npos ||
       tts_option.file_format().find("mp3") != string::npos)) {
    float volume =
        tts_option.volume() * speaker_manager_->GetVolume(tts_option.speaker());
    encoder::PostProcessOption pp_option(
        kDefaultSamplingFrequency, tts_option.sampling_frequency(),
        kNoNormalizeFactor, volume, tts_option.file_format());
    string data_res;
    string duration = std::to_string(raw_data->data.size() * 1000 /
                                     tts_option.sampling_frequency());
    callback->GetChunkDuration(duration);
    if (callback->GetResult().empty()) {
      if (tts_option.file_format().find("flac") != string::npos) {
        raw_data->data.insert(raw_data->data.end(),
                              kDefaultSamplingFrequency * FLAGS_flac_silence,
                              0);
        encoder::PostProcessFlac(raw_data->data, pp_option, &encoder,
                                 &data_res);
      } else {
        raw_data->data.insert(raw_data->data.end(),
                              kDefaultSamplingFrequency * FLAGS_mp3_silence, 0);
        encoder::PostProcess(raw_data->data, pp_option, &data_res);
      }
    }
    callback->OnSynthesizeData(data_res);
    encoder.Finish();
    callback->OnSynthesizeData(encoder.GetAvailableEncodedData());
  }
#endif
}

bool Synthesizer::SynthesizeWorker(const vector<SsmlText>& split_text,
                                   const TTSOption& tts_option, bool last_seg,
#ifndef FOR_PORTABLE
                                   encoder::FlacEncoder* encoder,
#endif
                                   RawData* raw_data,
                                   SynthesizerEventInterface* callback,
                                   shared_ptr<Engine> custom_engine) const {
  if (split_text.size() == 1 && split_text[0].tag.name == kSsmlBreakKey) {
    float break_time = ParseBreakTime(split_text[0]);
    RawData tmp_data;
    tmp_data.data.insert(tmp_data.data.end(),
                         kDefaultSamplingFrequency * break_time, 0);
#ifndef FOR_PORTABLE
    return CollectData(tts_option, raw_data, encoder, &tmp_data, callback);
#else
    return CollectData(tts_option, raw_data, &tmp_data, callback);
#endif
  }

  vector<string> label_data;
  Json::Value debug_info;
  TnDetail detail;
  if (!GenLabels(split_text, tts_option, last_seg, &label_data, &debug_info,
                 &detail) ||
      label_data.empty()) {
    LOG(WARNING) << "label list is empty.";
    if (!debug_info.empty()) {
      raw_data->debug_infos.emplace_back(debug_info);
    }
    return true;
  }
  detail.Display();
  raw_data->tn_details.emplace_back(detail);
  raw_data->debug_infos.emplace_back(debug_info);
  if (tts_option.only_frontend()) {
    LOG(INFO) << "skip wav synthesis";
    return true;
  }

  string language = speaker_manager_->GetLanguage(tts_option.speaker());
  vector<vector<string>> label_parts;
  SplitLabelsByLP(label_data, language, &label_parts);
  for (const vector<string>& label_part : label_parts) {
    vector<string> languages;
    vector<vector<string>> language_labels;
    if (!speaker_manager_->IsSupportEn(tts_option.speaker())) {
      SplitLabelsByLanguage(label_part, &languages, &language_labels);
    } else {
      languages.emplace_back(language);
      language_labels.emplace_back(label_part);
    }
    for (size_t i = 0; i < language_labels.size(); ++i) {
      if (VLOG_IS_ON(2)) {
        LOG(INFO) << languages[i];
        for (size_t j = 0; j < language_labels[i].size(); ++j) {
          LOG(INFO) << language_labels[i][j];
        }
      }
      RawData tmp_data;
#ifndef FOR_PORTABLE
      SynthesizeData(languages[i], tts_option, language_labels[i], encoder,
                     &tmp_data, callback, custom_engine);
#else
      SynthesizeData(languages[i], tts_option, language_labels[i], &tmp_data,
                     callback, custom_engine);
#endif

      if ((tts_option.file_format().find("streaming") == string::npos) ||
          (callback == nullptr)) {
#ifndef FOR_PORTABLE
        if (!CollectData(tts_option, raw_data, encoder, &tmp_data, callback)) {
          LOG(INFO) << "cancel synthesizing";
          return false;
        }
#else
        if (!CollectData(tts_option, raw_data, &tmp_data, callback)) {
          LOG(INFO) << "cancel synthesizing";
          return false;
        }
#endif
      }
    }
  }
  return true;
}

bool Synthesizer::SynthesizeData(const string& language,
                                 const TTSOption& tts_option,
                                 const vector<string>& labels,
#ifndef FOR_PORTABLE
                                 encoder::FlacEncoder* encoder,
#endif
                                 RawData* result_data,
                                 SynthesizerEventInterface* callback,
                                 shared_ptr<Engine> custom_engine) const {
  string speaker = tts_option.speaker();
  if (language == kEnglishTypeString &&
      !speaker_manager_->IsSupportEn(tts_option.speaker())) {
    LOG(INFO) << speaker << " do not speaker English ,switch to angela ";
#ifndef FOR_PORTABLE
    speaker = "angela_gru";
#else
#ifdef FOR_CNS
    speaker = "angela";
#else
    speaker = "angela_hts";
#endif  // FOR_CNS
#endif  // FOR_PORTABLE
  }
  if (!speaker_manager_->CheckSpeaker(speaker)) return false;
  std::shared_ptr<engine::Engine> engine = speaker_manager_->GetEngine(speaker);
  if (custom_engine != nullptr) engine = custom_engine;
  RawData temp_data;
  if (engine == nullptr ||
      !engine->SynthesizeFromLabel(tts_option, labels, &temp_data)) {
    return false;
  }
  std::shared_ptr<vocoder::Vocoder> vocoder;
  if (engine->GetEngineModelType().find("straight") != string::npos) {
    vocoder = vocoder::VocoderFactory::Instance().Create("straight", "");
  } else {
    vocoder = speaker_manager_->GetVocoder(speaker);
  }

  if (vocoder == nullptr) return false;
  if ((tts_option.file_format().find("streaming") != string::npos) &&
      (callback != nullptr)) {
#ifndef FOR_PORTABLE
    VLOG(2) << "using vocoder callback";
    if (!vocoder->Synthesize(temp_data.feature, tts_option,
                             speaker_manager_->GetVolume(speaker), encoder,
                             callback)) {
      return false;
    }
#endif
  } else {
    if (!tts_option.alignment() &&
        !vocoder->Synthesize(temp_data.feature, tts_option,
                             &(temp_data.data))) {
      return false;
    }
    AppendRawData(temp_data, result_data);
  }

  return true;
}

}  // namespace tts
