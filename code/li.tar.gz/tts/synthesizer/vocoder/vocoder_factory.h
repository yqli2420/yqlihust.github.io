// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: ranzhang@mobvoi.com (Dylan)

#ifndef TTS_SYNTHESIZER_VOCODER_VOCODER_FACTORY_H_
#define TTS_SYNTHESIZER_VOCODER_VOCODER_FACTORY_H_

#include "mobvoi/base/macros.h"

#include "tts/synthesizer/proto/tts.pb.h"
#include "tts/synthesizer/vocoder/lpc_vocoder/lpc_vocoder.h"
#include "tts/synthesizer/vocoder/vocoder.h"
#include "tts/util/tts_util/util.h"

#ifndef FOR_PORTABLE
#include "tts/synthesizer/vocoder/straight_vocoder/straight_vocoder.h"
#endif

namespace vocoder {

class VocoderFactory {
 public:
  static VocoderFactory& Instance();
  shared_ptr<Vocoder> Create(const string& vocoder_type,
                             const string& vocoder_path);

 private:
  VocoderFactory();
  shared_ptr<LpcVocoder> lpc_vocoder_;
#ifndef FOR_PORTABLE
  shared_ptr<StraightVocoder> straight_vocoder_;
#endif
  DISALLOW_COPY_AND_ASSIGN(VocoderFactory);
};
}  // namespace vocoder
#endif  // TTS_SYNTHESIZER_VOCODER_VOCODER_FACTORY_H_
