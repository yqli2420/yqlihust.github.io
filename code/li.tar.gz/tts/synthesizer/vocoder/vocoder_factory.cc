// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: ranzhang@mobvoi.com (Dylan)

#include "tts/synthesizer/vocoder/vocoder_factory.h"
#include "tts/synthesizer/vocoder/lpc_vocoder/lpc_vocoder.h"

#ifndef FOR_PORTABLE
#include "tts/synthesizer/vocoder/lpcnet_vocoder/lpcnet_vocoder.h"
#include "tts/synthesizer/vocoder/melgan_vocoder/melgan_vocoder.h"
#endif

namespace vocoder {

static const int kSamplingRate = 16000;
static const int kFrameLength = 80;
static const string kLpcVocoder = "lpc";            // NOLINT
static const string kLpcNetVocoder = "lpcnet";      // NOLINT
static const string kStraightVocoder = "straight";  // NOLINT
static const string kMelGANVocoder = "melgan";      // NOLINT

VocoderFactory& VocoderFactory::Instance() {
  static VocoderFactory instance;
  return instance;
}

VocoderFactory::VocoderFactory() {
  lpc_vocoder_.reset(new LpcVocoder(kSamplingRate, kFrameLength));
#ifndef FOR_PORTABLE
  straight_vocoder_.reset(new StraightVocoder(kSamplingRate, kFrameLength));
#endif
}

shared_ptr<Vocoder> VocoderFactory::Create(const string& vocoder_type,
                                           const string& vocoder_path) {
  shared_ptr<Vocoder> vocoder = nullptr;
  if (vocoder_type == kLpcVocoder) {
    return std::static_pointer_cast<Vocoder>(lpc_vocoder_);
  } else if (vocoder_type == kLpcNetVocoder) {
#ifndef FOR_PORTABLE
    return std::static_pointer_cast<Vocoder>(
        std::make_shared<LpcNetVocoder>(vocoder_path));
#endif
  } else if (vocoder_type == kStraightVocoder) {
#ifndef FOR_PORTABLE
    return std::static_pointer_cast<Vocoder>(straight_vocoder_);
#endif
  } else if (vocoder_type == kMelGANVocoder) {
#ifndef FOR_PORTABLE
    return std::static_pointer_cast<Vocoder>(
        std::make_shared<MelGANVocoder>(vocoder_path));
#endif
  }

  return vocoder;
}

}  // namespace vocoder
