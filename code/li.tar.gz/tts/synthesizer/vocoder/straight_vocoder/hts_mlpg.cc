// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng Yang)

#include "tts/synthesizer/vocoder/straight_vocoder/hts_mlpg.h"
#include "mobvoi/base/log.h"
#include "tts/synthesizer/vocoder/straight_vocoder/hts_misc.h"

DWin_CLASS::DWin_CLASS() {
  int i, j, k;
  int fsize, leng;
  int maxw[2];

  int a[3] = {1, 3, 3};
  float b[7] = {1.0, -0.5, 0.0, 0.5, 1.0, -2.0, 1.0};

  num = 3;

  /* memory allocation */
  width = reinterpret_cast<int **>(HTS_Calloc(num, sizeof(int *)));
  for (i = 0; i < num; i++)
    width[i] = reinterpret_cast<int *>(HTS_Calloc(2, sizeof(int)));
  coef = reinterpret_cast<float **>(HTS_Calloc(num, sizeof(float *)));

  /* set window coefficients */
  for (i = 0, k = 0; i < num; i++) {
    fsize = a[i];
    coef[i] = reinterpret_cast<float *>(HTS_Calloc(fsize, sizeof(float)));
    for (j = 0; j < fsize; j++) coef[i][j] = b[k++];

    /* set pointer */
    leng = fsize / 2;
    coef[i] += leng;
    width[i][WLEFT] = -leng;
    width[i][WRIGHT] = leng;
    if (fsize % 2 == 0) width[i][WRIGHT]--;
  }

  maxw[WLEFT] = maxw[WRIGHT] = 0;
  for (i = 0; i < num; i++) {
    if (maxw[WLEFT] > width[i][WLEFT]) maxw[WLEFT] = width[i][WLEFT];
    if (maxw[WRIGHT] < width[i][WRIGHT]) maxw[WRIGHT] = width[i][WRIGHT];
  }

  /* calcurate max_L to determine size of band matrix */
  if (maxw[WLEFT] >= maxw[WRIGHT])
    max_L = maxw[WLEFT];
  else
    max_L = maxw[WRIGHT];
}
/* DWin: Initialise window coefficients */
DWin_CLASS::DWin_CLASS(char *head) {
  int i, j;
  int fsize, leng;
  int maxw[2];
  char *fname;
  FILE *fp;

  fname = reinterpret_cast<char *>(HTS_Calloc(strlen(head) + 3, sizeof(char)));
  for (num = 0;; num++) {
    snprintf(fname, sizeof(fname), "%s%d", head, num + 1);
    if ((fp = fopen(fname, "rt")) == NULL) break;
    fclose(fp);
  }
  if (num == 0) HTS_Error(1, "DWIn: can't open file: %s%d", head, 1);

  /* memory allocation */
  width = reinterpret_cast<int **>(HTS_Calloc(num, sizeof(int *)));
  for (i = 0; i < num; i++)
    width[i] = reinterpret_cast<int *>(HTS_Calloc(2, sizeof(int)));
  coef = reinterpret_cast<float **>(HTS_Calloc(num, sizeof(float *)));

  /* set window coefficients */
  for (i = 0; i < num; i++) {
    /* open window file */
    snprintf(fname, sizeof(fname), "%s%d", head, i + 1);
    fp = HTS_Getfp(fname, "rt");
    /* check the number of coefficients */
    fscanf(fp, "%d", &fsize);
    if (fsize < 1)
      HTS_Error(1, "InitDWIn: number of coefficients in %s is invalid", fname);
    /* read coefficients */
    coef[i] = reinterpret_cast<float *>(HTS_Calloc(fsize, sizeof(float)));
    for (j = 0; j < fsize; j++) fscanf(fp, "%lf", &(coef[i][j]));
    /* close window file */
    fclose(fp);

    /* set pointer */
    leng = fsize / 2;
    coef[i] += leng;
    width[i][WLEFT] = -leng;
    width[i][WRIGHT] = leng;
    if (fsize % 2 == 0) width[i][WRIGHT]--;
  }

  maxw[WLEFT] = maxw[WRIGHT] = 0;
  for (i = 0; i < num; i++) {
    if (maxw[WLEFT] > width[i][WLEFT]) maxw[WLEFT] = width[i][WLEFT];
    if (maxw[WRIGHT] < width[i][WRIGHT]) maxw[WRIGHT] = width[i][WRIGHT];
  }

  /* calcurate max_L to determine size of band matrix */
  if (maxw[WLEFT] >= maxw[WRIGHT])
    max_L = maxw[WLEFT];
  else
    max_L = maxw[WRIGHT];

  // memory free
  HTS_Free(fname);
  fname = NULL;
}

/* DWin: free regression window */
DWin_CLASS::~DWin_CLASS() {
  int i;

  /* free window */
  if (coef != NULL) {
    for (i = num - 1; i >= 0; i--) {
      coef[i] += width[i][WLEFT];
      HTS_Free(coef[i]);
    }
    HTS_Free(coef);
    coef = NULL;
  }

  if (width != NULL) {
    for (i = num - 1; i >= 0; i--) HTS_Free(width[i]);
    HTS_Free(width);
    width = NULL;
  }
}

GVPDF_CLASS::GVPDF_CLASS() {
  mean = NULL;
  var = NULL;
}

GVPDF_CLASS::GVPDF_CLASS(char *file, int dim) {
  int i;
  float temp;
  FILE *fp;

  mean = NULL;
  var = NULL;

  if ((fp = fopen(file, "rb")) != NULL) {
    mean = reinterpret_cast<float *>(HTS_Calloc(dim, sizeof(float)));
    var = reinterpret_cast<float *>(HTS_Calloc(dim, sizeof(float)));

    fseek(fp, 2 * sizeof(int), SEEK_SET);

    for (i = 0; i < dim; i++) {
      if (HTS_Fread(&temp, sizeof(float), 1, fp) != 1)
        HTS_Error(1, "GVPDF: number of dimensions in %s is invalid", file);
      mean[i] = static_cast<float>(temp);
    }
    for (i = 0; i < dim; i++) {
      if (HTS_Fread(&temp, sizeof(float), 1, fp) != 1)
        HTS_Error(1, "GVPDF: number of dimensions in %s is invalid", file);
      if (temp <= 0.0) HTS_Error(1, "GVPDF: variance in %s is invalid", file);
      var[i] = 1.0 / static_cast<float>(temp);
    }
    fclose(fp);
  } else {
    LOG(ERROR) << "can not open the file of gv ";
  }
}

GVPDF_CLASS::~GVPDF_CLASS() {
  if (mean != NULL) {
    HTS_Free(mean);
    mean = NULL;
  }
  if (var != NULL) {
    HTS_Free(var);
    var = NULL;
  }
}

SMatrices_CLASS::SMatrices_CLASS(const int T, const int width) {
  R = HTS_AllocMatrix(T, width);
  r = HTS_AllocVector(T);
  g = HTS_AllocVector(T);
  b = HTS_AllocVector(T);
}

SMatrices_CLASS::~SMatrices_CLASS() {
  if (R != NULL || r != NULL || g != NULL || b != NULL)
    HTS_Error(1, "SMatrices: memory should be free.\n");
}

void SMatrices_CLASS::clean(const int T) {
  HTS_FreeMatrix(R, T);
  R = NULL;
  HTS_FreeVector(r);
  r = NULL;
  HTS_FreeVector(g);
  g = NULL;
  HTS_FreeVector(b);
  b = NULL;
}

PStream_CLASS::PStream_CLASS(const int size, const int t, DWin dwin,
                             GVPDF gvpdf) {
  vSize = size;
  dw = dwin;
  dim = vSize / dw->num;
  width = dw->max_L * 2 + 1;
  vm = NULL;
  vv = NULL;
  if (gvpdf != NULL) {
    if (gvpdf->mean != NULL && gvpdf->var != NULL) {
      vm = gvpdf->mean;
      vv = gvpdf->var;
    }
  }
  T = t;
  sm = new SMatrices_CLASS(T, width);
  mseq = HTS_AllocMatrix(T, vSize);
  ivseq = HTS_AllocMatrix(T, vSize);
  par = HTS_AllocMatrix(T, dim);
}

PStream_CLASS::~PStream_CLASS() {
  dw = NULL;
  vm = NULL;
  vv = NULL;
  sm->clean(T);
  delete sm;
  sm = NULL;
  HTS_FreeMatrix(mseq, T);
  mseq = NULL;
  HTS_FreeMatrix(ivseq, T);
  ivseq = NULL;
  HTS_FreeMatrix(par, T);
  par = NULL;
}

/*------ parameter generation fuctions */
/* calc_R_and_r : calculate R=W'U^{-1}W and r=W'U^{-1}M */
void PStream_CLASS::calc_R_and_r(const int m) {
  register int i, j, k, l, n;
  float wu;

  for (i = 0; i < T; i++) {
    sm->r[i] = ivseq[i][m] * mseq[i][m];
    sm->R[i][0] = ivseq[i][m];

    for (j = 1; j < width; j++) sm->R[i][j] = 0.0;
    for (j = 1; j < dw->num; j++) {
      for (k = dw->width[j][0]; k <= dw->width[j][1]; k++) {
        n = i + k;
        if ((n >= 0) && (n < T) && (dw->coef[j][-k] != 0.0)) {
          l = j * dim + m;
          wu = dw->coef[j][-k] * ivseq[n][l];
          sm->r[i] += wu * mseq[n][l];
          for (l = 0; l < width; l++) {
            n = l - k;
            if ((n <= dw->width[j][1]) && (i + l < T) &&
                (dw->coef[j][n] != 0.0))
              sm->R[i][l] += wu * dw->coef[j][n];
          }
        }
      }
    }
  }

  return;
}

/* Cholesky : Cholesky factorization of Matrix R */
void PStream_CLASS::Cholesky() {
  register int t, j, k;

  sm->R[0][0] = sqrt(sm->R[0][0]);

  for (j = 1; j < width; j++) sm->R[0][j] /= sm->R[0][0];

  for (t = 1; t < T; t++) {
    for (j = 1; j < width; j++)
      if (t - j >= 0) sm->R[t][0] -= sm->R[t - j][j] * sm->R[t - j][j];
    sm->R[t][0] = sqrt(sm->R[t][0]);

    for (j = 1; j < width; j++) {
      for (k = 0; k < dw->max_L; k++)
        if (j != width - 1)
          sm->R[t][j] -= sm->R[t - k - 1][j - k] * sm->R[t - k - 1][j + 1];
      sm->R[t][j] /= sm->R[t][0];
    }
  }

  return;
}

/* Cholesky_forward : forward substitution to solve linear equations */
void PStream_CLASS::Cholesky_forward() {
  register int t, j;
  float hold;

  sm->g[0] = sm->r[0] / sm->R[0][0];

  for (t = 1; t < T; t++) {
    hold = 0.0;
    for (j = 1; j < width; j++) {
      if (t - j >= 0 && sm->R[t - j][j] != 0.0)
        hold += sm->R[t - j][j] * sm->g[t - j];
    }
    sm->g[t] = (sm->r[t] - hold) / sm->R[t][0];
  }

  return;
}

/* Cholesky_backward : backward substitution to solve linear equations */
void PStream_CLASS::Cholesky_backward(const int m) {
  register int t, j;
  float hold;

  par[T - 1][m] = sm->g[T - 1] / sm->R[T - 1][0];

  for (t = T - 2; t >= 0; t--) {
    hold = 0.0;
    for (j = 1; j < width; j++) {
      if (t + j < T && sm->R[t][j] != 0.0) hold += sm->R[t][j] * par[t + j][m];
    }
    par[t][m] = static_cast<float>(((sm->g[t] - hold) / sm->R[t][0]));
  }

  return;
}

/* generate parameter sequence from pdf sequence */
void PStream_CLASS::mlpg() {
  int m;

  for (m = 0; m < dim; m++) {
    calc_R_and_r(m);
    Cholesky();
    Cholesky_forward();
    Cholesky_backward(m);
  }

  return;
}

void PStream_CLASS::calc_varstats(float **c, const int m, float *av,
                                  float *var) {
  register int i;
  register float d;

  *av = 0.0;
  *var = 0.0;
  for (i = 0; i < T; i++) *av += c[i][m];
  *av /= static_cast<float>(T);
  for (i = 0; i < T; i++) {
    d = c[i][m] - *av;
    *var += d * d;
  }
  *var /= static_cast<float>(T);

  return;
}

void PStream_CLASS::calc_varstats(const int m, float *av, float *var) {
  register int i;
  register float d;

  *av = 0.0;
  *var = 0.0;
  for (i = 0; i < T; i++) *av += par[i][m];
  *av /= static_cast<float>(T);
  for (i = 0; i < T; i++) {
    d = par[i][m] - *av;
    *var += d * d;
    sm->b[i] = d;
  }
  *var /= static_cast<float>(T);

  return;
}

/*setting the inintial trajectory*/
void PStream_CLASS::varconv(float **c, const int m, const float var) {
  register int n;
  float sd, osd;
  float oav = 0.0, ovar = 0.0;

  calc_varstats(c, m, &oav, &ovar);
  osd = sqrt(ovar);
  sd = sqrt(var);
  for (n = 0; n < T; n++) c[n][m] = (c[n][m] - oav) / osd * sd + oav;

  return;
}

// calc_grad: calculate -RX + r = -W'U^{-1}W * X + W'U^{-1}M
void PStream_CLASS::calc_grad(const int m) {
  register int i, j;

  for (i = 0; i < T; i++) {
    sm->g[i] = sm->r[i] - par[i][m] * sm->R[i][0];
    for (j = 1; j < width; j++) {
      if (i + j < T) sm->g[i] -= par[i + j][m] * sm->R[i][j];
      if (i - j >= 0) sm->g[i] -= par[i - j][m] * sm->R[i - j][j];
    }
  }

  return;
}

void PStream_CLASS::calc_vargrad(const int m, const float alpha,
                                 const float n) {
  register int i;
  float vg, w1, w2;
  float av = 0.0, var = 0.0;

  if (alpha > 1.0 || alpha < 0.0) {
    w1 = 1.0;
    w2 = 1.0;
  } else {
    w1 = alpha;
    w2 = 1.0 - alpha;
  }

  /*if(alpha==2) {w2=0.5;w1=1.0;}
  */

  calc_varstats(par, m, &av, &var);

  for (i = 0; i < T; i++) {
    vg = -(var - vm[m]) * (par[i][m] - av) * vv[m] * 2.0 /
         static_cast<float>(T);
    sm->g[i] = w1 * sm->g[i] / n + w2 * vg;
  }

  return;
}

void PStream_CLASS::calc_stepNW(const int m, const float alpha,
                                const float n) {
  register int i;
  register float coef, w1, w2, dv, h;
  register float av = 0.0, var = 0.0;

  if (alpha > 1.0 || alpha < 0.0) {
    w1 = 1.0;
    w2 = 1.0;
  } else {
    w1 = alpha;
    w2 = 1.0 - alpha;
  }

  // global variance
  calc_varstats(m, &av, &var);
  dv = var - vm[m];

  // L' = (-Rx+r)*w + v'
  coef = 2.0 * vv[m] / static_cast<float>(T);
  calc_grad(m);
  for (i = 0; i < T; i++)
    sm->g[i] = w1 * sm->g[i] / n - w2 * coef * dv * (par[i][m] - av);

  // Hesse matrix, H=L''
  coef = 2.0 * vv[m] / static_cast<float>((T * T));
  for (i = 0; i < T; i++) {
    h = -w1 * sm->R[i][0] / n -
        w2 * coef *
            (2.0 * sm->b[i] * sm->b[i] + dv * static_cast<float>((T - 1)));
    if (h == 0.0)
      sm->b[i] = 0.0;
    else
      sm->b[i] = sm->g[i] / h;
  }

  return;
}

// generate parameter sequence from pdf sequence using gradient
void PStream_CLASS::mlpgGrad(const int max, const float th, const float e,
                             const float alpha, const int nrmflag,
                             const int vcflag) {
  register int m, i, t;
  float n, dth, diff = 0.0;

  /* parameter generation */
  mlpg();

  if (vm == NULL || vv == NULL) return;

  // parameter generation considering GV
  if (nrmflag == 1)
    n = static_cast<float>((T * vSize / dim));
  else
    n = 1.0;

  // generating parameter in each dimension
  for (m = 0; m < dim; m++) {
    calc_R_and_r(m);
    dth = th * sqrt(vm[m]);
    if (vcflag == 1) varconv(par, m, vm[m]);
    for (i = 0; i < max; i++) {
      calc_grad(m);
      calc_vargrad(m, alpha, n);
      for (t = 0, diff = 0.0; t < T; t++) {
        diff += sm->g[t] * sm->g[t];
        par[t][m] += e * sm->g[t];
      }
      diff = sqrt(diff / static_cast<float>(T));
      if (diff < dth || diff == 0.0) break;
    }
  }

  return;
}

// generate parameter sequence from pdf sequence using gradient
void PStream_CLASS::mlpgGradNW(const int max, const float th, const float e,
                               const float alpha, const int nrmflag,
                               const int vcflag) {
  register int m, i, t;
  float n, dth, diff = 0.0;

  /* parameter generation */
  mlpg();

  if (vm == NULL || vv == NULL) return;

  // parameter generation considering GV
  if (nrmflag == 1)
    n = static_cast<float>((T * vSize / dim));
  else
    n = 1.0;

  int a = 0;
  if (1 && dim > 13) {
    a = 1;
  }
  // generating parameter in each dimension
  for (m = a; m < dim; m++) {
    calc_R_and_r(m);
    dth = th * sqrt(vm[m]);
    if (vcflag == 1) varconv(par, m, vm[m]);
    for (i = 0; i < max; i++) {
      calc_stepNW(m, alpha, n);
      for (t = 0, diff = 0.0; t < T; t++) {
        diff += sm->b[t] * sm->b[t];
        par[t][m] -= e * sm->b[t];
      }
      diff = sqrt(diff / static_cast<float>(T));
      if (diff < dth || diff == 0.0) break;
    }
  }

  return;
}

int PStream_CLASS::get_T() { return T; }

int PStream_CLASS::get_dim() { return dim; }
