// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng yang)

#include "tts/synthesizer/vocoder/straight_vocoder/straight_vocoder.h"

#include "mobvoi/base/file.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"
#include "tts/util/tts_util/wave_util.h"

#include "tts/synthesizer/vocoder/straight_vocoder/hts_global.h"
#include "tts/synthesizer/vocoder/straight_vocoder/hts_misc.h"
#include "tts/synthesizer/vocoder/straight_vocoder/hts_mlpg.h"
#include "tts/synthesizer/vocoder/straight_vocoder/hts_sp_sub.h"
#include "tts/synthesizer/vocoder/straight_vocoder/hts_vocoder.h"
#include "tts/synthesizer/vocoder/straight_vocoder/sinusoid.h"

DEFINE_int32(mgc_dim, 40, "order of mel-generalized cepstrum, 40");
DEFINE_int32(fft_length, 512, "fft length, 512");
DEFINE_double(alpha, 0.42, "alpha of mel-generalized cepstrum, 0.42");
DEFINE_double(beta, 0.4, "beta of postfiltering, 0.4");
DEFINE_double(gamma, 0, "gamma of mel-generalized cepstrum, 0");
DEFINE_double(frqbnd_rate, 0.5, "Timbre Lighting up: 0~1.0, 0");
DEFINE_double(cut_end_time_dur, 0.03, "delete end time to fix glitch, 0");

namespace vocoder {

#define INFTY ((float)1.0e+38)
#define INFTY2 ((float)1.0e+19)
#define INVINF ((float)1.0e-38)
#define INVINF2 ((float)1.0e-19)
float finv(const float x);
static const int kDimAll = 0;
static const int kDimMgc = 0;
static const int kDimLf0 = 0;
static const int kDimBap = 0;
static const int kLf0Dim = 1;
static const int kMgcDim = 40;
static const int kBapDim = 5;
static const float kUVThreshold = 0.5;
static const int kRobotPitch = 160;
StraightVocoder::StraightVocoder(int sampling_rate, int frame_period) {
  /* default value for control parameter */
  gp_.reset(new globalP_CLASS(NULL));
  gp_->RATE = sampling_rate;
  gp_->FPERIOD = frame_period;
  mgc_order_ = kMgcDim + 1;
  gp_->ALPHA = FLAGS_alpha;
  gp_->GAMMA = FLAGS_gamma;
  gp_->BETA = FLAGS_beta;
  gp_->FFTLEN = FLAGS_fft_length;
  gp_->frqbnd_rate = FLAGS_frqbnd_rate;
}
StraightVocoder::~StraightVocoder() {}

#ifndef FOR_PORTABLE
bool StraightVocoder::Synthesize(
    const vector<float> &fea, const tts::TTSOption &tts_option,
    float speaker_volume, encoder::FlacEncoder *encoder,
    tts::SynthesizerEventInterface *callback) const {
  // TODO(xipeng.yang) use vocoder callback
  return true;
}
#endif

bool VecReshape(const vector<float> &t, int row, int col,
                vector<vector<float>> *ret) {
  if (t.size() % col * row != 0) {
    return false;
  }
  size_t i = 0;
  vector<float> tmp;
  for (i = 0; i < t.size(); i++) {
    if (i % row == 0) {
      ret->push_back(tmp);
      tmp.clear();
      tmp.push_back(t[i]);
    } else {
      tmp.push_back(t[i]);
    }
  }
  if (tmp.size() != 0) {
    ret->push_back(tmp);
    tmp.clear();
  }
  return true;
}

/*                memory layout of cmp:
 *
 *                   ______cmp_dims____________
 *                  /                           \
 *                  mgc             f0    bap    uv
 *         index    0-40            41   42-46   47
 *             / 0  ...............................
 *             | 1  ...............................
 *             | 2  ...............................
 *   num_frame | .  ...............................
 *             | .  ...............................
 *             \ .  ...............................
 */
void StraightVocoder::ParseFeature(const vector<float> &fea, bool use_robot,
                                   vector<float> *pitch,
                                   vector<vector<float>> *mgc,
                                   vector<vector<float>> *bap) const {
  int fea_dim = kLf0Dim + mgc_order_ + kBapDim + 1;  // mgc pitch bap uv
  CHECK(fea.size() % fea_dim == 0) << " wrong feature dims:";
  // cut end time to fix glitch
  int frame_num =
      fea.size() / fea_dim -
      FLAGS_cut_end_time_dur / (gp_->FPERIOD / static_cast<float>(gp_->RATE));
  // set mgc
  mgc->resize(frame_num);
  for (auto &mgc_frame : *mgc) {
    mgc_frame.reserve(mgc_order_);
  }
  // set bap
  bap->resize(frame_num);
  for (auto &bap_frame : *bap) {
    bap_frame.reserve(kBapDim);
  }
  for (size_t i = 0; i < frame_num; ++i) {
    (*mgc)[i].insert((*mgc)[i].end(), fea.begin() + i * fea_dim,
                     fea.begin() + i * fea_dim + mgc_order_);

    (*bap)[i].insert((*bap)[i].end(),
                     fea.begin() + i * fea_dim + mgc_order_ + 1,
                     fea.begin() + i * fea_dim + fea_dim - 1);
  }
  // set pitch
  pitch->reserve(frame_num);
  for (size_t i = 0; i < frame_num; ++i) {
    if (fea[i * fea_dim + fea_dim - 1] > kUVThreshold) {
      if (use_robot) {
        pitch->push_back(kRobotPitch);
      } else {
        pitch->push_back(fea[i * fea_dim + mgc_order_]);
      }
    } else {
      pitch->push_back(0);
    }
  }
}

bool StraightVocoder::Synthesize(const vector<float> &fea,
                                 const tts::TTSOption &tts_option,
                                 vector<int16> *data) const {
  vector<float> lf0;
  vector<vector<float>> dlf0;
  vector<vector<float>> dmgc;
  vector<vector<float>> dbap;
  ParseFeature(fea, tts_option.use_robot(), &lf0, &dmgc, &dbap);
  // ParseFeature(fea, false, &lf0, &dmgc, &dbap);
  int nframe = lf0.size();
  for (size_t i = 0; i < nframe; i++) {
    vector<float> tmp;
    tmp.push_back(lf0[i]);
    dlf0.push_back(tmp);
  }

  vector<float> uv;
  Synthesize(dlf0, dmgc, dbap, uv, data);
  // Add erased end silence
  size_t pad_samples =
      FLAGS_cut_end_time_dur / (1.0 / static_cast<float>(gp_->RATE));
  data->insert(data->end(), pad_samples, 0);
  return true;
}

bool StraightVocoder::Synthesize(const vector<vector<float>> &_lf0,
                                 const vector<vector<float>> &_mgc,
                                 const vector<vector<float>> &_bap,
                                 const vector<float> &_v_uv,
                                 vector<int16> *data) const {
  int i = 0, idx = 0;
  int t, k, nframe = 0, lf0frame = 0, cepframe = 0, bapframe = 0;

  int lf0vsize = kLf0Dim;
  int cepvsize = mgc_order_;
  int bapvsize = kBapDim;

  char ingvlf0f[1024] = {0};
  char ingvcepf[1024] = {0};
  char ingvbapf[1024] = {0};

  HTS_Boolean *voiced = NULL;
  HTS_Boolean *uvv = NULL;
  HTS_Boolean uvflag = 0;
  DWin dwinlf0 = NULL;
  DWin dwincep = NULL;
  DWin dwinbap = NULL;
  GVPDF gvlf0 = NULL;
  GVPDF gvmgc = NULL;
  GVPDF gvbap = NULL;

  PStream lf0pst = NULL;
  PStream ceppst = NULL;
  PStream bappst = NULL;
  DVECTOR f0v = NULL;
  DMATRIX cep = NULL;
  DMATRIX bap = NULL;
  DVECTOR wav = NULL;
  Synthesis syn = NULL;

  /* default value for sin model*/
  sin_config_CLASS cfp;

  if (kDimAll == 3) {
    lf0vsize = kLf0Dim * kDimAll;
    cepvsize = mgc_order_ * kDimAll;
    bapvsize = kBapDim * kDimAll;
  } else {
    lf0vsize = kLf0Dim;
    cepvsize = mgc_order_;
    bapvsize = kBapDim;
  }
  if (kDimMgc == 3)
    cepvsize = mgc_order_ * kDimMgc;
  else
    cepvsize = mgc_order_;
  if (kDimLf0 == 3)
    lf0vsize = kLf0Dim * kDimLf0;
  else
    lf0vsize = kLf0Dim;
  if (kDimLf0 == 3)
    bapvsize = kBapDim * kDimLf0;
  else
    bapvsize = kBapDim;

  dwinlf0 = new DWin_CLASS;
  dwincep = new DWin_CLASS;
  dwinbap = new DWin_CLASS;
  // read lf0 file
  if (_lf0.size() == 0) {
    LOG(ERROR) << "lf0 data is null.";
    exit(1);
  }
  if (lf0vsize == kLf0Dim) {
    nframe = _lf0.size();
  } else {
    nframe = _lf0.size() / 2;
  }
  f0v = new DVECTOR_CLASS(nframe);

  if (lf0vsize == kLf0Dim) {
    voiced = reinterpret_cast<HTS_Boolean *>(
        HTS_Calloc(nframe, sizeof(HTS_Boolean)));
    for (lf0frame = 0, t = 0; t < nframe; t++) {
      float tmp[64];

      for (idx = 0; idx < lf0vsize; idx++) {
        tmp[idx] = _lf0[t][idx];
      }
      for (k = 1; k < lf0vsize; k++) {
        tmp[0] += tmp[k];
      }
      f0v->data[t] = static_cast<float>((tmp[0]));
    }
  } else {
    if (!strnone(ingvlf0f)) gvlf0 = new GVPDF_CLASS(ingvlf0f, lf0vsize / 3);
    lf0pst = new PStream_CLASS(lf0vsize, nframe, dwinlf0, gvlf0);
    voiced = reinterpret_cast<HTS_Boolean *>(
        HTS_Calloc(nframe, sizeof(HTS_Boolean)));
    if (uvflag) {
      float uv;
      int nuv = _v_uv.size();
      if (nuv != nframe) {
        LOG(ERROR) << "read uv file failed .";
        exit(1);
      }
      uvv =
          reinterpret_cast<HTS_Boolean *>(HTS_Calloc(nuv, sizeof(HTS_Boolean)));
      for (t = 0; t < nuv; t++) {
        uv = _v_uv[i];
        if (uv >= 0.5) {
          uvv[t] = (HTS_Boolean)1;
        } else {
          uvv[t] = (HTS_Boolean)0;
        }
      }
    }

    for (lf0frame = 0, t = 0; t < nframe; t++) {
      float tmp[64];
      for (idx = 0; idx < lf0vsize; idx++) {
        tmp[idx] = _lf0[t][idx];
      }
      // copy lf0 means
      voiced[t] = (HTS_Boolean)1;
      if (uvflag) {
        voiced[t] = uvv[t];
      } else {
        if (tmp[0] <= 0) {
          voiced[t] = (HTS_Boolean)0;
        }
      }

      for (k = 0; k < lf0vsize; k++) {
        lf0pst->mseq[t][k] = static_cast<float>(tmp[k]);
      }
      // copy lf0 variances
      for (idx = 0; idx < lf0vsize; idx++) {
        tmp[idx] = _lf0[t][idx];
      }
      for (k = 0; k < lf0vsize; k++) {
        lf0pst->ivseq[t][k] = static_cast<float>(tmp[k]);
      }
      if (voiced[t]) lf0frame++;
    }

    PStream lf0pst0 = new PStream_CLASS(lf0vsize, lf0frame, dwinlf0, gvlf0);
    for (t = 0, lf0frame = 0; t < nframe; t++) {
      if (!voiced[t]) continue;

      for (k = 0; k < lf0vsize; k++) {
        int ki = k / lf0pst->get_dim();
        int lw = dwinlf0->width[ki][WLEFT];
        int rw = dwinlf0->width[ki][WRIGHT];
        HTS_Boolean nobound = (HTS_Boolean)1;
        // check current frame is UV boundary or not
        for (int n = lw; n <= rw; n++) {
          if (t + n < 0 || nframe <= t + n)
            nobound = (HTS_Boolean)0;
          else
            nobound = (HTS_Boolean)(static_cast<int>(nobound) &
                                    static_cast<int>(voiced[t + n]));
        }
        lf0pst0->mseq[lf0frame][k] = lf0pst->mseq[t][k];
        if (nobound || k < lf0pst->get_dim()) {
          lf0pst0->ivseq[lf0frame][k] = finv(lf0pst->ivseq[t][k]);
        } else {  // the variances for dynamic feature are set to inf on v/uv
                  // boundary
          lf0pst0->ivseq[lf0frame][k] = 0.0;
        }
      }
      lf0frame++;
    }
    delete lf0pst;
    lf0pst = lf0pst0;

    // parameter generation for lf0
    if (lf0frame > 0) lf0pst->mlpgGradNW(10000, 0.01, 1.0e-2, -1.0, 1, 1);
    // parameter sequences
    for (lf0frame = 0, t = 0; t < nframe; t++) {
      if (voiced[t]) {  // f0 modification
        for (k = 1; k < lf0pst->get_dim(); k++) {
          lf0pst->par[lf0frame][0] += lf0pst->par[lf0frame][k];
        }
        f0v->data[t] = exp(lf0pst->par[lf0frame++][0]);
      } else {
        f0v->data[t] = 0.0;
      }
    }
  }

  // read cep file
  if (_mgc.size() == 0) {
    LOG(ERROR) << "mgc data is null.";
    exit(1);
  }
  if (cepvsize == mgc_order_) {
    cepframe = _mgc.size();
  } else {
    cepframe = _mgc.size() / 2;
  }
  cepframe = MIN(cepframe, nframe);
  cep = new DMATRIX_CLASS(cepframe, mgc_order_);
  if (cepvsize == mgc_order_) {
    for (t = 0; t < cepframe; t++) {
      float tmp[1024];
      for (idx = 0; idx < cepvsize; idx++) {
        tmp[idx] = _mgc[t][idx];
      }
      for (k = 0; k < cepvsize; k++) {
        cep->data[t][k] = static_cast<float>(tmp[k]);
      }
    }
  } else {
    if (!strnone(ingvcepf)) gvmgc = new GVPDF_CLASS(ingvcepf, cepvsize / 3);
    ceppst = new PStream_CLASS(cepvsize, cepframe, dwincep, gvmgc);
    for (t = 0; t < cepframe; t++) {
      float tmp[1024];
      // copy cep means
      for (idx = 0; idx < cepvsize; idx++) {
        tmp[idx] = _mgc[t][idx];
      }
      for (k = 0; k < cepvsize; k++) {
        ceppst->mseq[t][k] = static_cast<float>(tmp[k]);
      }
      // copy cep variances
      for (idx = 0; idx < cepvsize * 2; idx++) {
        tmp[idx] = _mgc[t][idx];
      }

      for (k = 0; k < cepvsize; k++) {
        ceppst->ivseq[t][k] = finv(static_cast<float>(tmp[k]));
      }
    }
    // parameter generation for cep
    ceppst->mlpgGradNW(10000, 0.05, 1.0e-2, -1.0, 1, 1);
    // parameter sequences
    for (t = 0; t < ceppst->get_T(); t++) {
      for (k = 0; k < ceppst->get_dim(); k++) {
        cep->data[t][k] = ceppst->par[t][k];
      }
    }
  }

  if (_bap.size() != 0) {
    if (bapvsize == kBapDim) {
      bapframe = _bap.size();
    } else {
      bapframe = _bap.size() / 2;
    }
    bapframe = MIN(bapframe, cepframe);
    bap = new DMATRIX_CLASS(bapframe, kBapDim);
    if (bapvsize == kBapDim) {
      for (t = 0; t < bapframe; t++) {
        float tmp[1024];
        for (idx = 0; idx < bapvsize; idx++) {
          if (_bap[t][idx] > 0.0) {
            tmp[idx] = 0.0;
          } else {
            tmp[idx] = _bap[t][idx];
          }
        }
        for (k = 0; k < bapvsize; k++) {
          bap->data[t][k] = static_cast<float>(tmp[k]);
        }
      }
    } else {
      if (!strnone(ingvbapf)) {
        gvbap = new GVPDF_CLASS(ingvbapf, bapvsize / 3);
      }
      bappst = new PStream_CLASS(bapvsize, bapframe, dwinbap, gvbap);
      for (t = 0; t < bapframe; t++) {
        float tmp[1024];
        // copy bap means
        for (idx = 0; idx < bapvsize; idx++) {
          tmp[idx] = _bap[t][idx];
        }
        for (k = 0; k < bapvsize; k++) {
          bappst->mseq[t][k] = static_cast<float>(tmp[k]);
        }
        // copy cep variances
        for (idx = 0; idx < bapvsize; idx++) {
          tmp[idx] = _bap[t][idx];
        }
        for (k = 0; k < bapvsize; k++) {
          bappst->ivseq[t][k] = finv(static_cast<float>(tmp[k]));
        }
      }
      // parameter generation for cep
      bappst->mlpgGradNW(10000, 0.05, 1.0e-2, -1.0, 1, 1);
      // parameter sequences
      for (t = 0; t < bappst->get_T(); t++) {
        for (k = 0; k < bappst->get_dim(); k++) {
          bap->data[t][k] = bappst->par[t][k];
        }
      }
    }
  }
  // synthesize waveforms by digital filter: syn = NULL
  if (gp_->ALPHA != -1) {
    syn = new SynthesisClass(mgc_order_ - 1, gp_.get());
    wav = syn->SynthesisBody(f0v, cep, bap, gp_->sigp, NULL);
  } else {
    sinF_CLASS sinu = sinF_CLASS(cepframe, &cfp);
    sinu.sin_decoder(cep, f0v);
    wav = sinu.synthesize_sinusoid(f0v);
  }
  // copy wav to data
  data->reserve(wav->length);
  data->insert(data->end(), wav->data, wav->data + wav->length);
  if (dwinlf0) delete dwinlf0;
  if (dwincep) delete dwincep;
  if (dwinbap) delete dwinbap;
  HTS_Free(voiced);
  voiced = NULL;
  delete lf0pst;
  lf0pst = NULL;
  delete ceppst;
  ceppst = NULL;
  if (bappst) {
    delete bappst;
    bappst = NULL;
  }
  delete f0v;
  f0v = NULL;
  delete cep;
  cep = NULL;
  if (bap) {
    delete bap;
    bap = NULL;
  }
  delete syn;
  syn = NULL;
  delete wav;
}

bool StraightVocoder::ReadLf0File(const char *lf0_file,
                                  vector<vector<float>> *data) const {
  FILE *fp = NULL;
  int i = 0, j = 0;
  int lf0vsize = kLf0Dim;
  if (kDimAll == 3) {
    lf0vsize = kLf0Dim * kDimAll;
  }
  if ((fp = fopen(lf0_file, "rb")) == NULL) {
    LOG(ERROR) << "Can't open lf0 file.";
    exit(1);
  }
  fseek(fp, 0, SEEK_END);
  int nframe = ftell(fp) / (sizeof(float) * lf0vsize);
  fseek(fp, 0, SEEK_SET);
  for (i = 0; i < nframe; i++) {
    float tmp[64];
    if ((size_t)lf0vsize != fread(tmp, sizeof(float), (size_t)lf0vsize, fp)) {
      LOG(ERROR) << "Error frames when reading lf0 file. ";
      exit(1);
    }
    vector<float> data_tmp;
    for (j = 0; j < lf0vsize; j++) {
      if (tmp[j] != -1.0E+10) {
        tmp[j] = exp(tmp[j]);
      } else {
        tmp[j] = 0;
      }
      data_tmp.push_back(tmp[j]);
    }
    data->push_back(data_tmp);
  }
  fclose(fp);
  return true;
}
bool StraightVocoder::ReadMgcFile(const char *mgc_file,
                                  vector<vector<float>> *data) const {
  FILE *fp = NULL;
  int i = 0, j = 0;
  int cepvsize = mgc_order_;
  if (kDimAll == 3) {
    cepvsize = mgc_order_ * kDimAll;
  }
  if ((fp = fopen(mgc_file, "rb")) == NULL) {
    LOG(ERROR) << "Can't open mgc file.";
    exit(1);
  }
  fseek(fp, 0, SEEK_END);
  int nframe = ftell(fp) / (sizeof(float) * cepvsize);
  fseek(fp, 0, SEEK_SET);
  for (i = 0; i < nframe; i++) {
    float tmp[1024];
    if ((size_t)cepvsize != fread(tmp, sizeof(float), (size_t)cepvsize, fp)) {
      LOG(ERROR) << "Error frames when reading mgc file.";
      exit(1);
    }
    vector<float> data_tmp;
    for (j = 0; j < cepvsize; j++) {
      data_tmp.push_back(tmp[j]);
    }
    data->push_back(data_tmp);
  }

  fclose(fp);
  return true;
}
bool StraightVocoder::ReadBapFile(const char *bap_file,
                                  vector<vector<float>> *data) const {
  FILE *fp = NULL;
  int i = 0, j = 0;
  int bapvsize = kBapDim;
  if (kDimAll == 3) {
    bapvsize = mgc_order_ * kDimAll;
  }
  if ((fp = fopen(bap_file, "rb")) == NULL) {
    LOG(ERROR) << "Can't open bap file.";
    exit(1);
  }
  fseek(fp, 0, SEEK_END);
  int nframe = ftell(fp) / (sizeof(float) * bapvsize);
  fseek(fp, 0, SEEK_SET);
  for (i = 0; i < nframe; i++) {
    float tmp[1024];
    if ((size_t)bapvsize != fread(tmp, sizeof(float), (size_t)bapvsize, fp)) {
      LOG(ERROR) << "Error frames when reading bap file.";
      exit(1);
    }
    vector<float> data_tmp;
    for (j = 0; j < bapvsize; j++) {
      data_tmp.push_back(tmp[j]);
    }
    data->push_back(data_tmp);
  }

  fclose(fp);
  return true;
}
bool StraightVocoder::SynthesizeFromFile(const string &f0_file,
                                         const string &mgc_file,
                                         const string &bap_file,
                                         const string &wav_file) const {
  vector<vector<float>> lf0;
  vector<vector<float>> mgc;
  vector<vector<float>> bap;
  vector<int16> data;
  vector<float> uv;
  ReadLf0File(f0_file.c_str(), &lf0);
  ReadMgcFile(mgc_file.c_str(), &mgc);
  ReadBapFile(bap_file.c_str(), &bap);

  Synthesize(lf0, mgc, bap, uv, &data);

  string wave_data;
  string riff_header;
  tts::WaveFile::WriteRiffHeader(gp_->RATE, data.size(), &riff_header);
  wave_data.append(riff_header);
  for (size_t i = 0; i < data.size(); ++i) {
    wave_data.append(reinterpret_cast<const char *>(&data[i]), sizeof(int16));
  }
  mobvoi::File::WriteStringToFileOrDie(wave_data, wav_file);
  return true;
}
bool StraightVocoder::SynthesizeFeaFromFile(const string &f0_file,
                                            const string &mgc_file,
                                            const string &bap_file,
                                            const string &wav_file) const {
  vector<vector<float>> lf0;
  vector<vector<float>> mgc;
  vector<vector<float>> bap;
  vector<int16> data;
  ReadLf0File(f0_file.c_str(), &lf0);
  ReadMgcFile(mgc_file.c_str(), &mgc);
  ReadBapFile(bap_file.c_str(), &bap);
  int nframe = lf0.size();
  vector<float> fea;
  for (size_t i = 0; i < nframe; i++) {
    for (size_t j = 0; j < mgc_order_; j++) {
      fea.push_back(mgc[i][j]);
    }
    fea.push_back(lf0[i][0]);
    for (size_t j = 0; j < kBapDim; j++) {
      fea.push_back(bap[i][j]);
    }
    if (lf0[i][0] == 0) {
      fea.push_back(0);
    } else {
      fea.push_back(1);
    }
  }
  tts::TTSOption tts_option;
  Synthesize(fea, tts_option, &data);

  string wave_data;
  string riff_header;
  tts::WaveFile::WriteRiffHeader(gp_->RATE, data.size(), &riff_header);
  wave_data.append(riff_header);
  for (size_t i = 0; i < data.size(); ++i) {
    wave_data.append(reinterpret_cast<const char *>(&data[i]), sizeof(int16));
  }
  mobvoi::File::WriteStringToFileOrDie(wave_data, wav_file);
  return true;
}

float finv(const float x) {
  if (x >= INFTY2) return 0.0;
  if (x <= -INFTY2) return 0.0;
  if (x <= INVINF2 && x >= 0) return INFTY;
  if (x >= -INVINF2 && x < 0) return -INFTY;

  return (1.0 / x);
}
}  // namespace vocoder
