// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng Yang)

#include "tts/synthesizer/vocoder/straight_vocoder/hts_misc.h"

#ifdef FESTIVAL
#include "EST_walloc.h"
#endif

/* ----- Routines for file input/output ----- */
/* HTS_Error: output error message */
void HTS_Error(const int error, const char *message, ...) {
  va_list arg;

  fflush(stdout);
  fflush(stderr);

  if (error > 0)
    fprintf(stderr, "\nError: ");
  else
    fprintf(stderr, "\nWarning: ");

  va_start(arg, message);
  vfprintf(stderr, message, arg);
  va_end(arg);

  fflush(stderr);

  if (error > 0) exit(error);

  return;
}

/* HTS_Getfp: wrapper for fopen */
FILE *HTS_Getfp(const char *name, const char *opt) {
  FILE *fp = fopen(name, opt);

  if (fp == NULL) HTS_Error(2, "HTS_Getfp: Cannot open %s.\n", name);

  return (fp);
}

/* HTS_GetToken: parser */
void HTS_GetToken(FILE *fp, char *buff) {
  char c;
  int i;
  HTS_Boolean squote = 0, dquote = 0;

  c = fgetc(fp);

  while (isspace(c)) c = fgetc(fp);

  if (c == '\'') { /* single quote case */
    c = fgetc(fp);
    squote = 1;
  }

  if (c == '\"') { /*float quote case */
    c = fgetc(fp);
    dquote = 1;
  }

  if (c == ',') { /*special character ',' */
    // strcpy(buff, ",");
    snprintf(buff, sizeof(buff), "%s", ",");
    return;
  }

  i = 0;
  while (1) {
    buff[i++] = c;
    c = fgetc(fp);
    if (squote && c == '\'') break;
    if (dquote && c == '\"') break;
    if (!(squote || dquote || isgraph(c))) break;
  }

  buff[i] = 0;

  return;
}

/* ----- Routines for memory allocation/free ----- */
/* HTS_Calloc: wrapper for calloc */
char *HTS_Calloc(const size_t num, const size_t size) {
#ifdef FESTIVAL
  char *mem = reinterpret_cast<char *>(safe_wcalloc(num * size));
#else
  char *mem = reinterpret_cast<char *>(calloc(num, size));
#endif

  if (mem == NULL) HTS_Error(1, "HTS_calloc: Cannot allocate memory.\n");

  return (mem);
}

/* HTS_Free: wrapper for free */
void HTS_Free(void *ptr) {
#ifdef FESTIVAL
  wfree(ptr);
#else
  free(ptr);
#endif

  return;
}

/* HTS_Strdup: wrapper for strdup */
char *HTS_Strdup(const char *in) {
#ifdef FESTIVAL
  return (wstrdup(in));
#else
  char *tmp =
      reinterpret_cast<char *>(HTS_Calloc(strlen(in) + 1, sizeof(char)));
  // strcpy(tmp, in);
  snprintf(tmp, sizeof(tmp), "%s", in);
  return tmp;
#endif
}

/* HTS_AllocVector: allocate vector */
float *HTS_AllocVector(const int x) {
  float *ptr = reinterpret_cast<float *>(HTS_Calloc(x, sizeof(float)));

  // ptr--;

  return (ptr);
}

/* HTS_AllocMatrix: allocate matrix */
float **HTS_AllocMatrix(const int x, const int y) {
  int i;
  float **ptr = reinterpret_cast<float **>(HTS_Calloc(x, sizeof(float *)));

  // ptr--;

  for (i = 0; i < x; i++) ptr[i] = HTS_AllocVector(y);

  return (ptr);
}

/* HTS_FreeVector: free vector */
void HTS_FreeVector(float *ptr) {
  // ptr++;

  HTS_Free(reinterpret_cast<void *>(ptr));

  return;
}

/* HTS_FreeMatrix: free matrix */
void HTS_FreeMatrix(float **ptr, const int x) {
  int i;

  for (i = x - 1; i >= 0; i--) HTS_FreeVector(ptr[i]);

  // ptr++;

  HTS_Free(reinterpret_cast<void *>(ptr));

  return;
}

/* ----- Routines for reading from binary file ----- */
/* HTS_ByteSwap: byte swap */
int HTS_ByteSwap(void *p, const int size, const int blocks) {
  char *q, tmp;
  int i, j;

  q = reinterpret_cast<char *>(p);

  for (i = 0; i < blocks; i++) {
    for (j = 0; j < (size / 2); j++) {
      tmp = *(q + j);
      *(q + j) = *(q + (size - 1 - j));
      *(q + (size - 1 - j)) = tmp;
    }
    q += size;
  }

  return i;
}

/* HTS_Fread: fread with byteswap */
int HTS_Fread(void *p, const int size, const int num, FILE *fp) {
  const int block = fread(p, size, num, fp);

#ifndef WORDS_BIGENDIAN
  HTS_ByteSwap(p, size, block);
#endif /* !BIG_ENDIAN */

  return block;
}
