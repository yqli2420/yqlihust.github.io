// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng Yang)

#ifndef TTS_SYNTHESIZER_VOCODER_STRAIGHT_VOCODER_HTS_GLOBAL_H_
#define TTS_SYNTHESIZER_VOCODER_STRAIGHT_VOCODER_HTS_GLOBAL_H_

#include "tts/synthesizer/vocoder/straight_vocoder/hts_misc.h"

#ifdef __cplusplus
extern "C" {
#endif
#ifdef __cplusplus
}
#endif

typedef class globalP_CLASS {
 public:
  int RATE;     /* sampring rate                              */
  int FPERIOD;  /* frame period (point)                       */
  int FFTLEN;   /* FFT length                                 */
  float RHO;   /* variable for speaking rate control         */
  float VOL;   /* variable for speaking volume control       */
  float ALPHA; /* variable for frequency warping parameter   */
  float GAMMA; /* variable for control the cepstral scale in MGC or MGC-LSP */
  float F0_MEAN;       /* variable for f0 control                    */
  float F0_STD;        /* variable for f0 control                    */
  float BETA;          /* variable for postfiltering                 */
  float UV;            /* variable for U/V threshold                 */
  float LENGTH;        /* total number of frame for generated speech */
  HTS_Boolean rnd_flag; /* use pulse train with phase manipulationn   */
  float sigp;          /* mapping parameter for mixed excitation     */
  float frqbnd_rate;   /* 音色调亮: 0~1.0 */
  globalP_CLASS(char *);
  ~globalP_CLASS();
} * globalP;

#endif  //  TTS_SYNTHESIZER_VOCODER_STRAIGHT_VOCODER_HTS_GLOBAL_H_
