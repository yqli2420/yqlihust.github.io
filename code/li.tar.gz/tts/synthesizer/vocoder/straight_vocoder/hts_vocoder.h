// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng Yang)

/* STRAIGHT mixed excitation has been implemented */

#ifndef TTS_SYNTHESIZER_VOCODER_STRAIGHT_VOCODER_HTS_VOCODER_H_
#define TTS_SYNTHESIZER_VOCODER_STRAIGHT_VOCODER_HTS_VOCODER_H_

#include "tts/synthesizer/vocoder/straight_vocoder/hts_global.h"
#include "tts/synthesizer/vocoder/straight_vocoder/hts_misc.h"
#include "tts/synthesizer/vocoder/straight_vocoder/hts_pulse_noise.h"
#include "tts/synthesizer/vocoder/straight_vocoder/hts_sp_sub.h"

#ifdef __cplusplus
extern "C" {
#endif
#ifdef __cplusplus
}
#endif

#define RANDMAX 32767

#define IPERIOD 1
#define SEED 1
#define B0 0x00000001
#define B28 0x10000000
#define B31 0x80000000
#define B31_ 0x7fffffff
#define Z 0x00000000

#ifdef HTS_EMBEDDED
#define GAUSS 0
#define PADEORDER 4 /* pade order (for MLSA filter) */
#define IRLENG 64   /* length of impulse response */
#else
#define GAUSS 1
#define PADEORDER 5
#define IRLENG 96
#endif
/* Vocoder: structure for setting of vocoder */
typedef class VocoderClass {
 public:
  VocoderClass(const int, globalP);
  ~VocoderClass();
  void MlsaFilter(float *, float *, int, FILE *);
  void PoleFilter(float *, float *, int, FILE *);
  void Filter(float *, float *, int, FILE *);

 private:
  int order_;
  int iprd_;
  int pd_;
  float alpha_;
  float gamma_;
  float beta_;
  float pade_[21];
  float *ppade_;
  float *pb_;
  float *cb_;
  float *binc_;
  float *d1_;
  /* for postfiltering */
  int irleng_;
  float *pfd_;
  float *pfg_;
  float *pfmc_;
  float *pfcep_;
  float *pfir_;

  void Movem(float *, float *, int);
  void Mc2b(float *);
  void B2mc();
  void Freqt();
  void C2ir();
  float B2en();
  void PostFilter(float *);
  float MlsaFirWithSimd(const float, float *);
  float MlsaFir(const float, float *);
  float MlsaDf1(float, float *);
  float MlsaDf2(float, float *);
  float MlsaDf(float);
  float PoleDf(float);
  void Lsp2Lpc(float *, float *, const int);
} * Vocoder;

/* pulse with random phase */
typedef class RphapfClass {
 private:
  float gdbw_;
  float gdsd_;
  float cornf_;
  float fs_;
  int64 fftl_;
  DVECTOR phstransw_;
  DVECTOR fgdsw_;
  DVECTOR gdwt_;
  DVECTOR gd_;
  DVECTOR apf_;

  DVECTOR XPhstransWin();
  DVECTOR XGrpdlyWin();
  DVECTOR XFgrpdlyWin();
  DVECTOR XGdWeight(float);
  void GetGrpdly();
  void GdtoRandomApf();
  void GetRandomApf();

 public:
  RphapfClass(float samp_freq, int64 fft_len);
  ~RphapfClass();
  void RandomSpec(DVECTOR spc);
} * RPHAPF;

typedef class SynthesisClass {
 private:
  int fprd_;
  float fs_;
  int64 len_;
  int64 hlen_;
  float f0min_;
  float uvf0_;
  XBOOL rnd_flag_;
  DVECTOR hann_;
  DVECTOR psres_;
  DVECTOR pulse_;
  DVECTOR noise_;
  Vocoder vs_;
  RPHAPF rphapf_;
  float volume_rate_;
  float frqbnd_rate_;

  void HanNing(float *, int64);
  void HanNing(float *, int64, int64, int64);
  void PShannWin(int64);
  void PShannWin(int64, int64);
  float Sigmoid(float, float, float);
  void PsresMixRndphs(DMATRIX, int64, float, int, int, float);
  void WaveAmpCheck(DVECTOR, XBOOL);
  void WavCompressor(float *, const int);
  void SetVolume(float *, const int);
  void FrqbandEnhanced(float *, const int, float);

 public:
  SynthesisClass(int, globalP);
  ~SynthesisClass();

  DVECTOR SynthesisBody(DVECTOR, DMATRIX, DMATRIX, float, FILE *);
} * Synthesis;
#endif  // TTS_SYNTHESIZER_VOCODER_STRAIGHT_VOCODER_HTS_VOCODER_H_
