// Copyright 2020 Mobvoi Inc.All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng Yang)

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "tts/synthesizer/vocoder/straight_vocoder/hts_sp_sub.h"

#define sp_warning 0

// using namespace BASIC;
/* Basic Functions */
float spround(float x) {
  float y;

  y = floor(x + 0.5);

  return y;
}

float rem(float x, float y) {
  float n, z;

  z = modff(x / y, &n);
  z = x - n * y;

  return z;
}

void cexp(float *xr, float *xi) {
  float a;

  if (xr == NULL) {
    return;
  } else if (*xr == 0.0) {
    *xr = cos(*xi);
    *xi = sin(*xi);
  } else if (xi != NULL && *xi != 0.0) {
    a = exp(*xr);
    *xr = a * cos(*xi);
    *xi = a * sin(*xi);
  } else {
    *xr = exp(*xr);
  }
  return;
}

void clog(float *xr, float *xi) {
  float a;

  if (*xr < 0.0 || (xi != NULL && *xi != 0.0)) {
    a = CABS(*xr, *xi);
    *xi = atan2(*xi, *xr);
    *xr = log(a);
  } else {
    if (*xr == 0.0) {
      if (sp_warning) LOG(WARNING) << "warning: clog: log of zero";
      *xr = log(ALITTLE_NUMBER);
    } else {
      *xr = log(*xr);
    }
  }

  return;
}

/*
float BASIC::simple_random()
{
    static int64 x = 1, a = 419, c = 6173, m = 29282;

    x  = ( x * a + c) % m;

    return((float)x / (float)m);
}


// Gaussian noise
float BASIC::simple_gnoise(float rms)
{
    float     x, yy;

    yy = simple_random() + 1.0e-30;
    x = sqrt(-2.* log(yy)) * cos(2.* PI * simple_random())* rms;

    return x;
}*/
/*--------------------------------------*/
/*random data genration class           */
/*--------------------------------------*/
float SMP_GAUSSIAN_RND::simple_random() {
  x = (x * a + c) % m;

  return (static_cast<float>(x) / static_cast<float>(m));
}

SMP_GAUSSIAN_RND::SMP_GAUSSIAN_RND() {
  x = 1;
  a = 419;
  c = 6173;
  m = 29282;
}

SMP_GAUSSIAN_RND::~SMP_GAUSSIAN_RND() {}

float SMP_GAUSSIAN_RND::simple_gnoise(float rms) {
  float x, yy;

  yy = simple_random() + 1.0e-30;
  x = sqrt(-2. * log(yy)) * cos(2. * PI * simple_random()) * rms;

  return x;
}

/*float BASIC::randn()
{
    return simple_gnoise(1.0);
}*/

/* Double-Format Vector */
DVECTOR_CLASS::DVECTOR_CLASS(int64 l) {
  length = MAX(l, 0);
  data = new float[length];
  imag = NULL;
}

DVECTOR_CLASS::DVECTOR_CLASS(int64 l, float d) {
  int64 k;

  length = MAX(l, 0);
  data = new float[length];
  imag = NULL;

  for (k = 0; k < length; k++) data[k] = d;
}

DVECTOR_CLASS::DVECTOR_CLASS(int64 l, float *dvr, float *dvi) {
  int64 k;

  length = MAX(l, 0);
  data = new float[length];

  if (dvr != NULL) {
    for (k = 0; k < length; k++) data[k] = dvr[k];
  }
  if (dvi == NULL) {
    imag = NULL;
  } else {
    imag = new float[length];
    for (k = 0; k < length; k++) imag[k] = dvi[k];
  }
}

DVECTOR_CLASS::~DVECTOR_CLASS() {
  delete[] data;
  data = NULL;
  if (imag != NULL) delete[] imag;
  imag = NULL;
}

void DVECTOR_CLASS::dvifree() {
  if (imag != NULL) {
    delete[] imag;
    imag = NULL;
  }

  return;
}

void DVECTOR_CLASS::dvialloc() {
  dvifree();
  imag = new float[length];

  return;
}

void DVECTOR_CLASS::dvialloc(float d) {
  int64 k;

  dvifree();
  imag = new float[length];
  for (k = 0; k < length; k++) imag[k] = d;

  return;
}
/*
void DVECTOR_CLASS::dvrandn()
{
    int64 k;

    for (k = 0; k < length; k++) data[k] = randn();
    if (imag != NULL) for (k = 0; k < length; k++) imag[k] = randn();

    return;
}
*/

void DVECTOR_CLASS::dvrandn() {
  int64 k;
  SMP_GAUSSIAN_RND sgr;
  for (k = 0; k < length; k++) data[k] = sgr.simple_gnoise(1.0);
  if (imag != NULL) {
    for (k = 0; k < length; k++) imag[k] = sgr.simple_gnoise(1.0);
  }
  return;
}

float DVECTOR_CLASS::dvmax(int64 *index) {
  int64 k, ind;
  float max;

  ind = 0;
  max = data[ind];
  for (k = 1; k < length; k++) {
    if (max < data[k]) {
      ind = k;
      max = data[k];
    }
  }
  if (index != NULL) *index = ind;

  return max;
}

float DVECTOR_CLASS::dvmin(int64 *index) {
  int64 k, ind;
  float min;

  ind = 0;
  min = data[ind];
  for (k = 1; k < length; k++) {
    if (min > data[k]) {
      ind = k;
      min = data[k];
    }
  }

  if (index != NULL) *index = ind;

  return min;
}

/* Double-Format Matrix */
DMATRIX_CLASS::DMATRIX_CLASS(int64 r, int64 c) {
  int64 k;

  row = MAX(r, 1);
  col = MAX(c, 1);

  data = new float *[row];
  for (k = 0; k < row; k++) data[k] = new float[col];
}

DMATRIX_CLASS::~DMATRIX_CLASS() {
  int64 k;

  for (k = 0; k < row; k++) {
    delete[] data[k];
    data[k] = NULL;
  }
  delete[] data;
  data = NULL;
}

/* Operation with VECTOR_CLASS */
DVECTOR xdvclone(DVECTOR x) {
  DVECTOR y = new DVECTOR_CLASS(x->length, x->data, x->imag);

  return y;
}

DVECTOR xdvcplx(DVECTOR xr, DVECTOR xi) {
  int64 k, length;
  DVECTOR y = NULL;

  if (xr != NULL && xi != NULL)
    length = MAX(MIN(xr->length, xi->length), 0);
  else if (xr != NULL)
    length = xr->length;
  else if (xi != NULL)
    length = xi->length;
  else
    length = 0;

  y = new DVECTOR_CLASS(length);

  for (k = 0; k < length; k++) {
    if (xr != NULL)
      y->data[k] = xr->data[k];
    else
      y->data[k] = 0.0;
    if (xi != NULL)
      y->imag[k] = xi->data[k];
    else
      y->imag[k] = 0.0;
  }

  return y;
}

void dvoper(DVECTOR x, const char *op, DVECTOR y) {
  int64 k;
  int reverse = 0;
  const char *op2 = op;

  if (strveq(op2, "!")) {
    reverse = 1;
    op2++;
  }

  if (y->imag != NULL && x->imag == NULL) x->dvialloc(0.0);

  if (strveq(op2, "+")) {
    for (k = 0; k < x->length; k++) {
      if (k < y->length) {
        x->data[k] = x->data[k] + y->data[k];
        if (x->imag != NULL) {
          if (y->imag != NULL) {
            x->imag[k] = x->imag[k] + y->imag[k];
          }
        }
      }
    }
  } else if (strveq(op2, "-")) {
    if (reverse) {
      for (k = 0; k < x->length; k++) {
        if (k < y->length) {
          x->data[k] = y->data[k] - x->data[k];
          if (x->imag != NULL) {
            if (y->imag != NULL) {
              x->imag[k] = y->imag[k] - x->imag[k];
            } else {
              x->imag[k] = -x->imag[k];
            }
          }
        } else {
          x->data[k] = -x->data[k];
          if (x->imag != NULL) {
            x->imag[k] = -x->imag[k];
          }
        }
      }
    } else {
      for (k = 0; k < x->length; k++) {
        if (k < y->length) {
          x->data[k] = x->data[k] - y->data[k];
          if (x->imag != NULL) {
            if (y->imag != NULL) {
              x->imag[k] = x->imag[k] - y->imag[k];
            }
          }
        }
      }
    }
  } else if (strveq(op2, "*")) {
    float xr, xi;
    for (k = 0; k < x->length; k++) {
      if (k < y->length) {
        if (x->imag != NULL) {
          if (y->imag != NULL) {
            xr = x->data[k] * y->data[k] - x->imag[k] * y->imag[k];
            xi = x->data[k] * y->imag[k] + x->imag[k] * y->data[k];
            x->data[k] = xr;
            x->imag[k] = xi;
          } else {
            x->data[k] = x->data[k] * y->data[k];
            x->imag[k] = x->imag[k] * y->data[k];
          }
        } else {
          x->data[k] = x->data[k] * y->data[k];
        }
      } else {
        x->data[k] = 0.0;
        if (x->imag != NULL) {
          x->imag[k] = 0.0;
        }
      }
    }
  } else if (strveq(op2, "/")) {
    float a;
    float xr, xi;
    if (reverse) {
      for (k = 0; k < x->length; k++) {
        if (k < y->length) {
          if (x->imag != NULL) {
            if (x->data[k] == 0.0 && x->imag[k] == 0.0) {
              if (sp_warning)
                LOG(WARNING) << "warning: dvoper: divide by zero\n";
              if (y->data[k] == 0.0) {
                x->data[k] = 0.0;
              } else {
                x->data[k] = y->data[k] / ALITTLE_NUMBER;
              }
              if (y->imag != NULL) {
                if (y->imag[k] == 0.0) {
                  x->imag[k] = 0.0;
                } else {
                  x->imag[k] = y->imag[k] / ALITTLE_NUMBER;
                }
              } else {
                x->imag[k] = 0.0;
              }
            } else {
              a = CSQUARE(x->data[k], x->imag[k]);
              if (y->imag != NULL) {
                xr = x->data[k] * y->data[k] + x->imag[k] * y->imag[k];
                xi = x->data[k] * y->imag[k] - x->imag[k] * y->data[k];
                x->data[k] = xr / a;
                x->imag[k] = xi / a;
              } else {
                x->data[k] = x->data[k] * y->data[k] / a;
                x->imag[k] = -x->imag[k] * y->data[k] / a;
              }
            }
          } else {
            if (x->data[k] != 0.0) {
              x->data[k] = y->data[k] / x->data[k];
            } else {
              if (sp_warning)
                LOG(WARNING) << "warning: dvoper: divide by zero\n";
              if (y->data[k] == 0.0) {
                x->data[k] = 0.0;
              } else {
                x->data[k] = y->data[k] / ALITTLE_NUMBER;
              }
            }
          }
        } else {
          x->data[k] = 0.0;
          if (x->imag != NULL) {
            x->imag[k] = 0.0;
          }
        }
      }
    } else {
      for (k = 0; k < x->length; k++) {
        if (k < y->length) {
          if (x->imag != NULL && y->imag != NULL) {
            if (y->data[k] == 0.0 && y->imag[k] == 0.0) {
              if (sp_warning)
                LOG(WARNING) << "warning: dvoper: divide by zero ";
              if (x->data[k] == 0.0) {
                x->data[k] = 0.0;
              } else {
                x->data[k] = x->data[k] / ALITTLE_NUMBER;
              }
              if (x->imag[k] == 0.0) {
                x->imag[k] = 0.0;
              } else {
                x->imag[k] = x->imag[k] / ALITTLE_NUMBER;
              }
            } else {
              a = CSQUARE(y->data[k], y->imag[k]);
              xr = x->data[k] * y->data[k] + x->imag[k] * y->imag[k];
              xi = -x->data[k] * y->imag[k] + x->imag[k] * y->data[k];
              x->data[k] = xr / a;
              x->imag[k] = xi / a;
            }
          } else {
            if (y->data[k] == 0.0) {
              if (sp_warning)
                LOG(WARNING) << "warning: dvoper: divide by zero\n";
              if (x->data[k] == 0.0) {
                x->data[k] = 0.0;
              } else {
                x->data[k] = x->data[k] / ALITTLE_NUMBER;
              }
              if (x->imag != NULL) {
                if (x->imag[k] == 0.0) {
                  x->imag[k] = 0.0;
                } else {
                  x->imag[k] = x->imag[k] / ALITTLE_NUMBER;
                }
              }
            } else {
              x->data[k] = x->data[k] / y->data[k];
              if (x->imag != NULL) {
                x->imag[k] = x->imag[k] / y->data[k];
              }
            }
          }
        } else {
          x->data[k] = 0.0;
          if (x->imag != NULL) {
            x->imag[k] = 0.0;
          }
        }
      }
    }
  } else if (strveq(op2, "^")) {
    float xr, xi;
    float yr, yi;
    if (reverse) {
      if (x->imag != NULL) {
        for (k = 0; k < x->length; k++) {
          if (k < y->length) {
            if (y->imag == NULL) {
              yr = y->data[k];
              yi = 0.0;
            } else {
              yr = y->data[k];
              yi = y->imag[k];
            }
            if (yr == 0.0 && yi == 0.0) {
              x->data[k] = 0.0;
              x->imag[k] = 0.0;
            } else if (x->imag[k] == 0.0 && yi == 0.0) {
              x->data[k] = pow(y->data[k], x->data[k]);
            } else {
              clog(&yr, &yi);
              xr = x->data[k] * yr - x->imag[k] * yi;
              xi = x->data[k] * yi + x->imag[k] * yr;
              cexp(&xr, &xi);
              x->data[k] = xr;
              x->imag[k] = xi;
            }
          } else {
            x->data[k] = 0.0;
            x->imag[k] = 0.0;
          }
        }
      } else {
        for (k = 0; k < x->length; k++) {
          if (k < y->length) {
            x->data[k] = pow(y->data[k], x->data[k]);
          } else {
            x->data[k] = 0.0;
          }
        }
      }
    } else {
      if (x->imag != NULL) {
        for (k = 0; k < x->length; k++) {
          if (k < y->length) {
            if (x->data[k] == 0.0 && x->imag[k] == 0.0) {
              x->data[k] = 0.0;
              x->imag[k] = 0.0;
            } else {
              if (y->imag == NULL) {
                yr = y->data[k];
                yi = 0.0;
              } else {
                yr = y->data[k];
                yi = y->imag[k];
              }
              if (x->imag[k] == 0.0 && yi == 0.0) {
                x->data[k] = pow(x->data[k], y->data[k]);
              } else {
                clog(&x->data[k], &x->imag[k]);
                xr = x->data[k] * yr - x->imag[k] * yi;
                xi = x->data[k] * yi + x->imag[k] * yr;
                cexp(&xr, &xi);
                x->data[k] = xr;
                x->imag[k] = xi;
              }
            }
          } else {
            x->data[k] = 1.0;
            x->imag[k] = 1.0;
          }
        }
      } else {
        for (k = 0; k < x->length; k++) {
          if (k < y->length) {
            x->data[k] = pow(x->data[k], y->data[k]);
          } else {
            x->data[k] = 1.0;
          }
        }
      }
    }
  } else {
    LOG(WARNING) << "dvoper: unknouwn operation: " << op2;
    exit(1);
  }

  return;
}

DVECTOR xdvoper(DVECTOR x, char *op, DVECTOR y) {
  DVECTOR z = xdvclone(x);

  dvoper(z, op, y);

  return z;
}

void dvscoper(DVECTOR x, const char *op, float t) {
  int64 k;
  int reverse = 0;
  const char *op2 = op;

  if (strveq(op2, "!")) {
    reverse = 1;
    op2++;
  }

  if (strveq(op2, "+")) {
    for (k = 0; k < x->length; k++) {
      x->data[k] = x->data[k] + t;
    }
  } else if (strveq(op2, "-")) {
    for (k = 0; k < x->length; k++) {
      if (reverse) {
        x->data[k] = t - x->data[k];
        if (x->imag != NULL) {
          x->imag[k] = -x->imag[k];
        }
      } else {
        x->data[k] = x->data[k] - t;
      }
    }
  } else if (strveq(op2, "*")) {
    for (k = 0; k < x->length; k++) {
      x->data[k] = x->data[k] * t;
      if (x->imag != NULL) {
        x->imag[k] = x->imag[k] * t;
      }
    }
  } else if (strveq(op2, "/")) {
    float a;
    for (k = 0; k < x->length; k++) {
      if (reverse) {
        if (x->imag != NULL) {
          if (x->data[k] == 0.0 && x->imag[k] == 0.0) {
            if (sp_warning)
              LOG(WARNING) << "warning: dvscoper: divide by zero\n";
            if (t == 0.0) {
              x->data[k] = 0.0;
            } else {
              x->data[k] = t / ALITTLE_NUMBER;
            }
            x->imag[k] = 0.0;
          } else {
            a = CSQUARE(x->data[k], x->imag[k]);
            x->data[k] = x->data[k] * t / a;
            x->imag[k] = -x->imag[k] * t / a;
          }
        } else {
          if (x->data[k] != 0.0) {
            x->data[k] = t / x->data[k];
          } else {
            if (sp_warning)
              LOG(WARNING) << "warning: dvscoper: divide by zero\n";
            if (t == 0.0) {
              x->data[k] = 0.0;
            } else {
              x->data[k] = t / ALITTLE_NUMBER;
            }
          }
        }
      } else {
        if (t != 0.0) {
          x->data[k] = x->data[k] / t;
          if (x->imag != NULL) {
            x->imag[k] = x->imag[k] / t;
          }
        } else {
          if (x->data[k] == 0.0) {
            x->data[k] = 0.0;
          } else {
            x->data[k] = x->data[k] / ALITTLE_NUMBER;
          }
          if (x->imag != NULL) {
            if (x->imag[k] == 0.0) {
              x->imag[k] = 0.0;
            } else {
              x->imag[k] = x->imag[k] / ALITTLE_NUMBER;
            }
          }
        }
      }
    }
  } else if (strveq(op2, "^")) {
    float a;
    for (k = 0; k < x->length; k++) {
      if (reverse) {
        if (x->imag != NULL && x->imag[k] != 0.0) {
          a = log(t);
          x->data[k] *= a;
          x->imag[k] *= a;
          cexp(&x->data[k], &x->imag[k]);
        } else {
          x->data[k] = pow(t, x->data[k]);
        }
      } else {
        if (x->imag != NULL && x->imag[k] != 0.0) {
          clog(&x->data[k], &x->imag[k]);
          x->data[k] *= t;
          x->imag[k] *= t;
          cexp(&x->data[k], &x->imag[k]);
        } else {
          x->data[k] = pow(x->data[k], t);
        }
      }
    }
  } else {
    LOG(ERROR) << "dvscoper: unknouwn operation: " << op2;
    exit(1);
  }

  return;
}

DVECTOR xdvscoper(DVECTOR x, char *op, float t) {
  DVECTOR y = xdvclone(x);

  dvscoper(y, op, t);

  return y;
}

void dvcumsum(DVECTOR x) {
  int64 k;
  float sum;

  for (k = 0, sum = 0.0; k < x->length; k++) {
    sum += x->data[k];
    x->data[k] = sum;
  }
  if (x->imag != NULL) {
    for (k = 0, sum = 0.0; k < x->length; k++) {
      sum += x->imag[k];
      x->imag[k] = sum;
    }
  }

  return;
}

DVECTOR xdvcumsum(DVECTOR x) {
  DVECTOR y = xdvclone(x);

  dvcumsum(y);

  return y;
}

void dvpaste(DVECTOR y, DVECTOR x, int64 offset, int64 length, int overlap) {
  int64 k, pos;

  if (length <= 0 || length > x->length) length = x->length;

  if (overlap) {
    for (k = 0; k < length; k++) {
      pos = k + offset;
      if (pos >= y->length) break;
      if (pos >= 0) {
        y->data[pos] += x->data[k];
        if (x->imag != NULL && y->imag != NULL) y->imag[pos] += x->imag[k];
      }
    }
  } else {
    for (k = 0; k < length; k++) {
      pos = k + offset;
      if (pos >= y->length) break;
      if (pos >= 0) {
        y->data[pos] = x->data[k];
        if (x->imag != NULL && y->imag != NULL) y->imag[pos] = x->imag[k];
      }
    }
  }

  return;
}

DVECTOR xdvcut(DVECTOR x, int64 offset, int64 length) {
  int64 k, pos;
  DVECTOR y = new DVECTOR_CLASS(length);

  if (x->imag != NULL) y->dvialloc();

  for (k = 0; k < y->length; k++) {
    pos = k + offset;
    if (pos >= 0 && pos < x->length) {
      y->data[k] = x->data[pos];
      if (y->imag != NULL) y->imag[k] = x->imag[pos];
    } else {
      y->data[k] = 0.0;
      if (y->imag != NULL) y->imag[k] = 0.0;
    }
  }

  return y;
}

/* Operation on FFT */
int nextpow2(int64 n) {
  int p;
  int64 value;

  for (p = 1;; p++) {
    value = static_cast<int64>(POW2(p));
    if (value >= n) {
      break;
    }
  }

  return p;
}

int fft(float *xRe, float *xIm, int64 fftp, int inv) {
  int p;
  int64 i, ip, j, k, m, me, me1, n, nv2;
  float uRe, uIm, vRe, vIm, wRe, wIm, tRe, tIm;

  p = nextpow2(fftp);
  n = static_cast<int64>(POW2(p));
  if (n != fftp) {
    LOG(ERROR) << "fft error: fft point must be a power of 2";
    return 0;
  }
  nv2 = n / 2;

  if (inv) {
    for (i = 0; i < n; i++) xIm[i] = -xIm[i];
  }
  // bit reversion
  for (i = 0, j = 0; i < n - 1; i++) {
    if (j > i) {
      tRe = xRe[j];
      tIm = xIm[j];
      xRe[j] = xRe[i];
      xIm[j] = xIm[i];
      xRe[i] = tRe;
      xIm[i] = tIm;
    }
    k = nv2;
    while (j >= k) {
      j -= k;
      k /= 2;
    }
    j += k;
  }

  // butterfly numeration
  for (m = 1; m <= p; m++) {
    me = static_cast<int64>(POW2(m));
    me1 = me / 2;
    uRe = 1.0;
    uIm = 0.0;
    wRe = cos(PI / static_cast<float>(me1));
    wIm = (-sin(PI / static_cast<float>(me1)));
    for (j = 0; j < me1; j++) {
      for (i = j; i < n; i += me) {
        ip = i + me1;
        tRe = xRe[ip] * uRe - xIm[ip] * uIm;
        tIm = xRe[ip] * uIm + xIm[ip] * uRe;
        xRe[ip] = xRe[i] - tRe;
        xIm[ip] = xIm[i] - tIm;
        xRe[i] += tRe;
        xIm[i] += tIm;
      }
      vRe = uRe * wRe - uIm * wIm;
      vIm = uRe * wIm + uIm * wRe;
      uRe = vRe;
      uIm = vIm;
    }
  }

  if (inv) {
    for (i = 0; i < n; i++) {
      xRe[i] /= static_cast<float>(n);
      xIm[i] /= static_cast<float>(-n);
    }
  }

  return 1;
}

void dvfft(DVECTOR x) {
  if (x->imag == NULL) x->dvialloc(0.0);
  fft(x->data, x->imag, x->length, 0);

  return;
}

void dvifft(DVECTOR x) {
  if (x->imag == NULL) x->dvialloc(0.0);
  fft(x->data, x->imag, x->length, 1);

  return;
}

DVECTOR xdvfft(DVECTOR x) {
  DVECTOR y = xdvclone(x);

  dvfft(y);

  return y;
}

DVECTOR xdvifft(DVECTOR x) {
  DVECTOR y = xdvclone(x);

  dvifft(y);

  return y;
}

DVECTOR xdvfft(DVECTOR x, int64 length) {
  int64 fftp = POW2(nextpow2(MAX(length, x->length)));
  DVECTOR y = new DVECTOR_CLASS(fftp, 0.0);

  y->dvialloc(0.0);
  dvpaste(y, x, 0, x->length, 0);

  fft(y->data, y->imag, fftp, 0);

  return y;
}

DVECTOR xdvifft(DVECTOR x, int64 length) {
  int64 fftp = POW2(nextpow2(MAX(length, x->length)));
  DVECTOR y = new DVECTOR_CLASS(fftp, 0.0);

  y->dvialloc(0.0);
  dvpaste(y, x, 0, x->length, 0);

  fft(y->data, y->imag, fftp, 1);

  return y;
}

void fftturn(float *xRe, float *xIm, int64 fftp) {
  int64 i;
  int64 hfftp = fftp - (fftp / 2);

  if (xRe != NULL) {
    for (i = 1; i < hfftp; i++) xRe[fftp - i] = xRe[i];
  }
  if (xIm != NULL) {
    for (i = 1; i < hfftp; i++) xIm[fftp - i] = -xIm[i];
  }

  return;
}

void dvfftturn(DVECTOR x) {
  fftturn(x->data, x->imag, x->length);

  return;
}

void fftshift(float *xRe, float *xIm, int64 fftp) {
  int64 i;
  float value, value2;
  int64 hfftp = fftp / 2;
  int64 hfftp2 = fftp - hfftp;
  int64 hfftpm = hfftp - 1;

  if (xRe != NULL) {
    value2 = xRe[hfftp];
    xRe[hfftp] = xRe[fftp - 1]; /* if fft point is odd */
    for (i = 0; i < hfftpm; i++) {
      value = xRe[i];
      xRe[i] = value2;
      value2 = xRe[i + hfftp + 1];
      xRe[i + hfftp2] = value;
    }
    value = xRe[i];
    xRe[i] = value2;
    xRe[i + hfftp2] = value;
  }
  if (xIm != NULL) {
    value2 = xIm[hfftp];
    xIm[hfftp] = xIm[fftp - 1]; /* if fft point is odd */
    for (i = 0; i < hfftpm; i++) {
      value = xIm[i];
      xIm[i] = value2;
      value2 = xIm[i + hfftp + 1];
      xIm[i + hfftp2] = value;
    }
    value = xIm[i];
    xIm[i] = value2;
    xIm[i + hfftp2] = value;
  }

  return;
}

void dvfftshift(DVECTOR x) {
  fftshift(x->data, x->imag, x->length);

  return;
}
