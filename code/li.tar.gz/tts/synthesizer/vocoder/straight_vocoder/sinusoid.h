// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng Yang)

#ifndef TTS_SYNTHESIZER_VOCODER_STRAIGHT_VOCODER_SINUSOID_H_
#define TTS_SYNTHESIZER_VOCODER_STRAIGHT_VOCODER_SINUSOID_H_

#include "tts/synthesizer/vocoder/straight_vocoder/hts_global.h"
#include "tts/synthesizer/vocoder/straight_vocoder/hts_sp_sub.h"

typedef class sin_config_CLASS {
 public:
  sin_config_CLASS();
  ~sin_config_CLASS();
  float FRAMESIZE;   // frame size in time
  float FRAMESHIFT;  // frame shift in time
  int FFTLEN;         // FFT length
  int ORDER = 80;     // order of sin
  int MVF;            // max voiced frequency
  int MF0;            // min f0
  int SPECTYPE;       // type of spec
  int LNGAIN;         // flag of ln gain
  int WINTYPE;        // type of win type
  int DEBUG;          // flag of debug
  int FS;             // sampring rate
} * sin_configP;

typedef class sinF_CLASS {
 public:
  int nframe;
  sin_config_CLASS cfp;
  float **A;
  float **F;
  float *sinF;
  // float ** P;
  // float ** NA;
  // float ** NF;
  // float ** NP;
  void sin_decoder(DMATRIX sinA, DVECTOR F0);
  void sin_decoder_i(float *a, float *f, float *sina, float *sinf,
                     float f0, int na);
  void get_sinF();
  void cal_P();
  DVECTOR synthesize_sinusoid(DVECTOR F0);
  float lagrange(float *x0, float *y0, float x, int sum);
  void amplitude_interp(float *A, float *sinf, float *sina, float *F,
                        int ln, int rn, int na);
  sinF_CLASS(int nframe, sin_configP cfp);
  ~sinF_CLASS();
} * sinFP;
#endif  // TTS_SYNTHESIZER_VOCODER_STRAIGHT_VOCODER_SINUSOID_H_
