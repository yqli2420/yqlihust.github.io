// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng yang)

#include "tts/synthesizer/vocoder/straight_vocoder/straight_vocoder.h"

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/time.h"
#include "tts/util/tts_util/wave_util.h"

DEFINE_string(
    lf0_file,
    "tts/synthesizer/vocoder/straight_vocoder/testdata/billy-004180.lf0",
    "lf0 file path");
DEFINE_string(
    mgc_file,
    "tts/synthesizer/vocoder/straight_vocoder/testdata/billy-004180.mgc",
    ",mgc file path");
DEFINE_string(
    bap_file,
    "tts/synthesizer/vocoder/straight_vocoder/testdata/billy-004180.bap",
    "bap file path");
DEFINE_string(wav_file,
              "tts/synthesizer/vocoder/straight_vocoder/testdata/out.wav",
              "out wav file path");
DEFINE_int32(repeat_time, 100, "");
DEFINE_int32(sampling_rate, 16000, "");
DEFINE_int32(frame_period, 80, "");
DEFINE_bool(if_test_performance, false, "");

int main(int argc, char *argv[]) {
  google::ParseCommandLineFlags(&argc, &argv, false);
  vocoder::StraightVocoder vocoder(FLAGS_sampling_rate, FLAGS_frame_period);

  if ((FLAGS_if_test_performance)) {
    int test_word_num = 11, sent_len = 1;
    sent_len = FLAGS_repeat_time;
    int64_t begin = mobvoi::GetTimeInMs();
    vector<vector<float> > lf0_data;
    vector<vector<float> > mgc_data;
    vector<vector<float> > bap_data;
    vector<int16> data;
    vector<float> uv;

    vocoder.ReadLf0File(FLAGS_lf0_file.c_str(), &lf0_data);
    vocoder.ReadMgcFile(FLAGS_mgc_file.c_str(), &mgc_data);
    vocoder.ReadBapFile(FLAGS_bap_file.c_str(), &bap_data);
    for (size_t i = 0; i < FLAGS_repeat_time; i++) {
      vocoder.Synthesize(lf0_data, mgc_data, bap_data, uv, &data);
    }
    string wave_data;
    string riff_header;
    tts::WaveFile::WriteRiffHeader(FLAGS_sampling_rate, data.size(),
                                   &riff_header);
    wave_data.append(riff_header);
    for (size_t i = 0; i < data.size(); ++i) {
      wave_data.append(reinterpret_cast<const char *>(&data[i]), sizeof(int16));
    }
    mobvoi::File::WriteStringToFileOrDie(wave_data, FLAGS_wav_file);
    int64_t end_time = mobvoi::GetTimeInMs();
    int64_t used_time = end_time - begin;
    float sen_per_sec =
        static_cast<float>(sent_len * 1000 / FLAGS_repeat_time) / used_time;
    float word_per_sec =
        static_cast<float>(test_word_num * 1000 * FLAGS_repeat_time) /
        used_time;
    LOG(INFO) << "Test sentences :" << sent_len
              << ", used time in Ms:" << used_time
              << ", used time in Ms average:" << used_time / FLAGS_repeat_time
              << ", test_word_num:" << test_word_num
              << ", performance:" << sen_per_sec << " sentences/sec"
              << ", " << word_per_sec << " words/sec";
  } else {
    vocoder.SynthesizeFromFile(FLAGS_lf0_file, FLAGS_mgc_file, FLAGS_bap_file,
                               FLAGS_wav_file);
  }

  return 0;
}
