// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: ranzhang@mobvoi.com (Dylan)

#ifndef TTS_SYNTHESIZER_VOCODER_VOCODER_H_
#define TTS_SYNTHESIZER_VOCODER_VOCODER_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "tts/synthesizer/interface/synthesizer_event_interface.h"
#include "tts/synthesizer/proto/tts.pb.h"
#include "tts/util/encoder/flac.h"

namespace vocoder {

class Vocoder {
 public:
  Vocoder() {}
  virtual ~Vocoder() {}

  virtual bool Synthesize(const vector<float>& feature,
                          const tts::TTSOption& tts_option,
                          vector<int16>* data) const = 0;
#ifndef FOR_PORTABLE
  virtual bool Synthesize(const vector<float>& feature,
                          const tts::TTSOption& tts_option,
                          float speaker_volume, encoder::FlacEncoder* encoder,
                          tts::SynthesizerEventInterface* callback) const = 0;
#endif

 private:
  DISALLOW_COPY_AND_ASSIGN(Vocoder);
};
}  // namespace vocoder
#endif  // TTS_SYNTHESIZER_VOCODER_VOCODER_H_
