// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng Yang)

#include "tts/synthesizer/vocoder/world_vocoder/world/world_vocoder.h"

namespace world_vocoder {

DEFINE_int32(fft_size, 0, "");
DEFINE_int32(mgc_order, 0, "");
DEFINE_int32(nbit, 16, "");
DEFINE_double(alpha, 0.0, "");
DEFINE_double(beta, 0.3, "");

static const float kUVThreshold = 0.5;
static const int kRobotPitch = 160;

WorldVocoder::WorldVocoder(int fs, double frame_period) {
  f0_scale_ = 0.0;
  formant_shift_ = 0.0;
  ap_order_ = static_cast<int>(
      MyMinDouble(world_vocoder::kUpperLimit,
                  fs / 2.0 - world_vocoder::kFrequencyInterval) /
      world_vocoder::kFrequencyInterval);

  frame_period_ = frame_period;
  fs_ = fs;
  mgc_order_ = FLAGS_mgc_order;
  alpha_ = FLAGS_alpha;
  fft_size_ = FLAGS_fft_size;
  if (fs == 16000) {
    if (FLAGS_alpha == 0) {
      alpha_ = 0.58;
    }
    if (FLAGS_fft_size == 0) {
      fft_size_ = 1024;
    }
  } else if (fs == 22050) {
    if (FLAGS_alpha == 0) {
      alpha_ = 0.65;
    }
    if (FLAGS_fft_size == 0) {
      fft_size_ = 1024;
    }
  } else if (fs == 44100) {
    if (FLAGS_alpha == 0) {
      alpha_ = 0.76;
    }
    if (FLAGS_fft_size == 0) {
      fft_size_ = 2048;
    }
  } else if (fs == 48000) {
    if (FLAGS_alpha == 0) {
      alpha_ = 0.77;
    }
    if (FLAGS_fft_size == 0) {
      fft_size_ = 2048;
    }
  } else {
    if (FLAGS_alpha == 0) {
      alpha_ = 0.58;
    }
    if (FLAGS_fft_size == 0) {
      fft_size_ = 1024;
    }
  }
  sp_order_ = fft_size_ / 2 + 1;
}

WorldVocoder::~WorldVocoder() {}

void WorldVocoder::set_mgc_order(int mgc_order) { mgc_order_ = mgc_order; }

void WorldVocoder::F0Estimation(double *x, int x_length,
                                WorldParameters *world_parameters) const {
  DioOption option = {0};
  InitializeDioOption(&option);
  option.frame_period = world_parameters->frame_period;
  option.speed = 1;
  option.f0_floor = 71.0;
  option.allowed_range = 0.1;
  world_parameters->f0_length = GetSamplesForDIO(
      world_parameters->fs, x_length, world_parameters->frame_period);
  world_parameters->f0 = new double[world_parameters->f0_length];
  world_parameters->time_axis = new double[world_parameters->f0_length];
  double *refined_f0 = new double[world_parameters->f0_length];

  Dio(x, x_length, world_parameters->fs, &option, world_parameters->time_axis,
      world_parameters->f0);

  StoneMask(x, x_length, world_parameters->fs, world_parameters->time_axis,
            world_parameters->f0, world_parameters->f0_length, refined_f0);

  for (int i = 0; i < world_parameters->f0_length; ++i)
    world_parameters->f0[i] = refined_f0[i];

  delete[] refined_f0;
  return;
}

void WorldVocoder::SpectralEnvelopeEstimation(
    double *x, int x_length, WorldParameters *world_parameters) const {
  CheapTrickOption option = {0};
  InitializeCheapTrickOption(&option);
  option.q1 = -0.15;
  option.f0_floor = 71.0;
  world_parameters->fft_size = fft_size_;
  // world_parameters->fft_size =
  //     GetFFTSizeForCheapTrick(world_parameters->fs, &option);
  world_parameters->spectrogram = new double *[world_parameters->f0_length];
  for (int i = 0; i < world_parameters->f0_length; ++i) {
    world_parameters->spectrogram[i] = new double[sp_order_];
  }

  CheapTrick(x, x_length, world_parameters->fs, world_parameters->time_axis,
             world_parameters->f0, world_parameters->f0_length, &option,
             world_parameters->spectrogram);
}

void WorldVocoder::AperiodicityEstimation(
    double *x, int x_length, WorldParameters *world_parameters) const {
  D4COption option = {0};
  InitializeD4COption(&option);
  // Parameters setting and memory allocation.
  int number_of_aperiodicities =
      static_cast<int>(MyMinDouble(world_vocoder::kUpperLimit,
                                   world_parameters->fs / 2.0 -
                                       world_vocoder::kFrequencyInterval) /
                       world_vocoder::kFrequencyInterval);
  world_parameters->aperiodicity = new double *[world_parameters->f0_length];
  for (int i = 0; i < world_parameters->f0_length; ++i) {
    world_parameters->aperiodicity[i] = new double[number_of_aperiodicities];
  }
  world_parameters->number_of_aperiodicities = number_of_aperiodicities;

  D4C_coarse(x, x_length, world_parameters->fs, world_parameters->time_axis,
             world_parameters->f0, world_parameters->f0_length,
             world_parameters->fft_size, &option,
             world_parameters->aperiodicity);
}

void WorldVocoder::AperiodicityInterp(WorldParameters *world_parameters) const {
  if (sp_order_ == world_parameters->number_of_aperiodicities) {
    return;
  }
  int number_of_aperiodicities = world_parameters->number_of_aperiodicities;

  double **aperiodicity = new double *[world_parameters->f0_length];
  double *coarse_aperiodicity = new double[number_of_aperiodicities + 2];
  coarse_aperiodicity[0] = -60.0;
  coarse_aperiodicity[number_of_aperiodicities + 1] = 0.0;
  double *coarse_frequency_axis = new double[number_of_aperiodicities + 2];
  for (int i = 0; i <= number_of_aperiodicities; ++i)
    coarse_frequency_axis[i] =
        static_cast<double>(i) * world_vocoder::kFrequencyInterval;
  coarse_frequency_axis[number_of_aperiodicities + 1] =
      world_parameters->fs / 2.0;
  double *frequency_axis = new double[world_parameters->fft_size / 2 + 1];
  for (int i = 0; i <= world_parameters->fft_size / 2; ++i)
    frequency_axis[i] = static_cast<double>(i) * world_parameters->fs /
                        world_parameters->fft_size;
  for (int i = 0; i < world_parameters->f0_length; ++i) {
    aperiodicity[i] = new double[world_parameters->fft_size / 2 + 1];
    if (world_parameters->f0[i] == 0) {
      for (int j = 0; j <= world_parameters->fft_size / 2; ++j)
        aperiodicity[i][j] = 0.0;
      continue;
    }
    for (int j = 0; j <= world_parameters->fft_size / 2; ++j)
      aperiodicity[i][j] = 0.0;
    for (int j = 1; j <= number_of_aperiodicities; j++) {
      coarse_aperiodicity[j] = world_parameters->aperiodicity[i][j - 1];
    }
    interp1(coarse_frequency_axis, coarse_aperiodicity,
            number_of_aperiodicities + 2, frequency_axis,
            world_parameters->fft_size / 2 + 1, aperiodicity[i]);
    for (int j = 0; j <= world_parameters->fft_size / 2; ++j) {
      aperiodicity[i][j] = pow(10.0, aperiodicity[i][j] / 20.0);
    }
  }
  for (int i = 0; i < world_parameters->f0_length; i++) {
    delete[] world_parameters->aperiodicity[i];
    world_parameters->aperiodicity[i] = NULL;
  }
  world_parameters->number_of_aperiodicities =
      world_parameters->fft_size / 2 + 1;
  delete[] world_parameters->aperiodicity;
  world_parameters->aperiodicity = aperiodicity;
  delete[] coarse_frequency_axis;
  delete[] coarse_aperiodicity;
  delete[] frequency_axis;
}

void WorldVocoder::ParameterModification(float Ff0_scale, float formant_shift,
                                         int fs, int f0_length, int fft_size,
                                         double *f0,
                                         double **spectrogram) const {
  // F0 scaling
  if (Ff0_scale > 0) {
    for (int i = 0; i < f0_length; ++i) f0[i] *= Ff0_scale;
  }
  if (Ff0_scale <= 0 && formant_shift <= 0) return;

  // Spectral stretching
  double ratio = static_cast<double>(formant_shift);
  double *freq_axis1 = new double[fft_size];
  double *freq_axis2 = new double[fft_size];
  double *spectrum1 = new double[fft_size];
  double *spectrum2 = new double[fft_size];

  for (int i = 0; i <= fft_size / 2; ++i) {
    freq_axis1[i] = ratio * i / fft_size * fs;
    freq_axis2[i] = static_cast<double>(i) / fft_size * fs;
  }
  for (int i = 0; i < f0_length; ++i) {
    for (int j = 0; j <= fft_size / 2; ++j)
      spectrum1[j] = log(spectrogram[i][j]);
    interp1(freq_axis1, spectrum1, fft_size / 2 + 1, freq_axis2,
            fft_size / 2 + 1, spectrum2);
    for (int j = 0; j <= fft_size / 2; ++j)
      spectrogram[i][j] = exp(spectrum2[j]);
    if (ratio >= 1.0) continue;
    for (int j = static_cast<int>(fft_size / 2.0 * ratio); j <= fft_size / 2;
         ++j)
      spectrogram[i][j] =
          spectrogram[i][static_cast<int>(fft_size / 2.0 * ratio) - 1];
  }
  delete[] spectrum1;
  delete[] spectrum2;
  delete[] freq_axis1;
  delete[] freq_axis2;
}

void WorldVocoder::WaveformSynthesis(WorldParameters *world_parameters, int fs,
                                     int y_length, double *y) const {
  // Synthesis by the aperiodicity
  AperiodicityInterp(world_parameters);
  Synthesis(world_parameters->f0, world_parameters->f0_length,
            world_parameters->spectrogram, world_parameters->aperiodicity,
            world_parameters->fft_size, world_parameters->frame_period, fs,
            y_length, y);
}

void WorldVocoder::DestroyMemory(WorldParameters *world_parameters) const {
  delete[] world_parameters->time_axis;
  delete[] world_parameters->f0;
  for (int i = 0; i < world_parameters->f0_length; ++i) {
    delete[] world_parameters->spectrogram[i];
    delete[] world_parameters->aperiodicity[i];
  }
  delete[] world_parameters->spectrogram;
  delete[] world_parameters->aperiodicity;
}

bool WorldVocoder::Analysis(int fs, int nbit, double *pcms, int pcm_len,
                            WorldParameters *world_parameters) const {
  world_parameters->fs = fs;
  world_parameters->frame_period = frame_period_;

  F0Estimation(pcms, pcm_len, world_parameters);
  SpectralEnvelopeEstimation(pcms, pcm_len, world_parameters);
  AperiodicityEstimation(pcms, pcm_len, world_parameters);
  ParameterModification(f0_scale_, formant_shift_, fs,
                        world_parameters->f0_length, world_parameters->fft_size,
                        world_parameters->f0, world_parameters->spectrogram);
  if (mgc_order_ != 0) {
    for (int i = 0; i < world_parameters->f0_length; i++) {
      double *mc = new double[mgc_order_ + 1];
      sp2mcep(world_parameters->spectrogram[i], alpha_, mgc_order_, fft_size_,
              mc);
      delete[] world_parameters->spectrogram[i];
      world_parameters->spectrogram[i] = mc;
    }
  }
  return true;
}

bool WorldVocoder::AnalysisFromFile(const char *wave_file, vector<double> *f0,
                                    vector<vector<double> > *sp,
                                    vector<vector<double> > *ap) const {
  int fs, nbit;
  int x_length = GetAudioLength(wave_file);
  WorldParameters world_parameters = {0};
  if (x_length <= 0) {
    if (x_length == 0)
      LOG(ERROR) << "error: File not found.";
    else
      LOG(ERROR) << "error: The file is not .wav format.";
    return false;
  }
  double *x = new double[x_length];
  wavread(wave_file, &fs, &nbit, x);
  Analysis(fs, nbit, x, x_length, &world_parameters);
  sp->resize(world_parameters.f0_length);
  ap->resize(world_parameters.f0_length);
  f0->reserve(world_parameters.f0_length);
  for (int i = 0; i < world_parameters.f0_length; i++) {
    int sp_len = world_parameters.fft_size / 2 + 1;
    if (mgc_order_ != 0) {
      sp_len = mgc_order_ + 1;
    }
    for (int j = 0; j < sp_len; j++) {
      (*sp)[i].push_back((world_parameters.spectrogram[i][j]));
    }
    for (int j = 0; j < world_parameters.number_of_aperiodicities; j++) {
      (*ap)[i].push_back((world_parameters.aperiodicity[i][j]));
    }
    f0->push_back((world_parameters.f0[i]));
  }
  DestroyMemory(&world_parameters);
  delete[] x;
  return true;
}

bool WorldVocoder::AnalysisFromPCM(int fs, int nbit, double *pcms,
                                   int pcm_length, vector<double> *f0,
                                   vector<vector<double> > *sp,
                                   vector<vector<double> > *ap) const {
  WorldParameters world_parameters = {0};
  if (pcm_length <= 0) {
    if (pcm_length == 0)
      LOG(ERROR) << "error: test wave File not found.input pcm_length = 0";
    else
      LOG(ERROR) << "error: The file is not .wav format.";
    return false;
  }
  double *x = new double[pcm_length];
  Analysis(fs, nbit, pcms, pcm_length, &world_parameters);
  sp->resize(world_parameters.f0_length);
  ap->resize(world_parameters.f0_length);
  f0->reserve(world_parameters.f0_length);
  for (int i = 0; i < world_parameters.f0_length; i++) {
    int sp_len = world_parameters.fft_size / 2 + 1;
    if (mgc_order_ != 0) {
      sp_len = mgc_order_ + 1;
    }
    for (int j = 0; j < sp_len; j++) {
      (*sp)[i].push_back((world_parameters.spectrogram[i][j]));
    }
    for (int j = 0; j < world_parameters.number_of_aperiodicities; j++) {
      (*ap)[i].push_back((world_parameters.aperiodicity[i][j]));
    }
    f0->push_back((world_parameters.f0[i]));
  }
  DestroyMemory(&world_parameters);
  delete[] x;
  return true;
}

/*                     memory layout of cmp:
 *
 *                   ______cmp_dims____________
 *                  /                           \
 *                  sp             f0    bap    uv
 *         index    0-512          513   514    515
 *             / 0  ...............................
 *             | 1  ...............................
 *             | 2  ...............................
 *   num_frame | .  ...............................
 *             | .  ...............................
 *             \ .  ...............................
 */
void WorldVocoder::ParseFeature(const vector<double> &fea, bool use_robot,
                                vector<double> *lf0,
                                vector<vector<double> > *sp,
                                vector<vector<double> > *ap) const {
  int sp_order = sp_order_;
  if (mgc_order_ != 0) {
    sp_order = mgc_order_ + 1;
  }
  int fea_dim = sp_order + 2 + ap_order_;  // mgc pitch bap uv
  if (fea.size() % fea_dim != 0) {
    LOG(ERROR) << " wrong feature dims " << fea.size() << " " << fea_dim;
    exit(1);
  }
  int frame_num = fea.size() / fea_dim;
  sp->resize(frame_num);
  ap->resize(frame_num);
  for (auto &mgc_frame : *sp) {
    mgc_frame.reserve(sp_order);
  }
  for (auto &ap_frame : *ap) {
    ap_frame.reserve(ap_order_);
  }
  for (size_t i = 0; i < frame_num; ++i) {
    (*sp)[i].insert((*sp)[i].end(), fea.begin() + i * fea_dim,
                    fea.begin() + i * fea_dim + sp_order);
    (*ap)[i].insert((*ap)[i].end(), fea.begin() + i * fea_dim + sp_order + 1,
                    fea.begin() + i * fea_dim + sp_order + 1 + ap_order_);
  }
  lf0->reserve(frame_num);
  ap->reserve(frame_num);
  for (size_t i = 0; i < frame_num; ++i) {
    if (fea[i * fea_dim + fea_dim - 1] > kUVThreshold) {
      if (use_robot) {
        lf0->push_back(kRobotPitch);
      } else {
        lf0->push_back(fea[i * fea_dim + sp_order]);
      }
    } else {
      lf0->push_back(0);
    }
  }
}

bool WorldVocoder::Synthesize(const vector<double> &fea,
                              vector<double> *data) const {
  vector<double> lf0;
  vector<vector<double> > sp;
  vector<vector<double> > ap;
  int sp_order = sp_order_;
  if (mgc_order_ != 0) {
    sp_order = mgc_order_ + 1;
  }

  WorldParameters world_parameters = {0};
  ParseFeature(fea, false, &lf0, &sp, &ap);
  int nframe = lf0.size();
  world_parameters.f0 = new double[nframe];
  world_parameters.spectrogram = new double *[nframe];
  world_parameters.aperiodicity = new double *[nframe];
  world_parameters.f0_length = nframe;
  world_parameters.fft_size = fft_size_;
  world_parameters.fs = fs_;
  world_parameters.frame_period = frame_period_;
  world_parameters.number_of_aperiodicities = ap_order_;
  for (size_t i = 0; i < nframe; i++) {
    world_parameters.spectrogram[i] = new double[sp_order];
    world_parameters.aperiodicity[i] = new double[ap_order_];
    for (size_t j = 0; j < sp_order; j++) {
      world_parameters.spectrogram[i][j] = sp[i][j];
    }
    for (size_t j = 0; j < ap_order_; j++) {
      world_parameters.aperiodicity[i][j] = ap[i][j];
    }
    world_parameters.f0[i] = lf0[i];
  }
  if (mgc_order_ != 0) {
    for (int i = 0; i < world_parameters.f0_length; i++) {
      if (FLAGS_beta != 0) {
        PostFilter(world_parameters.spectrogram[i], mgc_order_, FLAGS_beta,
                   alpha_);
      }
      double *sp = new double[sp_order_];
      mgc2sp(world_parameters.spectrogram[i], mgc_order_, alpha_, fft_size_, 0,
             sp);
      delete[] world_parameters.spectrogram[i];
      world_parameters.spectrogram[i] = sp;
    }
  }
  int y_length =
      static_cast<int>((world_parameters.f0_length - 1) *
                       world_parameters.frame_period / 1000.0 * fs_) +
      1;
  double *y = new double[y_length];
  WaveformSynthesis(&world_parameters, fs_, y_length, y);
  wavwrite(y, y_length, fs_, 16, "out1.wav");
  data->reserve(y_length);
  for (size_t i = 0; i < y_length; i++) {
    data->push_back(y[i]);
  }
  delete[] y;
  DestroyMemory(&world_parameters);
  return true;
}

bool WorldVocoder::MergeFeature(const vector<double> &lf0,
                                const vector<vector<double> > &sp,
                                const vector<vector<double> > &ap,
                                vector<double> *fea) const {
  int nframe = lf0.size();
  int sp_order = sp[0].size();
  int ap_order = ap[0].size();
  for (size_t i = 0; i < nframe; i++) {
    for (size_t j = 0; j < sp_order; j++) {
      fea->push_back(sp[i][j]);
    }
    fea->push_back(lf0[i]);
    for (size_t j = 0; j < ap_order; j++) {
      fea->push_back(ap[i][j]);
    }
    if (lf0[i] == 0) {
      fea->push_back(0);
    } else {
      fea->push_back(1);
    }
  }
  return true;
}

bool WorldVocoder::Vector2Wav(const vector<double> &data,
                              const string &wav_file) const {
  double *wav = new double[data.size()];
  for (size_t i = 0; i < data.size(); i++) {
    wav[i] = static_cast<double>(data[i]);
  }
  wavwrite(wav, data.size(), fs_, FLAGS_nbit, wav_file.c_str());
  delete[] wav;
  return true;
}

bool WorldVocoder::SynthesizeFeaFromFile(const std::string &lf0_file,
                                         const std::string &sp_file,
                                         const std::string &ap_file,
                                         const std::string &wav_file) const {
  vector<double> lf0;
  vector<vector<double> > sp;
  vector<vector<double> > ap;
  vector<double> data;

  ReadApLf0File(lf0_file.c_str(), &lf0);
  ReadspFile(ap_file.c_str(), &ap);
  ReadspFile(sp_file.c_str(), &sp);

  int nframe = lf0.size();
  vector<double> fea;
  MergeFeature(lf0, sp, ap, &fea);
  Synthesize(fea, &data);
  Vector2Wav(data, wav_file);
  return true;
}

void WorldVocoder::SynthesizeFeaFromFea(const vector<double> &lf0,
                                        const vector<vector<double> > &sp,
                                        const vector<vector<double> > &ap,
                                        vector<double> *data) const {
  if (lf0.size() != sp.size() || sp.size() != ap.size()) {
    LOG(ERROR) << "different feature lengtn !";
    return;
  }
  vector<double> fea;
  MergeFeature(lf0, sp, ap, &fea);
  Synthesize(fea, data);
}

bool WorldVocoder::ReadApFile(const char *fea_file,
                              vector<double> *data) const {
  FILE *fp = NULL;
  int i = 0, j = 0;
  int fea_size = 1;
  if ((fp = fopen(fea_file, "rb")) == NULL) {
    return false;
  }
  fseek(fp, 0, SEEK_END);
  int nframe = ftell(fp) / (sizeof(double) * fea_size);
  fseek(fp, 0, SEEK_SET);
  double tmp[64];
  for (i = 0; i < nframe; i++) {
    if ((size_t)fea_size != fread(tmp, sizeof(double), (size_t)fea_size, fp)) {
      return false;
    }
    data->push_back(tmp[0]);
  }
  fclose(fp);
  return true;
}

bool WorldVocoder::ReadApLf0File(const char *fea_file,
                                 vector<double> *data) const {
  FILE *fp = NULL;
  int i = 0, j = 0;
  int fea_size = 1;
  if ((fp = fopen(fea_file, "rb")) == NULL) {
    return false;
  }
  fseek(fp, 0, SEEK_END);
  int nframe = ftell(fp) / (sizeof(double) * fea_size);
  fseek(fp, 0, SEEK_SET);
  double tmp[64];
  for (i = 0; i < nframe; i++) {
    if ((size_t)fea_size != fread(tmp, sizeof(double), (size_t)fea_size, fp)) {
      return false;
    }
    data->push_back(tmp[0]);
  }
  fclose(fp);
  return true;
}

bool WorldVocoder::ReadspFile(const char *fea_file,
                              vector<vector<double> > *data) const {
  FILE *fp = NULL;
  int i = 0, j = 0;
  int fea_size = sp_order_;
  if ((fp = fopen(fea_file, "rb")) == NULL) {
    return false;
  }
  fseek(fp, 0, SEEK_END);
  int nframe = ftell(fp) / (sizeof(double) * fea_size);
  fseek(fp, 0, SEEK_SET);
  for (i = 0; i < nframe; i++) {
    double tmp[2048];
    if ((size_t)fea_size != fread(tmp, sizeof(double), (size_t)fea_size, fp)) {
      LOG(ERROR) << fea_file << " fea error !";
      return false;
    }
    vector<double> data_tmp;
    for (j = 0; j < fea_size; j++) {
      data_tmp.push_back(tmp[j]);
    }
    data->push_back(data_tmp);
  }

  fclose(fp);
  return true;
}

bool WorldVocoder::DoubleArrayToFile(const string file,
                                     const vector<vector<double> > &data,
                                     const int col, const int row) {
  FILE *fp;
  fp = fopen(file.c_str(), "wb");
  if (!fp) {
    LOG(ERROR) << "Can't open the file!";
    exit(-1);
  }
  int i = 0, j = 0;
  double **data_tmp = new double *[col];
  for (i = 0; i < col; i++) {
    data_tmp[i] = new double[row];
    for (int j = 0; j < row; j++) {
      data_tmp[i][j] = data[i][j];
    }
    fwrite(data_tmp[i], sizeof(double), row, fp);
    delete[] data_tmp[i];
  }
  delete[] data_tmp;

  fclose(fp);
}

bool WorldVocoder::DoubleArrayToFile(const string file,
                                     const vector<double> &data,
                                     const int len) {
  FILE *fp;
  fp = fopen(file.c_str(), "wb");
  if (!fp) {
    LOG(ERROR) << "Can't open the file!";
    exit(-1);
  }
  size_t i = 0;
  double *data_tmp = new double[len];
  for (i = 0; i < len; i++) {
    data_tmp[i] = data[i];
  }
  fwrite(data_tmp, sizeof(double), len, fp);
  delete[] data_tmp;
  fclose(fp);
}
}  // namespace world_vocoder
