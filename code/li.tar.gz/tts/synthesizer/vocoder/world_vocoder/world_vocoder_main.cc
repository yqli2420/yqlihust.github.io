// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng Yang)

#include "mobvoi/base/flags.h"

#include "tts/synthesizer/vocoder/world_vocoder/world/world_vocoder.h"

DEFINE_string(f0_file, "tts/synthesizer/vocoder/world_vocoder/test/test.f0",
              "lf0 file path");
DEFINE_string(sp_file, "tts/synthesizer/vocoder/world_vocoder/test/test.sp",
              ",sp file path");
DEFINE_string(ap_file, "tts/synthesizer/vocoder/world_vocoder/test/test.ap",
              "ap file path");
DEFINE_string(wav_file, "tts/synthesizer/vocoder/world_vocoder/test/test.wav",
              "input wav file path");
DEFINE_string(out_file, "tts/synthesizer/vocoder/world_vocoder/test/out.wav",
              "output wav file path");
DEFINE_int32(sampling_rate, 16000, "");
DEFINE_int32(frame_period, 5, "");
DEFINE_bool(if_features_to_file, true, "");

int main(int argc, char *argv[]) {
  google::ParseCommandLineFlags(&argc, &argv, false);
  world_vocoder::WorldVocoder vocoder(FLAGS_sampling_rate, FLAGS_frame_period);
  vector<double> lf0;
  vector<vector<double> > sp;
  vector<vector<double> > ap;
  vocoder.AnalysisFromFile(FLAGS_wav_file.c_str(), &lf0, &sp, &ap);

  if (FLAGS_if_features_to_file) {
    vocoder.DoubleArrayToFile(FLAGS_f0_file, lf0, lf0.size());
    vocoder.DoubleArrayToFile(FLAGS_ap_file, ap, ap.size(), ap[0].size());
    vocoder.DoubleArrayToFile(FLAGS_sp_file, sp, sp.size(), sp[0].size());
  }
  vector<double> data;
  vocoder.SynthesizeFeaFromFea(lf0, sp, ap, &data);
  double *wav = new double[data.size()];
  for (size_t i = 0; i < data.size(); i++) {
    wav[i] = static_cast<double>(data[i]);
  }
  world_vocoder::WavWriteUtils(wav, data.size(), FLAGS_sampling_rate, 16,
                               FLAGS_out_file.c_str());
  delete[] wav;
  lf0.clear();
  sp.clear();
  ap.clear();
  data.clear();
  return 0;
}
