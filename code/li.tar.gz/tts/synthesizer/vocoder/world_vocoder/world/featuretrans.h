// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng Yang)

#ifndef TTS_SYNTHESIZER_VOCODER_WORLD_VOCODER_WORLD_FEATURETRANS_H_
#define TTS_SYNTHESIZER_VOCODER_WORLD_VOCODER_WORLD_FEATURETRANS_H_

#include "tts/synthesizer/vocoder/world_vocoder/world/utils.h"

namespace world_vocoder {

int mgc2sp(double *mgc, int mgc_order, double alpha, int fft_size, double gamma,
           double *sp);
int sp2mcep(double *x, double alpha, const int mcsize, double nFFTHalf,
            double *mgc);
int PostFilter(double *mc, int m, double beta, double a);
}  // namespace world_vocoder
#endif  // TTS_SYNTHESIZER_VOCODER_WORLD_VOCODER_WORLD_FEATURETRANS_H_
