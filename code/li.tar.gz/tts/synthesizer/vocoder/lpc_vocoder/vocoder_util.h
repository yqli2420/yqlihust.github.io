// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: ranzhang@mobvoi.com (Dylan)

#ifndef TTS_SYNTHESIZER_VOCODER_LPC_VOCODER_VOCODER_UTIL_H_
#define TTS_SYNTHESIZER_VOCODER_LPC_VOCODER_VOCODER_UTIL_H_

#include <string>
#include <vector>

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"

namespace vocoder {

static const float k2PI = 6.2831853071f;
bool LoadLspFile(const string& filename, int frame_num,
                 vector<vector<float>>* lsp);

void AdjustLsp(vector<vector<float>>* lsp_pointer);
void CosineLsp(vector<vector<float>>* lsp);

bool LoadPitchFile(const string& filename, vector<float>* pitch);
}  // namespace vocoder
#endif  // TTS_SYNTHESIZER_VOCODER_LPC_VOCODER_VOCODER_UTIL_H_
