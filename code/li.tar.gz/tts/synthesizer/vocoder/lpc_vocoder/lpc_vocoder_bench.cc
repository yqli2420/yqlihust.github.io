// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: ranzhang@mobvoi.com (Dylan)

#include "tts/synthesizer/vocoder/lpc_vocoder/lpc_vocoder.h"

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/base/time.h"
#include "tts/synthesizer/vocoder/lpc_vocoder/vocoder_util.h"

DEFINE_string(lsp_file,
              "tts/synthesizer/vocoder/lpc_vocoder/testdata/chenshu_000001.mgc",
              "");
DEFINE_string(lf0_file,
              "tts/synthesizer/vocoder/lpc_vocoder/testdata/chenshu_000001.lf0",
              "");
DEFINE_string(wave_save_file, "test.wav", "");

DEFINE_int32(sampling_rate, 16000, "");
DEFINE_int32(frame_period, 80, "");
DEFINE_int32(lsp_dim, 41, "");
DEFINE_bool(convert_lsp, true, "");
DEFINE_int32(repeated, 20, "repeat time");

int main(int argc, char** argv) {
  google::ParseCommandLineFlags(&argc, &argv, false);

  size_t steps = FLAGS_repeated;
  vocoder::LpcVocoder vocoder(FLAGS_sampling_rate, FLAGS_frame_period);
  vector<float> pitch;
  vocoder::LoadPitchFile(FLAGS_lf0_file, &pitch);
  VLOG(1) << "Pitch size:" << pitch.size();

  // Load LPC file and convert LPC to LPC
  vector<vector<float>> lsp;
  int frame_num = pitch.size();
  vocoder::LoadLspFile(FLAGS_lsp_file, frame_num, &lsp);
  VLOG(1) << "lsp size:" << lsp.size();

  if (pitch.size() != lsp.size()) {
    LOG(ERROR) << "pitch size NOT equal to frame size.";
    // return false;
  }

  vector<int16> data;
  time_t begin = mobvoi::GetTimeInMs();
  while (--steps) {
    vocoder.Synthesize(pitch, &lsp, &data);
    data.clear();
  }
  time_t end = mobvoi::GetTimeInMs();
  LOG(INFO) << end - begin;
  LOG(INFO) << "Done.";
  return 0;
}
