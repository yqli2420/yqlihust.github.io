// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/synthesizer/vocoder/lpc_vocoder/vector_util.h"

#include "mobvoi/base/file.h"
#include "mobvoi/base/log.h"

namespace vocoder {

bool Write2DVector(const string& filename, const vector<vector<float>>& data) {
  if (data.empty()) {
    return true;
  }

  FILE* fp = fopen(filename.c_str(), "w");
  CHECK(fp) << "Failed to open file : " << filename;
  // Write rows & cols first.
  size_t rows = data.size();
  size_t cols = data[0].size();
  fwrite(&rows, sizeof(size_t), 1, fp);
  fwrite(&cols, sizeof(size_t), 1, fp);
  for (size_t i = 0; i < data.size(); ++i) {
    fwrite(static_cast<const void*>(data[i].data()), sizeof(float),
           data[i].size(), fp);
  }
  fclose(fp);
  return true;
}

bool Read2DVector(const string& filename, vector<vector<float>>* data) {
  FILE* fp = fopen(filename.c_str(), "r");
  CHECK(fp) << "Failed to open file : " << filename;
  size_t rows = 0;
  size_t cols = 0;
  ignore_result(fread((void*)&rows, sizeof(size_t), 1, fp));  // NOLINT
  ignore_result(fread((void*)&cols, sizeof(size_t), 1, fp));  // NOLINT
  // Read each row.
  data->resize(rows);
  for (size_t i = 0; i < rows; ++i) {
    (*data)[i].resize(cols);
    ignore_result(
        fread((void*)(*data)[i].data(), sizeof(float), cols, fp));  // NOLINT
  }
  fclose(fp);
  return true;
  return true;
}

bool WriteVector(const string& filename, const vector<float>& data) {
  FILE* fp = fopen(filename.c_str(), "w");
  CHECK(fp) << "Failed to open file : " << filename;
  fwrite(static_cast<const void*>(data.data()), sizeof(float), data.size(), fp);
  fclose(fp);
  return true;
}

bool ReadVector(const string& filename, vector<float>* data) {
  size_t s = 0;
  mobvoi::File::FileSize(filename, &s);
  size_t num = s / sizeof(float);
  data->resize(num, 0);
  FILE* fp = fopen(filename.c_str(), "r");
  CHECK(fp) << "Failed to open file : " << filename;
  ignore_result(fread((void*)data->data(), sizeof(float), num, fp));  // NOLINT
  fclose(fp);
  return true;
}

}  // namespace vocoder
