// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_SYNTHESIZER_VOCODER_LPC_VOCODER_LPC_VOCODER_H_
#define TTS_SYNTHESIZER_VOCODER_LPC_VOCODER_LPC_VOCODER_H_

#include <memory>
#include <string>
#include <vector>

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "tts/synthesizer/interface/synthesizer_event_interface.h"
#include "tts/synthesizer/vocoder/vocoder.h"

namespace vocoder {
class FirFilter;

class LpcVocoder : public Vocoder {
 public:
  LpcVocoder(int sampling_rate, int frame_period);
  ~LpcVocoder();

  // NOTE: pitch is not log pitch.
  // lsp will be changed
  bool Synthesize(const vector<float>& pitch, vector<vector<float>>* lsp,
                  vector<int16>* data) const;

  bool Synthesize(const vector<float>& fea, const tts::TTSOption& tts_option,
                  vector<int16>* data) const override;

#ifndef FOR_PORTABLE
  bool Synthesize(const vector<float>& in_features,
                  const tts::TTSOption& tts_option, float speaker_volume,
                  encoder::FlacEncoder* encoder,
                  tts::SynthesizerEventInterface* callback) const override;
#endif

  bool SynthesizeFromFile(const string& lsp_file, const string& lf0_file,
                          const string& wave_file);

// Below functions is very slow, for benchmark, make them public.
#ifdef TTS_USE_SSE4
  void FastSynthesizeUsingLpc(const vector<vector<float>>& lpc, int frame_step,
                              const vector<float>& excitation,
                              vector<short>* data) const;  // NOLINT
#endif                                                     // TTS_USE_SSE4
#ifdef __ARM_NEON
  void NeonSynthesizeUsingLpc(const vector<vector<float>>& lpc, int frame_step,
                              const vector<float>& excitation,
                              vector<short>* data) const;  // NOLINT
#endif
  void SlowSynthesizeUsingLpc(const vector<vector<float>>& lpc, int frame_step,
                              const vector<float>& excitation,
                              vector<short>* data) const;  // NOLINT
  void GenExcitation(const vector<float>& pitch,
                     vector<float>* excitation) const;
  void FastGenExcitation(const vector<float>& pitch,
                         vector<float>* excitation) const;
  void Lsp2Lpc(const vector<vector<float>>& lsp,
               vector<vector<float>>* lpc) const;
  void FastLsp2Lpc(const vector<vector<float>>& lsp,
                   vector<vector<float>>* lpc) const;
  // ret = v1[- 1] * v2[0] + v1[- 2] * v2[1] + ....
  static float ReverseDotProduct(const float* v1, const float* v2, int dim);

 private:
  void ParseFeature(const vector<float>& fea, bool use_robot,
                    vector<float>* pitch, vector<vector<float>>* lsp) const;

  void GenerateNoiseBuffer(int buffer_frame);
  void GenerateImpulse(const vector<float>& pitch, int sample_number,
                       int frame_number, int frame_step,
                       vector<float>* impulse) const;

  void ConvertLsp(vector<vector<float>>* lsp) const;
  void SortLsp(vector<vector<float>>* lsp) const;

  int sampling_rate_;
  int frame_period_;
  vector<float> noise_buffer_;
  std::unique_ptr<FirFilter> fir_filter_;
  DISALLOW_COPY_AND_ASSIGN(LpcVocoder);
};
}  // namespace vocoder

#endif  // TTS_SYNTHESIZER_VOCODER_LPC_VOCODER_LPC_VOCODER_H_
