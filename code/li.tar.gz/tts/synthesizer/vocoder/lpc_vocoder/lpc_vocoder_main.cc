// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/synthesizer/vocoder/lpc_vocoder/lpc_vocoder.h"

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/string_util.h"

DEFINE_string(lsp_file,
              "tts/synthesizer/vocoder/lpc_vocoder/testdata/chenshu_000001.mgc",
              "");
DEFINE_string(lf0_file,
              "tts/synthesizer/vocoder/lpc_vocoder/testdata/chenshu_000001.lf0",
              "");
DEFINE_string(wave_save_file, "test.wav", "");

DEFINE_string(lsp_dir, "", "");
DEFINE_string(lf0_dir, "", "");
DEFINE_string(resynthesized_dir, "resynthesis", "");

DEFINE_int32(sampling_rate, 16000, "");
DEFINE_int32(frame_period, 80, "");
DEFINE_int32(lsp_dim, 41, "");
DEFINE_bool(alignment_lf0_and_lsp, false, "");

string GetBaseName(const string& file_path) {
  string::size_type index = file_path.rfind('/');
  string path(file_path);
  if (index != string::npos) {
    path = path.substr(index + 1);
  }
  string extension = ".mgc";
  return path.substr(0, path.size() - extension.size());
}

int main(int argc, char** argv) {
  google::ParseCommandLineFlags(&argc, &argv, false);

  vocoder::LpcVocoder vocoder(FLAGS_sampling_rate, FLAGS_frame_period);
  if (FLAGS_lsp_dir.empty()) {
    vocoder.SynthesizeFromFile(FLAGS_lsp_file, FLAGS_lf0_file,
                               FLAGS_wave_save_file);
  } else {
    vector<string> lsp_files;
    mobvoi::File::GetFilesInDir(FLAGS_lsp_dir, &lsp_files);
    for (size_t i = 0; i < lsp_files.size(); ++i) {
      string basename = GetBaseName(lsp_files[i]);
      LOG(INFO) << "basename:" << basename;
      string lf0_file =
          StringPrintf("%s/%s.lf0", FLAGS_lf0_dir.c_str(), basename.c_str());
      string wave_path = StringPrintf(
          "%s/%s.wav", FLAGS_resynthesized_dir.c_str(), basename.c_str());
      if (FLAGS_alignment_lf0_and_lsp) {
        // Alignment
        string lf0;
        mobvoi::File::ReadFileToStringWithMmap(lf0_file, &lf0);
        string lsp;
        mobvoi::File::ReadFileToStringWithMmap(lsp_files[i], &lsp);
        lf0.resize(lsp.size() / FLAGS_lsp_dim);
        mobvoi::File::WriteStringToFile(lf0, lf0_file);
      }

      vocoder.SynthesizeFromFile(lsp_files[i], lf0_file, wave_path);
    }
  }
  LOG(INFO) << "Done.";
  return 0;
}
