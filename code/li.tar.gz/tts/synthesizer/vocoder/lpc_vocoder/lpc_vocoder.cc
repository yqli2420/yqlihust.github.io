// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/synthesizer/vocoder/lpc_vocoder/lpc_vocoder.h"

#include <sys/stat.h>
#include <sys/types.h>

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifdef TTS_USE_SSE4
#include <pmmintrin.h>
#endif  // TTS_USE_SSE4
#ifdef __ARM_NEON
#include <arm_neon.h>
#endif  // __ARM_NEON

#include <algorithm>
#include <utility>

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/base/time.h"
#include "tts/synthesizer/vocoder/lpc_vocoder/firfilter.h"
#include "tts/synthesizer/vocoder/lpc_vocoder/vocoder_util.h"
#include "tts/util/tts_util/util.h"
#include "tts/util/tts_util/wave_util.h"

DEFINE_int32(min_f0, 30, "");
DEFINE_double(additional_gain, 2.0, "");
DEFINE_int32(lpc_energy_threshold, 100000, "lpc energy threshold");
DEFINE_double(lpc_sil_dur, 0.125, "duration seconds");
DEFINE_double(lpc_sil_dur_remove, 0.05,
              "duration seconds remove end & insert silence");

namespace vocoder {
static const int kRobotPitch = 160;
// Use large enough to boost speed. takes up about 1M for 10s duration.
static const int kNoiseBufferFrame = 2000;
// don't change this
static const int kLspOrder = 40;
static const int kFrameStep = 80;

static const int kFirOverLapTimes = 10;
static const float kUVThreshold = 0.5;

// only support order 40
inline void Lsp2LpcByFrame(const vector<float>& lsp, int order,
                           vector<float>* lpc) {
  int i, j;
  double xout1, xout2, xin1, xin2;

  double *pw, *n1, *n2, *n3, *n4 = NULL;
  int m = order / 2;
  double Wp[kLspOrder * 2 + 2];
  pw = Wp;

  for (i = 0; i <= 4 * m + 1; ++i) {
    *pw++ = 0.0;
  }

  pw = Wp;
  xin1 = 1.0;
  xin2 = 1.0;

  /* reconstruct P(z) and Q(z) by 1 - 2xz(-1) +z(-2)
   where x is the LSP
   */

  for (i = 0; i < m; ++i) {
    n1 = pw + (i * 4);
    n2 = n1 + 1;
    n3 = n2 + 1;
    n4 = n3 + 1;
    xout1 = xin1 - 2 * (lsp[2 * i]) * *n1 + *n2;
    xout2 = xin2 - 2 * (lsp[2 * i + 1]) * *n3 + *n4;
    *n2 = *n1;
    *n4 = *n3;
    *n1 = xin1;
    *n3 = xin2;
    xin1 = xout1;
    xin2 = xout2;
  }

  *(n4 + 1) = xin1;
  *(n4 + 2) = xin2;

  xin1 = 0.0;
  xin2 = 0.0;

  for (j = 0; j < order; ++j) {
    for (i = 0; i < m; ++i) {
      n1 = pw + (i * 4);
      n2 = n1 + 1;
      n3 = n2 + 1;
      n4 = n3 + 1;
      xout1 = xin1 - 2 * (lsp[2 * i]) * *n1 + *n2;
      xout2 = xin2 - 2 * (lsp[2 * i + 1]) * *n3 + *n4;
      *n2 = *n1;
      *n4 = *n3;
      *n1 = xin1;
      *n3 = xin2;
      xin1 = xout1;
      xin2 = xout2;
    }

    xout1 = xin1 + *(n4 + 1);
    xout2 = xin2 - *(n4 + 2);
    (*lpc)[j] = (xout1 + xout2) * 0.5;
    *(n4 + 1) = xin1;
    *(n4 + 2) = xin2;

    xin1 = 0.0;
    xin2 = 0.0;
  }
  (*lpc)[order] = lsp[order];
}

// See
// https://github.com/loushuai/FFmpeg-n3.1.3/blob/e241e468c2989d05aeb93fd8e12d5243eca82e1e/libavcodec/g723_1.c
// function : static void lsp2lpc(int16_t *lpc)
// TODO(spye) : Use avx2 to improve this function, or find some high
// performance open source project for this convertion.
// As we can see from .s file,
// GCC compiler can generate high performance assambly code for it.
inline void FastLsp2LpcByFrame(const vector<float>& lsp, int order,
                               vector<float>* lpc) {
  int i, j;
  double xout1, xout2, xin1, xin2;

  double *pw, *n1, *n2, *n3, *n4 = NULL;
  int m = order / 2;
  double Wp[kLspOrder * 2 + 2];
  pw = Wp;

  for (i = 0; i <= 4 * m + 1; ++i) {
    *pw++ = 0.0;
  }

  pw = Wp;
  xin1 = 1.0;
  xin2 = 1.0;

  /* reconstruct P(z) and Q(z) by 1 - 2xz(-1) +z(-2)
   where x is the LSP
   */

  for (i = 0; i < m; ++i) {
    n1 = pw + (i * 4);
    n2 = n1 + 1;
    n3 = n2 + 1;
    n4 = n3 + 1;
    xout1 = xin1 - 2 * (lsp[2 * i]) * *n1 + *n2;
    xout2 = xin2 - 2 * (lsp[2 * i + 1]) * *n3 + *n4;
    *n2 = *n1;
    *n4 = *n3;
    *n1 = xin1;
    *n3 = xin2;
    xin1 = xout1;
    xin2 = xout2;
  }

  *(n4 + 1) = xin1;
  *(n4 + 2) = xin2;

  xin1 = 0.0;
  xin2 = 0.0;

  for (j = 0; j < order; ++j) {
    for (i = 0; i < m; ++i) {
      n1 = pw + (i * 4);
      n2 = n1 + 1;
      n3 = n2 + 1;
      n4 = n3 + 1;
      xout1 = xin1 - 2 * (lsp[2 * i]) * *n1 + *n2;
      xout2 = xin2 - 2 * (lsp[2 * i + 1]) * *n3 + *n4;
      *n2 = *n1;
      *n4 = *n3;
      *n1 = xin1;
      *n3 = xin2;
      xin1 = xout1;
      xin2 = xout2;
    }

    xout1 = xin1 + *(n4 + 1);
    xout2 = xin2 - *(n4 + 2);
    (*lpc)[j] = (xout1 + xout2) * 0.5;
    *(n4 + 1) = xin1;
    *(n4 + 2) = xin2;

    xin1 = 0.0;
    xin2 = 0.0;
  }
  (*lpc)[order] = lsp[order];
}

inline bool IsSorted(const vector<float>& vec) {
  // Skip the first element. it's gain.
  for (size_t i = 2; i < vec.size(); ++i) {
    if (vec[i] >= vec[i - 1]) {
      // Do Nothing. This branch is almost true.
    } else {
      return false;
    }
  }
  return true;
}

void PrintVec(const vector<float>& vec) {
  for (size_t i = 1; i < vec.size(); ++i) {
    std::cout << vec[i] << " ";
  }
  std::cout << endl;
}

void LpcVocoder::SortLsp(vector<vector<float>>* lsp) const {
  for (auto it = lsp->begin(); it != lsp->end(); ++it) {
    if (IsSorted(*it)) {
      // Do Nothing.
    } else {
      sort(it->begin() + 1, it->end());
    }
  }
}

void LpcVocoder::ConvertLsp(vector<vector<float>>* lsp) const {
  CHECK(!lsp->empty() && lsp->at(0).size() == kLspOrder + 1)
      << "lsp is empty or wrong dim";
  int order = lsp->at(0).size() - 1;
  for (auto it = lsp->begin(); it != lsp->end(); ++it) {
    float gain = (*it)[0] * 0.95;
    for (int i = 0; i < order; ++i) {
      (*it)[i] = ((*it)[i + 1]) / k2PI;
    }
    (*it)[order] = gain + FLAGS_additional_gain;
  }
}

void LpcVocoder::SlowSynthesizeUsingLpc(const vector<vector<float>>& lpc,
                                        int frame_step,
                                        const vector<float>& excitation,
                                        vector<int16>* data) const {
  int order = lpc[0].size() - 1;
  CHECK(order == 40) << "order should be 40 now.";
  CHECK(frame_step == 80) << "frame_step should be 80.";
  float y[kFrameStep + kLspOrder];
  memset(y, 0, sizeof(float) * (kFrameStep + kLspOrder));

  data->reserve(lpc.size() * frame_step);
  for (size_t i = 0; i < lpc.size(); ++i) {
    float gain = exp(lpc[i][order]);
    int start_point = i * frame_step;

    memcpy(y, y + frame_step, order * sizeof(float));
    memset(y + order, 0, frame_step * sizeof(float));

    for (int j = 0; j < kFrameStep; ++j) {
      y[j + order] = gain * excitation[j + start_point];
      for (int k = 0; k < kLspOrder; ++k) {
        y[j + order] -= y[j + order - k - 1] * lpc[i][k];
      }
    }

    for (int j = start_point; j < start_point + frame_step; ++j) {
      float final_val = 0;
      if (LIKELY(y[j - start_point + order] >= kint16min &&
                 y[j - start_point + order] <= kint16max)) {
        final_val = y[j - start_point + order];
        // Do Nothing, for branch predict.
      } else if (y[j - start_point + order] > kint16max) {
        final_val = kint16max;
      } else {
        final_val = kint16min;
      }
      data->push_back(final_val);
    }
  }
}

// computation critical
// lpc : 1041 * 41,
// excitation : 83280.
// frame_step : 80
#ifdef TTS_USE_SSE4
void LpcVocoder::FastSynthesizeUsingLpc(const vector<vector<float>>& lpc,
                                        int frame_step,
                                        const vector<float>& excitation,
                                        vector<int16>* data) const {
  int order = lpc[0].size() - 1;
  DCHECK(order == 40) << "order should be 40 now.";
  DCHECK(frame_step == 80) << "frame_step should be 80.";
  float y[kFrameStep + kLspOrder];
  memset(y, 0, sizeof(float) * (kFrameStep + kLspOrder));

  data->reserve(lpc.size() * frame_step);
  for (size_t i = 0; i < lpc.size(); ++i) {
    float gain = exp(lpc[i][order]);
    int start_point = i * frame_step;

    memcpy(y, y + frame_step, order * sizeof(float));
    memset(y + order, 0, frame_step * sizeof(float));

    for (int j = 0; j < kFrameStep; ++j) {
      float sumall = 0;
      // TODO(spye) : Use SIMD to compute below line. each time process 4
      // floats. 20 * 4 = 80.
      float* ptr = &y[j + order];
      *ptr = gain * excitation[j + start_point];
      __m128 sum = _mm_setzero_ps();
      // Expand two groups for better CPU pipeline.
      for (int k = 0; k < order; k += 8) {
        // See this post for NOT using _mm_load_ps
        // https://stackoverflow.com/questions/11085924/segmentation-fault-while-working-with-sse-intrinsics-due-to-incorrect-memory-ali
        __m128 a1 = _mm_loadu_ps(ptr - k - 4);
        __m128 a2 = _mm_loadu_ps(ptr - k - 8);
        __m128 b1 = _mm_load_ps(&lpc[i][k]);
        __m128 b2 = _mm_load_ps(&lpc[i][k + 4]);
        // revert a.
        a1 = _mm_shuffle_ps(a1, a1, _MM_SHUFFLE(0, 1, 2, 3));
        a2 = _mm_shuffle_ps(a2, a2, _MM_SHUFFLE(0, 1, 2, 3));

        // mul
        __m128 c1 = _mm_mul_ps(a1, b1);
        __m128 c2 = _mm_mul_ps(a2, b2);

        sum = _mm_add_ps(sum, _mm_add_ps(c1, c2));
      }
      // All all elements in sum.
      // https://stackoverflow.com/questions/5526658/intel-sse-why-does-mm-extract-ps-return-int-instead-of-float
      // // NOLINT
      sumall +=
          _mm_cvtss_f32(_mm_shuffle_ps(sum, sum, _MM_SHUFFLE(0, 0, 0, 0)));
      sumall +=
          _mm_cvtss_f32(_mm_shuffle_ps(sum, sum, _MM_SHUFFLE(0, 0, 0, 1)));
      sumall +=
          _mm_cvtss_f32(_mm_shuffle_ps(sum, sum, _MM_SHUFFLE(0, 0, 0, 2)));
      sumall +=
          _mm_cvtss_f32(_mm_shuffle_ps(sum, sum, _MM_SHUFFLE(0, 0, 0, 3)));
      *ptr -= sumall;
    }

    vector<float> frame_step_vals;
    frame_step_vals.reserve(frame_step_vals.size() + frame_step);
    for (int j = start_point; j < start_point + frame_step; ++j) {
      float final_val = 0;
      if (LIKELY(y[j - start_point + order] >= kint16min &&
                 y[j - start_point + order] <= kint16max)) {
        final_val = y[j - start_point + order];
        // Do Nothing, for branch predict.
      } else if (y[j - start_point + order] > kint16max) {
        final_val = kint16max;
      } else {
        final_val = kint16min;
      }
      if (start_point < 40 * frame_step) {
        frame_step_vals.emplace_back(final_val);
      } else {
        data->emplace_back(static_cast<int16>(final_val));
      }
    }

    if (start_point < 40 * frame_step) {
      float energy = 0.0;
      for (size_t j = 0; j < (size_t)frame_step; ++j) {
        energy += frame_step_vals[j] * frame_step_vals[j];
      }
      if (energy > FLAGS_lpc_energy_threshold) {
        data->insert(data->end(), frame_step_vals.begin(),
                     frame_step_vals.end());
      }
    }
  }
}
#endif  // TTS_USE_SSE4

#ifdef __ARM_NEON
inline float32x4_t Reverse(float32x4_t input) {
  auto rev = vrev64q_f32(input);
  return vcombine_f32(vget_high_f32(rev), vget_low_f32(rev));
}

inline float AccInsideReg(float32x4_t input) {
  float arr[4];
  vst1q_f32(arr, input);
  float res = 0;
  for (int i = 0; i < 4; ++i) {
    res += arr[i];
  }
  return res;
}

// TODO(ypfeng): add unit test
void LpcVocoder::NeonSynthesizeUsingLpc(const vector<vector<float>>& lpc,
                                        int frame_step,
                                        const vector<float>& excitation,
                                        vector<int16>* data) const {
  int order = lpc[0].size() - 1;
  CHECK(order == kLspOrder) << "order should be 40 now.";
  CHECK(frame_step == kFrameStep) << "frame_step should be 80.";
  float y[kFrameStep + kLspOrder];
  memset(y, 0, sizeof(float) * (frame_step + order));

  data->reserve(lpc.size() * frame_step);
  data->clear();
  int start_point = 0;
  for (size_t i = 0; i < lpc.size(); ++i, start_point += frame_step) {
    auto ith_lpc = lpc[i].data();
    float gain = std::exp(ith_lpc[order]);
    memcpy(y, y + frame_step, order * sizeof(float));

    auto y_order = y + order;
    // TODO(ypfeng): could accumulate cause overflow/saturation?
    for (int j = 0; j < frame_step; ++j) {
      y_order[j] = gain * excitation[j + start_point];
      float32x4_t acc = {0.0f, 0.0f, 0.0f, 0.0f};
      for (int k = 0; k < order; k += 8) {
        auto lpc_f32x4_0 = vld1q_f32(ith_lpc + k);
        auto y_f32x4_0 = vld1q_f32(y_order + j - k - 4);
        auto y_f32x4_rev_0 = Reverse(y_f32x4_0);
        auto mul_0 = vmulq_f32(y_f32x4_rev_0, lpc_f32x4_0);

        auto lpc_f32x4_1 = vld1q_f32(ith_lpc + k + 4);
        auto y_f32x4_1 = vld1q_f32(y_order + j - k - 8);
        auto y_f32x4_rev_1 = Reverse(y_f32x4_1);
        auto mul_1 = vmulq_f32(y_f32x4_rev_1, lpc_f32x4_1);
        acc = vaddq_f32(acc, vaddq_f32(mul_0, mul_1));
      }
      y_order[j] -= AccInsideReg(acc);
    }

    float final_val = 0;
    vector<float> frame_step_vals;
    frame_step_vals.reserve(frame_step_vals.size() + frame_step);

    // TODO(ypfeng): neon version
    for (int j = 0; j < frame_step; ++j) {
      if (LIKELY(y_order[j] >= kint16min && y_order[j] <= kint16max)) {
        final_val = y_order[j];
        // Do Nothing, for branch predict.
      } else if (y_order[j] > kint16max) {
        final_val = kint16max;
      } else {
        final_val = kint16min;
      }
      if (start_point < 40 * frame_step) {
        frame_step_vals.emplace_back(final_val);
      } else {
        data->emplace_back(static_cast<int16>(final_val));
      }
    }

    if (start_point < 40 * frame_step) {
      float energy = 0.0;
      for (size_t j = 0; j < (size_t)frame_step; ++j) {
        energy += frame_step_vals[j] * frame_step_vals[j];
      }
      if (energy > FLAGS_lpc_energy_threshold) {
        data->insert(data->end(), frame_step_vals.begin(),
                     frame_step_vals.end());
      }
    }
  }
}
#endif  // __ARM_NEON

void LpcVocoder::GenerateImpulse(const vector<float>& pitch, int sample_number,
                                 int frame_number, int frame_step,
                                 vector<float>* impulse) const {
  int last_epoch = 0;

  impulse->resize(frame_number * frame_step, 0);
  for (int i = 0; i < frame_number; ++i) {
    int start_point = i * frame_step;

    if (pitch[i] > FLAGS_min_f0) {
      if (i > 1 && pitch[i - 1] <= FLAGS_min_f0) {
        impulse->at(start_point) = 1;
        last_epoch = start_point;
      }
      int T0 = static_cast<int>(sampling_rate_ / pitch[i]);
      for (int j = start_point; j < start_point + frame_step; ++j) {
        int multiple = static_cast<int>((j - last_epoch) / T0);
        if ((multiple > 0) && (multiple == (j - last_epoch) / T0)) {
          for (int k = 1; k <= multiple; k++) {
            impulse->at(last_epoch + k * T0) = 1;
          }
          last_epoch = j;
        }
      }
    }
  }
}

// functions for random noise generation
static int LPC_rnd(uint64* next) {
  int r;
  *next = *next * 1103515245L + 12345;
  r = (*next / 65536L) % RAND_MAX;
  return r;
}

void LpcVocoder::GenerateNoiseBuffer(int buffer_frame) {
  uint64 seed = mobvoi::GetTimeInMs();
  size_t buffer_size = buffer_frame * frame_period_;
  noise_buffer_.resize(buffer_size);
  for (size_t i = 0; i < buffer_size; ++i) {
    float n1 = (LPC_rnd(&seed) + 1) /
               static_cast<float>(static_cast<int64>(RAND_MAX) + 1);
    float n2 = (LPC_rnd(&seed) + 1) /
               static_cast<float>(static_cast<int64>(RAND_MAX) + 1);
    float z = static_cast<float>(sqrt(-2.0 * log(n1)) * sin(k2PI * n2));
    noise_buffer_[i] = z;
  }
  float energy = 0;
  for (size_t i = 0; i < buffer_size; ++i) {
    energy += noise_buffer_[i] * noise_buffer_[i];
  }
  energy = sqrt(energy);
  for (size_t i = 0; i < buffer_size; ++i) {
    noise_buffer_[i] = noise_buffer_[i] / energy;
  }
}

LpcVocoder::LpcVocoder(int sampling_rate, int frame_period)
    : sampling_rate_(sampling_rate), frame_period_(frame_period) {
  fir_filter_.reset(new FirFilter(kFirOverLapTimes));
  GenerateNoiseBuffer(kNoiseBufferFrame);
}

LpcVocoder::~LpcVocoder() {}

void LpcVocoder::Lsp2Lpc(const vector<vector<float>>& lsp,
                         vector<vector<float>>* lpc) const {
  int frame_number = lsp.size();
  lpc->reserve(frame_number);
  for (int i = 0; i < frame_number; ++i) {
    vector<float> lpc_item(kLspOrder + 1);
    Lsp2LpcByFrame(lsp[i], kLspOrder, &lpc_item);
    lpc->emplace_back(std::move(lpc_item));
  }
}

void LpcVocoder::FastLsp2Lpc(const vector<vector<float>>& lsp,
                             vector<vector<float>>* lpc) const {
  int frame_number = lsp.size();
  lpc->reserve(frame_number);
  // TODO(spye): Refactor with SIMD.
  for (int i = 0; i < frame_number; ++i) {
    vector<float> lpc_item(kLspOrder + 1);
    FastLsp2LpcByFrame(lsp[i], kLspOrder, &lpc_item);
    lpc->emplace_back(std::move(lpc_item));
  }
}

void LpcVocoder::GenExcitation(const vector<float>& pitch,
                               vector<float>* excitation) const {
  int sample_number = pitch.size() * frame_period_;

  // Voiced
  vector<float> impulse;
  GenerateImpulse(pitch, sample_number, pitch.size(), frame_period_, &impulse);

  // Unvoiced
  vector<float> noise(sample_number);
  float new_energy = sqrt(static_cast<float>(pitch.size()));
  // Slow version.
  for (int i = 0; i < sample_number; ++i) {
    noise[i] = noise_buffer_[i % kNoiseBufferFrame] * new_energy;
  }

  float ratio[5] = {1.0f, 0.8f, 0.7f, 0.6f, 0.5f};
  int band_number = fir_filter_->band_number();

  // Use malloc to alloc flat memory (1D instead of 2D).
  const int col_size = fir_filter_->overlap() + impulse.size();
  const int mem_size = sizeof(float) * band_number * col_size;
  float* impulse_band = reinterpret_cast<float*>(malloc(mem_size));
  memset(impulse_band, 0, mem_size);
  float* noise_band = reinterpret_cast<float*>(malloc(mem_size));
  memset(noise_band, 0, mem_size);

  fir_filter_->DoConvolution(impulse, col_size, impulse_band);
  fir_filter_->DoConvolution(noise, col_size, noise_band);

  // Generate excitation
  excitation->resize(sample_number, 0);
  for (int i = 0; i < band_number; ++i) {
    for (int j = 0; j < sample_number; ++j) {
      if (pitch[j / frame_period_] > FLAGS_min_f0) {
        (*excitation)[j] += impulse_band[i * col_size + j] * ratio[i] +
                            noise_band[i * col_size + j] * (1 - ratio[i]);
      } else {
        (*excitation)[j] += noise_band[i * col_size + j];
      }
    }
  }
}

void LpcVocoder::FastGenExcitation(const vector<float>& pitch,
                                   vector<float>* excitation) const {
  int sample_number = pitch.size() * frame_period_;

  // Voiced
  vector<float> impulse;
  GenerateImpulse(pitch, sample_number, pitch.size(), frame_period_, &impulse);

  // Unvoiced
  vector<float> noise(sample_number);
  float new_energy = sqrt(static_cast<float>(pitch.size()));
  // Slow version.
  for (int i = 0; i < sample_number; ++i) {
    noise[i] = noise_buffer_[i % kNoiseBufferFrame] * new_energy;
  }

  const float ratio[5] = {1.0f, 0.8f, 0.7f, 0.6f, 0.5f};
  const float one_sub_ratio[5] = {0.0f, 0.2f, 0.3f, 0.4f, 0.5f};
  int band_number = fir_filter_->band_number();

  // Use malloc to alloc flat memory (1D instead of 2D).
  const int col_size = fir_filter_->overlap() + impulse.size();
  const int mem_size = sizeof(float) * band_number * col_size;
  float* impulse_band = reinterpret_cast<float*>(malloc(mem_size));
  memset(impulse_band, 0, mem_size);
  float* noise_band = reinterpret_cast<float*>(malloc(mem_size));
  memset(noise_band, 0, mem_size);

// DoConvolution use 3X times than below for loop.
#ifdef TTS_USE_SSE4
  fir_filter_->FastDoConvolution(impulse, col_size, impulse_band);
  fir_filter_->FastDoConvolution(noise, col_size, noise_band);
#else
  fir_filter_->DoConvolution(impulse, col_size, impulse_band);
  fir_filter_->DoConvolution(noise, col_size, noise_band);
#endif  // TTS_USE_SSE4

  // Generate excitation
  // band_number : 5
  excitation->resize(sample_number, 0);
  CHECK_EQ(band_number, 5) << "band_number should be 5.";

  excitation->resize(sample_number, 0);
  int pitch_index = 0;
  int pitch_cnt = 0;
#define DO_EXCITATION(i)                                                   \
  pitch_index = 0;                                                         \
  pitch_cnt = 0;                                                           \
  for (int j = 0; j < sample_number; ++j, ++pitch_cnt) {                   \
    if (pitch_cnt == frame_period_) {                                      \
      ++pitch_index;                                                       \
      pitch_cnt = 0;                                                       \
    }                                                                      \
    if (pitch[pitch_index] > FLAGS_min_f0) {                               \
      (*excitation)[j] += impulse_band[i * col_size + j] * ratio[i] +      \
                          noise_band[i * col_size + j] * one_sub_ratio[i]; \
    } else {                                                               \
      (*excitation)[j] += noise_band[i * col_size + j];                    \
    }                                                                      \
  }
  // Use macro to unroll all bands.
  DO_EXCITATION(0)
  DO_EXCITATION(1)
  DO_EXCITATION(2)
  DO_EXCITATION(3)
  DO_EXCITATION(4)

  free(impulse_band);
  free(noise_band);
}

#ifndef FOR_PORTABLE
bool LpcVocoder::Synthesize(const vector<float>& fea,
                            const tts::TTSOption& tts_option,
                            float speaker_volume, encoder::FlacEncoder* encoder,
                            tts::SynthesizerEventInterface* callback) const {
  // TODO(haoyin) use vocoder callback
  return true;
}
#endif

bool LpcVocoder::Synthesize(const vector<float>& fea,
                            const tts::TTSOption& tts_option,
                            vector<int16>* data) const {
  vector<float> pitch;
  vector<vector<float>> lsp;
  ParseFeature(fea, tts_option.use_robot(), &pitch, &lsp);
  Synthesize(pitch, &lsp, data);
  #ifndef FOR_PORTABLE
  // tacotron model should add silence
  if (tts_option.speaker() != "cissy" && tts_option.speaker() != "tina"
     && tts_option.speaker().find("gru") == string::npos) {
    // remove last points & insert silence
    VLOG(2) << "FLAGS_lpc_sil_dur_remove:" << FLAGS_lpc_sil_dur_remove;
    vector<int16> silence_remove(FLAGS_lpc_sil_dur_remove
                                 * tts::kDefaultSamplingFrequency);

    data->erase(data->end() - silence_remove.size(), data->end());
    data->reserve(data->size() + silence_remove.size());
    data->insert(data->end(), silence_remove.begin(), silence_remove.end());

    vector<int16> silence(FLAGS_lpc_sil_dur * tts::kDefaultSamplingFrequency);
    data->reserve(data->size() + silence.size());
    data->insert(data->end(), silence.begin(), silence.end());
  }
  #endif
  return true;
}

/*  memory layout of cmp:
 *
 *                   ______cmp_dims_______
 *                  /                     \
 *                  lsp             f0   uv
 *         index    0-40            41   42
 *             / 0  .......................
 *             | 1  .......................
 *             | 2  .......................
 *   num_frame | .  .......................
 *             | .  .......................
 *             \ .  .......................
 */
void LpcVocoder::ParseFeature(const vector<float>& fea, bool use_robot,
                              vector<float>* pitch,
                              vector<vector<float>>* lsp) const {
  int fea_dim = kLspOrder + 3;  // mgc pitch uv
  CHECK(fea.size() % fea_dim == 0) << " wrong feature dims:";
  int frame_num = fea.size() / fea_dim;

  // set lsp
  lsp->resize(frame_num);
  for (auto& lsp_frame : *lsp) {
    lsp_frame.reserve(kLspOrder + 1);
  }
  for (int i = 0; i < frame_num; ++i) {
    (*lsp)[i].insert((*lsp)[i].end(), fea.begin() + i * fea_dim,
                     fea.begin() + i * fea_dim + kLspOrder + 1);
  }

  // set pitch
  pitch->reserve(frame_num);
  for (int i = 0; i < frame_num; ++i) {
    if (fea[i * fea_dim + fea_dim - 1] > kUVThreshold) {
      if (use_robot) {
        pitch->push_back(kRobotPitch);
      } else {
        pitch->push_back(fea[i * fea_dim + fea_dim - 2]);
      }
    } else {
      pitch->push_back(0);
    }
  }
}

bool LpcVocoder::Synthesize(const vector<float>& pitch,
                            vector<vector<float>>* lsp,
                            vector<int16>* data) const {
  SortLsp(lsp);
  ConvertLsp(lsp);
  AdjustLsp(lsp);
  CosineLsp(lsp);

  vector<vector<float>> lpc;
  Lsp2Lpc(*lsp, &lpc);

  vector<float> excitation;
  FastGenExcitation(pitch, &excitation);

// Using excitation and LPC to generate the wave
#ifdef TTS_USE_SSE4
  FastSynthesizeUsingLpc(lpc, frame_period_, excitation, data);
#elif defined __ARM_NEON
  NeonSynthesizeUsingLpc(lpc, frame_period_, excitation, data);
#else
  SlowSynthesizeUsingLpc(lpc, frame_period_, excitation, data);
#endif  // TTS_USE_SSE4
  return true;
}

bool LpcVocoder::SynthesizeFromFile(const string& lsp_file,
                                    const string& lf0_file,
                                    const string& wave_file) {
  // Load pitch
  vector<float> pitch;
  LoadPitchFile(lf0_file.c_str(), &pitch);
  VLOG(1) << "Pitch size:" << pitch.size();

  // Load LPC file and convert LPC to LPC
  vector<vector<float>> lsp;
  int frame_num = pitch.size();
  LoadLspFile(lsp_file.c_str(), frame_num, &lsp);
  VLOG(1) << "lsp size:" << lsp.size();

  if (pitch.size() != lsp.size()) {
    LOG(ERROR) << "pitch size NOT equal to frame size.";
    return false;
  }

  vector<int16> data;
  Synthesize(pitch, &lsp, &data);

  string wave_data;
  string riff_header;
  tts::WaveFile::WriteRiffHeader(sampling_rate_, data.size(), &riff_header);
  wave_data.append(riff_header);
  for (size_t i = 0; i < data.size(); ++i) {
    wave_data.append(reinterpret_cast<const char*>(&data[i]), sizeof(int16));
  }
  mobvoi::File::WriteStringToFileOrDie(wave_data, wave_file);
  return true;
}
}  // namespace vocoder
