// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/synthesizer/vocoder/lpc_vocoder/lpc_vocoder.h"

#include "benchmark/benchmark.h"
#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/base/time.h"
#include "tts/synthesizer/vocoder/lpc_vocoder/vector_util.h"
#include "tts/synthesizer/vocoder/lpc_vocoder/vocoder_util.h"

// #define BASIC_BENCHMARK(x) BENCHMARK(x)->Arg(8)->Arg(64)->Arg(512)
#define BASIC_BENCHMARK(x) BENCHMARK(x)->Arg(8)

#ifdef TTS_USE_SSE4
void BM_CompareSynthesizeUsingLpc(benchmark::State& state) {  // NOLINT
  vocoder::LpcVocoder vocoder(16000, 80);
  vector<vector<float>> lpc;
  vocoder::Read2DVector("tts/synthesizer/vocoder/lpc_vocoder/testdata/test.lpc",
                        &lpc);
  VLOG(2) << "rows : " << lpc.size() << ", cols : " << lpc[0].size();
  int frame_step = 80;
  vector<float> excitation;
  vocoder::ReadVector(
      "tts/synthesizer/vocoder/lpc_vocoder/testdata/test.excitation",
      &excitation);
  VLOG(2) << "excitation size : " << excitation.size();

  vector<int16> data;
  vector<int16> data2;
  vocoder.FastSynthesizeUsingLpc(lpc, frame_step, excitation, &data);
  vocoder.SlowSynthesizeUsingLpc(lpc, frame_step, excitation, &data2);
  VLOG(2) << "slow size : " << data.size() << ", slow size : " << data2.size();
  // Since we use float, result maybe different a little.
  vocoder::EqualVector(data, data2, static_cast<int16>(2));
}
BENCHMARK(BM_CompareSynthesizeUsingLpc);

void BM_FastSynthesizeUsingLpc(benchmark::State& state) {  // NOLINT
  vocoder::LpcVocoder vocoder(16000, 80);
  vector<vector<float>> lpc;
  vocoder::Read2DVector("tts/synthesizer/vocoder/lpc_vocoder/testdata/test.lpc",
                        &lpc);
  VLOG(2) << "rows : " << lpc.size() << ", cols : " << lpc[0].size();
  int frame_step = 80;
  vector<float> excitation;
  vocoder::ReadVector(
      "tts/synthesizer/vocoder/lpc_vocoder/testdata/test.excitation",
      &excitation);
  VLOG(2) << "excitation size : " << excitation.size();

  for (auto _ : state) {
    for (int x = 0; x < state.range(0); ++x) {
      vector<int16> data;
      vocoder.FastSynthesizeUsingLpc(lpc, frame_step, excitation, &data);
    }
  }
}
BASIC_BENCHMARK(BM_FastSynthesizeUsingLpc);
#endif

void BM_SlowSynthesizeUsingLpc(benchmark::State& state) {  // NOLINT
  vocoder::LpcVocoder vocoder(16000, 80);
  vector<vector<float>> lpc;
  vocoder::Read2DVector("tts/synthesizer/vocoder/lpc_vocoder/testdata/test.lpc",
                        &lpc);
  VLOG(2) << "rows : " << lpc.size() << ", cols : " << lpc[0].size();
  int frame_step = 80;
  vector<float> excitation;
  vocoder::ReadVector(
      "tts/synthesizer/vocoder/lpc_vocoder/testdata/test.excitation",
      &excitation);
  VLOG(2) << "excitation size : " << excitation.size();

  for (auto _ : state) {
    for (int x = 0; x < state.range(0); ++x) {
      vector<int16> data;
      vocoder.SlowSynthesizeUsingLpc(lpc, frame_step, excitation, &data);
    }
  }
}
BASIC_BENCHMARK(BM_SlowSynthesizeUsingLpc);

void BM_GenExcitation(benchmark::State& state) {  // NOLINT
  vocoder::LpcVocoder vocoder(16000, 80);
  vector<float> pitch;
  vocoder::ReadVector(
      "tts/synthesizer/vocoder/lpc_vocoder/testdata/GenExcitation.input",
      &pitch);

  for (auto _ : state) {
    for (int x = 0; x < state.range(0); ++x) {
      vector<float> excitation;
      vocoder.GenExcitation(pitch, &excitation);
    }
  }
}
BASIC_BENCHMARK(BM_GenExcitation);

void BM_FastGenExcitation(benchmark::State& state) {  // NOLINT
  vocoder::LpcVocoder vocoder(16000, 80);
  vector<float> pitch;
  vocoder::ReadVector(
      "tts/synthesizer/vocoder/lpc_vocoder/testdata/GenExcitation.input",
      &pitch);

  for (auto _ : state) {
    for (int x = 0; x < state.range(0); ++x) {
      vector<float> excitation;
      vocoder.FastGenExcitation(pitch, &excitation);
    }
  }
}
BASIC_BENCHMARK(BM_FastGenExcitation);

void BM_CompareGenExcitation(benchmark::State& state) {  // NOLINT
  vocoder::LpcVocoder vocoder(16000, 80);
  vector<float> pitch;
  vocoder::ReadVector(
      "tts/synthesizer/vocoder/lpc_vocoder/testdata/GenExcitation.input",
      &pitch);

  vector<float> excitation;
  vocoder.FastGenExcitation(pitch, &excitation);
  vector<float> excitation2;
  vocoder.GenExcitation(pitch, &excitation2);
  CHECK(vocoder::EqualVector(excitation, excitation2, 0.001f));
}

BENCHMARK(BM_CompareGenExcitation);

void BM_Lsp2Lpc(benchmark::State& state) {  // NOLINT
  vocoder::LpcVocoder vocoder(16000, 80);
  vector<vector<float>> lsp;
  vocoder::Read2DVector(
      "tts/synthesizer/vocoder/lpc_vocoder/testdata/Lsp2Lpc.input", &lsp);

  for (auto _ : state) {
    for (int x = 0; x < state.range(0); ++x) {
      vector<vector<float>> lpc;
      vocoder.Lsp2Lpc(lsp, &lpc);
    }
  }
}
BASIC_BENCHMARK(BM_Lsp2Lpc);

void BM_FastLsp2Lpc(benchmark::State& state) {  // NOLINT
  vocoder::LpcVocoder vocoder(16000, 80);
  vector<vector<float>> lsp;
  vocoder::Read2DVector(
      "tts/synthesizer/vocoder/lpc_vocoder/testdata/Lsp2Lpc.input", &lsp);

  for (auto _ : state) {
    for (int x = 0; x < state.range(0); ++x) {
      vector<vector<float>> lpc;
      vocoder.FastLsp2Lpc(lsp, &lpc);
    }
  }
}
BASIC_BENCHMARK(BM_FastLsp2Lpc);

void BM_CompareLsp2Lpc(benchmark::State& state) {  // NOLINT
  vocoder::LpcVocoder vocoder(16000, 80);
  vector<vector<float>> lsp;
  vocoder::Read2DVector(
      "tts/synthesizer/vocoder/lpc_vocoder/testdata/Lsp2Lpc.input", &lsp);

  vector<vector<float>> lpc;
  vocoder.FastLsp2Lpc(lsp, &lpc);
  vector<vector<float>> lpc2;
  vocoder.Lsp2Lpc(lsp, &lpc2);
  CHECK_EQ(lpc.size(), lpc2.size()) << "size is not equal.";
  for (size_t i = 0; i < lpc.size(); ++i) {
    CHECK(vocoder::EqualVector(lpc[i], lpc2[i], 0.001f));
  }
}
BASIC_BENCHMARK(BM_CompareLsp2Lpc);
