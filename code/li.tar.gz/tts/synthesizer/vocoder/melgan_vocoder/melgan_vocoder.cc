// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: yunlinchen@mobvoi.com (Yunlin Chen)

#include "tts/synthesizer/vocoder/melgan_vocoder/melgan_vocoder.h"

#include "mobvoi/base/file.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/string_util.h"

#include "tts/util/encoder/encoder.h"
#include "tts/util/tts_util/util.h"
#include "tts/util/tts_util/wave_util.h"

DEFINE_bool(if_test_chunk_streaming, false, "test streaming");
DEFINE_double(melgan_sil_begin_dur, 0.0375,
              "duration seconds to solve begin glitch");
DEFINE_double(melgan_sil_end_dur, 0.0625,
              "duration seconds to solve end glitch");

namespace vocoder {
static const int kPadding = 3;
static const int kMelChannel = 80;
static const float kResstackContext = 1 + 1 + 3 + 1 + 9 + 27 + 1;
static const int kOutputContext = std::ceil(
    kResstackContext / 8 + kResstackContext / 40 + kResstackContext / 200);
static const int kInputContext = kPadding + kOutputContext;
static const float kFrameShift = 0.0125;

MelGANVocoder::MelGANVocoder(const std::string& model_file) {
  model_.reset(new mobvoi::one::MelGANModel(model_file));
}

MelGANVocoder::~MelGANVocoder() {}

static void FloatVecToIntVec(const vector<float>& src_vector,
                             vector<int16>* dst_vector) {
  dst_vector->reserve(src_vector.size());
  for (auto it : src_vector) {
    it = it * (INT16_MAX + 1);
    if (it > INT16_MAX) {
      it = INT16_MAX;
    } else if (it < INT16_MIN) {
      it = INT16_MIN;
    }
    dst_vector->emplace_back(static_cast<int16>(it));
  }
}

static vector<float> GetInputChunk(const vector<float>& input, int start_frame,
                                   int chunk_size) {
  int total_seqlen = input.size() / kMelChannel - 2 * kPadding;

  CHECK_GE(start_frame, 0);
  CHECK_LE(start_frame, total_seqlen - 1);

  int start_index = start_frame + kPadding;
  int input_start = start_index - kInputContext;
  input_start = std::max(input_start, 0);

  int end_frame = start_frame + chunk_size;
  int end_index = end_frame + kPadding;
  int input_end = end_index + kInputContext;
  input_end = std::min(static_cast<int>(input.size() / kMelChannel), input_end);

  return std::vector<float>(input.begin() + input_start * kMelChannel,
                            input.begin() + input_end * kMelChannel);
}

static void GetReflectionPad(const vector<float>& input, int padding,
                             vector<float>* output) {
  output->resize(input.size());
  std::copy(input.begin(), input.end(), output->begin());
  output->reserve(input.size() + 2 * padding * kMelChannel);
  for (size_t i = 1; i <= (size_t)padding; ++i) {
    output->insert(output->begin(), input.begin() + i * kMelChannel,
                   input.begin() + (i + 1) * kMelChannel);
    output->insert(output->end(), input.end() - (i + 1) * kMelChannel,
                   input.end() - i * kMelChannel);
  }
}

bool MelGANVocoder::Synthesize(const vector<float>& in_features,
                               const tts::TTSOption& tts_option,
                               vector<int16>* wav_vector) const {
  vector<float> in_features_padding;
  GetReflectionPad(in_features, kPadding, &in_features_padding);

  int seq_len = static_cast<int>(in_features.size()) / kMelChannel;
  int chunk_size = model_->DefaultChunkSize();
  VLOG(2) << "melgan model chunk size " << chunk_size;

  vector<float> result;
  if (FLAGS_if_test_chunk_streaming) {
    int start_frame = 0;
    vector<float> features;

    // first chunk
    int first_chunk_size = chunk_size > seq_len ? seq_len : chunk_size;
    features =
        GetInputChunk(in_features_padding, start_frame, first_chunk_size);
    vector<float> output;
    output = model_->Inference(features, chunk_size, 0);
    result.insert(result.end(), output.begin(), output.end());
    start_frame += first_chunk_size;

    // intermediate chunks
    for (int i = 1; i < seq_len / chunk_size - 1;
         ++i, start_frame += chunk_size) {
      features = GetInputChunk(in_features_padding, start_frame, chunk_size);
      output = model_->Inference(features);
      result.insert(result.end(), output.begin(), output.end());
    }

    // last chunk
    if (seq_len - start_frame > 0) {
      chunk_size = seq_len - start_frame;
      features = GetInputChunk(in_features_padding, start_frame, chunk_size);
      output = model_->Inference(features, chunk_size, kOutputContext);
      result.insert(result.end(), output.begin(), output.end());
    }

  } else {
    result = model_->Inference(in_features_padding, seq_len, 0);
  }
  FloatVecToIntVec(result, wav_vector);

  if (seq_len * kFrameShift >
      (FLAGS_melgan_sil_begin_dur + FLAGS_melgan_sil_end_dur)) {
    int cut_begin_sil_samples =
        FLAGS_melgan_sil_begin_dur * tts::kDefaultSamplingFrequency;
    int cut_end_sil_samples =
        FLAGS_melgan_sil_end_dur * tts::kDefaultSamplingFrequency;
    std::fill_n(wav_vector->begin(), cut_begin_sil_samples, 0);
    wav_vector->erase(wav_vector->end() - cut_end_sil_samples,
                      wav_vector->end());
    // audio fade out
    float decay_time =
        kFrameShift;  // time to fall to 10% of original amplitude
    float sample_time = 1.0 / tts::kDefaultSamplingFrequency;
    float natural_decay_factor = exp(-log(10) * sample_time / decay_time);

    int decay_samples = decay_time * tts::kDefaultSamplingFrequency;
    int index = wav_vector->size() - decay_samples;
    float iterationSum = 1.0f;
    for (size_t i = 0; i < (size_t)decay_samples; ++i) {
      int pcm = wav_vector->at(index + i);
      iterationSum *= natural_decay_factor;
      wav_vector->at(index + i) = static_cast<int16>(iterationSum * pcm);
    }
    wav_vector->reserve(wav_vector->size() + cut_end_sil_samples);
    wav_vector->insert(wav_vector->end(), cut_end_sil_samples, 0);
  }

  return true;
}

#ifndef FOR_PORTABLE
bool MelGANVocoder::Synthesize(const vector<float>& in_features,
                               const tts::TTSOption& tts_option,
                               float speaker_volume,
                               encoder::FlacEncoder* encoder,
                               tts::SynthesizerEventInterface* callback) const {
  vector<float> in_features_padding;
  GetReflectionPad(in_features, kPadding, &in_features_padding);
  // vocoder callback each frames
  int chunk_size = model_->DefaultChunkSize();
  float volume = tts_option.volume() * speaker_volume;
  encoder::PostProcessOption pp_option(
      tts::kDefaultSamplingFrequency, tts_option.sampling_frequency(),
      tts::kNoNormalizeFactor, volume, tts_option.file_format());
  vector<int16> data;
  int start_frame = 0;
  int seq_len = static_cast<int>(in_features.size()) / kMelChannel;
  vector<float> features;

  int cut_begin_sil_samples =
      FLAGS_melgan_sil_begin_dur * tts::kDefaultSamplingFrequency;
  int cut_end_sil_samples =
      FLAGS_melgan_sil_end_dur * tts::kDefaultSamplingFrequency;

  // first chunk
  int first_chunk_size = chunk_size > seq_len ? seq_len : chunk_size;
  features = GetInputChunk(in_features_padding, start_frame, first_chunk_size);
  vector<float> output;
  output = model_->Inference(features, first_chunk_size, 0);
  FloatVecToIntVec(output, &data);
  if (static_cast<int32>(data.size()) > cut_begin_sil_samples) {
    data.erase(data.begin(), data.begin() + cut_begin_sil_samples);
  }
  if (first_chunk_size == seq_len) {
    std::fill_n(data.end() - cut_end_sil_samples, cut_end_sil_samples, 0);
  }

  string data_res;
  if (pp_option.file_format.find("flac") != string::npos) {
    encoder::PostProcessFlac(data, pp_option, encoder, &data_res);
  } else {
    encoder::PostProcess(data, pp_option, &data_res);
  }
  callback->OnSynthesizeData(data_res);
  data.clear();
  start_frame += first_chunk_size;

  // intermediate chunks
  for (int i = 1; i < seq_len / chunk_size - 1;
       ++i, start_frame += chunk_size) {
    features = GetInputChunk(in_features_padding, start_frame, chunk_size);
    vector<float> output;
    output = model_->Inference(features);

    FloatVecToIntVec(output, &data);
    string data_res;
    if (pp_option.file_format.find("flac") != string::npos) {
      encoder::PostProcessFlac(data, pp_option, encoder, &data_res);
    } else {
      encoder::PostProcess(data, pp_option, &data_res);
    }
    callback->OnSynthesizeData(data_res);
    data.clear();
  }

  // last chunk
  if (seq_len - start_frame > 0) {
    chunk_size = seq_len - start_frame;
    features = GetInputChunk(in_features_padding, start_frame, chunk_size);
    vector<float> output =
        model_->Inference(features, chunk_size, kOutputContext);
    FloatVecToIntVec(output, &data);

    if (static_cast<int32>(data.size()) > cut_end_sil_samples) {
      data.erase(data.end() - cut_end_sil_samples, data.end());
      data.reserve(data.size() + cut_end_sil_samples);

      // audio fade out
      float decay_time =
          kFrameShift;  // time to fall to 10% of original amplitude
      float sample_time = 1.0 / tts::kDefaultSamplingFrequency;
      float natural_decay_factor = exp(-log(10) * sample_time / decay_time);

      int decay_samples = decay_time * tts::kDefaultSamplingFrequency;
      int index = data.size() - decay_samples;
      float iterationSum = 1.0f;
      for (size_t i = 0; i < (size_t)decay_samples; ++i) {
        int pcm = data.at(index + i);
        iterationSum *= natural_decay_factor;
        data.at(index + i) = static_cast<int16>(iterationSum * pcm);
      }
      data.insert(data.end(), cut_end_sil_samples, 0);
    }

    string data_res;
    if (pp_option.file_format.find("flac") != string::npos) {
      encoder::PostProcessFlac(data, pp_option, encoder, &data_res);
    } else {
      encoder::PostProcess(data, pp_option, &data_res);
    }
    callback->OnSynthesizeData(data_res);
  }
  return true;
}
#endif

}  // namespace vocoder
