// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: hao.yin@mobvoi.com (Hao Yin)

#include "tts/synthesizer/vocoder/lpcnet_vocoder/lpcnet_vocoder.h"

#include <sys/stat.h>
#include <sys/types.h>

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "mobvoi/base/file.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/string_util.h"

#include "tts/synthesizer/vocoder/lpcnet_vocoder/freq.h"
#include "tts/synthesizer/vocoder/lpcnet_vocoder/lpcnet.h"
#include "tts/util/encoder/encoder.h"
#include "tts/util/tts_util/util.h"
#include "tts/util/tts_util/wave_util.h"

DEFINE_int32(lpcnet_energy_threshold, 200000, "silence engery threshold");
DEFINE_double(lpcnet_sil_dur, 0.125, "duration seconds");
DEFINE_double(lpcnet_sil_end_dur_minmax, 0.03,
              "duration seconds to solve end glitch");
DEFINE_double(lpcnet_sil_begin_dur_minmax, 0.06,
              "duration seconds to solve begin glitch");

namespace vocoder {
static const float silence_table[20] = {
    -1.237470912933349609e+01, -6.661726534366607666e-02,
    3.466924652457237244e-02,  -7.584977895021438599e-03,
    6.503222393803298473e-04,  -1.333076506853103638e-03,
    -4.409614484757184982e-03, 2.342575608054175973e-04,
    5.320437718182802200e-03,  -1.800699718296527863e-02,
    7.472906727343797684e-03,  1.648839376866817474e-02,
    -6.537397857755422592e-03, 9.665929712355136871e-03,
    8.932705037295818329e-03,  -4.998476710170507431e-03,
    -2.251060912385582924e-03, -3.665575990453362465e-03,
    -6.000000238418579102e-01, -3.107207119464874268e-01};

LpcNetVocoder::LpcNetVocoder(const std::string& model_file) {
  model_ = lpcnet_model_create(model_file);
  sil_features_.insert(sil_features_.begin(), silence_table,
                       silence_table + 20);
}

LpcNetVocoder::~LpcNetVocoder() { lpcnet_model_destroy(model_); }

bool LpcNetVocoder::Synthesize(const vector<float>& in_features,
                               const tts::TTSOption& tts_option,
                               vector<int16>* wav_vector) const {
  // TODO(yunlin) refact the code, no number
  LPCNetState* net = lpcnet_create();
  // silences
  vector<int16> end_silence(FLAGS_lpcnet_sil_end_dur_minmax *
                            tts::kDefaultSamplingFrequency);

  int cut_begin_frames_for_minmax =
      static_cast<int>(FLAGS_lpcnet_sil_begin_dur_minmax * 100);
  int cut_end_frames_for_minmax =
      static_cast<int>(FLAGS_lpcnet_sil_end_dur_minmax * 100);
  VLOG(2) << "cut_end_frames_for_minmax: " << cut_end_frames_for_minmax;

  wav_vector->reserve((in_features.size() / 20 - cut_end_frames_for_minmax) *
                      FRAME_SIZE);

  float features[NB_FEATURES];
  int16 pcm[FRAME_SIZE];
  RNN_COPY(features, &sil_features_[0], 18);
  RNN_CLEAR(&features[18], 18);
  RNN_COPY(&features[36], &sil_features_[18], 2);
  for (size_t i = 0; i < (size_t)cut_begin_frames_for_minmax; ++i) {
    lpcnet_synthesize(model_, net, features, pcm, FRAME_SIZE);
    wav_vector->insert(wav_vector->end(), FRAME_SIZE, 0.5);
  }

  for (int i = cut_begin_frames_for_minmax;
       i <
       static_cast<int>(in_features.size() / 20) - cut_end_frames_for_minmax;
       ++i) {
    int16 pcm[FRAME_SIZE];
    RNN_COPY(features, &in_features[i * 20], 18);
    RNN_CLEAR(&features[18], 18);
    RNN_COPY(&features[36], &in_features[i * 20 + 18], 2);
    lpcnet_synthesize(model_, net, features, pcm, FRAME_SIZE);

    wav_vector->insert(wav_vector->end(), pcm, pcm + FRAME_SIZE);
  }

  // https://stackoverflow.com/questions/20037947/
  // fade-out-function-of-audio-between-samplerate-changes
  float decay_time = 0.01;  // time to fall to 10% of original amplitude
  float sample_time = 1.0 / tts::kDefaultSamplingFrequency;
  float natural_decay_factor = exp(-log(10) * sample_time / decay_time);

  int index = wav_vector->size() - FRAME_SIZE;
  float iterationSum = 1.0f;
  for (size_t i = 0; i < FRAME_SIZE; ++i) {
    int pcm = wav_vector->at(index + i);
    iterationSum *= natural_decay_factor;
    wav_vector->at(index + i) = static_cast<int16>(iterationSum * pcm);
  }

  wav_vector->reserve(wav_vector->size() + end_silence.size());
  int pre_pcm = wav_vector->at(wav_vector->size() - 1);
  for (size_t i = 0; i < end_silence.size(); ++i) {
    wav_vector->emplace_back(static_cast<int16>(0.5 + 0.85 * pre_pcm));
    pre_pcm = static_cast<int16>(0.5 + 0.85 * pre_pcm);
  }
  lpcnet_destroy(net);
  return true;
}

#ifndef FOR_PORTABLE
bool LpcNetVocoder::Synthesize(const vector<float>& in_features,
                               const tts::TTSOption& tts_option,
                               float speaker_volume,
                               encoder::FlacEncoder* encoder,
                               tts::SynthesizerEventInterface* callback) const {
  // TODO(yunlin) refact the code, no number
  int k = 0;
  // vocoder callback each frames
  int frames = tts_option.callback_frames();
  float volume = tts_option.volume() * speaker_volume;
  encoder::PostProcessOption pp_option(
      tts::kDefaultSamplingFrequency, tts_option.sampling_frequency(),
      tts::kNoNormalizeFactor, volume, tts_option.file_format());
  vector<int16> data;
  LPCNetState* net = lpcnet_create();
  bool is_first_patch = true;

  int cut_begin_frames_for_minmax =
      static_cast<int>(FLAGS_lpcnet_sil_begin_dur_minmax * 100);
  int cut_end_frames_for_minmax =
      static_cast<int>(FLAGS_lpcnet_sil_end_dur_minmax * 100);
  VLOG(2) << "cut_end_frames_for_minmax: " << cut_end_frames_for_minmax;

  // i -> current frame in all frames
  for (int i = 0; i < static_cast<int>(in_features.size()) / 20 -
                          cut_end_frames_for_minmax;
       ++i) {
    float features[NB_FEATURES];
    int16 pcm[FRAME_SIZE];

    if (i < cut_begin_frames_for_minmax) {
      RNN_COPY(features, &sil_features_[0], 18);
      RNN_COPY(&features[36], &sil_features_[18], 2);
    } else {
      RNN_COPY(features, &in_features[i * 20], 18);
      RNN_COPY(&features[36], &in_features[i * 20 + 18], 2);
    }

    RNN_CLEAR(&features[18], 18);

    lpcnet_synthesize(model_, net, features, pcm, FRAME_SIZE);
    // cut beginning silence using energy
    if (i < 20 && is_first_patch) {
      float energy = 0.0;
      for (size_t j = 0; j < FRAME_SIZE; ++j) {
        energy += pcm[j] * static_cast<float>(pcm[j]);
      }
      VLOG(2) << "energy " << energy;
      if (energy < FLAGS_lpcnet_energy_threshold) {
        continue;
      }
    }

    data.reserve(data.size() + FRAME_SIZE);
    data.insert(data.end(), pcm, pcm + FRAME_SIZE);
    k += 1;
    if (k >= frames &&
        (i + frames) < static_cast<int>(in_features.size()) / 20) {
      is_first_patch = false;
      string data_res;
      if (pp_option.file_format.find("flac") != string::npos) {
        encoder::PostProcessFlac(data, pp_option, encoder, &data_res);
      } else {
        encoder::PostProcess(data, pp_option, &data_res);
      }
      callback->OnSynthesizeData(data_res);
      data.clear();
      k = 0;
    }
  }

  // audio fade out
  float decay_time = 0.01;  // time to fall to 10% of original amplitude
  float sample_time = 1.0 / tts::kDefaultSamplingFrequency;
  float natural_decay_factor = exp(-log(10) * sample_time / decay_time);

  if (data.size() > 0) {
    int fade_out_index = static_cast<int>(data.size()) > FRAME_SIZE
                             ? FRAME_SIZE
                             : static_cast<int>(data.size());
    int index = data.size() - fade_out_index;
    float iterationSum = 1.0f;
    for (size_t i = 0; i < (size_t)fade_out_index; ++i) {
      int pcm = data.at(index + i);
      iterationSum *= natural_decay_factor;
      data.at(index + i) = static_cast<int16>(iterationSum * pcm);
    }
  }

  // insert duration at the end of splited sentences
  if (tts_option.speaker().find("gru") == string::npos) {
    vector<int16> end_silence(
        (FLAGS_lpcnet_sil_dur + FLAGS_lpcnet_sil_end_dur_minmax) *
        tts::kDefaultSamplingFrequency);
    data.reserve(data.size() + end_silence.size());
    int pre_pcm = data.at(data.size() - 1);
    for (size_t i = 0; i < end_silence.size(); ++i) {
      data.emplace_back(static_cast<int16>(0.5 + 0.85 * pre_pcm));
      pre_pcm = static_cast<int16>(0.5 + 0.85 * pre_pcm);
    }
  }

  string data_res;
  if (pp_option.file_format.find("flac") != string::npos) {
    encoder::PostProcessFlac(data, pp_option, encoder, &data_res);
  } else {
    encoder::PostProcess(data, pp_option, &data_res);
  }
  callback->OnSynthesizeData(data_res);
  lpcnet_destroy(net);
  return true;
}
#endif

}  // namespace vocoder
