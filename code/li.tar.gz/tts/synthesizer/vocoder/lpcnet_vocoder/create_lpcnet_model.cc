// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: sxwang@mobvoi.com (Sixue Wang)

#include "mobvoi/base/file.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"

#include "tts/synthesizer/vocoder/lpcnet_vocoder/lpcnet_model.pb.h"
#include "tts/synthesizer/vocoder/lpcnet_vocoder/nnet_data.h"

DEFINE_string(output, "/tmp/lpcnet.pb", "");
DEFINE_int32(pack_n_rows, 3, "");

template <typename T>
void memcpy(google::protobuf::RepeatedField<T>* dst, int size, const T* src) {
  dst->Resize(size, 0.0);
  memcpy(dst->mutable_data(), src, size * sizeof(T));
}

void CreateDenseLayer(const DenseLayer& src,
                      vocoder::lpcnet::pb::DenseLayer* dst) {
  dst->set_nb_inputs(src.nb_inputs);
  dst->set_nb_neurons(src.nb_neurons);
  dst->set_activation(vocoder::lpcnet::pb::ACTIVATION(src.activation));

  memcpy(dst->mutable_bias(), src.nb_neurons, src.bias);
  memcpy(dst->mutable_input_weights(), src.nb_inputs * src.nb_neurons,
         src.input_weights);
}

void CreateMDenseLayer(const MDenseLayer& src,
                       vocoder::lpcnet::pb::MDenseLayer* dst) {
  dst->set_nb_inputs(src.nb_inputs);
  dst->set_nb_neurons(src.nb_neurons);
  dst->set_nb_channels(src.nb_channels);
  dst->set_activation(vocoder::lpcnet::pb::ACTIVATION(src.activation));

  memcpy(dst->mutable_bias(), src.nb_neurons * src.nb_channels, src.bias);
  memcpy(dst->mutable_input_weights(),
         src.nb_inputs * src.nb_neurons * src.nb_channels, src.input_weights);
  memcpy(dst->mutable_factor(), src.nb_neurons * src.nb_channels, src.factor);
}

void CreateGRULayer(const GRULayer& src, vocoder::lpcnet::pb::GRULayer* dst) {
  dst->set_nb_inputs(src.nb_inputs);
  dst->set_nb_neurons(src.nb_neurons);
  dst->set_activation(vocoder::lpcnet::pb::ACTIVATION(src.activation));
  dst->set_reset_after(src.reset_after);

  memcpy(dst->mutable_bias(), src.nb_neurons * 6, src.bias);
  memcpy(dst->mutable_input_weights(), src.nb_inputs * src.nb_neurons * 3,
         src.input_weights);
  memcpy(dst->mutable_recurrent_weights(), src.nb_neurons * src.nb_neurons * 3,
         src.recurrent_weights);
}

int CalcSparseSize(int rows, const int* idx) {
  int sum = 0;
  for (int i = 0; i < rows / 16; ++i) {
    int cols = *idx++;
    idx += cols;
    sum += cols;
  }
  return sum;
}

void PackSparseSgemv(int rows, const float* weights, const int* idx,
                     float* packed_weights, int* packed_idx) {
  std::vector<std::pair<int, int>> order(rows / 16);
  std::vector<const int*> idx_index(rows / 16, nullptr);
  std::vector<const float*> weights_index(rows / 16, nullptr);
  int sum = 0;
  const int* idx_ptr = idx;
  const float* weights_ptr = weights;
  for (int i = 0; i < rows / 16; ++i) {
    int cols = *idx_ptr++;
    sum += cols;
    idx_index[i] = idx_ptr;
    idx_ptr += cols;
    weights_index[i] = weights_ptr;
    weights_ptr += cols * 16;
    order[i] = std::make_pair(cols, i);
  }
  std::sort(order.begin(), order.end());
  for (int i = 0; i < rows / 16; i += FLAGS_pack_n_rows) {
    for (int j = 0; j < FLAGS_pack_n_rows; ++j) {
      *packed_idx++ = order[i + j].second * 16;
    }
    int min_col = std::numeric_limits<int>::max();
    for (int j = 0; j < FLAGS_pack_n_rows; ++j) {
      min_col = std::min(min_col, order[i + j].first);
    }
    *packed_idx++ = min_col;
    for (int k = 0; k < min_col; ++k) {
      for (int j = 0; j < FLAGS_pack_n_rows; ++j) {
        *packed_idx++ = idx_index[order[i + j].second][k];
        memcpy(packed_weights, weights_index[order[i + j].second] + k * 16,
               16 * sizeof(float));
        packed_weights += 16;
      }
    }
    for (int j = 0; j < FLAGS_pack_n_rows; ++j) {
      *packed_idx++ = order[i + j].first - min_col;
      for (int k = min_col; k < order[i + j].first; ++k) {
        *packed_idx++ = idx_index[order[i + j].second][k];
        memcpy(packed_weights, weights_index[order[i + j].second] + k * 16,
               16 * sizeof(float));
        packed_weights += 16;
      }
    }
  }
}

void CreateSparseGRULayer(const SparseGRULayer& src,
                          vocoder::lpcnet::pb::SparseGRULayer* dst) {
  dst->set_nb_neurons(src.nb_neurons);
  dst->set_activation(vocoder::lpcnet::pb::ACTIVATION(src.activation));
  dst->set_reset_after(src.reset_after);

  memcpy(dst->mutable_bias(), src.nb_neurons * 6, src.bias);
  memcpy(dst->mutable_diag_weights(), src.nb_neurons * 3, src.diag_weights);

  int rows = 3 * src.nb_neurons;
  int size = CalcSparseSize(rows, src.idx);

  memcpy(dst->mutable_recurrent_weights(), size * 16, src.recurrent_weights);
  memcpy(dst->mutable_idx(), size + rows / 16, src.idx);

  dst->mutable_packed_recurrent_weights()->Resize(size * 16, 0.0);
  dst->mutable_packed_idx()->Resize(
      size + 2 * rows / 16 + rows / 16 / FLAGS_pack_n_rows, 0.0);
  PackSparseSgemv(rows, src.recurrent_weights, src.idx,
                  dst->mutable_packed_recurrent_weights()->mutable_data(),
                  dst->mutable_packed_idx()->mutable_data());
}

void CreateConv1DLayer(const Conv1DLayer& src,
                       vocoder::lpcnet::pb::Conv1DLayer* dst) {
  dst->set_nb_inputs(src.nb_inputs);
  dst->set_kernel_size(src.kernel_size);
  dst->set_nb_neurons(src.nb_neurons);
  dst->set_activation(vocoder::lpcnet::pb::ACTIVATION(src.activation));

  memcpy(dst->mutable_bias(), src.nb_neurons, src.bias);
  memcpy(dst->mutable_input_weights(),
         src.nb_inputs * src.nb_neurons * src.kernel_size, src.input_weights);
}

void CreateEmbeddingLayer(const EmbeddingLayer& src,
                          vocoder::lpcnet::pb::EmbeddingLayer* dst) {
  dst->set_nb_inputs(src.nb_inputs);
  dst->set_dim(src.dim);

  memcpy(dst->mutable_embedding_weights(), src.nb_inputs * src.dim,
         src.embedding_weights);
}

int main(int argc, char** argv) {
  google::ParseCommandLineFlags(&argc, &argv, false);

  vocoder::lpcnet::pb::LPCNetModel model;
  CreateEmbeddingLayer(gru_a_embed_sig, model.mutable_gru_a_embed_sig());
  CreateEmbeddingLayer(gru_a_embed_pred, model.mutable_gru_a_embed_pred());
  CreateEmbeddingLayer(gru_a_embed_exc, model.mutable_gru_a_embed_exc());
  CreateDenseLayer(gru_a_dense_feature, model.mutable_gru_a_dense_feature());
  CreateEmbeddingLayer(embed_pitch, model.mutable_embed_pitch());
  CreateConv1DLayer(feature_conv1, model.mutable_feature_conv1());
  CreateConv1DLayer(feature_conv2, model.mutable_feature_conv2());
  CreateDenseLayer(feature_dense1, model.mutable_feature_dense1());
  CreateEmbeddingLayer(embed_sig, model.mutable_embed_sig());
  CreateDenseLayer(feature_dense2, model.mutable_feature_dense2());
  CreateGRULayer(gru_a, model.mutable_gru_a());
  CreateGRULayer(gru_b, model.mutable_gru_b());
  CreateMDenseLayer(dual_fc, model.mutable_dual_fc());
  CreateSparseGRULayer(sparse_gru_a, model.mutable_sparse_gru_a());

  mobvoi::File::WriteStringToFileOrDie(model.SerializeAsString(), FLAGS_output);
  return 0;
}
