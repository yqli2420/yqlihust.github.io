// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_SYNTHESIZER_SYNTHESIZER_H_
#define TTS_SYNTHESIZER_SYNTHESIZER_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "tts/nlp/text_splitter/text_splitter.h"
#include "tts/synthesizer/interface/synthesizer_event_interface.h"
#include "tts/synthesizer/interface/synthesizer_interface.h"
#include "tts/synthesizer/proto/tts.pb.h"
#include "tts/synthesizer/speaker_manager.h"
#include "tts/util/encoder/encoder.h"
#include "tts/util/ssml/ssml_parser.h"

namespace tts {
using engine::Engine;

class Synthesizer : public SynthesizerInterface {
 public:
  explicit Synthesizer(const string& speaker_info_file);
  virtual ~Synthesizer();
  virtual void FrontendSynthesize(const string& text,
                                  const TTSOption& tts_option,
                                  Json::Value* frontend_data) const;
  virtual void Synthesize(const string& text, const TTSOption& tts_option,
                          string* data_res,
                          shared_ptr<Engine> custom_engine = nullptr) const;
  virtual void Synthesize(const string& text, const TTSOption& tts_option,
                          vector<int16>* data) const;
  virtual void Synthesize(const string& text, const TTSOption& tts_option,
                          SynthesizerEventInterface* callback,
                          shared_ptr<Engine> custom_engine = nullptr) const;

  vector<std::pair<string, bool>> GetSpeakers(const string& language) const;

  bool LoadSpeaker(const string& speaker);
  bool CheckSpeaker(const string& speaker);
  bool UnloadSpeaker(const string& speaker);
  vector<string> GetSupLanguages() const;

 private:
  void InitCacheDatas();
  void PrepareCacheData(const string& speaker);
  void GetLabelOption(const TTSOption& tts_option, bool last_seg,
                      LabelOption* label_option) const;
  void TextSplit(const vector<SsmlText>& text, const TTSOption& tts_option,
                 vector<vector<SsmlText>>* split_texts) const;
  void CheckSpeakerForTacotron(const vector<vector<SsmlText>>& split_texts,
                               TTSOption* tts_option) const;
  bool GenLabels(const vector<SsmlText>& text, const TTSOption& tts_option,
                 bool last_seg, std::vector<std::string>* label_data,
                 Json::Value* debug_info, TnDetail* detail) const;
  void SynthesizeWorker(const string& text, const TTSOption& tts_option,
                        RawData* data, SynthesizerEventInterface* callback,
                        shared_ptr<Engine> custom_engine = nullptr) const;
  bool TryPrefixCache(vector<SsmlText>* ssml_texts, const TTSOption& tts_option,
#ifndef FOR_PORTABLE
                      encoder::FlacEncoder* encoder,
#endif
                      RawData* raw_data,
                      SynthesizerEventInterface* callback) const;
  bool SynthesizeWorker(const vector<SsmlText>& split_text,
                        const TTSOption& tts_option, bool last_seg,
#ifndef FOR_PORTABLE
                        encoder::FlacEncoder* encoder,
#endif
                        RawData* raw_data, SynthesizerEventInterface* callback,
                        shared_ptr<Engine> custom_engine = nullptr) const;
  bool SynthesizeData(const string& language, const TTSOption& tts_option,
                      const vector<string>& labels,
#ifndef FOR_PORTABLE
                      encoder::FlacEncoder* encoder,
#endif
                      RawData* result_data, SynthesizerEventInterface* callback,
                      shared_ptr<Engine> custom_engine = nullptr) const;
  bool CollectData(const TTSOption& tts_option, RawData* raw_data,
#ifndef FOR_PORTABLE
                   encoder::FlacEncoder* encoder,
#endif
                   RawData* tmp_data,
                   SynthesizerEventInterface* callback) const;

  std::unique_ptr<nlp::splitter::TextSplitter> text_splitter_;
  std::unique_ptr<SpeakerManager> speaker_manager_;
  DISALLOW_COPY_AND_ASSIGN(Synthesizer);
};
}  // namespace tts

#endif  // TTS_SYNTHESIZER_SYNTHESIZER_H_
