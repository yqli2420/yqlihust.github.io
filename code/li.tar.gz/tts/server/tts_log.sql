CREATE TABLE tts_log (
  id INT NOT NULL AUTO_INCREMENT,
  time timestamp NOT NULL,
  product text,
  net_type text,
  device_id text,
  platform text,
  voice text,
  language text,
  text text NOT NULL,
  used_time_ms INT,
  PRIMARY KEY (id)
) ENGINE=innodb;


CREATE TABLE tts_log_new (
  id INT NOT NULL AUTO_INCREMENT,
  create_time timestamp NOT NULL,
  product varchar(60) DEFAULT '',
  uri text,
  query text,
  all_chunk_time text,
  synthesize_mode text,
  speaker varchar(50) DEFAULT '',
  latency INT,
  appkey varchar(60) DEFAULT '',
  msg_id varchar(40) DEFAULT '',
  source varchar(30) DEFAULT '',
  PRIMARY KEY (id),
) ENGINE=innodb;

create index appkey on tts_log_new(appkey);
create index product on tts_log_new(product);
create index msg_id on tts_log_new(msg_id);
create index source on tts_log_new(source);

