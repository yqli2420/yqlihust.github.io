// Copyright 2018. All Rights Reserved.
// Author: chhyu@mobvoi.com (Changhe Yu)

#include "tts/server/server_util.h"

#include <future>  // NOLINT

#include "mobvoi/base/md5.h"
#include "mobvoi/base/singleton.h"
#include "mobvoi/base/time.h"
#include "mobvoi/util/net/http_client/http_client.h"
#include "mobvoi/util/utf8/utf.h"
#include "re2/re2.h"
#include "third_party/xml2/libxml/parser.h"
#include "tts/server/proto/tts_log.pb.h"
#include "tts/server/speaker_mapping.h"
#include "tts/util/protobuf/proto_json_format.h"
#include "tts/util/tts_util/util.h"
#include "tts/util/tts_util/wave_util.h"

DEFINE_int32(max_text_length, 500, "max text length in unicode number");
DEFINE_double(max_speed, 4.0,
              "Limit max speed for request params, to avoid coredump.");
DEFINE_bool(write_matrics_to_kibana, false, "If true, write data to kibana");
DEFINE_int32(http_connect_timeout, 10000, "http connect timeout");
DEFINE_int32(http_fetch_timeout, 10000, "http fetch timeout");
DEFINE_int32(init_top_bgm, 50, "fetch top 50 bgm");
DEFINE_string(base_model_url,
              "http://mobvoi-oss/v1/ufile/mobvoi-speech-private/mobvoi-tts/"
              "adaptation/%s/%s.quant.one",
              "speaker engine url");
DEFINE_bool(use_replace_url, false, "If true, use replaced url");
DEFINE_string(replace_url, "http://mobvoi-speech-private.cn-bj.ufileos.com",
              "speaker engine replace url");
DEFINE_string(moyin_url, "http://edge/tts-web-api/v1/bgms/%s/inner", "bgm url");
DEFINE_string(save_adaptation_model_dir,
              "external/config/acoustic_models/tacotron_one/",
              "dir for save model");
DEFINE_string(save_audio_tmp_dir, "external/config/web_server/record_wav/tmp/",
              "dir for save audio");
DEFINE_string(word_pron_dict, "external/config/front_end/dict/word_pron.dict",
              "path for word pron dict ");
DEFINE_string(phone_map_dict,
              "external/config/front_end/dict/phone_mapping.dict",
              "path for phone map dict ");
DEFINE_bool(enable_offline_reject, false, "To control start or stop reject");
DEFINE_string(product_list, "sop2,icas3,sop1.5,37w",
              "Product list for reject offline request.");

namespace server {

static const char* kEnglishSpeaker = "angela_gru";
static const char* kLucyEnglishSpeaker = "_eng";
static const char* kTicwatchDemoAppkey = "8AF273BF23E389B13F59817278BA27B9";

void ServerUtil::AppendHeadSilence(const map<string, string>& params,
                                   string* text) {
  string res;
  mobvoi::TrimWhitespaceASCII(*text, mobvoi::TrimPositions::TRIM_ALL, &res);
  if (params.find("head_append_sil") != params.end()) {
    string break_str = StringPrintf("<break time='%sms' />",
                                    params.at("head_append_sil").c_str());
    if (res.find("<speak>") != string::npos) {
      res = res.substr(0, 7) + break_str + res.substr(7);
    } else {
      res = "<speak>" + break_str + res + "</speak>";
    }
  }
  *text = res;
}

void ServerUtil::AcquireLicense(bool use_license) {
  if (use_license) {
    while (mobvoi::LicenseValidator::GetInstance()->WaitSemaphore(0, 10000)) {
      VLOG_EVERY_N(1, 500) << "http waiting for thread release";
    }
  }
}

void ServerUtil::ReleaseLicense(bool use_license) {
  if (use_license) {
    mobvoi::LicenseValidator::GetInstance()->PostSemaphore();
  }
}

bool ServerUtil::Download(const string& engine_name) {
  // download taco model from oss
  string model_url = StringPrintf(FLAGS_base_model_url.c_str(),
                                  engine_name.c_str(), engine_name.c_str());
  string model_content = FetchUrl(model_url);
  if (model_content.empty()) {
    LOG(ERROR) << "url: " << model_url;
    return false;
  }

  string model_md5_url = model_url + ".md5";
  string md5_output = FetchUrl(model_md5_url);
  string remote_model_md5_content;
  mobvoi::TrimWhitespaceASCII(md5_output, mobvoi::TrimPositions::TRIM_ALL,
                              &remote_model_md5_content);
  string model_md5_content = MD5String(model_content);
  if (remote_model_md5_content.empty() ||
      remote_model_md5_content != model_md5_content) {
    LOG(ERROR) << "model url:" << model_url << ", download model incorrect. "
               << "model content md5: " << model_md5_content
               << ", remote model content md5: " << remote_model_md5_content;
    return false;
  }
  string engine_path =
      FLAGS_save_adaptation_model_dir + engine_name + ".quant.one";
  mobvoi::File::WriteStringToFileOrDie(model_content, engine_path);
  return true;
}

string ServerUtil::FetchUrl(const string& url) {
  util::HttpClient http_client;
  http_client.SetFetchTimeout(FLAGS_http_fetch_timeout);
  http_client.SetConnectTimeout(FLAGS_http_connect_timeout);
  string location_url;
  if (!http_client.FetchUrl(url) || http_client.response_code() != 200) {
    if (http_client.response_code() == 302 ||
        http_client.response_code() == 301) {
      location_url = http_client.GetLocation();
      http_client.Reset();
      http_client.SetFetchTimeout(FLAGS_http_fetch_timeout);
      http_client.SetConnectTimeout(FLAGS_http_connect_timeout);
      if (FLAGS_use_replace_url) {
        size_t index = location_url.find("/mobvoi-tts");
        location_url = FLAGS_replace_url + location_url.substr(index);
      }
      if (!http_client.FetchUrl(location_url) ||
          http_client.response_code() != 200) {
        LOG(ERROR) << "url: " << url << ", location_url: " << location_url
                   << ", code: " << http_client.response_code()
                   << ", curl code: " << http_client.curl_code();
        return "";
      }
    }
    if (http_client.response_code() != 200) {
      LOG(ERROR) << "url: " << url << ", location_url: " << location_url
                 << ", code: " << http_client.response_code()
                 << ", curl code: " << http_client.curl_code();
      return "";
    }
  }

  return http_client.ResponseBody();
}

void ServerUtil::RequestInputParser(const string& request_string,
                                    const string& text_type,
                                    vector<vector<string>>* prase_text) {
  if (text_type == kInputTypeText) {
    vector<string> text_split;
    SplitString(request_string, '\n', &text_split);
    prase_text->emplace_back(text_split);
  } else {
    Json::Reader reader;
    Json::Value json_object(Json::arrayValue);
    if (!reader.parse(request_string, json_object)) {
      VLOG(1) << "Input is not Json type";
    } else {
      for (size_t i = 0; i < json_object.size(); ++i) {
        vector<string> text_split;
        for (size_t j = 0; j < json_object[i].size(); ++j) {
          text_split.emplace_back(json_object[i][j]["sentence"].asString());
        }
        prase_text->emplace_back(text_split);
      }
    }
  }
}

// restrict total text length, remove remain syn_texts
void ServerUtil::RestrictTextLen(string* text, int* word_num) {
  int remain_text_len = FLAGS_max_text_length;
  if (tts::SsmlParser::Instance().IsSsmlFast(*text)) {
    *word_num = tts::SsmlParser::Instance().CountWordNum(*text);
    if (*word_num > remain_text_len) {
      LOG(WARNING) << "the length of ssml_text is out of max_text_length";
      *text = "对不起,文本超长,请不要超过500字";
      *word_num = 18;
    }
  } else {
    *word_num = util::utflen(text->c_str());
    if (*word_num > remain_text_len) {
      *word_num = remain_text_len;
      tts::CutOffText(text, remain_text_len);
    }
  }
}

void ServerUtil::GetTextLen(const string& text, int* word_num) {
  if (tts::SsmlParser::Instance().IsSsmlFast(text)) {
    *word_num = tts::SsmlParser::Instance().CountWordNum(text);
  } else {
    *word_num = util::utflen(text.c_str());
  }
}

string ServerUtil::GetRequestParams(const map<string, string>& params) {
  vector<string> param_strings;
  for (const auto& param : params) {
    param_strings.emplace_back(param.first + "=" + param.second);
  }
  return JoinVector(param_strings, '&');
}

void ServerUtil::ParseRequestParams(util::HttpRequest* request,
                                    map<string, string>* params) {
  if (request->HttpMethod() == util::HttpMethodType_kGet) {
    request->GetQueryParams(params);
  } else if (request->HttpMethod() == util::HttpMethodType_kPost) {
    request->GetPostParams(params);
  } else {
    LOG(ERROR) << "Don't support this method : " << request->HttpMethod();
  }
  LOG(INFO) << "receive request:" << request->Url();
}

// Set options for synthesis
void ServerUtil::SetTTSOption(const map<string, string>& params,
                              tts::TTSOption* tts_option) {
  // First we set default speaker by flag.
  auto it = params.find("audio_type");
  if (it != params.end() && !it->second.empty()) {
    tts_option->set_file_format(it->second);
  }
  it = params.find("request_type");
  if (it != params.end() && !it->second.empty()) {
    if (it->second == kReqTypeFrontend) {
      tts_option->set_only_frontend(true);
    } else if (it->second == kReqTypeAlign) {
      tts_option->set_alignment(true);
      tts_option->set_detail_output(true);
      if (!tts::IsGruModel(tts_option->speaker())) {
        LOG(WARNING) << "speaker not support alignment:"
                     << tts_option->speaker();
      }
    } else if (it->second == kReqTypeFrontendTn) {
      tts_option->set_only_frontend(true);
      tts_option->set_only_frontend_tn(true);
    }
  }

  it = params.find("rate");
  if (it != params.end() && !it->second.empty()) {
    tts_option->set_sampling_frequency(StringToInt(it->second));
  }

  it = params.find("speed");
  if (it != params.end() && !it->second.empty()) {
    float speed = StringToFloat(it->second);
    if (speed > FLAGS_max_speed) speed = FLAGS_max_speed;
    tts_option->set_speed(speed);
  }
  it = params.find("volume");
  if (it != params.end() && !it->second.empty()) {
    tts_option->set_volume(StringToFloat(it->second));
  }
  it = params.find("bgm_volume");
  if (it != params.end() && !it->second.empty()) {
    tts_option->set_bgm_volume(StringToFloat(it->second));
  }
  it = params.find("pitch");
  if (it != params.end() && !it->second.empty()) {
    tts_option->set_pitch(StringToFloat(it->second));
  }
  it = params.find("domain");
  if (it != params.end() && !it->second.empty()) {
    tts_option->set_domain(it->second);
  }
  it = params.find("bgm");
  if (it != params.end() && !it->second.empty()) {
    tts_option->set_bgm(it->second);
  }
  it = params.find("speaker");
  if (it != params.end() && !it->second.empty()) {
    tts_option->set_speaker(it->second);
  }
  it = params.find("break_time");
  if (it != params.end() && !it->second.empty()) {
    tts_option->set_break_time(StringToInt(it->second));
  }
  it = params.find("app_key");
  if (it != params.end() && !it->second.empty()) {
    tts_option->set_appkey(it->second);
  }
  it = params.find("appkey");
  if (it != params.end() && !it->second.empty()) {
    tts_option->set_appkey(it->second);
  }
  it = params.find("user_dict");
  if (it != params.end() && !it->second.empty()) {
    tts_option->set_user_dict(it->second);
  }
  it = params.find("split_bylen");
  if (it != params.end() && it->second == "false") {
    tts_option->set_split_bylen(false);
  }
  it = params.find("for_voice_maker");
  if (it != params.end() && it->second == "true") {
    tts_option->set_for_voice_maker(true);
  }
  // depreciated
  it = params.find("mandarin_speaker");
  if (it != params.end() && !it->second.empty()) {
    tts_option->set_speaker(it->second);
  }
  // for cns project.
  it = params.find("product");
  if ((tts_option->speaker() == "emily" || tts_option->speaker() == "tina") &&
      it != params.end() && it->second == "cns") {
    tts_option->set_speaker("emily_gru");
  }
  it = params.find("language");
  if (it != params.end() && it->second == tts::kEnglishTypeString &&
      tts_option->speaker() == "angela") {
    // convert angela (tacotron) to angela_gru for taco is not stable yet
    tts_option->set_speaker(kEnglishSpeaker);
  }
  if (it != params.end() && it->second == tts::kEnglishTypeString &&
      (tts_option->speaker() == "lucy" || tts_option->speaker() == "lucy_gru" ||
       tts_option->speaker() == "lucy_lpcnet")) {
    tts_option->set_speaker(tts_option->speaker() + kLucyEnglishSpeaker);
  }
  it = params.find("appkey");
  if (it != params.end() && it->second == kTicwatchDemoAppkey &&
      tts_option->speaker() == "lucy") {
    tts_option->set_speaker(tts_option->speaker() + kLucyEnglishSpeaker);
  }
  it = params.find("detail_output");
  if (it != params.end() && it->second == "true") {
    tts_option->set_detail_output(true);
  }
  it = params.find("append_sil");
  if (it != params.end() && it->second == "true") {
    tts_option->set_append_sil(true);
  }
  it = params.find("callback_frames");
  if (it != params.end() && !it->second.empty()) {
    tts_option->set_callback_frames(StringToInt(it->second));
  }
  it = params.find("convert");
  if (it != params.end() && it->second == "robot") {
    tts_option->set_use_robot(true);
  }
  it = params.find("bgm_offset");
  if (it != params.end() && !it->second.empty()) {
    tts_option->set_bgm_offset(StringToInt(it->second));
  }
  it = params.find("frontend_type");
  if (it != params.end() && !it->second.empty()) {
    tts_option->set_frontend_type(it->second);
  } else {
    tts_option->set_frontend_type(tts::kFrontendTypeMan);
  }
  it = params.find("tone_rule");
  if (it != params.end() && it->second == "false") {
    tts_option->set_tone_rule(false);
  }
}

void ServerUtil::SetJsonContentType(const string& request_type,
                                    const string& audio_type,
                                    util::HttpResponse* response) {
  if (request_type == kReqTypeFrontend || request_type == kReqTypeAlign ||
      request_type == kReqTypeFrontendTn) {
    response->AppendHeader("Content-Type", "application/json");
  } else {
    if (audio_type == "mp3" || audio_type == "mp3_hq") {
      response->AppendHeader("Content-Type", "audio/mpeg");
    } else {
      string response_header = "audio/" + audio_type;
      response->AppendHeader("Content-Type", response_header);
    }
  }
}

bool ServerUtil::SetAllParams(const map<string, string>& params,
                              const string& type, tts::TTSOption* tts_option,
                              util::HttpResponse* response) {
  auto text_str = params.find("text");
  if (text_str == params.end() || text_str->second.empty()) return false;
  tts::SetDefaultTTSOption(tts_option);
  SetTTSOption(params, tts_option);
  if (type == kTypeStreaming) {
    string file_format = tts_option->file_format();
    if (file_format == "wav") {
      tts_option->set_file_format("raw");
    }
  }
  string request_type = GetRequestTypeParam(params);
  if (response != nullptr) {
    SetJsonContentType(request_type, tts_option->file_format(), response);
  }
  // parse domain
  string domain = tts::GetDomainFromXml(text_str->second);
  if (!domain.empty()) tts_option->set_domain(domain);
  LOG(INFO) << "domain: " << tts_option->domain();
  // speaker mapping
  string map_speaker;
  auto speaker_mapping = Singleton<SpeakerMapping>::get();
  if (speaker_mapping->MapSpeaker(tts_option->appkey(), tts_option->speaker(),
                                  &map_speaker)) {
    tts_option->set_speaker(map_speaker);
  }
  return true;
}

string ServerUtil::GetProductParam(const map<string, string>& params) {
  string product;
  auto it = params.find("product");
  if (it != params.end() && !it->second.empty()) {
    product = it->second;
  } else {
    product = "unknown";
  }
  return product;
}

string ServerUtil::GetRequestTypeParam(const map<string, string>& params) {
  string request_type;
  auto it = params.find("request_type");
  if (it != params.end() && !it->second.empty()) {
    request_type = it->second;
  } else {
    request_type = kReqTypeSynthesis;
  }
  return request_type;
}

string ServerUtil::GetRequestTextTypeParam(const map<string, string>& params) {
  string request_type;
  auto it = params.find("text_type");
  if (it != params.end() && !it->second.empty()) {
    request_type = it->second;
  } else {
    request_type = kInputTypeText;
  }
  return request_type;
}

string ServerUtil::GetSaveAudioTmpDir() { return FLAGS_save_audio_tmp_dir; }

void ServerUtil::DoInputPreprocess(const map<string, string>& params,
                                   string* text, int* word_num) {
  auto it = params.find("ignore_limit");
  if (it != params.end() && it->second == "true") {
    GetTextLen(*text, word_num);
  } else {
    RestrictTextLen(text, word_num);
  }
  LOG(INFO) << " word : " << *word_num << ", text : " << *text;
}

void ServerUtil::SplitOptionSent(const string& request,
                                 vector<OptionSent>* option_sents) {
  vector<tts::SsmlText> ssml_texts;
  tts::SsmlParser::Instance().ParseText(request, "option", &ssml_texts);
  for (const auto& ssml_text : ssml_texts) {
    string context = "<speak>" + ssml_text.text + "</speak>";
    string speaker = string();
    double speed = 0.0;
    bool is_set = false;
    auto attr_it = ssml_text.tag.attrs.find(kSsmlSpeakerKey);
    if (attr_it != ssml_text.tag.attrs.end()) {
      speaker = attr_it->second;
      is_set = true;
    }
    attr_it = ssml_text.tag.attrs.find(kSsmlSpeedKey);
    if (attr_it != ssml_text.tag.attrs.end()) {
      speed = StringToFloat(attr_it->second);
      is_set = true;
    }
    option_sents->emplace_back(context, speaker, speed, is_set);
  }
  return;
}

void ServerUtil::SaveLogToQueue(
    const map<string, string>& params, const string& synthesize_mode,
    int32 used_time, const string& all_time,
    mobvoi::ConcurrentQueue<KibanaData>* log_queue) {
  if (log_queue == nullptr) return;
  KibanaData item;
  item["create_time"] = (Json::UInt)time(NULL);
  item["latency"] = used_time;
  item["all_chunk_time"] = all_time;
  item["synthesize_mode"] = synthesize_mode;
  item["product"] = "";
  auto it = params.find("product");
  if (it != params.end()) {
    item["product"] = it->second;
  }
  item["text"] = "";
  it = params.find("text");
  if (it != params.end()) {
    item["text"] = it->second;
  }
  item["speaker"] = "";
  it = params.find("speaker");
  if (it != params.end()) {
    item["speaker"] = it->second;
  }
  string appkey = "";
  it = params.find("appkey");
  if (it != params.end()) {
    appkey = it->second;
  }
  item["appkey"] = appkey;
  string msg_id = "";
  it = params.find("msg_id");
  if (it != params.end()) {
    msg_id = it->second;
  }
  item["msg_id"] = msg_id;
  string source = "";
  it = params.find("source");
  if (it != params.end()) {
    source = it->second;
  }
  item["source"] = source;
  item["uri"] = GetRequestParams(params);
  log_queue->Push(item);
}

void ServerUtil::SaveSyncLog(const map<string, string>& params, int used_time,
                             server::AsyncLogger* logger) {
  // Convert log to protobuf message
  LogMessage log;
  auto it = params.find("product");
  if (it != params.end() && !it->second.empty()) {
    log.set_product(it->second);
  }
  it = params.find("net_type");
  if (it != params.end() && !it->second.empty()) {
    log.set_net_type(it->second);
  }
  it = params.find("device_id");
  if (it != params.end() && !it->second.empty()) {
    log.set_device_id(it->second);
  }
  it = params.find("platform");
  if (it != params.end() && !it->second.empty()) {
    log.set_platform(it->second);
  }
  it = params.find("voice");
  if (it != params.end() && !it->second.empty()) {
    log.set_voice(it->second);
  }
  it = params.find("language");
  if (it != params.end() && !it->second.empty()) {
    log.set_language(it->second);
  }
  it = params.find("audio_type");
  if (it != params.end() && !it->second.empty()) {
    log.set_audio_type(it->second);
  }
  it = params.find("convert");
  if (it != params.end() && !it->second.empty()) {
    log.set_convert(it->second);
  }
  it = params.find("rate");
  if (it != params.end() && !it->second.empty()) {
    log.set_rate_str(it->second);
  }
  it = params.find("speed");
  if (it != params.end() && !it->second.empty()) {
    log.set_speed(it->second);
  }
  it = params.find("volume");
  if (it != params.end() && !it->second.empty()) {
    log.set_volume(it->second);
  }
  it = params.find("alignment");
  if (it != params.end() && it->second == "true") {
    log.set_alignment(true);
  }
  it = params.find("text");
  if (it != params.end() && !it->second.empty()) {
    log.set_text(it->second);
  }
  log.set_time(time(NULL));

  if (logger != NULL) {
    string log_str;
    util::ProtoJsonFormat::PrintToFastString(log, &log_str);
    logger->Log(log_str);
  }
}

void ServerUtil::SaveLog(const map<string, string>& params,
                         const int& used_time,
                         const string& all_time,
                         const string& type,
                         server::AsyncLogger* logger,
                         mobvoi::ConcurrentQueue<KibanaData>* log_queue) {
  ServerUtil::SaveSyncLog(params, used_time, logger);
  string debug_mode = "false";
  auto it = params.find("debug_mode");
  if (it != params.end() && !it->second.empty()) {
    debug_mode = it->second;
  }
  if (debug_mode == "false") {
    if (type == kTypeStreaming)
      ServerUtil::SaveLogToQueue(params, "streaming",
                                 used_time, all_time, log_queue);
    else
      ServerUtil::SaveLogToQueue(params, "non-streaming",
                                 used_time, all_time, log_queue);
  }
}

void ServerUtil::WriteToKibana(
    int use_cache, int used_time_ms, int text_length, const string& type,
    const string& speaker, const string& product,
    mobvoi::ConcurrentQueue<KibanaData>* data_queue) {
  if (FLAGS_write_matrics_to_kibana && data_queue != nullptr) {
    KibanaData item;
    item["query_date"] = static_cast<Json::UInt64>(mobvoi::GetTimeInMs());
    item["time"] = used_time_ms;
    item["text_len"] = text_length;
    item["tts_type"] = type;
    item["speaker"] = speaker;
    item["product"] = product;
    item["use_cache"] = use_cache;
    item["tts_detail_info"] = product + "_" + speaker + "_" + type;
    data_queue->Push(item);
  }
}

void ServerUtil::GetSpecialAudio(const AudioParams& audio_param, int* beg,
                                 int* end, map<int, int>* bgm_section,
                                 vector<int16>* pcm_result) {
  vector<int16> pcm_res_tmp;
  if (GetAudio(audio_param, &pcm_res_tmp)) {
    tts::VecFastAppend(pcm_res_tmp, pcm_result);
    bgm_section->insert(std::make_pair(*beg, *end));
    *end += pcm_res_tmp.size();
    *beg = *end;
  }
}

bool ServerUtil::GetAudio(const AudioParams& audio_param,
                          vector<int16>* pcm_result, bool del_tmp_file) {
  auto bgm = Singleton<server::Bgm>::get();
  string audio_url = audio_param.name;
  string name;
  if (audio_param.is_id) {
    string id = audio_param.name;
    GetUrl(id, &audio_url, &name);
    if (bgm->GetBgmData(id, pcm_result) ||
        FetchWavByUrl(audio_url, name, pcm_result)) {
      bgm->SetBgmTmpData(id, *pcm_result);
      AudioVolume audio_volume(1.0, 1.0);
      GenAudioVolume(*pcm_result, &audio_volume);
      bgm->SetAudioVolume(id, audio_volume);
    }
  } else {
    size_t found = audio_url.find_last_of("/");
    name = audio_url.substr(found + 1);
    if (bgm->GetBgmData(audio_url, pcm_result) ||
        FetchWavByUrl(audio_url, name, pcm_result, del_tmp_file)) {
      bgm->SetBgmTmpData(audio_url, *pcm_result);
      AudioVolume audio_volume(1.0, 1.0);
      GenAudioVolume(*pcm_result, &audio_volume);
      bgm->SetAudioVolume(audio_url, audio_volume);
    }
  }
  if (!pcm_result->empty()) {
    if (audio_param.volume != 1.0) {
      float volume = pow(audio_param.volume, 1.5);
      for (auto& it : *pcm_result) it *= volume;
    }
    return true;
  }
  return false;
}

void ServerUtil::GenAudioVolume(const vector<int16>& pcm_result,
                                AudioVolume* audio_volume) {
  double factor_sum = 0;
  double factor_tmp = 0.0;
  vector<float> volume_vec;
  volume_vec.reserve(pcm_result.size());
  for (size_t i = 0; i < pcm_result.size(); ++i) {
    factor_tmp = static_cast<double>(abs(pcm_result[i])) /
                 static_cast<double>(INT16_MAX);
    factor_sum += factor_tmp;
    volume_vec.emplace_back(factor_tmp);
  }
  std::sort(volume_vec.begin(), volume_vec.end());
  audio_volume->avg_vol = pow(factor_sum / pcm_result.size(), 0.67);
  audio_volume->p95_vol = pow(volume_vec[pcm_result.size() * 0.95], 0.67);
}

bool ServerUtil::GetAudioVolume(const string& id, AudioVolume* audio_volume) {
  auto bgm = Singleton<server::Bgm>::get();
  if (bgm->GetAudioVolume(id, audio_volume)) {
    return true;
  } else {
    string audio_url;
    string name;
    GetUrl(id, &audio_url, &name);
    vector<int16> pcm_result;
    if (bgm->GetBgmData(id, &pcm_result) ||
        (GetUrl(id, &audio_url, &name) &&
         FetchWavByUrl(audio_url, name, &pcm_result))) {
      bgm->SetBgmTmpData(id, pcm_result);
      GenAudioVolume(pcm_result, audio_volume);
      bgm->SetAudioVolume(id, *audio_volume);
      return true;
    }
  }
  return false;
}

bool ServerUtil::FetchWavByUrl(const string& url, const string& name,
                               vector<int16>* wav_data, bool del_tmp_file) {
  util::HttpClient http_client;
  http_client.SetFetchTimeout(FLAGS_http_fetch_timeout);
  http_client.SetConnectTimeout(FLAGS_http_connect_timeout);
  if (!http_client.FetchUrl(url) || http_client.response_code() != 200) {
    if (http_client.response_code() == 302 ||
        http_client.response_code() == 301) {
      string location_url = http_client.GetLocation();
      http_client.Reset();
      http_client.SetFetchTimeout(FLAGS_http_fetch_timeout);
      http_client.SetConnectTimeout(FLAGS_http_connect_timeout);
      if (!http_client.FetchUrl(location_url) ||
          http_client.response_code() != 200) {
        LOG(ERROR) << "location_url: " << location_url
                   << ", code: " << http_client.response_code();
      }
    }
    if (http_client.response_code() != 200) {
      LOG(ERROR) << "url: " << url << ", code: " << http_client.response_code();
      return false;
    }
  }
  string audio_path = FLAGS_save_audio_tmp_dir + name;
  int sample_rate, bits_per_sample;
  int16 channels;
  mobvoi::File::WriteStringToFileOrDie(http_client.ResponseBody(), audio_path);
  tts::WaveFile::ReadWaveFileInfo(audio_path, wav_data, &sample_rate,
                                  &bits_per_sample, &channels);
  if (del_tmp_file) {
    mobvoi::File::Delete(audio_path);
  }
  if ((sample_rate != tts::kDefaultSamplingFrequency) ||
      (channels != tts::kDefaultChannels)) {
    LOG(INFO) << "the wav's format is false !";
    LOG(INFO) << "sample_rate " << sample_rate << " channels " << channels;
    return false;
  }
  return true;
}

bool ServerUtil::GetUrl(const string& id, string* url, string* name) {
  string url_tmp = StringPrintf(FLAGS_moyin_url.c_str(), id.c_str());
  util::HttpClient http_client;
  if (!http_client.FetchUrl(url_tmp) || http_client.response_code() != 200) {
    LOG(WARNING) << "Failed to fetch url:" << url
                 << ", code:" << http_client.response_code()
                 << ", body:" << http_client.ResponseBody();
    return false;
  }
  VLOG(1) << "http response :  " << http_client.ResponseBody();
  Json::Value node;
  Json::Reader reader;
  if (!reader.parse(http_client.ResponseBody(), node)) {
    LOG(WARNING) << "Fail to parse json :" << http_client.ResponseBody();
    return false;
  }
  *url = node["data"]["url"].asString();
  *name = node["data"]["name"].asString();
  return true;
}

void ServerUtil::GetPitch(const string& text, tts::TTSOption* tts_option) {
  xmlDocPtr doc;
  string audio;
  if (!tts::SsmlParser::Instance().IsSsml(text, &doc)) return;
  xmlNode* root = xmlDocGetRootElement(doc);
  xmlAttr* attr = root->properties;
  map<string, string> attrs;
  while (attr) {
    attrs[(char*)(attr->name)] = (char*)(attr->children->content);  // NOLINT
    attr = attr->next;
  }
  map<string, string>::iterator it = attrs.find(tts::kSsmlPitch);
  if (it != attrs.end()) {
    tts_option->set_pitch(atof(it->second.c_str()));
  }
  xmlFreeDoc(doc);
}

void ServerUtil::GetBgmParam(const string& text, tts::TTSOption* tts_option) {
  xmlDocPtr doc;
  string audio;
  if (!tts::SsmlParser::Instance().IsSsml(text, &doc)) return;
  xmlNode* root = xmlDocGetRootElement(doc);
  xmlAttr* attr = root->properties;
  map<string, string> attrs;
  while (attr) {
    attrs[(char*)(attr->name)] = (char*)(attr->children->content);  // NOLINT
    attr = attr->next;
  }
  map<string, string>::iterator it = attrs.find(tts::kSsmlBgm);
  if (it != attrs.end()) {
    tts_option->set_bgm(it->second);
    it = attrs.find(tts::kSsmlBgmVolume);
    if (it != attrs.end() && atof(it->second.c_str()) > 0.0) {
      tts_option->set_bgm_volume(atof(it->second.c_str()));
    }
    it = attrs.find(tts::kSsmlBgmOffset);
    if (it != attrs.end() && atoi(it->second.c_str()) > 0) {
      tts_option->set_bgm_offset(atoi(it->second.c_str()));
    }
  }
  xmlFreeDoc(doc);
}

bool ServerUtil::GetBgm(const string& bgm_id, vector<int16>* pcm_tmp) {
  auto bgm = Singleton<server::Bgm>::get();
  string url;
  string name;
  if (bgm->GetBgmData(bgm_id, pcm_tmp) ||
      (GetUrl(bgm_id, &url, &name) && FetchWavByUrl(url, name, pcm_tmp))) {
    bgm->SetBgmTmpData(bgm_id, *pcm_tmp);
    AudioVolume audio_volume(1.0, 1.0);
    GenAudioVolume(*pcm_tmp, &audio_volume);
    bgm->SetAudioVolume(bgm_id, audio_volume);
    return true;
  }
  return false;
}

void ServerUtil::InitBgm() {
  auto bgm = Singleton<server::Bgm>::get();
  for (int i = 1; i <= FLAGS_init_top_bgm; ++i) {
    vector<int16> pcm_tmp;
    string url;
    string name;
    if (GetUrl(std::to_string(i), &url, &name) &&
        FetchWavByUrl(url, name, &pcm_tmp)) {
      bgm->SetBgmData(std::to_string(i), pcm_tmp);
      AudioVolume audio_volume(1.0, 1.0);
      GenAudioVolume(pcm_tmp, &audio_volume);
      bgm->SetAudioVolume(std::to_string(i), audio_volume);
    }
  }
}

void ServerUtil::FrontendDictJsonWrapper(Json::Value* frontend_dict_data) {
  Json::Value man_word_pron_dict(Json::arrayValue);
  Json::Value tw_word_pron_dict(Json::arrayValue);
  if (!FLAGS_word_pron_dict.empty() &&
      mobvoi::File::Exists(FLAGS_word_pron_dict)) {
    vector<string> lines;
    tts::GetConfigCenterLines(FLAGS_word_pron_dict, &lines);
    for (auto line : lines) {
      vector<string> values;
      Json::Value tmp_word_pron;
      SplitString(line, '\t', &values);
      if (values.size() == 4 || values.size() == 3) {
        tmp_word_pron["w"] = values[1];
        tmp_word_pron["t"] = values[2];
        tmp_word_pron["s"] = string();
        if (values.size() == 4) tmp_word_pron["s"] = values[3];
        if (values[0] == "man") {
          man_word_pron_dict.append(tmp_word_pron);
        }
        if (values[0] == "tw") {
          tw_word_pron_dict.append(tmp_word_pron);
        }
      }
    }
  }
  Json::Value phone_map_dict;
  if (!FLAGS_phone_map_dict.empty() &&
      mobvoi::File::Exists(FLAGS_phone_map_dict)) {
    vector<string> lines;
    tts::GetConfigCenterLines(FLAGS_phone_map_dict, &lines);
    for (auto line : lines) {
      vector<string> values;
      Json::Value tmp_phone_map;
      SplitString(line, '\t', &values);
      if (values.size() == 3) {
        tmp_phone_map["t"] = values[1];
        tmp_phone_map["tp"] = values[2];
        phone_map_dict[values[0]].append(tmp_phone_map);
      }
    }
  }
  if (!phone_map_dict.empty())
    (*frontend_dict_data)["phone_map_dict"] = phone_map_dict;
  if (!man_word_pron_dict.empty())
    (*frontend_dict_data)["man_word_pron_dict"] = man_word_pron_dict;
  if (!tw_word_pron_dict.empty())
    (*frontend_dict_data)["tw_word_pron_dict"] = tw_word_pron_dict;
}

bool ServerUtil::IsRejectOfflineRequest(
    const std::map<std::string, std::string>& params) {
  if (FLAGS_enable_offline_reject) {
    vector<string> product_list;
    mobvoi::SplitStringToVector(FLAGS_product_list, ",", true, &product_list);
    string product = GetProductParam(params);
    if (params.find("source") != params.end() &&
        params.at("source") == "app.navi") {
      for (const auto& item : product_list) {
        if (product == item) return true;
      }
    }
  }
  return false;
}

bool ServerUtil::IsRejectOfflineRequestSop1(
    const std::map<std::string, std::string>& params,
    const std::string& domain) {
  static vector<string> filter_list = {
    "为您切换到第",
    "请问您想导航去哪里",
    "请问您想查哪里",
    "抱歉，导航系统正在加载，请稍后再试",
    "为您找到多个目的地，请选择",
    "为您找到",
    "抱歉，未找到",
    "抱歉，在",
    "您可以尝试联网并重新搜索",
    "为您选择",
    "当前已有路径规划，将",
    "为您导航到",
    "当前未在路径规划中，请直接说出目的地",
    "抱歉，当前未在路径规划中，请设置目的地后重试",
    "地址暂未存储",
    "为您找到相应结果",
    "抱歉，当前未在路径规划中，该功能暂无法使用",
    "抱歉，当前导航状态下不支持此功能",
    "为您打开路况显示",
    "已是路况显示状态",
    "为您关闭路况显示",
    "已是路况关闭状态",
    "为您显示2D地图",
    "当前已是2D地图状态",
    "为您显示3D地图",
    "当前已是3D地图状态",
    "为您返回车辆当前位置",
    "为您停止导航",
    "为您显示限行信息",
    "为您放大地图",
    "为您缩小地图",
    "抱歉,无法继续放大地图",
    "为您将地图扩至最大",
    "抱歉,无法继续缩小地图",
    "为您将地图缩至最小",
    "抱歉,请在地图视图下使用该功能",
    "为您切换至夜间",
    "车辆已是车辆当前位置，无法再次反馈",
    "与当前导航路线相同，无法再次规划路线",
    "当前已是夜间",
    "抱歉，当前页面不支持此功能",
    "抱歉，仅支持搜索沿途加油站、维修站、洗手间",
    "抱歉，限行视图加载失败，请检查网络后重试",
    "抱歉，路况显示设置失败，请检查网络后重试",
    "抱歉，路线请求失败，请稍后重试",
    "预计回家需要",
    "预计去公司需要",
    "未能查询到时间信息"};
  if (FLAGS_enable_offline_reject) {
    string product = GetProductParam(params);
    if (domain == "public.navigation" &&
        (product == "cns" || product == "ebo" || product == "cns3.0")) {
      string text = params.at("text");
      for (const auto& item : filter_list) {
        if (text.find(item) != string::npos) return false;
      }
      return true;
    }
  }

  return false;
}

}  // namespace server
