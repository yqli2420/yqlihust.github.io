// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: yongqiangli@mobvoi.com (yongqiang li)

#include "tts/server/concurrent_service_handler.h"

#include <algorithm>
#include <regex>   // NOLINT
#include <thread>  // NOLINT
#include <vector>

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/concurrent_queue.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/mutex.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/base/time.h"
#include "third_party/googleurl/url_util.h"
#include "third_party/perftools/profiler.h"
#include "third_party/xml2/libxml/parser.h"
#include "third_party/xml2/libxml/xpath.h"

#include "tts/server/proto/tts_log.pb.h"
#include "tts/server/server_util.h"
#include "tts/server/speaker_mapping.h"
#include "tts/synthesizer/synthesizer.h"
#include "tts/util/encoder/encoder.h"
#include "tts/util/soundtouch/sound_stretch.h"
#include "tts/util/tts_util/tts_data.h"
#include "tts/util/tts_util/util.h"
#include "tts/util/tts_util/wave_util.h"

DEFINE_int32(concurrent_thread_num, 32,
             "number of thread for concurrent synthesize.");
DEFINE_int32(sentence_length, 20, "length of sentenct.");

DECLARE_int32(flac_compression_level);

namespace server {
using std::thread;
static const int kRequestTimeOut = 500;
static const int kBufferSize = 10240;

void PatternSplit(const string& input, const std::regex& regex_pattern,
                  vector<string>* output) {
  const std::sregex_iterator end;
  for (std::sregex_iterator i(input.begin(), input.end(), regex_pattern);
       i != end; ++i) {
    if (i->prefix().length() != 0) {
      if (!output->empty())
        output->back() = i->prefix();
      else
        output->emplace_back(i->prefix());
    } else {
      if (!output->empty()) output->pop_back();
    }
    output->back() += i->str();
    if (i->suffix().length() != 0) output->emplace_back(i->suffix());
  }
  if (output->empty()) output->emplace_back(input);
}

void SplitText(const std::string& text, const string& speaker, double speed,
               int* id, mobvoi::ConcurrentQueue<ConcurrentSent>* input_queue) {
  const string ssml_start = "<speak";
  const string ssml_end = "</speak>";
  const std::regex split_re("；|，|,|\\?|;|\\!|。|！|？");
  if (tts::SsmlParser::Instance().CountWordNum(text) > FLAGS_sentence_length) {
    vector<string> ssvec;
    PatternSplit(text, split_re, &ssvec);
    for (size_t k = 0; k < ssvec.size(); ++k) {
      if (ssvec[k].empty() ||
          !tts::SsmlParser::Instance().CountWordNum(ssvec[k]))
        continue;
      string temp = ssvec[k];
      if (temp.find(ssml_start) != 0) {
        temp = "<speak>" + temp;
      }
      if (temp.find(ssml_end) + ssml_end.size() != temp.size()) {
        temp += "</speak>";
      }
      input_queue->Push(ConcurrentSent(*id, temp, speaker, speed));
      ++(*id);
    }
  } else {
    input_queue->Push(ConcurrentSent(*id, text, speaker, speed));
    ++(*id);
  }
  LOG(INFO) << "Synthesize sentence number: " << input_queue->Size();
}

void SplitSpeakerText(const std::string& text, const string& speaker,
                      double speed,
                      mobvoi::ConcurrentQueue<ConcurrentSent>* input_queue,
                      vector<std::pair<int, AudioParams>>* audio) {
  vector<tts::SsmlText> ssml_texts;
  tts::SsmlParser::Instance().ParseText(text, tts::kSsmlAudio, &ssml_texts);
  int id = 0;
  for (auto it : ssml_texts) {
    if (it.text.empty()) {
      bool is_id = true;
      auto attr_it = it.tag.attrs.find(tts::kSsmlAudioName);
      if (attr_it == it.tag.attrs.end()) {
        attr_it = it.tag.attrs.find(tts::kSsmlAudioSrc);
        is_id = false;
      }
      if (attr_it != it.tag.attrs.end()) {
        auto attr_volume = it.tag.attrs.find(tts::kSsmlAudioVolume);
        float volume = attr_volume != it.tag.attrs.end()
                           ? atof(attr_volume->second.c_str())
                           : 1.0;
        audio->emplace_back(
            std::make_pair(id == 0 ? -1 : id - 1,
                           AudioParams(attr_it->second, volume, is_id)));
      }
    } else {
      string context = "<speak>" + it.text + "</speak>";
      vector<OptionSent> option_sents;
      ServerUtil::SplitOptionSent(context, &option_sents);
      for (size_t i = 0; i < option_sents.size(); ++i) {
        OptionSent option_sent = option_sents[i];
        string speaker_tmp = speaker;
        double speed_tmp = speed;
        if (option_sent.is_set) {
          if (!option_sent.speaker.empty()) speaker_tmp = option_sent.speaker;
          if (option_sent.speed != 0.0) speed_tmp = option_sent.speed;
        }
        SplitText(option_sent.context, speaker_tmp, speed_tmp, &id,
                  input_queue);
      }
    }
  }
}

void ConcurrentDataProvider::BatchSynthesize(
    tts::SynthesizerInterface* tts,
    mobvoi::ConcurrentQueue<ConcurrentSent>* input_queue) {
  while (!input_queue->Empty()) {
    ConcurrentSent text_item;
    input_queue->Pop(text_item);
    if (text_item.context != "") {
      tts::TTSOption option_tmp = tts_option_;
      if (!text_item.speaker.empty()) {
        option_tmp.set_speaker(text_item.speaker);
      }
      if (text_item.speed != 0.0) {
        option_tmp.set_speed(text_item.speed);
      }
      vector<int16> pcm_result;
      tts->Synthesize(text_item.context, option_tmp, &pcm_result);
      if (!pcm_result.empty()) {
        if (tts_option_.pitch()) {
          tts::SoundStretch sound_stretch(tts_option_.sampling_frequency(), 0,
                                          tts_option_.pitch(), 0, true, false,
                                          true);
          sound_stretch.Process(&pcm_result);
        }
        pcm_res_->at(text_item.id) = pcm_result;
        cond_var_.Signal();
      }
    }
  }
}

void ConcurrentDataProvider::SynthesisThread(const string& request,
                                             bool use_license,
                                             tts::SynthesizerInterface* tts) {
  int begin = mobvoi::GetTimeInMs();
  mobvoi::ConcurrentQueue<ConcurrentSent> input_queue;
  SplitSpeakerText(request, tts_option_.speaker(), tts_option_.speed(),
                   &input_queue, audio_.get());
  int sentence_number = input_queue.Size();
  pcm_res_->resize(sentence_number);
  LOG(INFO) << "Concurrent synthesize sentence number: " << sentence_number;
  int thread_num = sentence_number > FLAGS_concurrent_thread_num
                       ? FLAGS_concurrent_thread_num
                       : sentence_number;
  vector<thread*> threads;
  for (int i = 0; i < thread_num; ++i) {
    thread* thd = new thread(&ConcurrentDataProvider::BatchSynthesize, this,
                             tts, &input_queue);
    threads.emplace_back(thd);
  }

  for (int i = 0; i < thread_num; ++i) threads[i]->join();

  for (int i = 0; i < thread_num; ++i) {
    if (threads[i] != nullptr) {
      delete threads[i];
      threads[i] = nullptr;
    }
  }
  threads.clear();
  int use_time = mobvoi::GetTimeInMs() - begin;
  LOG(INFO) << "used time (Ms):" << use_time
            << ", word : " << tts::SsmlParser::Instance().CountWordNum(request);
}

ConcurrentDataProvider::ConcurrentDataProvider(
    std::shared_ptr<tts::SynthesizerInterface> synthesizer, bool use_license)
    : use_license_(use_license),
      text_id_(0),
      bgm_offset_(0),
      text_is_empty_(false) {
  pcm_res_ = std::make_shared<vector<vector<int16>>>();
  audio_ = std::make_shared<vector<std::pair<int, server::AudioParams>>>();
  synthesizer_ = synthesizer;
}

void ConcurrentDataProvider::Start(util::HttpRequest* request,
                                   util::HttpResponse* response) {
  map<string, string> params;
  ServerUtil::ParseRequestParams(request, &params);
  request_params_ = params;
  if (!ServerUtil::SetAllParams(params, kTypeStreaming, &tts_option_,
                                response)) {
    ServerUtil::ReleaseLicense(use_license_);
    return;
  }
  string text = params["text"];
  if (text.empty() || !tts::SsmlParser::Instance().CountWordNum(text)) {
    text_is_empty_ = true;
  }
  ServerUtil::GetBgmParam(text, &tts_option_);
  ServerUtil::GetPitch(text, &tts_option_);
  LOG(INFO) << "Request synthesis request params:"
            << ServerUtil::GetRequestParams(params);

  // Input pre-processing
  int word_num = 0;
  ServerUtil::DoInputPreprocess(params, &text, &word_num);
  ServerUtil::AppendHeadSilence(params, &text);
  thread_.reset(new std::thread(&ConcurrentDataProvider::SynthesisThread, this,
                                text, use_license_, synthesizer_.get()));
}

bool ConcurrentDataProvider::Next(string* data) {
  string str;
  mobvoi::MutexLock mutex(&mutex_);
  if (text_is_empty_) {
    str = string();
  } else {
    while (pcm_res_->empty()) {
      cond_var_.Wait(&mutex_);
    }
    while (text_id_ != pcm_res_->size() && pcm_res_->at(text_id_).empty()) {
      cond_var_.Wait(&mutex_);
    }
    if (text_id_ == pcm_res_->size()) {
      str = string();
    } else {
      vector<int16> pcm_result;
      // head audio
      if (!audio_->empty() && audio_->at(0).first < 0) {
        vector<int16> audio_tmp;
        ServerUtil::GetAudio(audio_->at(0).second, &audio_tmp);
        tts::VecFastAppend(audio_tmp, &pcm_result);
      }
      // bgm
      vector<int16> bgm_data;
      vector<int16> pcm_tmp(pcm_res_->at(text_id_));
      if (!tts_option_.bgm().empty() && !tts_option_.insert_audio() &&
          server::ServerUtil::GetBgm(tts_option_.bgm(), &bgm_data)) {
        tts::WaveFile::AudioMix(bgm_data, tts_option_.volume(),
                                tts_option_.bgm_volume(), bgm_offset_,
                                &pcm_tmp);
        bgm_offset_ += pcm_tmp.size();
      }
      tts::VecFastAppend(pcm_tmp, &pcm_result);
      // insert audio
      auto it = find_if(audio_->begin(), audio_->end(),
                        [this](pair<int, AudioParams> curr) {
                          return curr.first == text_id_;
                        });
      if (it != audio_->end()) {
        vector<int16> audio_tmp;
        ServerUtil::GetAudio(it->second, &audio_tmp);
        tts::VecFastAppend(audio_tmp, &pcm_result);
      }

      encoder::PostProcessOption pp_option(
          tts::kDefaultSamplingFrequency, tts_option_.sampling_frequency(),
          tts::kNoNormalizeFactor, tts_option_.volume(),
          tts_option_.file_format());
      if (pp_option.file_format.find("flac") != string::npos) {
        encoder::FlacEncoder encoder;
        FLAC__byte buffer[kBufferSize];
        encoder.Reset(buffer, kBufferSize, tts_option_.sampling_frequency(),
                      FLAGS_flac_compression_level);
        encoder::PostProcessFlac(pcm_result, pp_option, &encoder, &str);
      } else {
        encoder::PostProcess(pcm_result, pp_option, &str);
      }
    }
    ++text_id_;
  }
  data->assign(str);
  return !str.empty();
}

ConcurrentDataProvider::~ConcurrentDataProvider() { thread_->join(); }

ConcurrentHttpHandler::ConcurrentHttpHandler(
    util::Callback callback, bool use_license,
    std::shared_ptr<tts::SynthesizerInterface> synthesizer)
    : use_license_(use_license), HttpHandler(callback) {
  synthesizer_ = synthesizer;
  url_util::Initialize();
  xmlInitParser();
}

ConcurrentHttpHandler::~ConcurrentHttpHandler() { xmlCleanupParser(); }

bool ConcurrentHttpHandler::Handler(util::HttpRequest* request,
                                    util::HttpResponse* response) {
  return true;
}

util::DataProvider* ConcurrentHttpHandler::CreateProvider(
    struct evhttp_request* req) const {
  LOG(INFO) << "create provider.";
  return new ConcurrentDataProvider(synthesizer_, use_license_);
}
}  // namespace server
