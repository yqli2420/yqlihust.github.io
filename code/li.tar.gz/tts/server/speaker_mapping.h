// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_SERVER_SPEAKER_MAPPING_H_
#define TTS_SERVER_SPEAKER_MAPPING_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/singleton.h"

namespace server {

class SpeakerMapping {
 public:
  virtual ~SpeakerMapping();

  bool MapSpeaker(const string& app_key, const string& speaker,
                  string* map_speaker) const;

 private:
  SpeakerMapping();
  friend struct DefaultSingletonTraits<SpeakerMapping>;
  void LoadSpeakerMapping(const string& map_config);

  std::unordered_map<string, string> speaker_mapping_;
  DISALLOW_COPY_AND_ASSIGN(SpeakerMapping);
};

}  // namespace server

#endif  // TTS_SERVER_SPEAKER_MAPPING_H_
