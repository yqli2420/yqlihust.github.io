// Copyright 2014 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include <signal.h>
#include <cstdio>

#include <thread>  //NOLINT

#include "mobvoi/base/at_exit.h"
#include "mobvoi/base/callback.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/singleton.h"
#include "mobvoi/base/time.h"
#include "mobvoi/util/net/http_server/http_server.h"

#ifdef USE_LICENSE
#include "mobvoi/license/license_validator.h"
#endif

#ifdef USE_GRPC
#include "tts/server/grpc/grpc_synth_service.h"
#include "tts/server/grpc/http_synth_service.h"
#include "tts/server/grpc/tts_resource_manager.h"
#endif

#ifndef USE_GRPC
#include "tts/server/bgm_server.h"
#include "tts/server/concurrent_service_handler.h"
#endif

#include "tts/server/align_service_handler.h"
#include "tts/server/block_service_handler.h"
#include "tts/server/cache_handler.h"
#include "tts/server/frontend_service_handler.h"
#include "tts/server/kibana/kibana_write_thread.h"
#include "tts/server/model_update_service_handler.h"
#include "tts/server/server_util.h"
#include "tts/server/streaming_service_handler.h"
#include "tts/server/tts_log.h"
#include "tts/synthesizer/interface/synthesizer_interface.h"
#include "tts/synthesizer/synthesizer.h"

DEFINE_int32(listen_port, 10012, "");
DEFINE_int32(thread_num, 10, "");
DEFINE_string(license, "path/to/license", "input file");
DEFINE_string(speaker_info_file, "external/config/config_file/speakers.json",
              "speaker info json file");
DEFINE_string(grpc_host, "0.0.0.0", "grpc service host");
DEFINE_string(grpc_port, "8080", "service port");
DEFINE_bool(synth_request_http, false, "grpc server enable or not");
DEFINE_string(synth_server_url, "", "synth http server url");
DEFINE_bool(debug, true, "debug enable or not");
DEFINE_bool(use_bgm, false, "use bgm");
DECLARE_bool(use_adaptation);

using std::placeholders::_1;
using std::placeholders::_2;

class HttpServerThread : public mobvoi::Thread {
 public:
  virtual void Run() {
    bool use_license = false;
#ifdef USE_LICENSE
    use_license = true;
#endif
    mobvoi::ConcurrentQueue<KibanaData> kibana_queue;
    mobvoi::ConcurrentQueue<KibanaData> log_queue;
    server::KinabaWriteThread write_thread(&kibana_queue);
    write_thread.Start();
    std::thread write_log_thread(SaveLogToMysql, &log_queue);

    util::HttpServer http_server(FLAGS_listen_port, FLAGS_thread_num);

    // block synthesis server
    server::BlockServerHandler block_tts_server(synthesizer_, use_license,
                                                &kibana_queue, &log_queue);
    auto callback = std::bind(&server::BlockServerHandler::Synthesize,
                              &block_tts_server, _1, _2);
    unique_ptr<util::HttpHandler> synthesize_handler;
    synthesize_handler.reset(new util::DefaultHttpHandler(callback));
    http_server.RegisterHttpHandler("/api/synthesis", synthesize_handler.get());

    // streaming synthesis server
    server::StreamingHttpHandler streaming_tts_handler(
        nullptr, use_license, synthesizer_, &kibana_queue, &log_queue,
        FLAGS_use_adaptation);
    http_server.RegisterChunkedHttpHandler("/api/streaming",
                                           &streaming_tts_handler);
#ifndef USE_GRPC
    // for concurrent synthesis server
    auto concurrent_callback =
        std::bind(&server::BlockServerHandler::ConcurrentSynthesize,
                  &block_tts_server, _1, _2);
    unique_ptr<util::HttpHandler> concurrent_synthesize_handler;
    concurrent_synthesize_handler.reset(
        new util::DefaultHttpHandler(concurrent_callback));
    http_server.RegisterHttpHandler("/api/concurrent_synthesis",
                                    concurrent_synthesize_handler.get());

    // streaming concurrent synthesis
    server::ConcurrentHttpHandler concurrent_tts_handler(nullptr, use_license,
                                                         synthesizer_);
    http_server.RegisterChunkedHttpHandler("/api/concurrent_streaming",
                                           &concurrent_tts_handler);
#endif
    // frontend analysis server
    server::FrontendServerHandler frontend_server(synthesizer_.get(),
                                                  use_license);
    auto frontend_callback =
        std::bind(&server::FrontendServerHandler::ConcurrentSynthesize,
                  &frontend_server, _1, _2);
    unique_ptr<util::HttpHandler> frontend_handler;
    frontend_handler.reset(new util::DefaultHttpHandler(frontend_callback));
    http_server.RegisterHttpHandler("/api/frontend_analysis",
                                    frontend_handler.get());

    // frontend resource server
    server::FrontendServerHandler frontend_resource_server(synthesizer_.get(),
                                                           use_license);
    auto frontend_resource_callback =
        std::bind(&server::FrontendServerHandler::GetFrontendDictSource,
                  &frontend_resource_server, _1, _2);
    unique_ptr<util::HttpHandler> frontend_resource_handler;
    frontend_resource_handler.reset(
        new util::DefaultHttpHandler(frontend_resource_callback));
    http_server.RegisterHttpHandler("/api/frontend_resource",
                                    frontend_resource_handler.get());

    // alignment server
    server::AlignServerHandler tts_align_server(synthesizer_, use_license,
                                                &kibana_queue, &log_queue);
    auto callback_align = std::bind(&server::AlignServerHandler::Synthesize,
                                    &tts_align_server, _1, _2);
    unique_ptr<util::HttpHandler> tts_align_handler;
    tts_align_handler.reset(new util::DefaultHttpHandler(callback_align));
    http_server.RegisterHttpHandler("/api/alignment", tts_align_handler.get());

#ifndef USE_GRPC
    // bgm
    server::BgmServerHandler bgm_server(&kibana_queue, &log_queue);
    auto callback_bgm =
        std::bind(&server::BgmServerHandler::FetchAudio, &bgm_server, _1, _2);
    unique_ptr<util::HttpHandler> bgm_handler;
    bgm_handler.reset(new util::DefaultHttpHandler(callback_bgm));
    http_server.RegisterHttpHandler("/api/bgm", bgm_handler.get());
#endif
    // update frontend model
    server::ModelUpdateServerHandler model_update_server_handler;
    auto model_update_callback =
        std::bind(&server::ModelUpdateServerHandler::UpdateFrontendModel,
                  &model_update_server_handler, _1, _2);
    unique_ptr<util::HttpHandler> model_update_handler;
    model_update_handler.reset(
        new util::DefaultHttpHandler(model_update_callback));
    http_server.RegisterHttpHandler("/api/update_model",
                                    model_update_handler.get());
#ifdef USE_GRPC
    mobvoi::HttpSynthService http_synth_service;
    auto callback_model_download = std::bind(
        &mobvoi::HttpSynthService::DownloadModel, &http_synth_service, _1, _2);
    util::DefaultHttpHandler model_download_handler(callback_model_download);
    http_server.RegisterHttpHandler("/api/model/download",
                                    &model_download_handler);
    http_server.RegisterHttpHandler("/api/notify", &model_download_handler);
#endif

    // status server
    string status_server;
    status_server = "tts_server_hts";
    util::StatusHttpHandler status(status_server, NULL);
    http_server.RegisterHttpHandler("/status", &status);
    LOG(INFO) << "http server listening on " << FLAGS_listen_port;
    http_server.Serv();
    write_thread.Join();
    write_log_thread.join();
  }

  void SetSynthesizer(std::shared_ptr<tts::Synthesizer> synthesizer) {
    synthesizer_ =
        std::static_pointer_cast<tts::SynthesizerInterface>(synthesizer);
  }

 private:
  std::shared_ptr<tts::SynthesizerInterface> synthesizer_;
};

#ifdef USE_GRPC
#pragma message("use grpc")
class GrpcServerThread : public mobvoi::Thread {
 public:
  virtual void Run() {
    mobvoi::GrpcSynthService service;
    service.SetSynthRequestHttp(FLAGS_synth_request_http);
    service.SetDefaultSynthServerUrl(FLAGS_synth_server_url);
    service.SetSynthesizer(synthesizer_);
    service.SetDebugFlag(FLAGS_debug);
    std::string server_address(FLAGS_grpc_host + ":" + FLAGS_grpc_port);
    grpc::ServerBuilder builder;
    builder.AddListeningPort(server_address, grpc::InsecureServerCredentials());
    builder.RegisterService(&service);
    builder.SetMaxMessageSize(1024 * 1024 * 1024);  // 1024 MB maximum payload
    unique_ptr<grpc::Server> server(builder.BuildAndStart());
    LOG(INFO) << "grpc server listening on " << server_address;
    server->Wait();
  }
  void SetSynthesizer(tts::Synthesizer* synthesizer) {
    synthesizer_ = synthesizer;
  }

 private:
  tts::Synthesizer* synthesizer_;
};
#endif

int main(int argc, char** argv) {
  base::AtExitManager at_exit;
  google::ParseCommandLineFlags(&argc, &argv, false);
  google::InitGoogleLogging(argv[0]);

#ifdef USE_LICENSE
#pragma message("use license")
  // use macro to avoid set by user
  mobvoi::LicenseValidator::GetInstance()->StartValidate(FLAGS_license);
#endif
  if (FLAGS_use_bgm) {
    std::thread init_bgm(&server::ServerUtil::InitBgm);
    init_bgm.join();
  }
  std::shared_ptr<tts::Synthesizer> synthesizer;
  synthesizer.reset(new tts::Synthesizer(FLAGS_speaker_info_file));
  HttpServerThread http_server_thread;
  http_server_thread.SetSynthesizer(synthesizer);
  http_server_thread.Start();
#ifdef USE_GRPC
  GrpcServerThread grpc_server_thread;
  grpc_server_thread.SetSynthesizer(synthesizer.get());
  grpc_server_thread.Start();
  grpc_server_thread.Join();
#endif
  http_server_thread.Join();

  return 0;
}
