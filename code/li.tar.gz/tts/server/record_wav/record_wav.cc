// Copyright 2016 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/server/record_wav/record_wav.h"

#include <fstream>
#include "mobvoi/base/file.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/string_util.h"
#include "tts/util/encoder/encoder.h"
#include "tts/util/ssml/ssml_parser.h"
#include "tts/util/tts_util/util.h"
#include "tts/util/tts_util/wave_util.h"

namespace server {

RecordWav::RecordWav(const string& record_file) {
  LoadRecordWav(record_file);
  VLOG(1) << "load record wav end";
}
RecordWav::~RecordWav() {}

string GetKey(const string& domain, const string& speaker, const string& text) {
  if (kPush == domain) {
    return kPush + "_" + text;
  }
  return speaker + "_" + text;
}

void RecordWav::LoadRecordWavBySource(const string& domain,
                                      const string& speaker,
                                      const string& record_file) {
  vector<string> lines;
  file::SimpleLineReader reader(record_file);
  reader.ReadLines(&lines);
  string wav_dir = mobvoi::File::FindFileDir(record_file);
  for (size_t i = 0; i < lines.size(); ++i) {
    vector<string> segs;
    SplitString(lines[i], '\t', &segs);
    if (segs.size() == 2) {
      string wav_file_name = wav_dir + segs[1];
      vector<int16> wav_data;
      int sample_freq;
      if (!mobvoi::File::Exists(wav_file_name)) {
        LOG(WARNING) << "No record wav file:" << wav_file_name;
        continue;
      }
      tts::WaveFile::ReadWaveFile(wav_file_name, &wav_data, &sample_freq);
      CHECK(sample_freq == tts::kDefaultSamplingFrequency)
          << "Error sample frequency" << sample_freq
          << "!=" << tts::kDefaultSamplingFrequency;
      string key = GetKey(domain, speaker, segs[0]);
      VLOG(3) << key;
      record_wav_maps_[key] = wav_data;
      VLOG(3) << "add record key: " << key;
    } else {
      LOG(WARNING) << "bad lines" << lines[i];
      continue;
    }
  }
}

void RecordWav::ParseAndLoad(const string& model_dir, const Json::Value& models,
                             const string& domain) {
  for (auto model : models) {
    string speaker = model.get("speaker", "").asString();
    string file = model.get("record_map", "").asString();
    VLOG(3) << speaker << " " << file;
    LoadRecordWavBySource(domain, speaker, model_dir + "/" + file);
  }
}

void RecordWav::LoadRecordWav(const string& record_file) {
  std::ifstream fp_record(record_file.c_str());
  if (!fp_record.is_open()) {
    LOG(ERROR) << "open " << record_file << " failed.";
    return;
  }
  string record_dir = mobvoi::File::FindFileDir(record_file);

  Json::Value root;
  fp_record >> root;
  ParseAndLoad(record_dir, root[kPush], kPush);
  ParseAndLoad(record_dir, root[kFaq], kFaq);
}

bool RecordWav::FindRecordWav(const string& text, const string& domain,
                              const string& speaker,
                              vector<int16>* data) const {
  string key = GetKey(domain, speaker, text);
  VLOG(2) << key;
  auto it = record_wav_maps_.find(key);
  if (it != record_wav_maps_.end()) {
    VLOG(1) << "Find recorded wave: " << key;
    data->insert(data->end(), it->second.begin(), it->second.end());
    return true;
  }
  return false;
}

bool RecordWav::GetRecordWav(const string& xml_text,
                             const tts::TTSOption& tts_option,
                             string* data_res) const {
  if (tts_option.domain() != kFaq && tts_option.domain() != kPush) {
    return false;
  }
  VLOG(2) << xml_text;
  vector<tts::SsmlText> ssml_text;
  tts::SsmlParser::Instance().ParseText(xml_text, &ssml_text);
  string text = tts::SsmlParser::Instance().JoinText(ssml_text);
  vector<int16> data;
  if (FindRecordWav(text, tts_option.domain(), tts_option.speaker(), &data)) {
    encoder::PostProcessOption pp_option(
        tts::kDefaultSamplingFrequency, tts_option.sampling_frequency(),
        tts::kNoNormalizeFactor, tts_option.volume(), tts_option.file_format());
    encoder::PostProcess(data, pp_option, data_res);
    return true;
  }
  return false;
}

}  // namespace server
