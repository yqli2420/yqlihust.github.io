// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng yang)

#ifndef TTS_SERVER_SING_REQUEST_HANDLER_H_
#define TTS_SERVER_SING_REQUEST_HANDLER_H_

#include "mobvoi/base/flags.h"
#include "tts/server/server_util.h"
#include "tts/synthesizer/sing_synthesis/sing_synthesis.h"

namespace sing_synthesizer {

class SingHttpServer {
 public:
  SingHttpServer(string res_dir, bool use_mgc);
  ~SingHttpServer();

  bool Handle(const util::HttpRequest* request,
              util::HttpResponse* response) const;

 private:
  string res_dir_;
  bool use_mgc_;
  SingingSyntheszer* sing_syn_;

  bool InternalHandle(const util::HttpRequest* request,
                      util::HttpResponse* response) const;
  bool ErrorReturn(util::HttpResponse* response, int error_code,
                   const string& desc) const;
  int GetHeaderLength(const std::string& audio_data, int* sample_rate) const;
};
}  // namespace sing_synthesizer
#endif  //  TTS_SERVER_SING_REQUEST_HANDLER_H_
