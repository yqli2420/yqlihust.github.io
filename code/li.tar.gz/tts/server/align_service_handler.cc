// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/server/align_service_handler.h"

#include "mobvoi/base/log.h"
#include "mobvoi/base/time.h"
#include "tts/util/tts_util/util.h"

namespace server {

AlignServerHandler::AlignServerHandler(
    std::shared_ptr<tts::SynthesizerInterface> _synthesizer, bool use_license,
    mobvoi::ConcurrentQueue<KibanaData>* _data_queue,
    mobvoi::ConcurrentQueue<KibanaData>* _log_queue)
    : use_license_(use_license),
      tts_(_synthesizer),
      data_queue_(_data_queue),
      log_queue_(_log_queue) {
  logger_ = Singleton<AsyncLogger>::get();
}

AlignServerHandler::~AlignServerHandler() {}

bool AlignServerHandler::Synthesize(util::HttpRequest* request,
                                    util::HttpResponse* response) const {
  ServerUtil::AcquireLicense(use_license_);
  // Get params
  map<string, string> params;
  ServerUtil::ParseRequestParams(request, &params);

  // Set params
  tts::TTSOption tts_option;
  if (!ServerUtil::SetAllParams(params, kTypeBlock, &tts_option, response)) {
    ServerUtil::ReleaseLicense(use_license_);
    return true;
  }

  LOG(INFO) << "Request synthesis request params:"
            << ServerUtil::GetRequestParams(params);
  string text = params["text"];
  // TODO(zhengzhang): add cache in the future
  int begin = mobvoi::GetTimeInMs();
  int word_num = 0;
  // Input pre-processing
  ServerUtil::DoInputPreprocess(params, &text, &word_num);
  int use_cache = -1;
  string data_res;
  tts_->Synthesize(text, tts_option, &data_res);
  response->AppendBuffer(data_res);
  int end = mobvoi::GetTimeInMs();
  int used_time = end - begin;
  LOG(INFO) << "used time (Ms):" << used_time << ", word : " << word_num
            << ", text : " << text;

  ServerUtil::SaveLog(params, used_time, "", kTypeBlock, logger_, log_queue_);
  string product = ServerUtil::GetProductParam(params);
  ServerUtil::WriteToKibana(use_cache, used_time, word_num, kReqTypeAlign,
                            tts_option.speaker(), product, data_queue_);
  ServerUtil::ReleaseLicense(use_license_);
  return true;
}

}  // namespace server
