// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng yang)

#include "tts/server/sing_request_handler.h"

#include "mobvoi/base/at_exit.h"

DEFINE_int32(listen_port, 7786, "");
DEFINE_int32(thread_num, 1, "");
DEFINE_string(sing_res_dir, "tts/synthesizer/sing_synthesis/data/resource/",
              "");
DEFINE_bool(if_use_mgc, true, "");

using std::placeholders::_1;
using std::placeholders::_2;
int main(int argc, char** argv) {
  base::AtExitManager at_exit;
  google::ParseCommandLineFlags(&argc, &argv, false);

  util::HttpServer http_server(FLAGS_listen_port, FLAGS_thread_num);
  sing_synthesizer::SingHttpServer sing_server(FLAGS_sing_res_dir,
                                               FLAGS_if_use_mgc);
  util::DefaultHttpHandler handler(
      bind(&sing_synthesizer::SingHttpServer::Handle, &sing_server, _1, _2));
  http_server.RegisterHttpHandler("/http/sing", &handler);
  REGISTER_STATUS(http_server, sing_http_server);
  http_server.Serv();

  return 0;
}
