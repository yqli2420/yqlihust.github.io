// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com

#ifndef TTS_SERVER_GRPC_MODEL_MANAGER_H_
#define TTS_SERVER_GRPC_MODEL_MANAGER_H_

#include <list>
#include <map>
#include <string>

#include "mobvoi/base/mutex.h"
#include "mobvoi/base/thread.h"
#include "tts/synthesizer/engine/tacotron/one_engine.h"
#include "tts/server/server_util.h"

namespace mobvoi {

struct ModelInfo {
  bool is_update;
};

class ModelManager : public Thread {
 private:
  ModelManager();

 public:
  ~ModelManager();

 public:
  static ModelManager* GetInstance();
  void StartUp();
  bool LoadModelFromLocal(const std::string& file_name);
  bool LoadModelFromRemote(const std::string& model_id);
  // if model updated, not use cache
  bool IsModelUpdate(const std::string& model_id);
  void ClearModelUpdate(const std::string& model_id);
  std::shared_ptr<engine::Engine> GetEngine(
      const std::string& engine_id);

 private:
  virtual void Run();
  std::string ReplaceString(
      const std::string& str,
      const std::string& str_src,
      const std::string& str_dst);

 private:
  std::map<std::string, ModelInfo> model_update_map_;
  std::list<std::string> model_download_list_;
  std::string model_save_dir_;
  Mutex model_update_mutex_;
  Mutex model_download_mutex_;
  Mutex mutex_;
  bool exit_flag_;
  static std::unique_ptr<ModelManager> instance_;
};

}  // namespace mobvoi

#endif  // TTS_SERVER_GRPC_MODEL_MANAGER_H_
