// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com (XiaoKai Yang)

#include "tts/server/grpc/synth_config.h"

#include <fstream>
#include <iostream>
#include <sstream>

#include "mobvoi/base/file.h"
#include "mobvoi/base/log.h"

namespace mobvoi {

std::map<std::string, std::string> SynthConfig::config_map_;
std::map<std::string, bool> SynthConfig::config_file_map_;
Mutex SynthConfig::mutex_;

SynthConfig::SynthConfig() {}

SynthConfig::~SynthConfig() {}

std::string SynthConfig::GetValueAsString(const std::string& key) {
  MutexLock mutex_lock(&mutex_);
  std::map<std::string, std::string>::iterator itKey;
  if ((itKey = config_map_.find(key)) != config_map_.end()) {
    return itKey->second;
  }
  return "";
}

bool SynthConfig::LoadConfigFromFile(const std::string& config_file) {
  MutexLock mutex_lock(&mutex_);
  if (config_file.empty()) {
    LOG(ERROR) << "config file path empty error";
    return false;
  }

  if (File::IsDir(config_file)) {
    LOG(ERROR) << "config file path set error: directory is set";
    return false;
  }

  std::map<std::string, bool>::iterator it_config_file;
  if ((it_config_file = config_file_map_.find(config_file)) !=
     config_file_map_.end()) {
     if (it_config_file->second == true) {
       return true;
     }
  }

  std::ifstream infile;
  infile.open(config_file.c_str());
  if (!infile.is_open()) {
    LOG(ERROR) << "load config from file error: "
               << config_file;
    return false;
  }

  char buff[512];
  std::string section = "";

  while (!infile.eof()) {
    memset(buff, 0, sizeof(buff));
    infile.getline(buff, sizeof(buff));
    if (buff[0] == '#' || buff[0] == '\0') continue;

    std::string s = buff;
    size_t index = std::string::npos;
    std::string key = "";
    std::string value = "";

    if ((index = s.find_first_of('=')) != std::string::npos) {
      key = s.substr(0, index);
      value = s.substr(index + 1);
    } else {
      continue;
    }

    std::map<std::string, std::string>::iterator itKey;

  if (!key.empty()) {
    std::string keyName = key;
    while ((index = keyName.find('.')) != std::string::npos) {
      keyName = keyName.substr(0, index) +
          keyName.substr(index + 1, keyName.length() - index - 1);
    }

    if ((itKey = config_map_.find(keyName)) == config_map_.end()) {
      config_map_.insert(std::pair<std::string, std::string>(keyName, value));
    } else {
      itKey->second = value;
    }
      LOG(INFO) << "config value: "
                << keyName << "="
                << value;
    }
  }
  infile.close();
  config_file_map_.insert(std::pair<std::string, bool>(config_file, true));
  return true;
}

void SynthConfig::SetConfigValue(
    const std::string& key, const std::string& value) {
  if (key.empty()) return;
  MutexLock mutex_lock(&mutex_);
  std::map<std::string, std::string>::iterator itKey;
  if ((itKey = config_map_.find(key)) == config_map_.end()) {
    config_map_.insert(std::pair<std::string, std::string>(key, value));
  } else {
    itKey->second = value;
  }
  LOG(INFO) << "set config value: "
            << key << "="
            << value;
}

bool SynthConfig::SetConfigValueByEnv(const std::string& key) {
  if (key.empty()) return false;
  const char* value = NULL;
  if ((value = std::getenv(key.c_str())) != NULL) {
    SetConfigValue(key, std::string(value));
    return true;
  } else {
    LOG(INFO) << "set config value failure, key: "
              << key;
  }
  return false;
}

}  // namespace mobvoi

