// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com
#include "tts/server/grpc/model_manager.h"

#include "absl/time/clock.h"
#include "absl/time/time.h"
#include "mobvoi/base/singleton.h"
#include "mobvoi/base/flags.h"
#include "tts/server/cache_handler.h"
#include "mobvoi/util/net/http_client/http_client.h"

DECLARE_string(base_model_url);
DECLARE_string(save_adaptation_model_dir);
DECLARE_int32(http_connect_timeout);
DECLARE_int32(http_fetch_timeout);

DEFINE_bool(model_auto_download, true, "enable model auto download or not");
DEFINE_string(model_url_replace_from, "", "model url replace from");
DEFINE_string(model_url_replace_to, "", "model url replace to");

namespace mobvoi {

std::unique_ptr<ModelManager> ModelManager::instance_(new ModelManager());

ModelManager::ModelManager()
    : exit_flag_(true) {}

ModelManager::~ModelManager() {
  if (this->running()) {
    exit_flag_ = true;
    this->Join();
  }
}

ModelManager* ModelManager::GetInstance() {
  return instance_.get();
}

void ModelManager::StartUp() {
  model_save_dir_ = FLAGS_save_adaptation_model_dir;
  if (!model_save_dir_.empty() && model_save_dir_.back() != '/') {
    model_save_dir_ += "/";
  }
  if (FLAGS_model_auto_download) {
    exit_flag_ = false;
    this->Start();
  }
}

bool ModelManager::LoadModelFromLocal(const std::string& file_name) {
  if (file_name.empty()) return false;
  return true;
}

bool ModelManager::LoadModelFromRemote(const std::string& engine_id) {
  if (engine_id.empty()) return false;
  // download taco model from oss
  string url = StringPrintf(FLAGS_base_model_url.c_str(),
      engine_id.c_str(), engine_id.c_str());
  util::HttpClient http_client;
  http_client.SetFetchTimeout(FLAGS_http_fetch_timeout);
  http_client.SetConnectTimeout(FLAGS_http_connect_timeout);
  if (!http_client.FetchUrl(url) || http_client.response_code() != 200) {
    if (http_client.response_code() == 302 ||
        http_client.response_code() == 301) {
      string location_url = http_client.GetLocation();
      if (!FLAGS_model_url_replace_to.empty()) {
        int index1 = location_url.find("http://");
        int index2 = std::string::npos;
        if (index1 != std::string::npos) {
          index2 = location_url.find("/", index1 + 7);
          if (index2 != std::string::npos) {
            location_url = "http://" +
                FLAGS_model_url_replace_to + location_url.substr(index2);
          }
        }
      }
      http_client.Reset();
      http_client.SetFetchTimeout(FLAGS_http_fetch_timeout);
      http_client.SetConnectTimeout(FLAGS_http_connect_timeout);
      if (!http_client.FetchUrl(location_url) ||
          http_client.response_code() != 200) {
        // please set --max_body_buffer_size=209715200 to avoid this error
        // if still error, please set --http_fetch_timeout more bigger
        LOG(ERROR) << "download error: location url: " << location_url
                   << ", response code: " << http_client.response_code()
                   << ", curl code: " << http_client.curl_code();
        return false;
      }
    }
    if (http_client.response_code() != 200) {
      LOG(ERROR) << "url: " << url << ", code: " << http_client.response_code();
      return false;
    }
  }
  const std::string& model_data = http_client.ResponseBody();
  if (model_data.empty()) {
    LOG(ERROR) << "download model error: " << url
               << ", response body empty";
    return false;
  }

  model_download_mutex_.Lock();
  string engine_path = model_save_dir_ + engine_id + ".quant.one";
  bool success = mobvoi::File::WriteStringToFile(model_data, engine_path);
  if (success) {
    LOG(INFO) << "model has been saved success: " << engine_path;
    MutexLock lock(&model_update_mutex_);
    auto it = model_update_map_.find(engine_id);
    if (it == model_update_map_.end()) {
      ModelInfo info;
      info.is_update = true;
      model_update_map_.insert(
          std::pair<std::string, ModelInfo>(engine_id, info));
    } else {
      it->second.is_update = true;
    }
  } else {
    LOG(ERROR) << "model saved failure: " << engine_path;
  }
  model_download_mutex_.Unlock();
  return success;
}

void ModelManager::Run() {
  while (!exit_flag_) {
    model_download_mutex_.Lock();
    auto it = model_download_list_.begin();
    if (it == model_download_list_.end()) {
      model_download_mutex_.Unlock();
      ::usleep(100 * 1000);
      continue;
    }
    std::string model_id = *it;
    model_download_list_.erase(it);
    model_download_mutex_.Unlock();
    LoadModelFromRemote(model_id);
  }
}

std::shared_ptr<engine::Engine> ModelManager::GetEngine(
    const std::string& engine_id) {
  if (engine_id.empty()) return nullptr;
  std::shared_ptr<engine::Engine> engine = nullptr;
  auto engine_cache = Singleton<server::TtsCache>::get();
  mutex_.Lock();
  if (engine_cache->HasEngine(engine_id)) {
    if (engine_cache->GetEngine(engine_id, &engine)) {
      mutex_.Unlock();
      return engine;
    }
  }
  mutex_.Unlock();

  // check if local model exists
  std::string engine_path = model_save_dir_ + engine_id + ".quant.one";
  model_download_mutex_.Lock();
  if (!File::Exists(engine_path)) {
    LOG(INFO) << "model file not found, download now: " << engine_path;
    model_download_list_.push_back(engine_id);
    model_download_mutex_.Unlock();
    return nullptr;
  }
  model_download_mutex_.Unlock();

  absl::Time create_start_time = absl::Now();
  try {
    std::shared_ptr<engine::Engine> new_engine(
        static_cast<engine::Engine*>(
            new engine::tacotron::ONEEngine(
                tts::LanguageType::kMandarin,
                engine_path,
                0.95,
                1)));
    engine_cache->PutInEngine(engine_id, new_engine);
    int64_t create_time =
        absl::ToInt64Milliseconds(absl::Now() - create_start_time);
    LOG(INFO) << "engine create time: " << create_time;
    return new_engine;
  } catch (std::exception& e) {
    LOG(ERROR) << "model is incorrect: " << e.what();
    return nullptr;
  }
}

bool ModelManager::IsModelUpdate(const std::string& model_id) {
  if (model_id.empty()) return false;
  MutexLock lock(&model_update_mutex_);
  auto it = model_update_map_.find(model_id);
  if (it == model_update_map_.end()) return false;
  return it->second.is_update;
}

void ModelManager::ClearModelUpdate(const std::string& model_id) {
  if (model_id.empty()) return;
  MutexLock lock(&model_update_mutex_);
  auto it = model_update_map_.find(model_id);
  if (it == model_update_map_.end()) return;
  it->second.is_update = false;
}

std::string ModelManager::ReplaceString(
    const std::string& str,
    const std::string& str_src,
    const std::string& str_dst) {
  std::string::size_type pos = 0;
  std::string::size_type len_src = str_src.size();
  std::string::size_type len_dst = str_dst.size();

  std::string result = str;
  pos = result.find(str_src, pos);
  while (pos != std::string::npos) {
    result.replace(pos, len_src, str_dst);
    pos = result.find(str_src, pos + len_dst);
  }
  return result;
}

}  // namespace mobvoi
