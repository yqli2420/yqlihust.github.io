// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com

#ifndef TTS_SERVER_GRPC_GRPC_SYNTH_SERVICE_H_
#define TTS_SERVER_GRPC_GRPC_SYNTH_SERVICE_H_

#include "grpc++/grpc++.h"

#include "mobvoi/base/mutex.h"
#include "tts/server/grpc/proto/synth.grpc.pb.h"
#include "tts/synthesizer/synthesizer.h"

namespace mobvoi {

using grpc::ServerContext;
using grpc::ServerReaderWriter;
using grpc::ServerWriter;
using grpc::Status;

using com::mobvoi::ai_commerce::tts::v1::Synthesizer;
using com::mobvoi::ai_commerce::tts::v1::SynthesizeRequest;
using com::mobvoi::ai_commerce::tts::v1::SynthesizeResponse;

class GrpcSynthService : public Synthesizer::Service {
 public:
  GrpcSynthService();
  virtual ~GrpcSynthService();

 public:
  Status synthesize(
      ServerContext* context,
      const SynthesizeRequest* request,
      ServerWriter<SynthesizeResponse>* writer) override;

  void SetSynthRequestHttp(bool synth_request_http = true);
  void SetDefaultSynthServerUrl(const std::string& synth_server_url);
  void SetAudioFrameSize(int frame_size);
  void SetSynthesizer(tts::Synthesizer* synthesizer);
  void SetDebugFlag(bool debug_flag);

 private:
  std::string synth_server_url_;
  int audio_frame_size_;
  bool synth_request_http_;
  bool debug_flag_;
  tts::Synthesizer* synthesizer_;
};

}  // namespace mobvoi

#endif  // TTS_SERVER_GRPC_GRPC_SYNTH_SERVICE_H_
