// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com

#include <string>
#include <list>

#include "mobvoi/base/at_exit.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/log.h"
#include "tts/server/grpc/model_manager.h"

int main(int argc, char** argv) {
  base::AtExitManager at_exit;
  mobvoi::ParseCommandLineFlags(&argc, &argv, false, "");
  google::InitGoogleLogging(argv[0]);

  std::string model_id = "03fe1ce8-d2b8-4d2e-a1a7-0c72294ad63e";
  bool success = mobvoi::ModelManager::GetInstance()
      ->LoadModelFromRemote(model_id);
}
