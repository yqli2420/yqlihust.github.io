// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com

#ifndef TTS_SERVER_GRPC_GRPC_SYNTH_CLIENT_H_
#define TTS_SERVER_GRPC_GRPC_SYNTH_CLIENT_H_

#include <list>
#include <string>

#include "absl/time/time.h"
#include "grpc++/grpc++.h"

#include "mobvoi/base/thread.h"
#include "tts/server/grpc/proto/synth.grpc.pb.h"

namespace mobvoi {

using grpc::ClientContext;
using grpc::ClientReaderWriter;
using grpc::ClientReader;
using grpc::Status;

using com::mobvoi::ai_commerce::tts::v1::Synthesizer;
using com::mobvoi::ai_commerce::tts::v1::SynthesizeRequest;
using com::mobvoi::ai_commerce::tts::v1::SynthesizeResponse;

class GrpcSynthClient {
 public:
  explicit GrpcSynthClient(const std::string& server);
  virtual ~GrpcSynthClient();

 public:
  void StreamingSynthsize(const std::string& text);
  void SetAudioFrameSize(int frame_size);
  int64_t GetAudioResultLength();
  int64_t GetFirstAudioReceivedTime();
  int64_t GetTotalAudioReceivedTime();
  bool IsSuccess();
  void SetSpeaker(const std::string& speaker);
  void SetChannelId(const std::string& channel_id);

 private:
  std::unique_ptr<Synthesizer::Stub> stub_;
  shared_ptr<grpc::ClientReaderWriter<SynthesizeRequest, SynthesizeResponse> >
      client_stream_;
  int audio_frame_size_;
  int64_t audio_result_length_;
  int64_t first_audio_received_time_;
  int64_t total_audio_received_time_;
  bool success_;
  std::string speaker_;
  std::string channel_id_;
};

}  // namespace mobvoi

#endif  // TTS_SERVER_GRPC_GRPC_SYNTH_CLIENT_H_
