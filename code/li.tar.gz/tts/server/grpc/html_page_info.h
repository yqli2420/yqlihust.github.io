// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com

#ifndef TTS_SERVER_GRPC_HTML_PAGE_INFO_H_
#define TTS_SERVER_GRPC_HTML_PAGE_INFO_H_

#include <string>

namespace mobvoi {

class HtmlPageInfo {
 public:
  HtmlPageInfo();
  virtual ~HtmlPageInfo();

 private:
  std::string page_name_;
  std::string page_path_;
  std::string page_content_;

 public:
  const std::string& GetPageName();
  const std::string& GetPagePath();
  const std::string& GetPageContent();
  bool LoadHtmlPageFromFile(const std::string& file_path);
};

}  // namespace mobvoi

#endif  // TTS_SERVER_GRPC_HTML_PAGE_INFO_H_
