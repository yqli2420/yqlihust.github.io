// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com

#ifndef TTS_SERVER_GRPC_TTS_SYNTH_PROCESSOR_H_
#define TTS_SERVER_GRPC_TTS_SYNTH_PROCESSOR_H_

#include <list>
#include <string>

#include "mobvoi/base/thread.h"
#include "mobvoi/matrix/kaldi-matrix.h"
#include "tts/server/grpc/tts_synth_event.h"

#include "tts/synthesizer/synthesizer.h"
#include "tts/util/ssml/tts_ssml_entity.h"

namespace mobvoi {

using kaldi::BaseFloat;
using kaldi::Vector;
using kaldi::VectorBase;
using kaldi::Matrix;
using kaldi::SubMatrix;

class TtsSynthInterface {
 public:
  TtsSynthInterface() {}
  virtual ~TtsSynthInterface() {}

  virtual void OnSynthesisPartial(TtsSsmlEntity* ssml_entity, bool success) = 0;
};

class TtsSynthProcessor : public mobvoi::Thread {
 public:
  TtsSynthProcessor();
  virtual ~TtsSynthProcessor();

 public:
  bool ProcessSynthesize(std::list<TtsSsmlEntity>* tts_ssml_entity_list,
                         bool async = false);

  static std::string CreateWavHeader(const std::string& src, int channel_number,
                                     int sample_rate);

  std::string AdjustWavSpeed(const std::string& audio_data, double speed,
                             int channel_number);

  std::string AdjustWavVolume(const std::string& audio_data, double volume,
                              int channel_number);

  void SetSynthesisServerUrl(const std::string& url);
  void SetSynthesisInterface(TtsSynthInterface* synthesis_interface);
  void SetSynthesisSpeakerInfoFile(const std::string& file_path);
  void SetSynthesisRequestHttp(bool synth_request_http = true);
  void SetSynthesizer(tts::Synthesizer* synthesizer);
  void SetSynthesisSampleRate(int sample_rate);
  void SetChannelId(const std::string& channel_id);
  void SetSynthesisRequestParameter(
      const std::map<std::string, std::string>& param);

 private:
  virtual void Run();
  bool Synthesize(std::list<TtsSsmlEntity>* tts_ssml_entity_list,
                  bool async = false);
  bool Synthesize(TtsSsmlEntity* ssml_entity);

 private:
  std::string synthesis_result_;
  std::string synthesis_server_url_;
  std::string synthesis_speaker_info_file_;
  std::string channel_id_;
  int sample_rate_;
  bool synth_request_http_;
  std::list<TtsSsmlEntity>* tts_ssml_entity_list_;
  TtsSynthInterface* synthesis_interface_;
  tts::Synthesizer* synthesizer_;
  std::map<std::string, std::string> request_parameter_;

  TtsSynthEvent synth_event_;
};
}  // namespace mobvoi

#endif  // TTS_SERVER_GRPC_TTS_SYNTH_PROCESSOR_H_
