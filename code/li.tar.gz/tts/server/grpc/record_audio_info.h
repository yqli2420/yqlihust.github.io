// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com

#ifndef TTS_SERVER_GRPC_RECORD_AUDIO_INFO_H_
#define TTS_SERVER_GRPC_RECORD_AUDIO_INFO_H_

#include <string>

namespace mobvoi {

enum RecordAudioFormat {
  RECORD_AUDIO_UNKNOWN = 0,
  RECORD_AUDIO_WAV = 1,
  RECORD_AUDIO_PCM = 2,
  RECORD_DUIDO_MP3 = 3,
};

class RecordAudioInfo {
 public:
  RecordAudioInfo();
  virtual ~RecordAudioInfo();

 private:
  std::string audio_name_;
  std::string audio_path_;
  std::string audio_data_;
  std::string audio_text_;
  int audio_header_length_;
  int sample_rate_;

 public:
  const std::string& GetAudioName();
  const std::string& GetAudioPath();
  const std::string& GetAudioData();
  const std::string& GetAudioText();
  int GetAudioHeaderLength();
  int GetSampleRate();

  void SetAudioText(const std::string& audio_text);
  bool LoadAudioFromFile(const std::string& file_path);
  bool LoadAudioFromWeb(const std::string& audio_url);

  int GetHeaderLength(const std::string& audio_data);
};

}  // namespace mobvoi

#endif  // TTS_SERVER_GRPC_RECORD_AUDIO_INFO_H_
