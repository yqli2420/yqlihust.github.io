// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com

#include <string>
#include <list>

#include "mobvoi/base/file.h"
#include "mobvoi/base/log.h"
#include "third_party/gtest/gtest.h"
#include "tts/util/encoder/sampling_rate_converter.h"

namespace mobvoi {

TEST(Resample, AudioResampleTest) {
  std::string audio_content = "";
  if (!mobvoi::File::ReadFileToString(
      "tts/server/grpc/testdata/1.wav", &audio_content)) {
    LOG(ERROR) << "read audio file error!";
    return;
  }
  int num_samp = audio_content.length() / 2;
  const char* buffer = audio_content.c_str();
  std::vector<int16> sample_points(num_samp);
  for (int i = 0; i < num_samp; i++) {
    const int16* s = reinterpret_cast<const int16*>(buffer + i * 2);
    sample_points[i] = *s;
  }
  std::vector<int16> resample_points;
  SamplingRateConverter converter;
  converter.ConvertSamplingRate(
      sample_points, 8000, 6500, &resample_points);
  int num_resamp = resample_points.size();
  std::string result(num_resamp * 2, '\0');
  for (int i = 0; i < num_resamp; ++i) {
    int16 s = resample_points[i];
    const char* ch = reinterpret_cast<const char*>(&s);
    result[i * 2] = *ch;
    result[i * 2 + 1] = *(ch + 1);
  }
  LOG(INFO) << "sample size: " << sample_points.size();
  LOG(INFO) << "resample size: " << resample_points.size();
}
}  // namespace mobvoi
