// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com

#include "tts/server/grpc/http_synth_service.h"

#include <list>
#include <vector>

#include "mobvoi/audio_util/audio_logger.h"
#include "mobvoi/base/base64.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/time.h"
#include "mobvoi/license/license_validator.h"
#include "third_party/jsoncpp/json.h"
#include "tts/server/grpc/model_manager.h"
#include "tts/server/grpc/tts_resource_manager.h"
#include "tts/server/grpc/tts_synth_processor.h"
#include "tts/server/server_util.h"
#include "tts/util/encoder/encoder.h"
#include "tts/util/encoder/sampling_rate_converter.h"
#include "tts/util/ssml/tts_ssml_entity.h"
#include "tts/util/ssml/tts_ssml_processor.h"

DEFINE_int32(default_sample_rate, 8000, "default sample rate");

namespace mobvoi {

HttpSynthService::HttpSynthService()
    : home_page_file_("index.html"),
      debug_flag_(true),
      synth_request_http_(true),
      synthesizer_(nullptr) {
  home_error_page_file_ =
      "<!DOCTYPE html>\n"
      "<html>\n"
      "  <head>\n"
      "    <meta charset=\"UTF-8\" />\n"
      "    <title>出门问问</title>\n"
      "  </head>\n"
      "  <body>\n"
      "    <h1 align=\"center\">404 Not Found</h1>\n"
      "    <hr align=\"center\" width=\"1000%\"/>\n"
      "    <h5 align=\"center\">mobvoi</h5>\n"
      "  </body>\n"
      "</html>";
}

HttpSynthService::~HttpSynthService() {}

bool HttpSynthService::Synthesize(util::HttpRequest* request,
                                  util::HttpResponse* response) {
  LOG(INFO) << "receive request synthesis";
  absl::Time synth_start_time = absl::Now();
  std::map<std::string, std::string> params;
  if (request->HttpMethod() == util::HttpMethodType_kGet) {
    request->GetQueryParams(&params);
  } else if (request->HttpMethod() == util::HttpMethodType_kPost) {
    request->GetPostParams(&params);
  } else {
    LOG(ERROR) << "method not supported : " << request->HttpMethod();
    return false;
  }

  std::map<std::string, std::string>::iterator it;
  if ((it = params.find("text")) == params.end()) {
    LOG(ERROR) << "param [text] not set!";
    return false;
  }

  std::string text = params["text"];
  std::list<TtsSsmlEntity> tts_text_info_list;
  TtsSsmlProcessor ssml_processor;
  if ((it = params.find("speed")) != params.end()) {
    ssml_processor.SetRequestSpeed(it->second);
    LOG(INFO) << "receive request speed: " << it->second;
  }
  if ((it = params.find("mandarin_speaker")) != params.end()) {
    ssml_processor.SetRequestSpeaker(it->second);
    LOG(INFO) << "receive request speaker: " << it->second;
  }
  if ((it = params.find("speaker")) != params.end()) {
    ssml_processor.SetRequestSpeaker(it->second);
    LOG(INFO) << "receive request speaker: " << it->second;
  }
  if (!ssml_processor.Analyze(text, &tts_text_info_list)) {
    LOG(ERROR) << "ssml analysis error";
    return false;
  }
  std::string audio_type = "wav";
  if ((it = params.find("audio_type")) != params.end()) {
    audio_type = it->second;
  } else if ((it = params.find("type")) != params.end()) {
    audio_type = it->second;
  }

  int sample_rate = FLAGS_default_sample_rate;
  if ((it = params.find("rate")) != params.end()) {
    sample_rate = atoi(it->second.c_str());
  } else if (audio_type.find("speex") != std::string::npos) {
    if (audio_type.find("wb") != std::string::npos) {
      sample_rate = 16000;
    } else if (audio_type.find("nb") != std::string::npos) {
      sample_rate = 8000;
    }
  }
  ssml_processor.SetRequestSampleRate(sample_rate);
  LOG(INFO) << "set resample rate: " << sample_rate;

  while (LicenseValidator::GetInstance()->WaitSemaphore(0, 10000) != 0) {
    VLOG_EVERY_N(1, 500) << "http waiting for thread release";
  }
  TtsSynthProcessor synth_processor;
  synth_processor.SetSynthesisRequestHttp(synth_request_http_);
  synth_processor.SetSynthesisServerUrl(synth_server_url_);
  synth_processor.SetSynthesisSpeakerInfoFile(synth_speaker_info_file_);
  synth_processor.SetSynthesizer(synthesizer_);
  synth_processor.SetSynthesisSampleRate(sample_rate);
  synth_processor.SetSynthesisRequestParameter(params);
  synth_processor.ProcessSynthesize(&tts_text_info_list, true);
  synth_processor.Join();
  int audio_data_length = 0;
  for (auto& tts_text_info : tts_text_info_list) {
    audio_data_length += tts_text_info.GetAudioLength();
  }
  std::string res_str;
  LOG(INFO) << "audio data length: " << audio_data_length;
  int index = 0;
  for (auto& tts_text_info : tts_text_info_list) {
    res_str += tts_text_info.GetAudioData();
    index += tts_text_info.GetAudioLength();
    LOG(INFO) << "length: " << tts_text_info.GetAudioLength()
              << " index: " << index;
  }
  LOG(INFO) << "total length: " << res_str.length();

  std::string wav_header = "";
  if (audio_type.compare("wav") == 0) {
    wav_header = synth_processor.CreateWavHeader(res_str, 1, sample_rate);
  }
  if (audio_type.compare("wav") == 0 || audio_type.compare("pcm") == 0) {
    if ((it = params.find("encode")) != params.end()) {
      if (it->second.compare("base64") == 0) {
        LOG(INFO) << "encode audio data with base64";
        std::string audio_data;
        base::Base64Encode(wav_header + res_str, &audio_data);
        response->AppendHeader("Content-Type", "audio/wav");
        response->AppendBuffer(audio_data);
      }
    } else {
      response->AppendHeader("Content-Type", "audio/wav");
      response->AppendBuffer(wav_header + res_str);
    }
  } else {
    std::string audio_data;
    ConvertWav(res_str, &audio_data, sample_rate, audio_type);
    response->AppendBuffer(audio_data);
  }
  absl::Time synth_end_time = absl::Now();
  if (debug_flag_) {
    absl::TimeZone loc = absl::LocalTimeZone();
    std::string file_name =
        absl::FormatTime("%Y%m%dT%H%M%E9S", absl::Now(), loc);
    std::stringstream wav_file_name;
    wav_file_name << "wav" << file_name << "_" << sample_rate << "HZ.wav";
    AudioMessageInfo audio_message;
    audio_message.audio_data_ = res_str;
    audio_message.audio_channel_number_ = 1;
    audio_message.recog_start_time_ = synth_start_time;
    audio_message.recog_end_time_ = synth_end_time;
    audio_message.audio_file_name_ = wav_file_name.str();
    audio_message.audio_save_path_remote_ = ssml_processor.GetAudioSaveUrl();
    audio_message.audio_source_ = "tts_grpc";
    audio_message.audio_sample_rate_ = sample_rate;
    AudioLogger::GetInstance()->SaveStreamingToWav(&audio_message);
  }
  LicenseValidator::GetInstance()->PostSemaphore();
  return true;
}

bool HttpSynthService::DownloadModel(util::HttpRequest* request,
                                     util::HttpResponse* response) {
  LOG(INFO) << "receive request download";
  absl::Time download_start_time = absl::Now();
  std::map<std::string, std::string> params;
  if (request->HttpMethod() == util::HttpMethodType_kGet) {
    request->GetQueryParams(&params);
  } else if (request->HttpMethod() == util::HttpMethodType_kPost) {
    request->GetPostParams(&params);
  } else {
    LOG(ERROR) << "method not supported : " << request->HttpMethod();
    return false;
  }

  Json::Value result;
  Json::FastWriter writer;
  std::map<std::string, std::string>::iterator it;
  if ((it = params.find("engine")) == params.end() || it->second.empty()) {
    LOG(ERROR) << "param [engine] not set!";
    result["code"] = -1;
    result["status"] = "failed";
    result["message"] = "param [engine] not set!";
    response->AppendHeader("Content-Type", "application/json;charset=utf8");
    response->AppendBuffer(writer.write(result));
    return false;
  }

  std::string engine_id = it->second;
  // bool success = server::ServerUtil::Download(engine_id);
  bool success = ModelManager::GetInstance()->LoadModelFromRemote(engine_id);
  result["code"] = success ? 200 : -1;
  result["status"] = success ? "ok" : "failed";
  result["message"] = success ? "ok" : "failed";
  response->AppendHeader("Content-Type", "application/json;charset=utf8");
  response->AppendBuffer(writer.write(result));
  return true;
}

void HttpSynthService::ConvertWav(const std::string& src_str,
                                  std::string* dst_str, int sample_rate,
                                  const std::string& audio_type) {
  if (src_str.empty() || dst_str == nullptr || sample_rate <= 0 ||
      audio_type.empty())
    return;
  std::vector<int16> wav_data(src_str.length() / 2, 0);
  const char* audio_data = src_str.c_str();
  for (int i = 0; i < src_str.length() / 2; ++i) {
    const int16* s = reinterpret_cast<const int16*>(audio_data + i * 2);
    wav_data[i] = *s;
  }
  LOG(INFO) << "convert wav to " << audio_type;

  tts::TTSOption tts_option;
  tts_option.set_sampling_frequency(sample_rate);
  tts_option.set_file_format(audio_type);
  tts_option.set_use_robot(false);
  tts_option.set_speed(1.0);
  tts_option.set_volume(1.0);
  tts_option.set_domain("");
  tts_option.set_append_sil(false);
  tts_option.set_only_frontend(false);
  tts_option.set_detail_output(false);
  encoder::PostProcessOption pp_option(
      tts::kDefaultSamplingFrequency, tts_option.sampling_frequency(),
      tts::kNoNormalizeFactor, tts_option.volume(), tts_option.file_format());
  encoder::PostProcess(wav_data, pp_option, dst_str);
}

bool HttpSynthService::GetHomePage(util::HttpRequest* request,
                                   util::HttpResponse* response) {
  if (response == nullptr) return false;
  response->AppendHeader("Content-Type", "text/html; charset=utf-8");
  LOG(INFO) << "Receive request homepage";

  HtmlPageInfo* page_info =
      TtsResourceManager::GetInstance()->GetHtmlPageInfo(home_page_file_);
  if (page_info == nullptr) {
    LOG(ERROR) << "home page not found: " << home_page_file_;
    response->AppendBuffer(home_error_page_file_);
  } else {
    response->AppendBuffer(page_info->GetPageContent());
  }
  return true;
}

void HttpSynthService::SetHomePageFile(const std::string& file_name) {
  this->home_page_file_ = file_name;
  if (!file_name.empty()) {
    std::string home_page_file = file_name;
    if (home_page_file.at(0) != '/') {
      home_page_file = this->html_page_dir_ + home_page_file;
    }
    if (mobvoi::File::ReadFileToStringWithMmap(home_page_file,
                                               &home_page_content_)) {
      LOG(INFO) << "load home page file success: " << home_page_file;
      this->home_page_file_ = home_page_file;
    } else if (mobvoi::File::ReadFileToStringWithMmap(
                   this->html_page_dir_ + "404.html", &home_page_content_)) {
      LOG(INFO) << "home page not found, default set to 404.html";
    } else {
      home_page_content_ = home_error_page_file_;
    }
  }
}

void HttpSynthService::SetDefaultSynthServerUrl(
    const std::string& synth_server_url) {
  synth_server_url_ = synth_server_url;
}

void HttpSynthService::SetSynthRequestHttp(bool synth_request_http) {
  synth_request_http_ = synth_request_http;
}

void HttpSynthService::SetSynthSpeakerInfoFile(const std::string& file_path) {
  synth_speaker_info_file_ = file_path;
}

void HttpSynthService::SetSynthesizer(tts::Synthesizer* synthesizer) {
  this->synthesizer_ = synthesizer;
}

bool HttpSynthService::LoadHtmlPageFromDir(const std::string& html_page_dir) {
  if (html_page_dir.empty()) {
    this->html_page_map_.clear();
    return false;
  }
  if (!File::IsDir(html_page_dir)) {
    LOG(ERROR) << "load html page from dir error: " << html_page_dir;
    return false;
  }

  std::vector<std::string> html_file_list;
  if (!File::GetFilesInDir(html_page_dir, &html_file_list)) {
    LOG(ERROR) << "get files from dir error: " << html_page_dir;
    return false;
  }

  for (const auto& html_file : html_file_list) {
    HtmlPageInfo page_info;
    if (page_info.LoadHtmlPageFromFile(html_file)) {
      this->html_page_map_.insert(
          std::pair<std::string, HtmlPageInfo>(html_file, page_info));
    } else {
      LOG(ERROR) << "load html file error: " << html_file;
    }
  }
  this->html_page_dir_ = html_page_dir;
}

bool HttpSynthService::LoadRecordAudioFromDir(
    const std::string& record_audio_dir) {
  if (record_audio_dir.empty()) {
    this->record_audio_map_.clear();
    return false;
  }
  if (!File::IsDir(record_audio_dir)) {
    LOG(ERROR) << "load record audio from dir error: " << record_audio_dir;
    return false;
  }

  std::vector<std::string> audio_file_list;
  if (!File::GetFilesInDir(record_audio_dir, &audio_file_list)) {
    LOG(ERROR) << "get files from dir error: " << record_audio_dir;
    return false;
  }

  for (const auto& audio_file : audio_file_list) {
    RecordAudioInfo audio_info;
    if (audio_info.LoadAudioFromFile(audio_file)) {
      this->record_audio_map_.insert(
          std::pair<std::string, RecordAudioInfo>(audio_file, audio_info));
    } else {
      LOG(ERROR) << "load record audio file error: " << audio_file;
    }
  }
  this->record_audio_dir_ = record_audio_dir;
}

void HttpSynthService::SetDebugFlag(bool debug_flag) {
  this->debug_flag_ = debug_flag;
}

}  // namespace mobvoi
