// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com

#ifndef TTS_SERVER_GRPC_CALLBACK_HANDLER_H_
#define TTS_SERVER_GRPC_CALLBACK_HANDLER_H_

#include <string>

#include "mobvoi/base/mutex.h"

class CallbackHandler {
 public:
  CallbackHandler();
  ~CallbackHandler();

 public:
  // callback for asr
  static void OnResult(const char* result);
  static void OnSpeechDetected();
  static void OnLocalSilenceDetected();
  static void OnRemoteSilenceDetected();
  static void OnPartialTranscription(const char* result);
  static void OnFinalTranscription(const char* result);
  static void OnKeyword(const char* result);
  static std::string WaitResult(int timeout_ms = 1000 * 10);
  static void Reset();
  static void OnError(int error_code);

  // callback for hotword
  static void OnHotwordDetected(const int frame, const int delay_time);
  static void WaitHotwordDetected(int timeout_ms = 1000 * 10);

 private:
  static std::string result_;
  static mobvoi::Mutex mutex_;
  static mobvoi::Condition cond_;
  static mobvoi::Mutex hotword_wait_mutex_;
  static mobvoi::Condition hotword_wait_cond_;
  static volatile bool in_asr_session_;
};

#endif  // TTS_SERVER_GRPC_CALLBACK_HANDLER_H_
