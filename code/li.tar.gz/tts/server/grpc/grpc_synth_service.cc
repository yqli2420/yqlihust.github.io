// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com

#include "tts/server/grpc/grpc_synth_service.h"

#include "absl/time/clock.h"
#include "absl/time/time.h"

#include "mobvoi/base/log.h"
#include "mobvoi/audio_util/audio_logger.h"
#include "mobvoi/license/license_validator.h"
#include "tts/server/grpc/tts_synth_processor.h"
#include "tts/util/ssml/tts_ssml_entity.h"
#include "tts/util/ssml/tts_ssml_processor.h"

DEFINE_int32(synth_timeout_ms, 5000, "grpc service host");

namespace mobvoi {

using grpc::StatusCode;

GrpcSynthService::GrpcSynthService()
  : audio_frame_size_(160),
    synth_request_http_(false),
    debug_flag_(true),
    synthesizer_(nullptr) {}

GrpcSynthService::~GrpcSynthService() {}

Status GrpcSynthService::synthesize(
    ServerContext* context,
    const SynthesizeRequest* request,
    ServerWriter<SynthesizeResponse>* writer) {
  absl::Time synth_start_time = absl::Now();
  std::string channel_id = request->channel_id();
  std::string synth_text = request->text();
  int frame_size = request->frame_size();
  int sample_rate = request->sample_rate();
  if (sample_rate <= 0) {
    sample_rate = 8000;
  }

  LOG(INFO) << "receive new request: "
            << ", channel id: " << channel_id
            << ", text: " << synth_text
            << ", frame size: " << frame_size;

  if (synth_text.empty()) {
    return Status(StatusCode::INVALID_ARGUMENT, "synth text empty error");
  }
  if (frame_size <= 0) {
    LOG(INFO) << "frame size not set: " << frame_size;
    frame_size = audio_frame_size_;
  }

  std::map<std::string, std::string> params;
  params.insert(std::pair<std::string, std::string>("text", synth_text));
  params.insert(std::pair<std::string, std::string>("speaker", ""));
  params.insert(std::pair<std::string, std::string>("audio_type", "pcm"));
  params.insert(std::pair<std::string, std::string>("rate", "1.0"));

  while (LicenseValidator::GetInstance()->WaitSemaphore(0, 10000) != 0) {
    if (context->IsCancelled()) {
      LOG(INFO) << "client is cancelled!";
      return Status(StatusCode::CANCELLED, "client cancelled");
    }
    VLOG_EVERY_N(1, 500) << "grpc waiting for thread release";
  }
  std::list<TtsSsmlEntity> tts_ssml_entity_list;
  TtsSsmlProcessor ssml_processor;
  if (!ssml_processor.Analyze(synth_text, &tts_ssml_entity_list)) {
    LOG(ERROR) << "ssml analysis error";
    LicenseValidator::GetInstance()->PostSemaphore();
    return Status(StatusCode::INVALID_ARGUMENT, "ssml format error");
  }

  TtsSynthProcessor synth_processor;
  synth_processor.SetSynthesisRequestHttp(synth_request_http_);
  synth_processor.SetSynthesisServerUrl(synth_server_url_);
  synth_processor.SetSynthesisSampleRate(sample_rate);
  synth_processor.SetSynthesisRequestParameter(params);
  synth_processor.SetSynthesizer(synthesizer_);
  synth_processor.SetChannelId(channel_id);
  synth_processor.ProcessSynthesize(&tts_ssml_entity_list, true);
  // send data to client
  std::string last_send_data = "";
  std::stringstream audio_data_send;
  int timeout = 0;
  int index = 1;
  int total_send_len = 0;
  LOG(INFO) << "begin send audio: channel id: " << channel_id;
  for (auto& tts_ssml_entity : tts_ssml_entity_list) {
    VLOG(2) << "begin send audio data: [ "
            << index << "/" << tts_ssml_entity_list.size()
            << " ], len: "
            << tts_ssml_entity.GetAudioLength();
    bool first_audio_send = false;
    while (!tts_ssml_entity.IsAudioOutputFinished()) {
      int last_send_len = last_send_data.length();
      int len = last_send_len < frame_size
          ? (frame_size - last_send_len) : last_send_len;
      const std::string& data = tts_ssml_entity.GetOutputAudioData(len);
      if (last_send_len + data.length() < frame_size) {
        last_send_data += data;
        absl::SleepFor(absl::Milliseconds(1));
        timeout += 1;
        if (timeout >= FLAGS_synth_timeout_ms) {
          LOG(ERROR) << "get synthesis audio timeout!!!"
                     << " audio length: " << tts_ssml_entity.GetAudioLength()
                     << ", audio index: "
                     << tts_ssml_entity.GetAudioOutputIndex();
          break;
        } else {
          continue;
        }
      } else {
        last_send_data += data;
        timeout = 0;
      }

      if (!last_send_data.empty()) {
        timeout = 0;
        SynthesizeResponse response;
        response.set_content(last_send_data);
        writer->Write(response);
        total_send_len += last_send_data.length();
        if (debug_flag_) {
          audio_data_send << last_send_data;
        }
        last_send_data = "";
        if (!first_audio_send) {
          VLOG(1) << "first audio send finish: channel id: " << channel_id;
          first_audio_send = true;
        }
        VLOG(2) << "send request audio: len: "
                << data.length();
      }
    }
    VLOG(1) << "end send audio data: [ "
            << index << "/" << tts_ssml_entity_list.size()
            << " ], len: "
            << tts_ssml_entity.GetAudioLength();
    ++index;
  }
  synth_processor.Join();
  LOG(INFO) << "end send audio data to client, total: "
            << total_send_len;

  absl::Time synth_end_time = absl::Now();
  if (debug_flag_) {
    absl::TimeZone loc = absl::LocalTimeZone();
    std::string file_name = absl::FormatTime(
        "%Y%m%dT%H%M%E9S", absl::Now(), loc);
    std::stringstream wav_file_name;
    wav_file_name << "wav" << file_name
                  << "_" << sample_rate
                  << "HZ.wav";
    AudioMessageInfo audio_message;
    audio_message.audio_data_ = audio_data_send.str();
    audio_message.audio_channel_number_ = 1;
    audio_message.recog_start_time_ = synth_start_time;
    audio_message.recog_end_time_ = synth_end_time;
    audio_message.audio_file_name_ = wav_file_name.str();
    audio_message.audio_save_path_remote_ = ssml_processor.GetAudioSaveUrl();
    audio_message.audio_source_ = "tts_grpc";
    audio_message.audio_sample_rate_ = sample_rate;
    AudioLogger::GetInstance()->SaveStreamingToWav(&audio_message);
  }
  LicenseValidator::GetInstance()->PostSemaphore();
  return Status::OK;
}

void GrpcSynthService::SetSynthRequestHttp(bool synth_request_http) {
  synth_request_http_ = synth_request_http;
}

void GrpcSynthService::SetDefaultSynthServerUrl(
    const std::string& synth_server_url) {
  this->synth_server_url_ = synth_server_url;
}

void GrpcSynthService::SetAudioFrameSize(int frame_size) {
  if (frame_size > 0) {
    audio_frame_size_ = frame_size;
  } else {
    LOG(ERROR) << "frame size set error: " << frame_size;
  }
}

void GrpcSynthService::SetSynthesizer(tts::Synthesizer* synthesizer) {
  this->synthesizer_ = synthesizer;
}

void GrpcSynthService::SetDebugFlag(bool debug_flag) {
  this->debug_flag_ = debug_flag;
}

}  // namespace mobvoi
