// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: fllin@mobvoi.com (Fenglv Lin)

#include <signal.h>
#include <cstdio>

#include "mobvoi/base/at_exit.h"
#include "mobvoi/base/callback.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/singleton.h"
#include "mobvoi/base/time.h"
#include "mobvoi/license/license_validator.h"
#include "mobvoi/util/net/http_server/http_server.h"
#include "tts/server/adaptation_service_handler.h"
#include "tts/server/streaming_service_handler.h"
#include "tts/synthesizer/interface/synthesizer_interface.h"
#include "tts/synthesizer/synthesizer.h"
#include "tts/server/kibana/kibana_write_thread.h"
#include "tts/server/tts_log.h"

DEFINE_int32(listen_port, 10012, "");
DEFINE_int32(thread_num, 10, "");
DEFINE_string(speaker_info_file, "external/config/config_file/speakers.json",
              "speaker info json file");
DECLARE_bool(use_adaptation);

using std::placeholders::_1;
using std::placeholders::_2;

int main(int argc, char **argv) {
  base::AtExitManager at_exit;
  google::ParseCommandLineFlags(&argc, &argv, false);
  google::InitGoogleLogging(argv[0]);

  bool use_license = false;
#ifdef USE_LICENSE
  use_license = true;
  mobvoi::LicenseValidator::GetInstance()->StartValidate(FLAGS_license);
#endif

  mobvoi::ConcurrentQueue<KibanaData> kibana_queue;
  mobvoi::ConcurrentQueue<KibanaData> log_queue;
  server::KinabaWriteThread write_thread(&kibana_queue);
  write_thread.Start();
  std::thread write_log_thread(SaveLogToMysql, &log_queue);
  auto synthesizer = std::static_pointer_cast<tts::SynthesizerInterface>(
      std::make_shared<tts::Synthesizer>(FLAGS_speaker_info_file));

  util::HttpServer http_server(FLAGS_listen_port, FLAGS_thread_num);
  // adaptation synthesis server
  server::AdaptationServerHandler adaptation_tts_server(
      synthesizer);
  auto synthesize_callback =
      std::bind(&server::AdaptationServerHandler::Synthesize,
                &adaptation_tts_server, _1, _2);
  unique_ptr<util::HttpHandler> synthesize_handler;
  synthesize_handler.reset(new util::DefaultHttpHandler(synthesize_callback));
  http_server.RegisterHttpHandler("/api/synthesis", synthesize_handler.get());

  auto notify_callback =
      std::bind(&server::AdaptationServerHandler::NotifyDownload,
                &adaptation_tts_server, _1, _2);
  unique_ptr<util::HttpHandler> notify_handler;
  notify_handler.reset(new util::DefaultHttpHandler(notify_callback));
  http_server.RegisterHttpHandler("/api/notify", notify_handler.get());

  // streaming synthesis server
  server::StreamingHttpHandler streaming_tts_handler(
      nullptr, use_license, synthesizer, &kibana_queue,
      &log_queue, FLAGS_use_adaptation);
  http_server.RegisterChunkedHttpHandler("/api/streaming",
                                         &streaming_tts_handler);
  // status server
  string status_server;
  status_server = "tts_adaptation_server";
  util::StatusHttpHandler status(status_server, NULL);
  http_server.RegisterHttpHandler("/status", &status);

  http_server.Serv();
  write_thread.Join();
  write_log_thread.join();
  return 0;
}
