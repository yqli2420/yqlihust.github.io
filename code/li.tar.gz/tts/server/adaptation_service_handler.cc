// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: fllin@mobvoi.com (Fenglv Lin)

#include "tts/server/adaptation_service_handler.h"

#include "mobvoi/base/flags.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/time.h"
#include "mobvoi/base/singleton.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/util/net/email/email_client.h"
#include "mobvoi/util/net/http_client/http_client.h"
#include "tts/server/server_util.h"
#include "tts/server/cache_handler.h"
#include "tts/synthesizer/engine/engine.h"
#include "tts/synthesizer/engine/tacotron/one_engine.h"
#include "tts/synthesizer/synthesizer.h"
#include "tts/util/tts_util/util.h"

DECLARE_string(save_adaptation_model_dir);
DEFINE_string(personalized_default_speaker, "cissy",
              "Default speaker for adapt.");

namespace server {

DEFINE_int32(adap_taco_thread_num, 1, "the number of taco's thread");
DEFINE_string(receivers, "tts@mobvoi.com", "Email receiver list.");

AdaptationServerHandler::AdaptationServerHandler(
    std::shared_ptr<tts::SynthesizerInterface> synthesizer)
    : tts_(synthesizer) {
}

bool AdaptationServerHandler::NotifyDownload(util::HttpRequest* request,
                                             util::HttpResponse* response) {
  Json::Value result;
  result["status"] = "ok";
  map<string, string> params;
  ServerUtil::ParseRequestParams(request, &params);
  LOG(INFO) << "Update speaker " << params["engine"] << " model";
  if (!ServerUtil::Download(params["engine"])) {
    LOG(ERROR) << "Downlad engine: " << params["engine"] << "failed!";
    result["status"] = "failed";
    return false;
  }
  response->AppendBuffer(writer_.write(result));
  return true;
}

bool AdaptationServerHandler::SendModelWarningEmail(const string& model_id) {
  util::EmailClient email_client;
  email_client.SetSubject("TTS个性化模型异常");
  email_client.SetReceiverList(FLAGS_receivers);
  string message = StringPrintf("model id: %s", model_id.c_str());
  email_client.SetMessage(message);
  return email_client.Send();
}

bool AdaptationServerHandler::Synthesize(util::HttpRequest* request,
                                         util::HttpResponse* response) {
  // Get params
  map<string, string> params;
  ServerUtil::ParseRequestParams(request, &params);
  if (params.find("engine") == params.end() || params["engine"] == "") {
    LOG(ERROR) << "params engine not exist or is null.";
    return false;
  }
  tts::TTSOption tts_option;
  // Set params
  if (!ServerUtil::SetAllParams(params, kTypeBlock, &tts_option, response)) {
    return true;
  }
  tts_option.set_speaker(FLAGS_personalized_default_speaker);
  bool force_update = false;
  if (params.find("force_update") != params.end() &&
      params["force_update"] == "true") {
    force_update = true;
  }
  int begin = mobvoi::GetTimeInMs();
  auto engine_cache = Singleton<server::TtsCache>::get();
  string engine_path = FLAGS_save_adaptation_model_dir +
      params["engine"] + ".quant.one";
  std::shared_ptr<engine::Engine> engine = nullptr;
  if (!force_update && engine_cache->HasEngine(params["engine"])) {
      engine_cache->GetEngine(params["engine"], &engine);
  } else {
    if (force_update || !mobvoi::File::Exists(engine_path)) {
      if (!ServerUtil::Download(params["engine"])) {
        LOG(ERROR) << "Downlad engine: " << params["engine"] << "failed!";
        if (!SendModelWarningEmail(params["engine"])) {
          LOG(ERROR) << "Send email failed, model id: " << params["engine"];
        }
        return false;
      }
    }
    // load engine
    try {
      std::shared_ptr<engine::Engine> new_engine(static_cast<engine::Engine*>(
          new engine::tacotron::ONEEngine(
          tts::LanguageType::kMandarin,
          engine_path,
          tts::kDefaultEngineSpeed,
          FLAGS_adap_taco_thread_num)));
      engine_cache->PutInEngine(params["engine"], new_engine);
      engine = new_engine;
    } catch(std::exception& e) {
      LOG(ERROR) << "model is incorrect." << e.what();
      if (!SendModelWarningEmail(params["engine"])) {
        LOG(ERROR) << "Send email failed, model id: " << params["engine"];
      }
    }
  }
  string text = params["text"];
  ServerUtil::AppendHeadSilence(params, &text);
  string data_res;
  tts_->Synthesize(text, tts_option, &data_res, engine);
  response->AppendBuffer(data_res);
  int use_time = mobvoi::GetTimeInMs() - begin;
  LOG(INFO) << "used time (Ms):" << use_time;

  return true;
}
}  // namespace server
