// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: yongqiangli@mobvoi.com (Yongqiang Li)

#include "mobvoi/base/at_exit.h"
#include "mobvoi/base/log.h"
#include "mobvoi/util/redis/redis_util.h"

DEFINE_bool(clean_all_data, false, "clean all data in redis");
DEFINE_string(prefix_cache_key, "billy", "prefix of all cache key in redis");
DEFINE_string(redis_config, "external/config/web_server/server/redis.conf",
              "redis config");

int main(int argc, char **argv) {
  base::AtExitManager at_exit;
  google::ParseCommandLineFlags(&argc, &argv, false);
  google::InitGoogleLogging(argv[0]);

  string pattern;
  if (!FLAGS_clean_all_data) {
    pattern += FLAGS_prefix_cache_key;
  }
  pattern += "*";
  util::RedisUtil redis_util(FLAGS_redis_config);
  if (!redis_util.DelKeysByPattern(pattern)) {
    LOG(WARNING) << "Failed to del keys by pattern : " << pattern;
    return -1;
  }
  LOG(INFO) << "The datas are deleted successfully with pattern: " << pattern;

  return 0;
}
