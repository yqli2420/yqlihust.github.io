// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: yongqiangli@mobvoi.com (yongqiang li)

#include "tts/server/bgm_server.h"

#include "mobvoi/base/log.h"
#include "mobvoi/base/time.h"
#include "tts/util/tts_util/util.h"

namespace server {

BgmServerHandler::BgmServerHandler(
    mobvoi::ConcurrentQueue<KibanaData>* _data_queue,
    mobvoi::ConcurrentQueue<KibanaData>* _log_queue)
    : data_queue_(_data_queue), log_queue_(_log_queue) {
  logger_ = Singleton<AsyncLogger>::get();
}

BgmServerHandler::~BgmServerHandler() {}

bool BgmServerHandler::FetchAudio(util::HttpRequest* request,
                                  util::HttpResponse* response) const {
  // Get params
  map<string, string> params;
  ServerUtil::ParseRequestParams(request, &params);

  LOG(INFO) << "Request synthesis request params:"
            << ServerUtil::GetRequestParams(params);
  string bgm_id = params["audio_id"];
  int begin = mobvoi::GetTimeInMs();
  AudioVolume audio_volume;
  if (ServerUtil::GetAudioVolume(bgm_id, &audio_volume)) {
    Json::Value bgm_info;
    bgm_info["avg_vol"] = std::to_string(audio_volume.avg_vol);
    bgm_info["p95_vol"] = std::to_string(audio_volume.p95_vol);
    response->AppendBuffer(bgm_info.toStyledString());
  } else {
    response->AppendBuffer("Fetch audio params error");
  }
  int end = mobvoi::GetTimeInMs();
  int used_time = end - begin;
  LOG(INFO) << "used time (Ms):" << used_time << "fetch bgm volume " << bgm_id;
  ServerUtil::SaveLog(params, used_time, "", kTypeBlock, logger_, log_queue_);
  return true;
}

}  // namespace server
