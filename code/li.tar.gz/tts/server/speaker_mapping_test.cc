// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/server/speaker_mapping.h"

#include "mobvoi/base/at_exit.h"
#include "mobvoi/base/flags.h"
#include "third_party/gtest/gtest.h"

DECLARE_string(speaker_mapping);

namespace server {

TEST(SpeakerMappingTest, LoadSpeakerMapping) {
  base::AtExitManager at_exit;
  FLAGS_speaker_mapping = "tts/server/testdata/speaker_mapping";
  auto mapping = Singleton<SpeakerMapping>::get();

  string map_speaker;
  EXPECT_TRUE(mapping->MapSpeaker("hello world", "cissy", &map_speaker));
  EXPECT_EQ("cissy_gru", map_speaker);

  EXPECT_FALSE(mapping->MapSpeaker("hello world", "billy", &map_speaker));
  EXPECT_FALSE(mapping->MapSpeaker("hello_world", "cissy", &map_speaker));
}

}  // namespace server
