// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "mobvoi/base/at_exit.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/file/proto_util.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/base/time.h"
#include "mobvoi/util/mysql/mysql_util.h"
#include "third_party/jsoncpp/json.h"

DEFINE_string(tts_log_dir, "/data/search/speech/tts/log/tts_log",
              "dir to find tts log files");
DEFINE_string(tts_log_backup_dir, "/data/search/speech/tts/log/tts_log_backup",
              "dir to save processed log files");
DEFINE_string(tmp_log_filename, "tts.log",
              "tmp log file, which should be skiped");
DEFINE_string(mysql_server_conf,
              "external/config/web_server/server/log_db.conf", "");

bool ImportTtsLog(const string& logfile) {
  // {"language":"unknown","product":"ticwatch",
  // "text":"南宁今天中雨，23到26度","time":1440935928,"voice":"female"}
  // TODO(shunping) : Read it line by line if log file is too large.
  file::SimpleLineReader reader(logfile);
  vector<string> lines;
  reader.ReadLines(&lines);
  // Create mysql connection.
  Json::Reader json_reader;
  for (size_t i = 0; i < lines.size(); ++i) {
    // Insert into mysql
    Json::Value doc;
    json_reader.parse(lines[i], doc);
    VLOG(1) << doc.toStyledString();

    string language;
    if (!doc["language"].isNull()) {
      language = doc["language"].asString();
    }
    string product;
    if (!doc["product"].isNull()) {
      product = doc["product"].asString();
    }
    string voice;
    if (!doc["voice"].isNull()) {
      voice = doc["voice"].asString();
    }
    string net_type;
    if (!doc["net_type"].isNull()) {
      net_type = doc["net_type"].asString();
    }
    string device_id;
    if (!doc["device_id"].isNull()) {
      device_id = doc["device_id"].asString();
    }
    string platform;
    if (!doc["platform"].isNull()) {
      platform = doc["platform"].asString();
    }
    string text;
    if (!doc["text"].isNull()) {
      text = doc["text"].asString();
    }
    int32 used_time_ms = 0;
    if (!doc["used_time_ms"].isNull()) {
      used_time_ms = doc["used_time_ms"].asInt();
    }
    uint32 time = 0;
    if (!doc["time"].isNull()) {
      time = doc["time"].asUInt();
    }
    if (text.empty() || time == 0) {
      LOG(WARNING) << "Bad log , drop it:" << lines[i];
      continue;
    }

    string command = StringPrintf(
        "INSERT INTO posts"
        " (time, product, net_type, device_id, platform, voice, language, "
        "text, used_time_ms) VALUES"  // NOLINT
        " (\"%s\", \"%s\", \"%s\", \"%s\", \"%s\", \"%s\", \"%s\", \"%s\", "
        "%d)",  // NOLINT
        mobvoi::GetDetailTime(mobvoi::Time::FromTimeT(time)).c_str(),
        product.c_str(), net_type.c_str(), device_id.c_str(),
        platform.c_str(), voice.c_str(), language.c_str(), text.c_str(),
        used_time_ms);
    LOG(INFO) << "Execute mysql command:" << command;
    util::RunMysqlCommand(FLAGS_mysql_server_conf, command);
  }
  return true;
}

void GetLogFiles(vector<string>* files) {
  vector<string> vec;
  mobvoi::File::GetFilesInDir(FLAGS_tts_log_dir, &vec);
  for (size_t i = 0; i < vec.size(); ++i) {
    if (mobvoi::File::BaseName(vec[i]) == FLAGS_tmp_log_filename) {
      continue;
    }
    files->push_back(vec[i]);
  }
}

int main(int argc, char** argv) {
  base::AtExitManager at_exit;
  google::ParseCommandLineFlags(&argc, &argv, false);
  google::InitGoogleLogging(argv[0]);

  while (true) {
    // Get log file list
    vector<string> files;
    GetLogFiles(&files);
    if (files.empty()) {
      LOG(INFO) << "No log left, sleep...";
      sleep(60);
      continue;
    }

    for (size_t i = 0; i < files.size(); ++i) {
      LOG(INFO) << "Begin to import log file:" << files[i];
      ImportTtsLog(files[i]);
      LOG(INFO) << "Import log file done:" << files[i];
      // Move log to backup dir then delete log files.
      string dest_path = mobvoi::File::JoinPath(
          FLAGS_tts_log_backup_dir, mobvoi::File::BaseName(files[i]));
      LOG(INFO) << "Move file to backup dir:" << dest_path;
      CHECK(mobvoi::File::Rename(files[i], dest_path))
          << "Failed to move file from :" << files[i] << " to :" << dest_path;
      mobvoi::File::Delete(files[i]);
    }
  }
  return 0;
}
