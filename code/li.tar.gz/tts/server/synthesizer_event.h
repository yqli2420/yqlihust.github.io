// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: fllin@mobvoi.com (Fenglv Lin)

#ifndef TTS_SERVER_SYNTHESIZER_EVENT_H_
#define TTS_SERVER_SYNTHESIZER_EVENT_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/concurrent_queue.h"
#include "tts/synthesizer/interface/synthesizer_event_interface.h"

namespace server {
class SynthesizerEvent : public tts::SynthesizerEventInterface {
 public:
  SynthesizerEvent(std::shared_ptr<mobvoi::ConcurrentQueue<string>> data_queue,
                   std::shared_ptr<std::vector<string>> duration);
  virtual ~SynthesizerEvent();

  void OnStart() override;
  bool OnSynthesizeData(const std::string& data) override;
  bool GetChunkDuration(const std::string& duration) override;
  void OnFinish() override;
  string GetResult() override;

 private:
  std::shared_ptr<mobvoi::ConcurrentQueue<string>> data_queue_;
  std::shared_ptr<std::vector<string>> duration_;
  string data_res_;
};

}  // namespace server

#endif  // TTS_SERVER_SYNTHESIZER_EVENT_H_
