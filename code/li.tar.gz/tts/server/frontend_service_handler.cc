// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaoqin.feng@mobvoi.com

#include "tts/server/frontend_service_handler.h"

#include "mobvoi/base/log.h"
#include "mobvoi/base/singleton.h"
#include "mobvoi/base/time.h"
#include "third_party/googleurl/url_util.h"
#include "third_party/xml2/libxml/parser.h"
#include "tts/synthesizer/synthesizer.h"

namespace server {
using std::thread;
static const int kRequestTimeOut = 500;

DEFINE_int32(frontend_process_thread_num, 32,
             "number of thread for concurrent frontend synthesize.");

FrontendServerHandler::FrontendServerHandler(
    tts::SynthesizerInterface* synthesizer, bool use_license)
    : use_license_(use_license) {
  tts_ = synthesizer;
  logger_ = Singleton<AsyncLogger>::get();
  url_util::Initialize();
  // init this for multithread
  xmlInitParser();
}

FrontendServerHandler::~FrontendServerHandler() { xmlCleanupParser(); }

void FrontendServerHandler::BatchSynthesize(
    const tts::TTSOption& tts_option,
    mobvoi::ConcurrentQueue<std::pair<int, string>>* input_queue,
    mobvoi::ConcurrentQueue<std::pair<int, Json::Value>>* output_queue) const {
  while (!input_queue->Empty()) {
    std::pair<int, string> text_item;
    input_queue->Pop(text_item);
    Json::Value data_res;
    tts_->FrontendSynthesize(text_item.second, tts_option, &data_res);
    output_queue->Push(std::make_pair(text_item.first, data_res));
  }
}
void FrontendServerHandler::PostProcess(
    vector<int> paragraph_sizes,
    mobvoi::ConcurrentQueue<std::pair<int, Json::Value>>* output_queue,
    Json::Value* frontend_data) const {
  vector<std::pair<int, Json::Value>> vec;
  while (!output_queue->Empty()) {
    std::pair<int, Json::Value> temp;
    output_queue->Pop(temp);
    vec.emplace_back(temp);
  }
  sort(vec.begin(), vec.end(),
       [](const std::pair<int, Json::Value>& l,
          const std::pair<int, Json::Value>& r) { return l.first < r.first; });
  size_t out_index = 0;
  for (auto& p_size : paragraph_sizes) {
    Json::Value paragraph_data(Json::arrayValue);
    for (size_t i = 0; i < p_size; ++i) {
      paragraph_data.append(vec[out_index++].second);
    }
    frontend_data->append(paragraph_data);
  }
}

void FrontendServerHandler::ProcessInput(
    const vector<vector<string>>& parse_texts, int* word_num,
    vector<int>* paragraph_sizes,
    mobvoi::ConcurrentQueue<pair<int, string>>* input_queue) const {
  int queue_index = 0;
  for (auto paragraph : parse_texts) {
    paragraph_sizes->emplace_back(paragraph.size());
    for (auto sentence : paragraph) {
      int temp_word_num = 0;
      ServerUtil::GetTextLen(sentence, &temp_word_num);
      *word_num += temp_word_num;
      input_queue->Push(std::make_pair(queue_index++, sentence));
    }
  }
}

bool FrontendServerHandler::ConcurrentSynthesize(util::HttpRequest* request,
                                                 util::HttpResponse* response) {
  ServerUtil::AcquireLicense(use_license_);
  // Get params
  map<string, string> params;
  ServerUtil::ParseRequestParams(request, &params);
  // Set params
  tts::TTSOption tts_option;
  if (!ServerUtil::SetAllParams(params, kTypeBlock, &tts_option, response)) {
    ServerUtil::ReleaseLicense(use_license_);
    return true;
  }
  // Get synthesis data, (json / text)
  string text_str = params["text"];
  string text_type = ServerUtil::GetRequestTextTypeParam(params);
  vector<vector<string>> parse_texts;
  ServerUtil::RequestInputParser(text_str, text_type, &parse_texts);
  int begin = mobvoi::GetTimeInMs();
  mobvoi::ConcurrentQueue<std::pair<int, string>> input_queue;
  mobvoi::ConcurrentQueue<std::pair<int, Json::Value>> output_queue;
  vector<int> paragraph_sizes;
  int word_num = 0;
  ProcessInput(parse_texts, &word_num, &paragraph_sizes, &input_queue);
  int sentence_number = input_queue.Size();
  LOG(INFO) << "Frontend Synthesize sentence number: " << sentence_number;
  int thread_num = sentence_number > FLAGS_frontend_process_thread_num
                       ? FLAGS_frontend_process_thread_num
                       : sentence_number;
  vector<thread*> threads;

  for (int i = 0; i < thread_num; ++i) {
    thread* thd = new thread(&FrontendServerHandler::BatchSynthesize, this,
                             tts_option, &input_queue, &output_queue);
    threads.emplace_back(thd);
  }

  for (int i = 0; i < thread_num; ++i) threads[i]->join();

  for (int i = 0; i < thread_num; ++i) {
    if (threads[i] != nullptr) {
      delete threads[i];
      threads[i] = nullptr;
    }
  }
  threads.clear();
  LOG(INFO) << "Frontend Synthesize sentence done size: "
            << output_queue.Size();
  // PostProcess
  Json::Value frontend_data(Json::arrayValue);
  PostProcess(paragraph_sizes, &output_queue, &frontend_data);
  if (text_type == kInputTypeText) {
    size_t start = 0;
    frontend_data = frontend_data[start];
  }
  response->AppendBuffer(writer_.write(frontend_data));
  // Summary
  int use_time = mobvoi::GetTimeInMs() - begin;
  LOG(INFO) << "used time (Ms):" << use_time << ", word : " << word_num;
  ServerUtil::SaveSyncLog(params, use_time, logger_);
  ServerUtil::ReleaseLicense(use_license_);
  return true;
}

bool FrontendServerHandler::Synthesize(util::HttpRequest* request,
                                       util::HttpResponse* response) {
  ServerUtil::AcquireLicense(use_license_);
  // Get params
  map<string, string> params;
  ServerUtil::ParseRequestParams(request, &params);
  // Set params
  tts::TTSOption tts_option;
  if (!ServerUtil::SetAllParams(params, kTypeBlock, &tts_option, response)) {
    ServerUtil::ReleaseLicense(use_license_);
    return true;
  }
  // Get synthesis data, (json / text)
  string text_str = params["text"];
  string text_type = ServerUtil::GetRequestTextTypeParam(params);
  vector<vector<string>> parse_texts;
  ServerUtil::RequestInputParser(text_str, text_type, &parse_texts);
  int begin = mobvoi::GetTimeInMs();
  int word_num = 0;
  int sentence_size = 0;
  Json::Value frontend_data(Json::arrayValue);
  for (auto& paragraph : parse_texts) {
    sentence_size += paragraph.size();
    Json::Value paragraph_data(Json::arrayValue);
    for (auto text : paragraph) {
      Json::Value data_res;
      int temp_word_num = 0;
      ServerUtil::GetTextLen(text, &temp_word_num);
      word_num += temp_word_num;
      tts_->FrontendSynthesize(text, tts_option, &data_res);
      paragraph_data.append(data_res);
    }
    frontend_data.append(paragraph_data);
  }
  if (text_type == kInputTypeText) {
    size_t start = 0;
    frontend_data = frontend_data[start];
  }
  response->AppendBuffer(writer_.write(frontend_data));
  // Summary
  int end = mobvoi::GetTimeInMs();
  int used_time = end - begin;
  LOG(INFO) << "Frontend analysis : used time (Ms):" << used_time
            << ", word : " << word_num << ", sentence size: " << sentence_size;
  ServerUtil::SaveSyncLog(params, used_time, logger_);

  ServerUtil::ReleaseLicense(use_license_);
  return true;
}

bool FrontendServerHandler::GetFrontendDictSource(
    util::HttpRequest* request, util::HttpResponse* response) {
  Json::Value frontend_dict_data;
  ServerUtil::FrontendDictJsonWrapper(&frontend_dict_data);
  response->AppendBuffer(writer_.write(frontend_dict_data));
}

}  // namespace server
