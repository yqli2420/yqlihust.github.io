// Copyright 2014 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/server/block_service_handler.h"

#include <algorithm>
#include <regex>   // NOLINT
#include <thread>  // NOLINT
#include <vector>

#include "mobvoi/base/concurrent_queue.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/singleton.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/base/time.h"
#include "third_party/googleurl/url_util.h"
#include "third_party/perftools/profiler.h"
#include "third_party/xml2/libxml/parser.h"
#include "third_party/xml2/libxml/xpath.h"
#include "tts/server/proto/tts_log.pb.h"
#include "tts/server/speaker_mapping.h"
#include "tts/synthesizer/synthesizer.h"
#include "tts/util/encoder/encoder.h"
#include "tts/util/soundtouch/sound_stretch.h"
#include "tts/util/tts_util/tts_data.h"
#include "tts/util/tts_util/util.h"
#include "tts/util/tts_util/wave_util.h"

DEFINE_string(record_file, "external/config/web_server/record_wav/record.json",
              "record wav trigger text");
DEFINE_int32(process_thread_num, 16,
             "number of thread for concurrent synthesize.");
DEFINE_int32(split_sentence_length, 20, "length of sentenct.");
DEFINE_bool(enable_cpu_profile, false, "use for enable cpu profile");
DEFINE_string(cpu_save_path, "external/tts.cpu",
              "Path for store cpu profile file.");

#ifndef FOR_PORTABLE
DECLARE_int32(flac_compression_level);
#endif

namespace server {
using std::thread;
static const int kRequestTimeOut = 500;

static const int kBufferSize = 10240;

BlockServerHandler::BlockServerHandler(
    std::shared_ptr<tts::SynthesizerInterface> synthesizer, bool use_license,
    mobvoi::ConcurrentQueue<KibanaData>* data_queue,
    mobvoi::ConcurrentQueue<KibanaData>* log_queue)
    : use_license_(use_license),
      data_queue_(data_queue),
      log_queue_(log_queue) {
  tts_ = synthesizer;
  record_wav_.reset(new RecordWav(FLAGS_record_file));
  logger_ = Singleton<AsyncLogger>::get();
  url_util::Initialize();
  // init this for multithread
  xmlInitParser();
}

BlockServerHandler::~BlockServerHandler() { xmlCleanupParser(); }

#ifndef USE_GRPC
bool BlockServerHandler::ConcurrentSynthesize(
    util::HttpRequest* request, util::HttpResponse* response) const {
  ServerUtil::AcquireLicense(use_license_);
  if (FLAGS_enable_cpu_profile) {
    ProfilerStart(FLAGS_cpu_save_path.c_str());
  }
  // Get params
  map<string, string> params;
  ServerUtil::ParseRequestParams(request, &params);
  tts::TTSOption tts_option;
  // Set params
  if (!ServerUtil::SetAllParams(params, kTypeBlock, &tts_option, response)) {
    ServerUtil::ReleaseLicense(use_license_);
    return true;
  }
  string text = params["text"];
  ServerUtil::GetBgmParam(text, &tts_option);
  ServerUtil::GetPitch(text, &tts_option);
  int begin = mobvoi::GetTimeInMs();
  mobvoi::ConcurrentQueue<ConcurrentSent> input_queue;
  mobvoi::ConcurrentQueue<std::pair<int, vector<int16>>> output_queue;
  vector<std::pair<int, std::pair<string, AudioParams>>> insert_audio;
  SplitSpeakerTexts(text, tts_option.speaker(), tts_option.speed(),
                    &insert_audio, &input_queue);
  int sentence_number = input_queue.Size();
  LOG(INFO) << "Concurrent synthesize sentence number: " << sentence_number;
  int thread_num = sentence_number > FLAGS_process_thread_num
                       ? FLAGS_process_thread_num
                       : sentence_number;
  vector<thread*> threads;
  for (int i = 0; i < thread_num; ++i) {
    thread* thd = new thread(&BlockServerHandler::BatchSynthesize, this,
                             tts_option, &input_queue, &output_queue);
    threads.emplace_back(thd);
  }

  for (int i = 0; i < thread_num; ++i) threads[i]->join();

  for (int i = 0; i < thread_num; ++i) {
    if (threads[i] != nullptr) {
      delete threads[i];
      threads[i] = nullptr;
    }
  }
  threads.clear();
  LOG(INFO) << "Concurrent synthesize sentence done size: "
            << output_queue.Size();
  // postprocess
  string data_res;
  Postprocess(tts_option, insert_audio, &output_queue, &data_res);
  response->AppendBuffer(data_res);
  // Summary
  int use_time = mobvoi::GetTimeInMs() - begin;
  LOG(INFO) << "used time (Ms):" << use_time
            << ", word : " << tts::SsmlParser::Instance().CountWordNum(text);
  ServerUtil::ReleaseLicense(use_license_);
  if (FLAGS_enable_cpu_profile) {
    ProfilerStop();
  }
  return true;
}

void BlockServerHandler::Postprocess(
    const tts::TTSOption& tts_option,
    const vector<std::pair<int, std::pair<string, AudioParams>>>& insert_audio,
    mobvoi::ConcurrentQueue<std::pair<int, vector<int16>>>* output_queue,
    std::string* data_res) const {
  vector<std::pair<int, vector<int16>>> vec;
  while (!output_queue->Empty()) {
    std::pair<int, vector<int16>> text_item;
    output_queue->Pop(text_item);
    vec.emplace_back(text_item);
  }
  sort(vec.begin(), vec.end(), [](const std::pair<int, vector<int16>>& l,
                                  const std::pair<int, vector<int16>>& r) {
    return l.first < r.first;
  });
  vector<int16> pcm_result;
  int beg = 0, end = 0;
  map<int, int> bgm_section;
  if (insert_audio.size()) {
    int j = 0;
    for (int i = 0; i < vec.size(); ++i) {
      while (j < insert_audio.size() && insert_audio[j].first < 0) {
        if (insert_audio[j].second.first == tts::kSsmlAudioName ||
            insert_audio[j].second.first == tts::kSsmlAudioSrc) {
          ServerUtil::GetSpecialAudio(insert_audio[j].second.second, &beg, &end,
                                      &bgm_section, &pcm_result);
        }
        ++j;
      }
      tts::VecFastAppend(vec[i].second, &pcm_result);
      end += vec[i].second.size();
      while (j < insert_audio.size() && i == insert_audio[j].first) {
        if (insert_audio[j].second.first == tts::kSsmlAudioName ||
            insert_audio[j].second.first == tts::kSsmlAudioSrc) {
          ServerUtil::GetSpecialAudio(insert_audio[j].second.second, &beg, &end,
                                      &bgm_section, &pcm_result);
          ++j;
        } else if (insert_audio[j].second.first == tts::kSsmlRefrain) {
          float time = tts::ParseTime(insert_audio[j].second.second.name);
          int skip_num =
              static_cast<int>(time * tts::kDefaultSamplingFrequency);
          bgm_section[beg] = end - skip_num;
          beg = end + skip_num;
          ++j;
        }
      }
    }
    while (j < insert_audio.size()) {
      if (insert_audio[j].second.first == tts::kSsmlAudioName ||
          insert_audio[j].second.first == tts::kSsmlAudioSrc) {
        ServerUtil::GetSpecialAudio(insert_audio[j].second.second, &beg, &end,
                                    &bgm_section, &pcm_result);
      } else if (insert_audio[j].second.first == tts::kSsmlRefrain) {
        float time = tts::ParseTime(insert_audio[j].second.second.name);
        int skip_num = static_cast<int>(time * tts::kDefaultSamplingFrequency);
        bgm_section[beg] = end - skip_num;
        beg = end + skip_num;
      }
      ++j;
    }
    bgm_section[beg] = end;
  } else {
    for (const auto& item : vec) {
      tts::VecFastAppend(item.second, &pcm_result);
      end += item.second.size();
    }
    bgm_section[beg] = end;
  }
  if (tts_option.pitch()) {
    tts::SoundStretch sound_stretch(tts_option.sampling_frequency(), 0,
                                    tts_option.pitch(), 0, true, false, true);
    sound_stretch.Process(&pcm_result);
  }
  vector<int16> bgm_data;
  if (!tts_option.bgm().empty() &&
      ServerUtil::GetBgm(tts_option.bgm(), &bgm_data)) {
    tts::WaveFile::AudioMix(bgm_data, bgm_section, tts_option.volume(),
                            tts_option.bgm_volume(), tts_option.bgm_offset(),
                            &pcm_result);
  }

  encoder::PostProcessOption pp_option(
      tts::kDefaultSamplingFrequency, tts_option.sampling_frequency(),
      tts::kNoNormalizeFactor, tts_option.volume(), tts_option.file_format());
#ifndef FOR_PORTABLE
  if (pp_option.file_format.find("flac") != string::npos) {
    encoder::FlacEncoder encoder;
    FLAC__byte buffer[kBufferSize];
    encoder.Reset(buffer, kBufferSize, tts_option.sampling_frequency(),
                  FLAGS_flac_compression_level);
    encoder::PostProcessFlac(pcm_result, pp_option, &encoder, data_res);
  } else {
    encoder::PostProcess(pcm_result, pp_option, data_res);
  }
#else
  encoder::PostProcess(pcm_result, pp_option, data_res);
#endif
}

void DoPatternSplit(const string& input, const std::regex& regex_pattern,
                    vector<string>* output) {
  const std::sregex_iterator end;
  for (std::sregex_iterator i(input.begin(), input.end(), regex_pattern);
       i != end; ++i) {
    if (i->prefix().length() != 0) {
      if (!output->empty())
        output->back() = i->prefix();
      else
        output->emplace_back(i->prefix());
    } else {
      if (!output->empty()) output->pop_back();
    }
    output->back() += i->str();
    if (i->suffix().length() != 0) output->emplace_back(i->suffix());
  }
  if (output->empty()) output->emplace_back(input);
}

void BlockServerHandler::SplitSpeakerTexts(
    const std::string& text, const string& speaker, double speed,
    vector<std::pair<int, std::pair<string, AudioParams>>>* insert_audio,
    mobvoi::ConcurrentQueue<ConcurrentSent>* input_queue) const {
  vector<tts::SsmlText> ssml_texts;
  tts::SsmlParser::Instance().ParseText(text, tts::kSsmlAudio, &ssml_texts);
  int id = 0;
  for (auto it : ssml_texts) {
    if (it.text.empty()) {
      bool is_id = true;
      auto attr_it = it.tag.attrs.find(tts::kSsmlAudioName);
      if (attr_it == it.tag.attrs.end()) {
        attr_it = it.tag.attrs.find(tts::kSsmlAudioSrc);
        is_id = false;
      }
      if (attr_it != it.tag.attrs.end()) {
        auto attr_volume = it.tag.attrs.find(tts::kSsmlAudioVolume);
        float volume = attr_volume != it.tag.attrs.end()
                           ? atof(attr_volume->second.c_str())
                           : 1.0;
        insert_audio->emplace_back(std::make_pair(
            id == 0 ? -1 : id - 1,
            std::make_pair(attr_it->first,
                           AudioParams(attr_it->second, volume, is_id))));
      }
      attr_it = it.tag.attrs.find(tts::kSsmlRefrain);
      if (attr_it != it.tag.attrs.end()) {
        insert_audio->emplace_back(std::make_pair(
            id == 0 ? -1 : id - 1,
            std::make_pair(attr_it->first,
                           AudioParams(attr_it->second, 1.0, is_id))));
      }
    } else {
      string context = "<speak>" + it.text + "</speak>";
      vector<OptionSent> option_sents;
      ServerUtil::SplitOptionSent(context, &option_sents);
      for (size_t i = 0; i < option_sents.size(); ++i) {
        OptionSent option_sent = option_sents[i];
        string speaker_tmp = speaker;
        double speed_tmp = speed;
        if (option_sent.is_set) {
          if (!option_sent.speaker.empty()) speaker_tmp = option_sent.speaker;
          if (option_sent.speed != 0.0) speed_tmp = option_sent.speed;
        }
        SplitTexts(option_sent.context, speaker_tmp, speed_tmp, &id,
                   input_queue);
      }
    }
  }
}

void BlockServerHandler::SplitTexts(
    const std::string& text, const string& speaker, double speed, int* id,
    mobvoi::ConcurrentQueue<ConcurrentSent>* input_queue) const {
  const string ssml_start = "<speak";
  const string ssml_end = "</speak>";
  const std::regex split_re("；|，|,|\\?|;|\\!|。|！|？");
  if (tts::SsmlParser::Instance().CountWordNum(text) >
      FLAGS_split_sentence_length) {
    vector<string> ssvec;
    DoPatternSplit(text, split_re, &ssvec);
    for (size_t k = 0; k < ssvec.size(); ++k) {
      if (ssvec[k].empty() ||
          !tts::SsmlParser::Instance().CountWordNum(ssvec[k]))
        continue;
      string temp = ssvec[k];
      if (temp.find(ssml_start) != 0) {
        temp = "<speak>" + temp;
      }
      if (temp.find(ssml_end) + ssml_end.size() != temp.size()) {
        temp += "</speak>";
      }
      input_queue->Push(ConcurrentSent(*id, temp, speaker, speed));
      ++(*id);
    }
  } else {
    input_queue->Push(ConcurrentSent(*id, text, speaker, speed));
    ++(*id);
  }
  LOG(INFO) << "Synthesize sentence number: " << input_queue->Size();
}

void BlockServerHandler::BatchSynthesize(
    const tts::TTSOption& tts_option,
    mobvoi::ConcurrentQueue<ConcurrentSent>* input_queue,
    mobvoi::ConcurrentQueue<std::pair<int, vector<int16>>>* output_queue)
    const {
  while (!input_queue->Empty()) {
    ConcurrentSent text_item;
    input_queue->Pop(text_item);
    if (text_item.context != "") {
      tts::TTSOption option_tmp = tts_option;
      if (!text_item.speaker.empty()) {
        option_tmp.set_speaker(text_item.speaker);
      }
      if (text_item.speed != 0.0) {
        option_tmp.set_speed(text_item.speed);
      }
      vector<int16> pcm_result;
      tts_->Synthesize(text_item.context, option_tmp, &pcm_result);
      output_queue->Push(std::make_pair(text_item.id, pcm_result));
    }
  }
}
#endif

void BlockServerHandler::SynthesisContext(const string& text,
                                          const tts::TTSOption& tts_option,
                                          string* data_res) const {
  vector<tts::SsmlText> ssml_texts;
  vector<int16> pcm_result;
  string file_format = tts_option.file_format();
  tts::SsmlParser::Instance().ParseText(text, tts::kSsmlAudio, &ssml_texts);
  int beg = 0;
  int end = 0;
  map<int, int> bgm_section;
  for (auto it : ssml_texts) {
    if (it.text.empty()) {
      bool is_id = true;
      auto attr_it = it.tag.attrs.find(tts::kSsmlAudioName);
      if (attr_it == it.tag.attrs.end()) {
        attr_it = it.tag.attrs.find(tts::kSsmlAudioSrc);
        is_id = false;
      }

      if (attr_it != it.tag.attrs.end()) {
        auto attr_volume = it.tag.attrs.find(tts::kSsmlAudioVolume);
        float volume = attr_volume != it.tag.attrs.end()
                           ? atof(attr_volume->second.c_str())
                           : 1.0;
        ServerUtil::GetSpecialAudio(AudioParams(attr_it->second, volume, is_id),
                                    &beg, &end, &bgm_section, &pcm_result);
      }
      attr_it = it.tag.attrs.find(tts::kSsmlRefrain);
      if (attr_it != it.tag.attrs.end()) {
        float time = tts::ParseTime(attr_it->second);
        bgm_section[beg] =
            end - static_cast<int>(time * tts::kDefaultSamplingFrequency);
        beg = end;
      }
    } else {
      string context = "<speak>" + it.text + "</speak>";
      vector<OptionSent> option_sents;
      ServerUtil::SplitOptionSent(context, &option_sents);
      for (size_t i = 0; i < option_sents.size(); ++i) {
        vector<int16> pcm_res_tmp;
        OptionSent option_sent = option_sents[i];
        LOG(INFO) << option_sent.context << " speaker: " << option_sent.speaker;
        tts::TTSOption option_tmp = tts_option;
        if (option_sent.is_set) {
          if (!option_sent.speaker.empty())
            option_tmp.set_speaker(option_sent.speaker);
          if (option_sent.speed != 0.0) option_tmp.set_speed(option_sent.speed);
        }
        tts_->Synthesize(option_sent.context, option_tmp, &pcm_res_tmp);
        tts::VecFastAppend(pcm_res_tmp, &pcm_result);
        end += pcm_res_tmp.size();
      }
    }
  }
  if (tts_option.pitch()) {
    tts::SoundStretch sound_stretch(tts_option.sampling_frequency(), 0,
                                    tts_option.pitch(), 0, true, false, true);
    sound_stretch.Process(&pcm_result);
  }
  bgm_section[beg] = end;
  vector<int16> bgm_data;
  if (!tts_option.bgm().empty() &&
      ServerUtil::GetBgm(tts_option.bgm(), &bgm_data)) {
    tts::WaveFile::AudioMix(bgm_data, bgm_section, tts_option.volume(),
                            tts_option.bgm_volume(), tts_option.bgm_offset(),
                            &pcm_result);
  }

  // TODO(zhengzhang): move into synthesize, reset volume
  encoder::PostProcessOption pp_option(
      tts::kDefaultSamplingFrequency, tts_option.sampling_frequency(),
      tts::kNoNormalizeFactor, tts_option.volume(), file_format);
#ifndef FOR_PORTABLE
  if (pp_option.file_format.find("flac") != string::npos) {
    encoder::FlacEncoder encoder;
    FLAC__byte buffer[kBufferSize];
    encoder.Reset(buffer, kBufferSize, tts_option.sampling_frequency(),
                  FLAGS_flac_compression_level);
    encoder::PostProcessFlac(pcm_result, pp_option, &encoder, data_res);
  } else {
    encoder::PostProcess(pcm_result, pp_option, data_res);
  }
#else
  encoder::PostProcess(pcm_result, pp_option, data_res);
#endif
}

bool BlockServerHandler::Synthesize(util::HttpRequest* request,
                                    util::HttpResponse* response) const {
  ServerUtil::AcquireLicense(use_license_);
  // Get params
  map<string, string> params;
  ServerUtil::ParseRequestParams(request, &params);
  if (ServerUtil::IsRejectOfflineRequest(params)) {
    Json::Value node;
    node["status"] = "404";
    response->AppendJson(node);
    return true;
  }

  tts::TTSOption tts_option;
  // Set params
  if (!ServerUtil::SetAllParams(params, kTypeBlock, &tts_option, response)) {
    ServerUtil::ReleaseLicense(use_license_);
    return true;
  }

  string text = params["text"];
  // for sop 1.0
  if (ServerUtil::IsRejectOfflineRequestSop1(params, tts_option.domain())) {
    response->SetResponseCode(404);
    text = "";
    return true;
  }

  LOG(INFO) << "Request synthesis request params:"
            << ServerUtil::GetRequestParams(params);
  // Get record_wav
  string data_res;
  int word_num = 0;
  int begin = mobvoi::GetTimeInMs();
  if (record_wav_->GetRecordWav(text, tts_option, &data_res)) {
    response->AppendBuffer(data_res);
    ServerUtil::ReleaseLicense(use_license_);
    return true;
  }
  // Input pre-processing
  ServerUtil::DoInputPreprocess(params, &text, &word_num);
  ServerUtil::AppendHeadSilence(params, &text);
  // Get synthesis data
  string cache_key = GenCacheKey(tts_option, text);
  string redis_key = tts_option.speaker() + cache_key;
  auto cache = Singleton<server::TtsCache>::get();
  int use_cache = -1;
  auto it = params.find("redis_cmd");

  if (cache->UseRedis() && cache->GetDataFromRedis(redis_key, &data_res)) {
    if (it != params.end() && it->second == "del") {
      if (cache->RedisDel(redis_key)) {
        LOG(INFO) << "Delete the key in redis: " << redis_key;
      }
    }
    use_cache = 1;
  } else if (cache->UseTtsCache() && word_num <= kMaxCacheLen &&
             cache->CanFetch(cache_key)) {
    cache->GetData(cache_key, &data_res);
    use_cache = 1;
  } else {
    ServerUtil::GetPitch(text, &tts_option);
    ServerUtil::GetBgmParam(text, &tts_option);
    SynthesisContext(text, tts_option, &data_res);
    if (cache->UseRedis() && it != params.end() && it->second == "set") {
      cache->RedisSet(redis_key, data_res);
    } else if (cache->UseTtsCache() && word_num <= kMaxCacheLen) {
      cache->PutInCache(cache_key, data_res);
    }
  }
  response->AppendBuffer(data_res);
  // Summary
  int use_time = mobvoi::GetTimeInMs() - begin;
  LOG(INFO) << "used time (Ms):" << use_time << ", word : " << word_num
            << ", text : " << text;

  ServerUtil::SaveLog(params, use_time, "", kTypeBlock, logger_, log_queue_);
  string product = ServerUtil::GetProductParam(params);
  ServerUtil::WriteToKibana(use_cache, use_time, word_num, kTypeBlock,
                            tts_option.speaker(), product, data_queue_);

  ServerUtil::ReleaseLicense(use_license_);

  return true;
}
}  // namespace server
