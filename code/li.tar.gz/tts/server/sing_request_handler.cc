// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng yang)

#include "tts/server/sing_request_handler.h"

#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/time.h"
#include "mobvoi/util/wave_reader.h"
#include "tts/util/tts_util/wave_util.h"

static const int kSamplingRate = 16000;
static const int kNBit = 16;

namespace sing_synthesizer {

SingHttpServer::SingHttpServer(string res_dir, bool use_mgc) {
  res_dir_ = res_dir;
  use_mgc_ = use_mgc;
  sing_syn_ = new SingingSyntheszer(res_dir, kSamplingRate, use_mgc);
}

SingHttpServer::~SingHttpServer() {
  if (sing_syn_ != NULL) {
    delete sing_syn_;
  }
}

bool SingHttpServer::ErrorReturn(util::HttpResponse* response, int error_code,
                                 const string& desc) const {
  LOG(ERROR) << "error code:" << error_code << ", " << desc;
  Json::Value res;
  res["error_code"] = error_code;
  res["status"] = desc;
  response->AppendJson(res);
  return true;
}

bool SingHttpServer::InternalHandle(const util::HttpRequest* request,
                                    util::HttpResponse* response) const {
  LOG(INFO) << "receive request from host:" << request->RemoteHost()
            << ", port:" << request->RemotePort();

  response->AppendHeader("Content-Type", "audio/wav");

  int sample_rate = StringToInt(request->GetHeader("Sample-Rate"));
  string asr_dur = request->GetHeader("Asr-Align");
  string song_id = request->GetHeader("Song-Id");
  string out_format = request->GetHeader("File-Format");
  string out_file = request->GetHeader("File-Path");
  double bgm_rate, voice_rate, f0_rate;
  string tmp_str = request->GetHeader("Bgm-Rate");

  if (tmp_str == "") {
    bgm_rate = 1.0;
  } else {
    bgm_rate = StringToDouble(tmp_str);
  }
  tmp_str = request->GetHeader("Voice-Rate");
  if (tmp_str == "") {
    voice_rate = 0.3;
  } else {
    voice_rate = StringToDouble(tmp_str);
  }
  tmp_str = request->GetHeader("F0-Rate");
  if (tmp_str == "") {
    f0_rate = 0;
  } else {
    f0_rate = StringToDouble(tmp_str);
  }

  LOG(INFO) << "asr align duratrion: " << asr_dur;
  LOG(INFO) << "song_id: " << song_id;
  LOG(INFO) << "out file format: " << out_format;
  LOG(INFO) << "bgm_rate: " << bgm_rate;
  LOG(INFO) << "voice_rate: " << voice_rate;
  LOG(INFO) << "f0_rate: " << f0_rate;

  int file_sample_rate = 0;
  string audio_data = request->GetRequestData();
  int audio_size = audio_data.size();
  LOG(INFO) << "audio size:" << audio_size;

  string content_length_str = request->GetHeader("Content-Length");
  if (!content_length_str.empty()) {
    LOG(INFO) << "content_length_str:" << content_length_str;
    int content_length = StringToInt(content_length_str);
    if (content_length != audio_size) {
      return ErrorReturn(response, 6, "content_length error");
    }
  }
  int wav_head_len = 44;
  if (audio_size < wav_head_len) {
    return ErrorReturn(response, 4, "wav head less than 44");
  }
  stringstream iss(audio_data);
  kaldi::WaveData wave;
  bool read_ok = wave.Read(iss);
  if (!read_ok) {
    return ErrorReturn(response, 3, "read wav file failed");
  }
  vector<int16> pcm_data;
  file_sample_rate = static_cast<int>(wave.SampFreq());
  pcm_data.reserve(audio_size - wav_head_len);
  if (sample_rate != file_sample_rate) {
    LOG(WARNING) << "Set sample_rate is " << sample_rate
                 << " ,but file sample rate is " << file_sample_rate
                 << " ,use file sample rate";
    sample_rate = file_sample_rate;
  }

  LOG(INFO) << "sample_rate: " << sample_rate;
  for (int i = wav_head_len; i < audio_size; i += sizeof(int16)) {
    pcm_data.push_back(*reinterpret_cast<const int16*>(&audio_data[i]));
  }
  int y_length = 0;
  int wav_length = (audio_size - wav_head_len) / 2;
  sing_syn_->SetPagamsFromFs(sample_rate, use_mgc_);

  unsigned char for_int_number[4];
  double* data = new double[wav_length];
  int quantization_byte = kNBit / 8;
  double zero_line = pow(2.0, 16 - 1);
  double tmp, sign_bias;

  for (int i = 0; i < wav_length; ++i) {
    sign_bias = tmp = 0.0;
    for (int j = 0; j < quantization_byte; j++) {
      for_int_number[j] = reinterpret_cast<const char*>(&pcm_data[i])[j];
    }

    if (for_int_number[quantization_byte - 1] >= 128) {
      sign_bias = pow(2.0, kNBit - 1);
      for_int_number[quantization_byte - 1] =
          for_int_number[quantization_byte - 1] & 0x7F;
    }
    for (int j = quantization_byte - 1; j >= 0; --j)
      tmp = tmp * 256.0 + for_int_number[j];
    data[i] = (tmp - sign_bias) / zero_line;
  }

  double* y =
      sing_syn_->sing_synthesis(data, wav_length, &y_length, asr_dur, "",
                                song_id, f0_rate, bgm_rate, voice_rate);
  string wave_data;
  if (out_format == "wav") {
    world_vocoder::ConvertPcmToWavString(y, y_length, sample_rate, &wave_data);
  } else if (out_format == "mp3") {
    world_vocoder::ConvertPcmToMp3String(y, y_length, sample_rate, &wave_data);
  } else {
    LOG(ERROR) << "error set output file format : << out_format";
  }
  if (out_file != "") {
    mobvoi::File::WriteStringToFileOrDie(wave_data, out_file);
  } else {
    response->AppendBuffer(wave_data);
  }
  delete[] y;
  return true;
}

bool SingHttpServer::Handle(const util::HttpRequest* request,
                            util::HttpResponse* response) const {
  bool result = InternalHandle(request, response);
  return result;
}
}  // namespace sing_synthesizer
