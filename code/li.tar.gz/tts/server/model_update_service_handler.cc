// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: mobvoi@mobvoi.com (mobvoi)

#include "tts/server/model_update_service_handler.h"

#include <map>

#include "mobvoi/base/file/proto_util.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/singleton.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/base/time.h"
#include "mobvoi/util/net/http_client/http_client.h"
#include "third_party/jsoncpp/json.h"
#include "tts/server/server_util.h"
#include "tts/synthesizer/label_generator/mandarin/frontend_manager.h"
#include "tts/synthesizer/label_generator/proto/frontend.pb.h"
#include "tts/util/tts_util/util.h"

DEFINE_int32(model_http_connect_timeout, 10000, "http connect timeout");
DEFINE_int32(model_http_fetch_timeout, 10000, "http fetch timeout");
DEFINE_string(frontend_save_dir, "external/config/front_end/",
              "Dir for save front_end resource");
DEFINE_string(polyphone_language, "man", "language for save polyphone model");
DEFINE_string(polyphone_base_oss_url,
              "http://mobvoi-oss/v1/ufile/mobvoi-speech-private/mobvoi-tts/"
              "frontend/polyphone/polyphone_%s.tar.gz",  // NOLINT
              "Url for store polyphone model.");

namespace server {

bool ModelUpdateServerHandler::Download(const string& oss_url,
                                        const string& save_dir,
                                        string* model_path) {
  util::HttpClient http_client;
  http_client.SetFetchTimeout(FLAGS_model_http_fetch_timeout);
  http_client.SetConnectTimeout(FLAGS_model_http_connect_timeout);
  if (!http_client.FetchUrl(oss_url) || http_client.response_code() != 200) {
    if (http_client.response_code() == 302 ||
        http_client.response_code() == 301) {
      string location_url = http_client.GetLocation();
      http_client.Reset();
      http_client.SetFetchTimeout(FLAGS_model_http_fetch_timeout);
      http_client.SetConnectTimeout(FLAGS_model_http_connect_timeout);
      if (!http_client.FetchUrl(location_url) ||
          http_client.response_code() != 200) {
        LOG(ERROR) << "location_url: " << location_url
                   << ", code: " << http_client.response_code();
        return false;
      }
    }
    if (http_client.response_code() != 200) {
      LOG(ERROR) << "url: " << oss_url
                 << ", code: " << http_client.response_code();
      return false;
    }
  }
  mobvoi::File::CreateDir(save_dir, mobvoi::DEFAULT_FILE_MODE);
  size_t found = oss_url.find_last_of("/");
  string file_name = oss_url.substr(found + 1);
  LOG(INFO) << "download model " << file_name << " success.";
  found = file_name.find_last_of("_");
  string mode_file_name = file_name.substr(0, found);
  *model_path = save_dir + mode_file_name + ".tar.gz";
  mobvoi::File::WriteStringToFileOrDie(http_client.ResponseBody(), *model_path);
  string target_model_path = FLAGS_frontend_save_dir + mode_file_name + "/";
  string cmd = StringPrintf("tar -zxf %s -C %s", model_path->c_str(),
                            target_model_path.c_str());
  if (!tts::RunOsSytemCmd(cmd)) {
    LOG(ERROR) << "unzip " << model_path->c_str() << " error.";
    return false;
  }
  return true;
}

bool ModelUpdateServerHandler::ReloadFrontendModel(
    const string& language, const string& frontend_type) {
  tts::FrontendResource fe_res;
  string resource_file = FLAGS_frontend_save_dir + language + "_frontend.conf";
  CHECK(mobvoi::ReadProtoFromTextFile(resource_file, &fe_res));
  string target_language;
  if (language == tts::kSubLanCan) {
    target_language = tts::kTaiwaneseTypeString;
  } else if (language == tts::kSubLanMan) {
    target_language = tts::kMandarinTypeString;
  } else if (language == tts::kSubLanTw) {
    target_language = tts::kMandarinTypeString;
  } else {
    LOG(ERROR) << " error language :" << language;
    return false;
  }
  if (frontend_type == tts::kFrontendPolyphone) {
    tts::FrontendManager::Instance().UpdatePolyphone(
        target_language, FLAGS_frontend_save_dir + fe_res.polyphone());
  } else {
    LOG(ERROR) << " error frontend_type :" << frontend_type;
    return false;
  }
  return true;
}

string ModelUpdateServerHandler::GetTimeOfDay() {
  mobvoi::Time time = mobvoi::Time::Now();
  mobvoi::Time::Exploded exploded;
  time.LocalExplode(&exploded);
  return StringPrintf("%.4d%.2d%.2d", exploded.year, exploded.month,
                      exploded.day_of_month);
}

bool ModelUpdateServerHandler::UpdateFrontendModel(
    util::HttpRequest* request, util::HttpResponse* response) {
  Json::Value result;
  result["status"] = "ok";
  // Get params
  map<string, string> params;
  ServerUtil::ParseRequestParams(request, &params);
  string time_of_day = GetTimeOfDay();
  string url;
  if (params["frontend_type"] == tts::kFrontendPolyphone) {
    string language = FLAGS_polyphone_language.c_str();
    string update_time = time_of_day;
    if (!params["language"].empty()) language = params["language"].c_str();
    if (!params["update_time"].empty())
      update_time = params["update_time"].c_str();
    url =
        StringPrintf(FLAGS_polyphone_base_oss_url.c_str(), update_time.c_str());
    string model_path;
    if (!Download(url, FLAGS_frontend_save_dir + "model/", &model_path)) {
      LOG(ERROR) << "Download url failed: " << url;
      result["status"] = "failed";
      return false;
    } else {
      ReloadFrontendModel(language, tts::kFrontendPolyphone);
    }
  }
  response->AppendBuffer(result.toStyledString());
  return true;
}

}  // namespace server
