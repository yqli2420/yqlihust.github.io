// Copyright 2016 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)
// Author: chwm@mobvoi.com (Changwei Ma)

#include "tts/server/bing_server/bing_tts_service.h"

#include "mobvoi/base/file.h"
#include "mobvoi/base/md5.h"
#include "mobvoi/base/platform_thread.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/base/time.h"
#include "mobvoi/util/net/email/email_client.h"
#include "mobvoi/util/net/http_client/http_client.h"
#include "mobvoi/util/net/util.h"
#include "mobvoi/util/url/encode/url_encode.h"
#include "tts/server/server_util.h"
#include "tts/util/encoder/encoder.h"
#include "tts/util/encoder/mp3_encoder.h"
#include "tts/util/tts_util/util.h"
#include "tts/util/tts_util/wave_util.h"

DEFINE_string(access_token_config,
              "external/config/web_server/server/access_token_config", "");
DEFINE_int32(tts_cache_size, 10000, "cache number for tts mp3 file.");
DEFINE_int32(tts_fetch_timeout_ms, 10000, "");
DEFINE_int32(http_client_timeout_ms, 5000, "");
DEFINE_int32(max_retry_times, 3, "max retry times for tts fetching.");
DEFINE_int32(token_expire_time, 500000, "expire time of token.");
DEFINE_int32(token_retry_times, 3, "retry times of getting token.");
DEFINE_string(error_mp3, "external/config/web_server/server/error.mp3", "");
DEFINE_string(email_receivers, "spye@mobvoi.com,qiangsun@mobvoi.com",
              "warning email receivers");
DEFINE_string(email_subject, "TTS Serving Error", "warning email subject");
DEFINE_string(email_message, "TTS serving is error, please check log",
              "warning email message");
DEFINE_string(record_file, "external/config/web_server/record_wav/record.json",
              "record wav trigger text");

namespace server {

static const char kTnResourceFile[] =
    "external/config/front_end/tn/eng_tn.conf";

static const char kSpeakUrlPrefix[] =
    "http://api.microsofttranslator.com/V2/Http.svc/Speak";

static string GetCacheKey(const Json::Value& root) {
  return MD5String(root.toStyledString());
}

static bool SendEmailErrorInfo(const string& error_info) {
  util::EmailClient email_client;
  email_client.SetReceiverList(FLAGS_email_receivers);
  email_client.SetSubject(FLAGS_email_subject);
  string host = util::GetLocalHostName();
  string message = FLAGS_email_message;
  message += StringPrintf("\n\nHostname: %s\nAdditional info: %s\n",
                          host.c_str(), error_info.c_str());
  email_client.SetMessage(message);

  if (email_client.Send()) {
    LOG(INFO) << "Send done.";
  } else {
    LOG(ERROR) << "Send failed.";
    return false;
  }
  return true;
}

TtsDataCache::TtsDataCache() : cache_(FLAGS_tts_cache_size) {}

TtsDataCache::~TtsDataCache() {}

void TtsDataCache::PutInCache(const string& key, const string& data) {
  cache_.Put(key, data);
}

bool TtsDataCache::GetData(const string& key, string* data) {
  return cache_.Get(key, data);
}

void TtsDataCache::StartFetch(const string& key) {
  mobvoi::MutexLock lock(&mutex_);
  fetching_keys_.insert(key);
}

bool TtsDataCache::NeedFetch(const string& key) {
  mobvoi::MutexLock lock(&mutex_);
  if (cache_.HasKey(key) || fetching_keys_.find(key) != fetching_keys_.end()) {
    return false;
  } else {
    return true;
  }
}

void TtsDataCache::FetchDone(const string& key) {
  mobvoi::MutexLock lock(&mutex_);
  fetching_keys_.erase(key);
}

FetchTtsResultThread::FetchTtsResultThread(
    mobvoi::ConcurrentQueue<Json::Value>* queue, AccessToken* token)
    : queue_(queue), access_token_(token) {
  cache_ = Singleton<TtsDataCache>::get();
}

FetchTtsResultThread::~FetchTtsResultThread() {}

void FetchTtsResultThread::Run() {
  while (true) {
    // Try to pop request url then fetch result from bing.
    Json::Value node;
    queue_->Pop(node);
    string cache_key = GetCacheKey(node);
    // Skip if it's being fetched or in cache.
    LOG(INFO) << "Pop request:" << node.toStyledString();
    if (!cache_->NeedFetch(cache_key)) {
      LOG(INFO) << "Don't need fetch again:" << node.toStyledString();
      continue;
    }

    cache_->StartFetch(cache_key);

    // Get access token
    LOG(INFO) << "Beg to get access token:";
    string token = GetAccessToken();
    LOG(INFO) << "token:" << token;

    // See
    // https://github.com/phpmasterdotcom/microsoft_translator/blob/master/translation_api_initializer.php
    // Save to cache.
    for (int i = 0; i < FLAGS_max_retry_times; ++i) {
      util::HttpClient http_client;
      http_client.SetFetchTimeout(FLAGS_http_client_timeout_ms);
      http_client.AddHeader("Authorization", token);
      http_client.AddHeader("Content-Type", "audio/mp3");
      string url = StringPrintf(
          "%s?text=%s&language=%s&gender=female"
          "&format=audio/mp3&options=MinSize",
          kSpeakUrlPrefix,
          util::UrlEncodeString(node["text"].asString()).c_str(),
          node["language"].asCString());
      LOG(INFO) << "Fetch url:" << url;
      CHECK(http_client.response_code() != 400)
          << "bing return 400, access_token was expired";
      if (!http_client.FetchUrl(url) || http_client.response_code() != 200) {
        // If token is expired, response code will be 400.
        LOG(ERROR) << "Failed to fetch url:" << url << "token:" << token
                   << ", code:" << http_client.response_code()
                   << ", body:" << http_client.ResponseBody();
        token = GetAccessToken();
        continue;
      } else {
        LOG(INFO) << "Fetch done, save into cache for key:" << cache_key;
        cache_->PutInCache(cache_key, http_client.ResponseBody());
        break;
      }
    }
    cache_->FetchDone(cache_key);
  }
}

string FetchTtsResultThread::GetAccessToken() {
  return access_token_->GetToken();
}

UpdateTokenThread::UpdateTokenThread(AccessToken* token)
    : access_token_(token) {
  string content;
  mobvoi::File::ReadFileToStringWithMmap(FLAGS_access_token_config, &content);
  Json::Reader reader;
  reader.parse(content, config_);
  LOG(INFO) << config_.toStyledString();
}

UpdateTokenThread::~UpdateTokenThread() {}

void UpdateTokenThread::Run() {
  const string kAccessTokenUrl =
      "https://api.cognitive.microsoft.com/sts/v1.0/issueToken";
  while (true) {
    util::HttpClient http_client;
    map<string, string> params;
    params["Subscription-Key"] = config_["Subscription-Key"].asString();
    string url = util::CreateUrl(kAccessTokenUrl, params);
    http_client.SetFetchTimeout(FLAGS_http_client_timeout_ms);
    http_client.SetHttpMethod(util::HttpMethod::kPost);
    if (!http_client.FetchUrl(url) || http_client.response_code() != 200) {
      LOG(ERROR) << "Failed to get token."
                 << ", code:" << http_client.response_code()
                 << ", body:" << http_client.ResponseBody();
      PlatformThread::Sleep(2);
      continue;
    }

    LOG(INFO) << "response:" << http_client.ResponseBody();
    access_token_->SetToken(string("Bearer ") + http_client.ResponseBody());
    PlatformThread::Sleep(FLAGS_token_expire_time);
  }
}

ErrorDetail BingTtsService::error_detail_;

BingTtsService::BingTtsService(mobvoi::ConcurrentQueue<Json::Value>* queue)
    : queue_(queue) {
  cache_ = Singleton<TtsDataCache>::get();
  text_normalizer_.reset(
      new nlp::tn::TextNormalizer(tts::kEnglishTypeString, kTnResourceFile));
  record_wav_.reset(new RecordWav(FLAGS_record_file));
}

BingTtsService::~BingTtsService() {}

void BingTtsService::ProcessPushRequest(const string& language,
                                        const string& text,
                                        util::HttpResponse* response) {
  // Begin to get mp3 from bing.
  Json::Value key;
  key["language"] = language;
  key["text"] = text;
  LOG(INFO) << "Begin to fetch result and cache key:" << key.toStyledString();
  queue_->Push(key);
  Json::Value node;
  node["status"] = "success";
  {
    std::lock_guard<std::mutex> lock(mutex_);
    error_detail_.err_msg = "success";
    error_detail_.err_status = "ok";
  }

  response->SetJsonContentType();
  Json::FastWriter writer;
  response->AppendBuffer(writer.write(node));
}

bool BingTtsService::ProcessGetDataRequest(const string& language,
                                           const string& text,
                                           const tts::TTSOption& tts_option,
                                           const string& source,
                                           util::HttpResponse* response) {
  // Begin to return data for client.
  if (language.empty() || text.empty()) {
    response->AppendHeader("Content-Type", "audio/mp3");
    SendEmailErrorInfo("url parameter is missing.");
    return false;
  }

  Json::Value key;
  key["language"] = language;
  key["text"] = text;
  string cache_key = GetCacheKey(key);
  LOG(INFO) << "Begin to get result for key:" << cache_key;
  // Try to push it again to make sure request has been created.
  queue_->Push(key);
  // Try to get data from cache key. If failed in some time, return false.
  string data;
  int64_t begin_time = mobvoi::GetTimeInMs();

  while (true) {
    if ((mobvoi::GetTimeInMs() - begin_time) >= FLAGS_tts_fetch_timeout_ms) {
      LOG(ERROR) << "Failed to get tts data for key in expected time:"
                 << key.toStyledString();
      response->SetResponseCode(200);
      response->AppendHeader("Content-Type", "audio/mp3");
      SendEmailErrorInfo("failed to get tts data in expected time.");
      {
        std::lock_guard<std::mutex> lock(mutex_);
        error_detail_.err_msg = "error";
        error_detail_.err_status =
            "Failed to get tts data for key in expected time.";
      }
      return false;
    }

    if (cache_->GetData(cache_key, &data)) {
      break;
    } else {
      PlatformThread::Sleep(10);
    }
  }

  {
    std::lock_guard<std::mutex> lock(mutex_);
    error_detail_.err_msg = "success";
    error_detail_.err_status = "ok";
  }

  LOG(INFO) << "Get data done, size:" << data.size();
  ServerUtil::SetJsonContentType("", tts_option.file_format(), response);
  encoder::PostProcessOption pp_option(
      tts::kDefaultSamplingFrequency, tts_option.sampling_frequency(),
      tts::kNoNormalizeFactor, tts_option.volume(), tts_option.file_format());
  // FIXME(xx) : Remove there ugly codes. Hack for Ticpods now.
  if (source == "ticpods") {
    // If source is ticpods, insert silence at head & tail.
    vector<int16> samples;
    int sampling_frequency = 0;
    encoder::DecodeMp3(data, &samples, &sampling_frequency);
    vector<int16> result_samples;
    // insert 1 second silence.
    int head_num = sampling_frequency * 1;
    result_samples.insert(result_samples.end(), head_num, 0);
    // copy data.
    result_samples.insert(result_samples.end(), samples.begin(), samples.end());
    // insert 500ms silence.
    int tail_num = sampling_frequency * 0.5;
    result_samples.insert(result_samples.end(), tail_num, 0);
    string res_data;
    encoder::PostProcess(result_samples, pp_option, &res_data);
    response->AppendBuffer(res_data);
  } else {
    if (tts_option.file_format() == "mp3") {
      response->AppendBuffer(data);
    } else {
      vector<int16> samples;
      int sampling_frequency = 0;
      encoder::DecodeMp3(data, &samples, &sampling_frequency);
      string res_data;
      encoder::PostProcess(samples, pp_option, &res_data);
      response->AppendBuffer(res_data);
    }
  }
  return true;
}

bool BingTtsService::ProcessRecordRequest(const string& language,
                                          const string& data,
                                          util::HttpResponse* response) {
  {
    std::lock_guard<std::mutex> lock(mutex_);
    error_detail_.err_msg = "success";
    error_detail_.err_status = "ok";
  }
  LOG(INFO) << "Load record wav done, size:" << data.size();
  response->AppendHeader("Content-Type", "audio/mp3");
  response->AppendBuffer(data);

  return true;
}

bool BingTtsService::SynthesisHandler(util::HttpRequest* request,
                                      util::HttpResponse* response) {
  map<string, string> params;
  request->GetQueryParams(&params);
  string type = params["type"];
  string source = params["source"];
  string language = params["language"];
  string file_format = params["audio_type"];
  if (file_format.empty()) file_format = "mp3";
  string text = params["text"];
  tts::TTSOption tts_option;
  tts::SetDefaultTTSOption(&tts_option);
  tts_option.set_speaker("cissy");
  tts_option.set_file_format(file_format);
  tts_option.set_domain(kFaq);

  string data;
  if (record_wav_->GetRecordWav(text, tts_option, &data)) {
    ProcessRecordRequest(language, data, response);
    return true;
  }

  vector<tts::SsmlText> ssml_texts;
  tts::SsmlParser::Instance().ParseText(text, &ssml_texts);
  vector<tts::SsmlText> norm_texts;
  if (language == "en-US" || language == "en") {
    string option;
    text_normalizer_->Normalize(ssml_texts, option, &norm_texts);
  }
  // TODO(zhengzhang): add ssml in the future
  text = tts::SsmlParser::Instance().JoinText(norm_texts);
  LOG(INFO) << "normalized english text: " << text;
  int64_t begin_time = mobvoi::GetTimeInMs();
  if (type == "push") {
    ProcessPushRequest(language, text, response);
    int64_t end_time = mobvoi::GetTimeInMs();
    LOG(INFO) << "push used time:" << end_time - begin_time << "Ms";
  } else if (type == "get") {
    if (!ProcessGetDataRequest(language, text, tts_option, source, response)) {
      std::lock_guard<std::mutex> lock(mutex_);
      error_detail_.type = type;
      error_detail_.language = language;
      error_detail_.text = text;
    }
    int64_t end_time = mobvoi::GetTimeInMs();
    LOG(INFO) << "get used time:" << end_time - begin_time << "Ms";
  } else {
    LOG(ERROR) << "Bad type:" << type;
    {
      std::lock_guard<std::mutex> lock(mutex_);
      error_detail_.err_msg = "bad type";
      error_detail_.err_status = "error";
    }

    Json::Value node;
    node["status"] = "error";
    node["reason"] = "bad type";
    response->SetJsonContentType();
    Json::FastWriter writer;
    response->AppendBuffer(writer.write(node));
  }
  return true;
}

bool BingTtsService::StatusHandler(util::HttpRequest* request,
                                   util::HttpResponse* response) {
  Json::Value node;
  {
    std::lock_guard<std::mutex> lock(mutex_);
    node["status"] = error_detail_.err_status;
    node["reason"] = error_detail_.err_msg;
    node["type"] = error_detail_.type;
    node["language"] = error_detail_.language;
    node["text"] = error_detail_.text;
  }
  response->SetJsonContentType();
  Json::FastWriter writer;
  response->AppendBuffer(writer.write(node));
  return true;
}
}  // namespace server
