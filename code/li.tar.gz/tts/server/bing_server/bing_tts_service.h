// Copyright 2016 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_SERVER_BING_SERVER_BING_TTS_SERVICE_H_
#define TTS_SERVER_BING_SERVER_BING_TTS_SERVICE_H_

#include <mutex>  // NOLINT
#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/concurrent_queue.h"
#include "mobvoi/base/singleton.h"
#include "mobvoi/base/thread.h"
#include "mobvoi/util/cache/lru_cache.h"
#include "mobvoi/util/net/http_server/http_handler.h"
#include "mobvoi/util/net/http_server/http_server.h"
#include "third_party/jsoncpp/json.h"
#include "tts/nlp/tn/text_normalizer.h"
#include "tts/server/record_wav/record_wav.h"

namespace server {
struct ErrorDetail {
  string err_mp3;
  string err_msg = "success";
  string err_status = "ok";
  string type;
  string language;
  string text;
};

class AccessToken {
 public:
  AccessToken() {}
  ~AccessToken() {}

  string GetToken() {
    mobvoi::ReadLock readlock(&share_mutex_);
    return token_;
  }

  void SetToken(const string& token) {
    mobvoi::WriteLock writelock(&share_mutex_);
    token_ = token;
  }

 private:
  string token_;
  mobvoi::SharedMutex share_mutex_;
};

class TtsDataCache {
 public:
  virtual ~TtsDataCache();

  void PutInCache(const string& key, const string& data);
  bool GetData(const string& key, string* data);

  void StartFetch(const string& key);
  bool NeedFetch(const string& key);
  void FetchDone(const string& key);

 private:
  mobvoi::Mutex mutex_;
  set<string> fetching_keys_;
  util::LruCache<string, string> cache_;

  TtsDataCache();
  friend struct DefaultSingletonTraits<TtsDataCache>;
  DISALLOW_COPY_AND_ASSIGN(TtsDataCache);
};

class FetchTtsResultThread : public mobvoi::Thread {
 public:
  explicit FetchTtsResultThread(mobvoi::ConcurrentQueue<Json::Value>* queue,
                                AccessToken* token);
  virtual ~FetchTtsResultThread();

  virtual void Run();

 private:
  string GetAccessToken();

  mobvoi::ConcurrentQueue<Json::Value>* queue_;
  AccessToken* access_token_;
  TtsDataCache* cache_;
  DISALLOW_COPY_AND_ASSIGN(FetchTtsResultThread);
};

class UpdateTokenThread : public mobvoi::Thread {
 public:
  explicit UpdateTokenThread(AccessToken* token);
  virtual ~UpdateTokenThread();

  virtual void Run();

 private:
  AccessToken* access_token_;
  Json::Value config_;
  DISALLOW_COPY_AND_ASSIGN(UpdateTokenThread);
};

class BingTtsService {
 public:
  explicit BingTtsService(mobvoi::ConcurrentQueue<Json::Value>* queue);
  ~BingTtsService();

  // This function should be thread-safe.
  bool SynthesisHandler(util::HttpRequest* request,
                        util::HttpResponse* response);

  bool StatusHandler(util::HttpRequest* request, util::HttpResponse* response);

 private:
  void ProcessPushRequest(const string& language, const string& text,
                          util::HttpResponse* response);
  bool ProcessGetDataRequest(const string& language, const string& text,
                             const tts::TTSOption& tts_option,
                             const string& source,
                             util::HttpResponse* response);
  bool ProcessRecordRequest(const string& language, const string& data,
                            util::HttpResponse* response);

  TtsDataCache* cache_;
  static ErrorDetail error_detail_;
  mobvoi::ConcurrentQueue<Json::Value>* queue_;
  unique_ptr<nlp::tn::TextNormalizer> text_normalizer_;
  unique_ptr<RecordWav> record_wav_;
  std::mutex mutex_;
  DISALLOW_COPY_AND_ASSIGN(BingTtsService);
};
}  // namespace server

#endif  // TTS_SERVER_BING_SERVER_BING_TTS_SERVICE_H_
