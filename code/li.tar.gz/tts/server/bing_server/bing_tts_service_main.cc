// Copyright 2016 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/server/bing_server/bing_tts_service.h"
#include "mobvoi/base/log.h"
#include "mobvoi/util/net/http_server/http_server.h"
#include "third_party/gflags/gflags.h"

DEFINE_int32(listen_port, 10012, "");
DEFINE_int32(thread_num, 1, "");
DEFINE_int32(tts_fetch_threads, 10, "threads to fetch tts result from bing.");

using std::placeholders::_1;
using std::placeholders::_2;

int main(int argc, char** argv) {
  google::ParseCommandLineFlags(&argc, &argv, false);
  google::InitGoogleLogging(argv[0]);

  mobvoi::ConcurrentQueue<Json::Value> queue;
  server::AccessToken shared_token;

  server::UpdateTokenThread update_token_thread(&shared_token);
  update_token_thread.Start();

  // Start fetch threads.
  vector<server::FetchTtsResultThread*> threads;
  for (int i = 0; i < FLAGS_tts_fetch_threads; ++i) {
    server::FetchTtsResultThread* thread =
        new server::FetchTtsResultThread(&queue, &shared_token);
    thread->Start();
    threads.push_back(thread);
  }

  util::HttpServer http_server(FLAGS_listen_port, FLAGS_thread_num);

  server::BingTtsService tts_service(&queue);

  auto callback = std::bind(&server::BingTtsService::SynthesisHandler,
                            &tts_service, _1, _2);
  util::DefaultHttpHandler bing_tts_handler(callback);
  http_server.RegisterHttpHandler("/tts", &bing_tts_handler);

  auto status_callback =
      std::bind(&server::BingTtsService::StatusHandler, &tts_service, _1, _2);
  util::DefaultHttpHandler status_handler(status_callback);
  http_server.RegisterHttpHandler("/status", &status_handler);

  http_server.Serv();

  for (auto& thread : threads) {
    thread->Join();
    delete thread;
  }
  update_token_thread.Join();
  return 0;
}
