// Copyright 2017 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/server/server_util.h"

#include "third_party/gtest/gtest.h"

namespace server {

TEST(RestrictTextLen, ssml1) {
  string test = "你好";
  string test_expected = "你好";
  int word_num;
  int word_num_expected = 2;
  ServerUtil::RestrictTextLen(&test, &word_num);

  EXPECT_EQ(test, test_expected);
  EXPECT_EQ(word_num, word_num_expected);
}

}  // namespace server
