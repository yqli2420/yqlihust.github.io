// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: yongqiangli@mobvoi.com (yongqiang li)

#ifndef TTS_SERVER_CONCURRENT_SERVICE_HANDLER_H_
#define TTS_SERVER_CONCURRENT_SERVICE_HANDLER_H_

#include <csignal>
#include <cstdio>
#include <map>
#include <string>
#include <thread>  // NOLINT

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/concurrent_queue.h"
#include "mobvoi/base/mutex.h"
#include "mobvoi/util/net/http_server/data_provider.h"
#include "mobvoi/util/net/http_server/event_loop.h"
#include "mobvoi/util/net/http_server/http_server.h"
#include "third_party/event/include/event2/buffer.h"
#include "third_party/event/include/event2/http.h"
#include "third_party/gflags/gflags.h"
#include "tts/server/cache_handler.h"
#include "tts/synthesizer/interface/synthesizer_interface.h"
#include "tts/util/tts_util/util.h"

#include "tts/server/server_util.h"

namespace server {

class ConcurrentDataProvider : public util::DataProvider {
 public:
  ConcurrentDataProvider(std::shared_ptr<tts::SynthesizerInterface> synthesizer,
                         bool use_license);
  virtual ~ConcurrentDataProvider();

  void Start(util::HttpRequest* http_request,
             util::HttpResponse* response) override;
  bool Next(string* data) override;
  void BatchSynthesize(tts::SynthesizerInterface* tts,
                       mobvoi::ConcurrentQueue<ConcurrentSent>* input_queue);
  void SynthesisThread(const string& request, bool use_license,
                       tts::SynthesizerInterface* tts);

 private:
  std::shared_ptr<vector<vector<int16>>> pcm_res_;
  std::shared_ptr<vector<std::pair<int, server::AudioParams>>> audio_;
  int text_id_;
  int bgm_offset_;
  tts::TTSOption tts_option_;
  std::shared_ptr<tts::SynthesizerInterface> synthesizer_;
  unique_ptr<std::thread> thread_;
  std::map<std::string, std::string> request_params_;
  bool use_license_;
  bool text_is_empty_;
  mutable mobvoi::Mutex mutex_;
  mobvoi::Condition cond_var_;
  DISALLOW_COPY_AND_ASSIGN(ConcurrentDataProvider);
};

class ConcurrentHttpHandler : public util::HttpHandler {
 public:
  ConcurrentHttpHandler(util::Callback callback, bool use_license,
                        std::shared_ptr<tts::SynthesizerInterface> synthesizer);

  virtual ~ConcurrentHttpHandler();

  virtual bool Handler(util::HttpRequest* request,
                       util::HttpResponse* response);

  virtual util::DataProvider* CreateProvider(struct evhttp_request* req) const;

 private:
  bool use_license_;
  std::shared_ptr<tts::SynthesizerInterface> synthesizer_;
  DISALLOW_COPY_AND_ASSIGN(ConcurrentHttpHandler);
};

}  // namespace server
#endif  // TTS_SERVER_CONCURRENT_SERVICE_HANDLER_H_
