// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_SERVER_STREAMING_DATA_PROVIDER_H_
#define TTS_SERVER_STREAMING_DATA_PROVIDER_H_

#include <thread>  // NOLINT

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/concurrent_queue.h"
#include "mobvoi/util/net/http_server/data_provider.h"
#include "tts/server/cache_handler.h"
#include "tts/server/server_util.h"
#include "tts/server/synthesizer_event.h"
#include "tts/synthesizer/interface/synthesizer_interface.h"

namespace server {

class TTSDataProvider;

class TTSDataProvider : public util::DataProvider {
 public:
  TTSDataProvider(std::shared_ptr<tts::SynthesizerInterface> synthesizer,
                  bool use_license,
                  mobvoi::ConcurrentQueue<KibanaData>* kibana_queue,
                  mobvoi::ConcurrentQueue<KibanaData>* log_queue,
                  bool use_adaptation = false);
  virtual ~TTSDataProvider();

  void Start(util::HttpRequest* http_request,
             util::HttpResponse* response) override;
  bool Next(string* data) override;

 private:
  std::shared_ptr<mobvoi::ConcurrentQueue<string>> data_queue_;
  std::shared_ptr<std::vector<string>> duration_;
  shared_ptr<SynthesizerEvent> event_;
  std::shared_ptr<tts::SynthesizerInterface> synthesizer_;
  unique_ptr<std::thread> thread_;
  mobvoi::ConcurrentQueue<KibanaData>* kibana_queue_;
  mobvoi::ConcurrentQueue<KibanaData>* log_queue_;
  std::map<std::string, std::string> request_params_;
  bool use_adaptation_;
  bool use_license_;
  string engine_name_;
  string speaker_;
  string product_;
  int word_num_;
  int first_chunk_time_;
  string all_chunk_time_;
  int64_t start_time_;
  bool first_chunk_ = true;
  bool cache_total_sentence_ = false;
  bool is_navigation_;
  DISALLOW_COPY_AND_ASSIGN(TTSDataProvider);
};

}  // namespace server

#endif  // TTS_SERVER_STREAMING_DATA_PROVIDER_H_
