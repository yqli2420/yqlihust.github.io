// Copyright 2016 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_SERVER_KIBANA_KIBANA_WRITE_THREAD_H_
#define TTS_SERVER_KIBANA_KIBANA_WRITE_THREAD_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/concurrent_queue.h"
#include "mobvoi/base/thread.h"
#include "tts/server/server_util.h"

namespace Json {
class Value;
}

namespace server {

class KinabaWriteThread : public mobvoi::Thread {
 public:
  explicit KinabaWriteThread(mobvoi::ConcurrentQueue<KibanaData>* data_queue);
  virtual ~KinabaWriteThread();

  virtual void Run();

 private:
  mobvoi::ConcurrentQueue<KibanaData>* data_queue_;
  string create_json_str_;
  DISALLOW_COPY_AND_ASSIGN(KinabaWriteThread);
};
}  // namespace server
#endif  // TTS_SERVER_KIBANA_KIBANA_WRITE_THREAD_H_
