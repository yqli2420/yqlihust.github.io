// Copyright 2018. All Rights Reserved.
// Author: chhyu@mobvoi.com (Changhe Yu)

#include "tts/server/streaming_service_handler.h"

#include "tts/server/server_util.h"
#include "tts/synthesizer/synthesizer.h"

DEFINE_bool(use_break, true, "whether to use break model");

namespace server {

StreamingHttpHandler::StreamingHttpHandler(
    util::Callback callback, bool use_license,
    std::shared_ptr<tts::SynthesizerInterface> synthesizer,
    mobvoi::ConcurrentQueue<KibanaData>* data_queue,
    mobvoi::ConcurrentQueue<KibanaData>* log_queue, bool use_adaptation)
    : use_license_(use_license),
      HttpHandler(callback),
      data_queue_(data_queue),
      log_queue_(log_queue),
      use_adaptation_(use_adaptation) {
  synthesizer_ = synthesizer;
}

StreamingHttpHandler::~StreamingHttpHandler() {}

bool StreamingHttpHandler::Handler(util::HttpRequest* request,
                                   util::HttpResponse* response) {
  // Do nothing in this function.
  return true;
}

util::DataProvider* StreamingHttpHandler::CreateProvider(
    struct evhttp_request* req) const {
  LOG(INFO) << "create provider.";
  return new TTSDataProvider(synthesizer_, use_license_, data_queue_,
                             log_queue_, use_adaptation_);
}

}  // namespace server
