# Neural-TTS(Text-to-speech)

Neural-TTS supports hts, gru, and tacotron models.

## Git clone the neural-tts
```
login in gerrit->Projects->neural-tts->Clone with commit-msg hook
git clone ssh://<YOUR NAME>@gerrit:29418/speech/neural-tts && scp -p -P 29418 <YOUR NAME>@gerrit:hooks/commit-msg neural-tts/.git/hooks/
```

## Build And Test

Build environment:

- OS: Ubuntu 16.04
- Bazel: 0.20.0
- GCC: 5.x

Make sure that directory structure is like:
```
$TOP_DIR/
├── common
├── tensorflow_lite
├── neural-tts
```

Default build and test command:

```
cd speech/neural-tts
bazel build --config=trt tts/...
bazel test --config=trt tts/...
```
