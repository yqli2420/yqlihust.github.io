#!/bin/bash

ulimit -c unlimited

bin/tts_log_importer_main --flagfile=flag/tts_log_importer_main.flag 1>>log/log.txt 2>>log/log.txt &
