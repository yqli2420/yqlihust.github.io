#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Dylan @ 2016-08-27 10:38:40

import os
import sys
sys.path.append("./:gs")
import argparse
import random


def api_test(test_file, test_num, server, port, seed, speaker):
    with open(test_file, "r") as fp:
        lines = fp.readlines()
        random.seed(seed)
        random.shuffle(lines)
        test_lines = lines[0:test_num]
        for x in test_lines:
            x = x.strip()
            os.system('ab -c 100 -n 100 ' \
                      '"http://%s:%s/api/' \
                      'synthesis?timestamp=1437737345&product=ticwatch&' \
                      'mandarin_speaker=%s&text=%s"' % \
                      (server, port, speaker, x))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--test_file', default='./production/test/log_text', help='test data')
    parser.add_argument('--test_num', type=int, default=100, help='test sentence number')
    parser.add_argument('--seed', type=int, default=1337, help='random seed')
    parser.add_argument('--server', default='10.1.205.135', help='server name')
    parser.add_argument('--port', default='8836', help='port number')
    parser.add_argument('--speaker', default='cissy', help='speaker')

    args = parser.parse_args()
    api_test(args.test_file, args.test_num, args.server, args.port, args.seed, args.speaker)
    print("done")


if __name__ == "__main__":
    main()
