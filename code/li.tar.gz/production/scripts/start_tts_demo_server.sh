#!/bin/bash

ulimit -c unlimited

bin/tts_demo_server --flagfile=flag/tts_demo_server.flag 1>>log/log.txt 2>>log/log.txt &
