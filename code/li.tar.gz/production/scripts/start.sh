#!/bin/bash

ulimit -c unlimited
export LD_LIBRARY_PATH=$(pwd)/libs:${LD_LIBRARY_PATH}

bin/tts_server_main --flagfile=flag/tts_server_main.flag 1>>log/log.txt 2>>log/log.txt &
