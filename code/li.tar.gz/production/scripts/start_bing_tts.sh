#!/bin/bash

ulimit -c unlimited
export LD_LIBRARY_PATH=libs

./bin/bing_tts_service_main \
  --flagfile=flag/bing_tts_service_main.flag 1>>log/log.txt 2>>log/log.txt &

