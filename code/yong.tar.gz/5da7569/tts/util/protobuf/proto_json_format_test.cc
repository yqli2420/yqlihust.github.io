// Copyright (c) 2013, The Toft Authors. All rights reserved.
// Author: Ye Shunping <yeshunping@gmail.com>

#include "tts/util/protobuf/proto_json_format.h"

#include <math.h>
#include <stdlib.h>
#include <limits>

#include "mobvoi/base/file.h"
#include "third_party/glog/logging.h"
#include "google/protobuf/text_format.h"
#include "third_party/gtest/gtest.h"
#include "third_party/jsoncpp/json.h"
#include "tts/util/protobuf/unittest.pb.h"

namespace util {

TEST(JsonFormatUnittest, PrintToJson) {
  Person p;
  p.set_age(30);
  NameInfo* name = p.mutable_name();
  name->set_first_name("Ye");
  name->set_second_name("Shunping");
  p.set_address("beijing");
  p.add_phone_number("15100000000");
  p.add_phone_number("15100000001");
  p.set_address_id(434798436777434024L);
  p.set_people_type(util::ZANG_ZU);
  LOG(INFO)<< "Text format for Message:\n" << p.Utf8DebugString();

  std::string styled_str;
  ProtoJsonFormat::PrintToStyledString(p, &styled_str);
  std::string expected_styled_str;
  mobvoi::File::ReadFileToStringWithMmap(
      "tts/util/protobuf/json_styled_string.txt", &expected_styled_str);
  EXPECT_EQ(styled_str, expected_styled_str);

  std::string fast_str;
  ProtoJsonFormat::PrintToFastString(p, &fast_str);
  VLOG(3) << "FastString json format for Message:\n" << fast_str;
  std::string expected_fast_str;
  mobvoi::File::ReadFileToStringWithMmap(
      "tts/util/protobuf/json_fast_string.txt", &expected_fast_str);
  EXPECT_EQ(fast_str, expected_fast_str);
}

void TestJsonString(const std::string& json_file) {
  std::string styled_str;
  mobvoi::File::ReadFileToStringWithMmap(json_file, &styled_str);
  Person pb;
  ProtoJsonFormat::ParseFromString(styled_str, &pb);

  Person expected_pb;
  {
    std::string content;
    std::string path = "tts/util/protobuf/debug_string.txt";
    mobvoi::File::ReadFileToStringWithMmap(path, &content);
    google::protobuf::TextFormat::ParseFromString(content, &expected_pb);
  }
  EXPECT_EQ(pb.SerializeAsString(), expected_pb.SerializeAsString());
}

TEST(JsonFormatUnittest, ParseFromFastJsonString) {
  std::string path = "tts/util/protobuf/json_fast_string.txt";
  TestJsonString(path);
}

TEST(JsonFormatUnittest, ParseFromStyledJsonString) {
  std::string path = "tts/util/protobuf/json_styled_string.txt";
  TestJsonString(path);
}
}  // namespace util
