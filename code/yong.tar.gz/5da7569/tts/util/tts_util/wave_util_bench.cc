// Copyright 2017 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include <smmintrin.h>
#include <immintrin.h>
#include <tmmintrin.h>

#include "mobvoi/base/file.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/time.h"
#include "benchmark/benchmark.h"
#include "tts/util/tts_util/wave_util.h"

inline int16 NormalMax(const vector<int16>& data) {
  if (data.empty()) {
    return kint16min;
  }

  int16 max = data[0];
  for (size_t i = 0; i < data.size(); ++i) {
    if (data[i] > max) {
      max = data[i];
    }
  }
  return max;
}

inline int16 MaxSSE(const vector<int16>& data) {
  if (data.size() < 8) {
    return NormalMax(data);
  }

  const int16* ptr = data.data();
  // Load first group.
  // __m128i maxv = _mm_loadu_si16(ptr);
  __m128i maxv = _mm_loadu_si128((const __m128i*)ptr);
  for (size_t i = 8; i + 8 < data.size(); i += 8) {
    __m128i a = _mm_loadu_si128((const __m128i*)(ptr + i));
    maxv = _mm_max_epi16(maxv, a);
  }

  int16 max = kint16min;
  int temp = 0;
#define UPDATE_MAX(i)                \
  temp = _mm_extract_epi16(maxv, i); \
  if (temp > max) {                  \
    max = temp;                      \
  }
  UPDATE_MAX(0);
  UPDATE_MAX(1);
  UPDATE_MAX(2);
  UPDATE_MAX(3);
  UPDATE_MAX(4);
  UPDATE_MAX(5);
  UPDATE_MAX(6);
  UPDATE_MAX(7);

  // Process remaining elements.
  int remaining = data.size() & 8;
  for (size_t i = data.size() - remaining; i < data.size(); ++i) {
    if (data[i] > max) {
      max = data[i];
    }
  }
  return max;
}

inline int16 NormalMaxAbs(const vector<int16>& data) {
  if (data.empty()) {
    return kint16min;
  }

  int16 max = abs(data[0]);
  for (size_t i = 0; i < data.size(); ++i) {
    if (abs(data[i]) > max) {
      max = abs(data[i]);
    }
  }
  return max;
}

inline int16 MaxAbsSSE(const vector<int16>& data) {
  if (data.size() < 8) {
    return NormalMax(data);
  }

  const int16* ptr = data.data();
  // Load first group.
  // Find _mm_loadu_si16 in
  // https://software.intel.com/sites/landingpage/IntrinsicsGuide/
  // but can NOT find it in gcc include header.
  // __m128i maxv = _mm_loadu_si16(ptr);
  __m128i maxv = _mm_loadu_si128((const __m128i*)ptr);
  maxv = _mm_abs_epi16(maxv);
  for (size_t i = 8; i + 8 < data.size(); i += 8) {
    __m128i a = _mm_loadu_si128((const __m128i*)(ptr + i));
    a = _mm_abs_epi16(a);
    maxv = _mm_max_epi16(maxv, a);
  }

  int16 max = kint16min;
  int temp = 0;
#define UPDATE_MAX(i)                \
  temp = _mm_extract_epi16(maxv, i); \
  if (temp > max) {                  \
    max = temp;                      \
  }
  UPDATE_MAX(0);
  UPDATE_MAX(1);
  UPDATE_MAX(2);
  UPDATE_MAX(3);
  UPDATE_MAX(4);
  UPDATE_MAX(5);
  UPDATE_MAX(6);
  UPDATE_MAX(7);

  // Process remaining elements.
  int remaining = data.size() & 8;
  for (size_t i = data.size() - remaining; i < data.size(); ++i) {
    if (data[i] > max) {
      max = data[i];
    }
  }
  return max;
}

void BM_Max(benchmark::State& state) {  // NOLINT
  const string filename = "tts/util/tts_util/testdata/test.wav";
  vector<int16> data;
  tts::WaveFile::ReadRawFile(filename, &data);
  int64 sum = 0;
  for (auto _ : state) {
    sum += NormalMax(data);
  }
  VLOG(1) << "sum : " << sum;
}

BENCHMARK(BM_Max);

void BM_MaxSSE(benchmark::State& state) {  // NOLINT
  const string filename = "tts/util/tts_util/testdata/test.wav";
  vector<int16> data;
  tts::WaveFile::ReadRawFile(filename, &data);
  VLOG(1) << "element number : " << data.size();
  int64 sum = 0;
  for (auto _ : state) {
    sum += MaxSSE(data);
  }
  VLOG(1) << "sum : " << sum;
}

BENCHMARK(BM_MaxSSE);

void MaxCompare(benchmark::State& state) {  // NOLINT
  const string filename = "tts/util/tts_util/testdata/test.wav";
  vector<int16> data;
  tts::WaveFile::ReadRawFile(filename, &data);

  for (auto _ : state) {
    int max1 = MaxSSE(data);
    int max2 = NormalMax(data);
    CHECK_EQ(max1, max2);
  }
}

BENCHMARK(MaxCompare);

void BM_MaxAbs(benchmark::State& state) {  // NOLINT
  const string filename = "tts/util/tts_util/testdata/test.wav";
  vector<int16> data;
  tts::WaveFile::ReadRawFile(filename, &data);
  int64 sum = 0;
  for (auto _ : state) {
    sum += NormalMaxAbs(data);
  }
  VLOG(1) << "sum : " << sum;
}

BENCHMARK(BM_MaxAbs);

void BM_MaxAbsSSE(benchmark::State& state) {  // NOLINT
  const string filename = "tts/util/tts_util/testdata/test.wav";
  vector<int16> data;
  tts::WaveFile::ReadRawFile(filename, &data);
  VLOG(1) << "element number : " << data.size();
  int64 sum = 0;
  for (auto _ : state) {
    sum += MaxAbsSSE(data);
  }
  VLOG(1) << "sum : " << sum;
}

BENCHMARK(BM_MaxAbsSSE);

void MaxAbsCompare(benchmark::State& state) {  // NOLINT
  const string filename = "tts/util/tts_util/testdata/test.wav";
  vector<int16> data;
  tts::WaveFile::ReadRawFile(filename, &data);

  for (auto _ : state) {
    int max1 = MaxAbsSSE(data);
    int max2 = NormalMaxAbs(data);
    CHECK_EQ(max1, max2);
  }
}

BENCHMARK(MaxAbsCompare);
