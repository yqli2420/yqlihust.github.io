// Copyright 2017 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/util/tts_util/wave_util.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/time.h"
#include "third_party/gtest/gtest.h"

namespace tts {
TEST(WaveFileTest, example) {
  const string filename = "tts/util/tts_util/testdata/test.wav";
  vector<int16> data;
  int sampling_rate = 0;
  WaveFile::ReadWaveFile(filename, &data, &sampling_rate);
  EXPECT_EQ(sampling_rate, 16000);
  string wave_data;
  mobvoi::File::ReadFileToStringWithMmap(filename, &wave_data);
  // Write data.
  string new_data;
  WaveFile::ConvertDataToWave(data, sampling_rate, &new_data);
  // EXPECT_EQ(wave_data, new_data);
}

TEST(WaveFileTest, NormalizeWaveVanillaBenchmark) {
  const string filename = "tts/util/tts_util/testdata/test.wav";
  vector<int16> data;
  int sampling_rate = 0;
  WaveFile::ReadWaveFile(filename, &data, &sampling_rate);
  int times = 10000;
  {
#ifndef FOR_PORTABLE
    mobvoi::BenchTimer timer("NormalizeWaveVanilla", times);
#endif
    for (int i = 0; i < times; ++i) {
      vector<int16> data2(data);
      WaveFile::NormalizeWaveVanilla(&data2, kDefaultVolume);
    }
  }
}

#ifdef USE_AVX2
TEST(WaveFileTest, NormalizeWaveAVX2Benchmark) {
  const string filename = "tts/util/tts_util/testdata/test.wav";
  vector<int16> data;
  int sampling_rate = 0;
  WaveFile::ReadWaveFile(filename, &data, &sampling_rate);
  int times = 10000;
  {
#ifndef FOR_PORTABLE
    mobvoi::BenchTimer timer("NormalizeWaveAVX2", times);
#endif
    for (int i = 0; i < times; ++i) {
      vector<int16> data2(data);
      WaveFile::NormalizeWaveAVX2(&data2, kDefaultVolume);
    }
  }
}

TEST(WaveFileTest, NormalizeWaveTest) {
  const string filename = "tts/util/tts_util/testdata/test.wav";
  vector<int16> data;
  int sampling_rate = 0;
  WaveFile::ReadWaveFile(filename, &data, &sampling_rate);
  vector<int16> data2(data);
  WaveFile::NormalizeWaveVanilla(&data2, kDefaultVolume);
  vector<int16> data3(data);
  WaveFile::NormalizeWaveAVX2(&data3, kDefaultVolume);
  EXPECT_EQ(data2.size(), data3.size());
  for (size_t i = 0; i < data3.size(); ++i) {
    EXPECT_EQ(data2[i], data3[i]);
  }
}
#endif  // USE_AVX2

#ifdef __ARM_NEON
TEST(WaveFileTest, NormalizeWaveAVX2Benchmark) {
  const string filename = "tts/util/tts_util/testdata/test.wav";
  vector<int16> data;
  int sampling_rate = 0;
  WaveFile::ReadWaveFile(filename, &data, &sampling_rate);
  int times = 10000;
  {
#ifndef FOR_PORTABLE
    mobvoi::BenchTimer timer("NormalizeWaveNeon", times);
#endif
    for (int i = 0; i < times; ++i) {
      vector<int16> data2(data);
      WaveFile::NormalizeWaveNeon(&data2, kDefaultVolume);
    }
  }
}

TEST(WaveFileTest, NormalizeWaveTest) {
  const string filename = "tts/util/tts_util/testdata/test.wav";
  vector<int16> data;
  int sampling_rate = 0;
  WaveFile::ReadWaveFile(filename, &data, &sampling_rate);
  vector<int16> data2(data);
  WaveFile::NormalizeWaveVanilla(&data2, kDefaultVolume);
  vector<int16> data3(data);
  WaveFile::NormalizeWaveNeon(&data3, kDefaultVolume);
  EXPECT_EQ(data2.size(), data3.size());
  for (size_t i = 0; i < data3.size(); ++i) {
    EXPECT_EQ(data2[i], data3[i]);
  }
}
#endif  // __ARM_NEON

}  // namespace tts
