// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/util/tts_util/util.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "third_party/gtest/gtest.h"

namespace tts {

static const string kTestDataDir = "tts/util/tts_util/testdata";  // NOLINT

TEST(UtilUnitTest, CutOffText) {
  string text1 = "I want to listen to English";
  const string expect1 = "I want to li";
  CutOffText(&text1, 12);
  EXPECT_EQ(expect1, text1);

  string text2 = "这是一个有趣打小明";
  const string expect2 = "这是一个有";
  CutOffText(&text2, 5);
  EXPECT_EQ(expect2, text2);
}

TEST(SplitSyllableTest, example) {
  {
    vector<string> phones;
    SplitSyllable("lai", &phones);
    EXPECT_EQ(2UL, phones.size());
    EXPECT_EQ("l", phones[0]);
    EXPECT_EQ("ai", phones[1]);
  }
  {
    vector<string> phones;
    SplitSyllable("a", &phones);
    EXPECT_EQ(1UL, phones.size());
    EXPECT_EQ("a", phones[0]);
  }
  {
    vector<string> phones;
    SplitSyllable("chuang", &phones);
    EXPECT_EQ(2UL, phones.size());
    EXPECT_EQ("ch", phones[0]);
    EXPECT_EQ("uang", phones[1]);
  }
  {
    vector<string> phones;
    SplitSyllable("zhuang", &phones);
    EXPECT_EQ(2UL, phones.size());
    EXPECT_EQ("zh", phones[0]);
    EXPECT_EQ("uang", phones[1]);
  }
}

void SplitLabelsByLPTest(const string& filename, vector<size_t> expect_size) {
  LOG(INFO) << "test file: " << filename;
  file::SimpleLineReader reader(filename);
  vector<string> lines;
  reader.ReadLines(&lines);
  vector<vector<string>> sliced_labels;
  SplitLabelsByLP(lines, kMandarinTypeString, &sliced_labels);
  EXPECT_EQ(expect_size.size(), sliced_labels.size());
  for (size_t i = 0; i < expect_size.size(); ++i) {
    EXPECT_EQ(expect_size[i], sliced_labels[i].size());
  }
}

TEST(UtilUnitTest, SplitLabelsByLP) {
  string filename;
  vector<size_t> expect_size;

  filename = mobvoi::File::JoinPath(kTestDataDir, "split_label_test1.lab");
  expect_size = {17, 43, 10, 68, 38};
  SplitLabelsByLPTest(filename, expect_size);

  filename = mobvoi::File::JoinPath(kTestDataDir, "split_label_test2.lab");
  expect_size = {7, 53, 10, 68, 38};
  SplitLabelsByLPTest(filename, expect_size);

  filename = mobvoi::File::JoinPath(kTestDataDir, "split_label_test3.lab");
  expect_size = {69, 69, 38};
  SplitLabelsByLPTest(filename, expect_size);

  filename = mobvoi::File::JoinPath(kTestDataDir, "split_label_test4.lab");
  expect_size = {36, 19, 69, 52};
  SplitLabelsByLPTest(filename, expect_size);

  filename = mobvoi::File::JoinPath(kTestDataDir, "split_label_test5.lab");
  expect_size = {69, 22};
  SplitLabelsByLPTest(filename, expect_size);
}

void SplitLabelsByLanguageTest(const string& filename,
                               const vector<string>& expect_languages,
                               const vector<size_t>& expect_size) {
  LOG(INFO) << "test file: " << filename;
  file::SimpleLineReader reader(filename);
  vector<string> lines;
  reader.ReadLines(&lines);
  vector<vector<string>> sliced_labels;
  vector<string> languages;
  SplitLabelsByLanguage(lines, &languages, &sliced_labels);
  EXPECT_EQ(expect_languages, languages);
  EXPECT_EQ(expect_size.size(), sliced_labels.size());
  for (size_t i = 0; i < expect_size.size(); ++i) {
    EXPECT_EQ(expect_size[i], sliced_labels[i].size());
  }
}

TEST(UtilUnitTest, SplitLabelsByLanguage) {
  string filename;
  vector<string> expect_languages;
  vector<size_t> expect_size;

  filename = mobvoi::File::JoinPath(kTestDataDir, "split_language_label1.lab");
  expect_languages = {"Mandarin", "English", "Mandarin", "English", "Mandarin"};
  expect_size = {10, 7, 7, 21, 9};
  SplitLabelsByLanguageTest(filename, expect_languages, expect_size);
}

TEST(UtilUnitTest, ToUpper) {
  {
    string orginstr = "toUpper function test = Toupper Test";
    string upperstr = ToUpper(orginstr);
    EXPECT_EQ("TOUPPER FUNCTION TEST = TOUPPER TEST", upperstr);
  }
  {
    string orginstr = "~toUpper function test = symbol 3 # 1 !~";
    string upperstr = ToUpper(orginstr);
    EXPECT_EQ("~TOUPPER FUNCTION TEST = SYMBOL 3 # 1 !~", upperstr);
  }
  {
    string originstr =
        "toUpper test : which string length is out of 128,"
        "so we  use another way to save cpu source. the st"
        "ring now is out of 128.hahhhhaa";
    string upperstr = ToUpper(originstr);
    EXPECT_EQ(129UL, upperstr.size());
    EXPECT_EQ(
        "TOUPPER TEST : WHICH STRING LENGTH IS OUT OF 128,"
        "SO WE  USE ANOTHER WAY TO SAVE CPU SOURCE. THE STRING NOW IS"
        " OUT OF 128.HAHHHHAA",
        upperstr);
  }
}

TEST(UtilUnitTest, ToLower) {
  {
    string orginstr = "tolower function test = Tolower Test";
    string lowerstr = ToLower(orginstr);
    EXPECT_EQ("tolower function test = tolower test", lowerstr);
  }
  {
    string orginstr = "~toLower function test = symbol 3 # 1 !~";
    string lowerstr = ToLower(orginstr);
    EXPECT_EQ("~tolower function test = symbol 3 # 1 !~", lowerstr);
  }
  {
    string originstr =
        "TOLOWER test : which string LENGHT is out of 128,"
        "so we  use ANOTHER way to save cpu source. the str"
        "ing now is out of 128.hahhhhaa";
    string lowerstr = ToLower(originstr);
    EXPECT_EQ(129UL, lowerstr.size());
    EXPECT_EQ(
        "tolower test : which string lenght is out of 128,"
        "so we  use another way to save cpu source. the string now is"
        " out of 128.hahhhhaa",
        lowerstr);
  }
}

TEST(UtilUnitTest, LoadSetFromFile) {
  string filename = "external/config/front_end/dict/erhua_dict";
  mobvoi::unordered_set<string> set;
  LoadSetFromFile(filename, &set);

  const string text1 = "板擦";
  const string text2 = "骑车";
  EXPECT_FALSE(set.find(text1) == set.end());
  EXPECT_TRUE(set.find(text2) == set.end());
}

TEST(UtilUnitTest, GetDomainFromXml) {
  const string filename = mobvoi::File::JoinPath(kTestDataDir, "ssml.xml");
  string text;
  mobvoi::File::ReadFileToStringOrDie(filename, &text);
  string domain = GetDomainFromXml(text);
  EXPECT_EQ("public.weather", domain);
}

TEST(UtilUnitTest, AllUpper) {
  string teststr1 = "This String is not all UPPER";
  EXPECT_FALSE(AllUpper(teststr1));

  string teststr2 = "THISSTRINGISALLUPPER";
  EXPECT_TRUE(AllUpper(teststr2));
}

TEST(UtilUnitTest, AllLower) {
  string teststr1 = "this string is not all Lower";
  EXPECT_FALSE(AllLower(teststr1));

  string teststr2 = "thisstringisalllower";
  EXPECT_TRUE(AllLower(teststr2));
}

TEST(UtilUnitTest, LoadStdVectorFromFile) {
  {
    string filename = mobvoi::File::JoinPath(kTestDataDir, "loadstdvector.lab");
    vector<float> floatvec;
    LoadStdVectorFromFile(filename, &floatvec);
    ASSERT_EQ(10UL, floatvec.size());
    EXPECT_FLOAT_EQ(0.34, floatvec[0]);
    EXPECT_FLOAT_EQ(0.999, floatvec[9]);
  }
  {
    string filename = mobvoi::File::JoinPath(kTestDataDir, "loadstdvector.lab");
    vector<double> doublevec;
    LoadStdVectorFromFile(filename, &doublevec);
    ASSERT_EQ(10UL, doublevec.size());
    EXPECT_DOUBLE_EQ(0.34, doublevec[0]);
    EXPECT_DOUBLE_EQ(0.999, doublevec[9]);
  }
}
TEST(UtilUnitTest, LoadMatrixFromFile) {
  {
    string filename = mobvoi::File::JoinPath(kTestDataDir, "/loadmatrix.lab");
    vector<vector<double>> output;
    vector<size_t> expect_size = {10, 10, 6};
    vector<double> expect_values = {0.12, 0.23, 0.34};
    LoadMatrixFromFile(filename, &output);
    ASSERT_EQ(expect_size.size(), output.size());
    for (size_t i = 0; i < expect_size.size(); ++i) {
      EXPECT_EQ(expect_size[i], output[i].size());
      EXPECT_DOUBLE_EQ(expect_values[i], output[i][0]);
    }
  }
}

}  // namespace tts
