// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_UTIL_TTS_UTIL_WAVE_UTIL_H_
#define TTS_UTIL_TTS_UTIL_WAVE_UTIL_H_

#include <string>
#include <vector>

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"

namespace tts {

static const float kNoNormalizeFactor = 0;
static const float kDefaultNormalizeFactor = 2.25;
static const float kDefaultVolume = 1;

class WaveFile {
 public:
  static void WriteRiffHeader(int sampling_frequency, int nsamples,
                              string* riff_header);
  static void ReadWaveFile(const string& filename, vector<int16>* data,
                           int* sampling_rate);
  static void ReadWaveFileInfo(const string& filename, vector<int16>* data,
                               int* sampling_rate, int* bits_per_sample,
                               int16* channels);

  // raw file has no RIFF header
  static bool ReadRawFile(const string& filename, vector<int16>* data);
  static void ConvertDataToWave(const vector<int16>& raw_data,
                                int sampling_frequency, string* data);
  static void ConvertDataToRaw(const vector<int16>& raw_data,
                               int sampling_frequency, string* data);
  static void ConvertWaveToData(const string& wav, vector<int16>* raw_data);
  static bool IsSilence(const vector<int16>& datas);
  static void NormalizeWave(vector<int16>* data, float volume,
                            float ratio = kNoNormalizeFactor);
  static void NormalizeWaveVanilla(vector<int16>* data, float volume,
                                   float ratio = kNoNormalizeFactor);
  static void NormalizeWaveAVX2(vector<int16>* data, float volume,
                                float ratio = kNoNormalizeFactor);
  static void NormalizeWaveNeon(vector<int16>* data, float volume,
                                float ratio = kNoNormalizeFactor);
  static void HighPassFilterFixedPoint(const vector<int16>& signal_in,
                                       vector<int16>* signal_out);
  static void LowPassFilterFixedPoint(const vector<int16>& input, int cut_off,
                                      int sample_rate, vector<int16>* output);
  static void AudioMix(const vector<int16>& bg_buf, const float volume,
                       const float bgm_volume, const int bgm_beg,
                       vector<int16>* src_buf);
  static void AudioMix(const vector<int16>& bg_buf,
                       const map<int, int>& section,
                       const float volume, const float bgm_volume,
                       const int bgm_beg, vector<int16>* src_buf);

 private:
  DECLARE_STATIC_CLASS(WaveFile);
  DISALLOW_COPY_AND_ASSIGN(WaveFile);
};

}  // namespace tts
#endif  // TTS_UTIL_TTS_UTIL_WAVE_UTIL_H_
