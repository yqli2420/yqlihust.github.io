// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)
// to generate a concatenated wav for tts MOS
// join wav files in target dir in order and add silence between

#include "mobvoi/base/file.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/string_util.h"
#include "tts/util/tts_util/wave_util.h"

DEFINE_string(wav_dir, "", "input dir");
DEFINE_int32(repeat_times, 2, "repeat time for each wav");
DEFINE_double(break_time, 1.5, "silence time (s) after each repeat times");
DEFINE_double(seperate_time, 2.5, "silence time (s) after each wav");
DEFINE_string(joined_wav, "join.wav", "output file");

// wav name length should be same, e.g. 01.wav 02.wav ...
bool CompareFileName(const string& a, const string& b) { return a < b; }

void JoinWave(const string& wav_dir, const string& output_file) {
  vector<string> files;
  mobvoi::File::GetFilesInDir(wav_dir, &files);
  // sort to right order
  sort(files.begin(), files.end(), CompareFileName);
  vector<vector<int16>> datas;
  int freq;
  for (const auto& file : files) {
    vector<int16> data;
    tts::WaveFile::ReadWaveFile(file, &data, &freq);
    datas.emplace_back(data);
  }

  vector<int16> join_data;
  for (const auto& data : datas) {
    for (size_t j = 0; j < (size_t)FLAGS_repeat_times; ++j) {
      join_data.insert(join_data.end(), data.begin(), data.end());
      if (j != (size_t)FLAGS_repeat_times - 1) {
        join_data.insert(join_data.end(), freq * FLAGS_break_time, 0);
      }
    }
    if (data != datas.back())
      join_data.insert(join_data.end(), freq * FLAGS_seperate_time, 0);
  }

  string wav_data;
  tts::WaveFile::ConvertDataToWave(join_data, freq, &wav_data);
  mobvoi::File::WriteStringToFile(wav_data, output_file);
}

int main(int argc, char** argv) {
  mobvoi::ParseCommandLineFlags(&argc, &argv, false, "");

  JoinWave(FLAGS_wav_dir, FLAGS_joined_wav);
  return 0;
}
