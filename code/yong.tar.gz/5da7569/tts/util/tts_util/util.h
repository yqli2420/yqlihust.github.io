// Copyright 2013 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_UTIL_TTS_UTIL_UTIL_H_
#define TTS_UTIL_TTS_UTIL_UTIL_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/util/utf8/utf8_util.h"
#include "re2/re2.h"
#include "third_party/jsoncpp/json.h"
#include "tts/synthesizer/proto/tts.pb.h"
#include "tts/util/tts_util/tts_data.h"

namespace tts {

void SetDefaultTTSOption(TTSOption* tts_option);
enum LanguageType {
  kMandarin = 0,
  kEnglish = 1,
  kUnknown = 2,
};

static const string kSubLanMan = "man";          // NOLINT
static const string kSubLanCan = "can";          // NOLINT
static const string kSubLanTw = "tw";            // NOLINT
static const string kSubLanUnknown = "unknown";  // NOLINT
static const string kDefaultSubLan = "man";      // NOLINT
static const string kLanguageEnglish = "eng";    // NOLINT

static const string kFrontendPolyphone = "polyphone";  // NOLINT
static const string kFrontendProsody = "prosody";      // NOLINT
static const string kFrontendTn = "tn";                // NOLINT
static const string kFrontendG2p = "g2p";              // NOLINT

// english speaker use mandarin frontend
static const char kSpeakerAngelaMix[] = "angela_mandarin";
static const char kSpeakerAngelaLpcnetMix[] = "angela_mandarin_lpcnet";
// text splitter
static const int kTextMaxBatchSize = 1500000;
static const int kMandarinTextBatchSize = 60;
static const int kEnglishTextBatchSize = 100;
// break tag
static const char kTextBreakTag[] = "<::>";
// ssml tag keys
static const char kSsmlAudioKey[] = "audio";
static const char kSsmlBreakKey[] = "break";
static const char kSsmlTnKey[] = "say-as";
static const char kSsmlWordKey[] = "w";
static const char kSsmlPhoneKey[] = "p";
static const char kSsmlPauseKey[] = "pau";
static const char kSsmlSubKey[] = "sub";
// ssml tn attr
static const char kSsmlTnInterAs[] = "interpret-as";
static const char kSsmlTnSubAlias[] = "alias";
static const char kSsmlTnAsValue[] = "value";
static const char kSsmlTnAsOrdinal[] = "ordinal";
static const char kSsmlTnAsDigits[] = "digits";
static const char kSsmlTnAsRatio[] = "ratio";
static const char kSsmlTnAsTwEmail[] = "tw_email";
static const char kSsmlTnAsTwDS[] = "tw_digit_string";
static const char kSsmlTnAsDate[] = "date";
static const char kSsmlTnAsFraction[] = "fraction";
static const char kSsmlTnAsTelephone[] = "telephone";
static const char kSsmlTnAsBuilding[] = "building";
static const char kSsmlTnAsContact[] = "contact";
static const char kSsmlTnAsBookName[] = "book-name";
static const char kSsmlTnAsFestival[] = "festival-name";
static const char kSsmlTnAsValueLiang[] = "value_liang";
static const char kSsmlTnAsValueLiangSigned[] = "value_signed_liang";
static const char kSsmlTnAsValueEr[] = "value_er";
static const char kSsmlTnAsValueErSigned[] = "value_signed_er";
static const char kSsmlTnAsDigitYao[] = "digit_yao";
static const char kSsmlTnAsDigitYi[] = "digit_yi";
static const char kSsmlTnAsScale[] = "scale";
static const char kSsmlTnAsMath[] = "math";
static const char kSsmlTnAsTime[] = "time";
static const char kSsmlTnAsAlphabet[] = "alphabet";
static const char kSsmlTnAsWord[] = "word";
static const char kSsmlTnAsSymbol[] = "symbol";
static const char kSsmlTnAsManValue[] = "mandarin_value";
static const char kSsmlTnAsManDigits[] = "mandarin_digits";
static const char kSsmlTnAsManDate[] = "mandarin_date";
static const char kSsmlTnAsManTelephone[] = "mandarin_telephone";
static const char kSsmlTnAsWebsite[] = "website";
static const char kSsmlTnAsManWebsite[] = "mandarin_website";
static const char kTnNamePrecentNumber[] = "percent_number";
static const char kTnNameCurrency[] = "currency";
static const char kTnNameCoordinate[] = "coordinate";
static const char kTnNameTemperature[] = "temperature";
static const char kTnNameStock[] = "stock";

// ssml segmenter attr
static const char kSsmlWordPhone[] = "phoneme";
static const char kSsmlAsrWordPhone[] = "asr_phoneme";
// ssml pause attr
static const char kSsmlPauseLevel[] = "level";
// ssml pause value
static const char kSsmlPauseLevelNon[] = "non";
static const char kSsmlPauseLevelProsody[] = "prosody";
static const char kSsmlPauseLevelPhrase[] = "phrase";
static const char kSsmlPauseLevelBreak[] = "break";
// ssml break attr
static const char kSsmlBreakStrength[] = "strength";
static const char kSsmlBreakWeak[] = "weak";
static const char kSsmlBreakMedium[] = "medium";
static const char kSsmlBreakStrong[] = "strong";
static const char kSsmlBreakXStrong[] = "x-strong";
static const char kSsmlBreakTime[] = "time";
static const char kSsmlBreakTimeMs[] = "ms";
static const char kSsmlBreakTimeS[] = "s";
// ssml bgm attr
static const char kSsmlBgm[] = "bgm";
static const char kSsmlBgmVolume[] = "bgm_volume";
static const char kSsmlBgmOffset[] = "bgm_offset";
// ssml insert audio attr
static const char kSsmlAudio[] = "audio";
static const char kSsmlAudioName[] = "name";
static const char kSsmlAudioSrc[] = "src";
static const char kSsmlRefrain[] = "refrain_time";
static const char kSsmlAudioVolume[] = "audio_volume";
// voice changer
static const char kSsmlPitch[] = "pitch";

// domain
static const char kDomainNavigation[] = "public.navigation";

static const int kPuncBreakTime = 400;  // \r \n break time 400ms
static const int kEnglishId = 1500000;
static const int kNumberId = 1499999;
static const int kEnglishKeyId = 1500000;
static const int kDefaultSamplingFrequency = 16000;
static const int kDefaultBitsPerSample = 16;
static const int kDefaultChannels = 1;
static const string kPinyinTag = "pinyin_";  // NOLINT
static const float kDefaultSpeed = 1.15;
static const float kDefaultEngineSpeed = 1.0;

using PuncType = std::pair<bool, bool>;

static const size_t kStateNum = 7;
static const size_t kMgcOrder = 40;
static const size_t kMgcHigh = 10;

static const string kMandarinTypeString = "Mandarin";      // NOLINT
static const string kEnglishTypeString = "English";        // NOLINT
static const string kCantoneseTypeString = "Cantonese";    // NOLINT
static const string kTaiwaneseTypeString = "Taiwanese";    // NOLINT
static const string kSichuaneseTypeString = "Sichuanese";  // NOLINT
static const string kUnknownTypeString = "unknown";        // NOLINT

static const char kFrontendTypeMan[] = "man";
static const char kFrontendTypeTw[] = "tw";
static const char kFrontendTypeEng[] = "eng";

static const string kSilenceMark = "^,.,^";  // NOLINT
static const float kFrontSilenceDuration = 1;
static const float kEndSilenceDuration = 0.5;
static const float kSilenceTagDuration = 1.0;
static const char kCCSepMark[] = ",";

static const string kEnglishPos = "En";     // NOLINT
static const string kNumberPos = "m";       // NOLINT
static const string kPunctuationPos = "w";  // NOLINT

static const char kSingleConsonants[] = {'b', 'p', 'm', 'f', 'd', 't', 'n',
                                         'l', 'g', 'k', 'h', 'j', 'q', 'x',
                                         'r', 'z', 'c', 's', 'y', 'w'};

static const string kDoubleConsonants[] = {"zh", "ch", "sh"};  // NOLINT

static const RE2 ch_pattern("[\u4e00-\u9fa5]+");
static const RE2 ch_pron_pattern("[a-z]+[1-6]");
static const RE2 eng_pattern("[a-zA-Z]+");

bool IsSingleConsonant(char ch);

LanguageType GetLanguageType(const string& lang_str);
// TODO(zhengzhang): add feature in speaker manager
bool IsGruModel(const string& speaker);

void CutOffText(string* text, int max_count);

Json::Value InitialFrontendDataInfo(const string& initial_str);

Json::Value ConstuctBlankOriginJson(size_t length);

// TODO(xiaoqin.feng): remove this old function
Json::Value ConstuctBlankOriginJsonOld(size_t length);

bool SplitSyllable(const string& syllable, vector<string>* phonemes);
void LoadStdVectorFromFile(const string& filename, vector<float>* output);
void LoadStdVectorFromFile(const string& filename, vector<double>* output);
void LoadMatrixFromFile(const string& filename, vector<vector<double>>* output);
void LoadSetFromFile(const string& filename,
                     mobvoi::unordered_set<string>* output);
void LoadMapFromFile(const string& filename,
                     mobvoi::unordered_map<string, string>* output);
string GetDomainFromXml(const string& xml);
string ToLower(const string& upper_str);
string ToUpper(const string& lower_str);
bool IsEngVowel(const string& phoneme);
bool AllDigit(const string& text);
bool AllLetter(const string& text);
bool AllUpper(const string& text);
bool AllLower(const string& text);
bool IsHttpUrl(const string& path);
bool IsChineseWord(const string& ch);
bool IsEnglishWord(const string& ch);
float ParseTime(const string& text);
bool IsChinesePron(const string& pron);
int MapSsmlPause(const string& level);
#ifndef FOR_PORTABLE
bool RunOsSytemCmd(const string& cmd);
#endif
// get file or config-center content lines
// if path is empty, means empty file return directly
void GetConfigCenterLines(const string& path, vector<string>* lines);
void GetConfigCenterAsJson(const string& path, Json::Value* content);
// append relativa path to absolute path except path is empty or http
string AppendPath(const string& dir, const string& rela_path);
void SplitLabelsByLP(const vector<string>& full_labels, const string& language,
                     vector<vector<string>>* sliced_labels);
void SplitLabelsByLanguage(const vector<string>& sliced_labels,
                           vector<string>* languages,
                           vector<vector<string>>* language_labels);

class SplitPoint {
 public:
  explicit SplitPoint(int level_number) { level_values_.resize(level_number); }
  ~SplitPoint() {}

  // get highest level which value is not 0
  bool GetSplitLevel(int* level) const;
  int GetLevelValue(int level) const;
  // set target and lower level value
  void SetLevelValue(int level, int value);
  // remove target level value, and decrease lower level this value
  // e.g. last_sp_value = 5, last_lp_value = 3, split and remove last lp, then
  // last_lp_value 3 -> 0, and last_sp_value 5 -> 2
  void RemoveLevelAndRefresh(int level);

 private:
  // split value of each level, level decrease from 0 to n
  vector<int> level_values_;
};

template <class real>
string RealVectorToString(const vector<real>& vec) {
  string str;
  for (size_t i = 0; i < vec.size(); ++i) {
    str.append(DoubleToString(vec[i]));
  }
  return str;
}

template <class real>
string RealMatrixToString(const vector<vector<real>>& vec) {
  vector<string> lines;
  for (const auto& v : vec) {
    lines.push_back(RealVectorToString(v));
  }
  return JoinVector(lines, '\n');
}

void SplitStringToVector(const string& full, const string& split_string,
                         bool omit_empty_strings, vector<string>* out);

}  // namespace tts
#endif  // TTS_UTIL_TTS_UTIL_UTIL_H_
