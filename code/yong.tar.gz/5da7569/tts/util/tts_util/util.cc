// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/util/tts_util/util.h"

#include <algorithm>

#include "re2/re2.h"
#include "third_party/xml2/libxml/parser.h"

#include "mobvoi/base/base64.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/log.h"
#include "mobvoi/util/config_manager/config_manager.h"
#include "tts/synthesizer/label_generator/label_def.h"

DEFINE_string(default_speaker, "cissy", "set default speaker");

namespace tts {

DEFINE_bool(load_config_center, false, "if false, don't load config center");

void SetDefaultTTSOption(TTSOption* tts_option) {
  tts_option->set_speaker(FLAGS_default_speaker);
  tts_option->set_sampling_frequency(16000);
  tts_option->set_file_format("mp3");
  tts_option->set_appkey("");
  tts_option->set_volume(1);
  tts_option->set_use_robot(false);
  tts_option->set_domain("");
  tts_option->set_append_sil(false);
  tts_option->set_only_frontend(false);
  tts_option->set_only_frontend_tn(false);
  tts_option->set_frontend_type(tts::kFrontendTypeMan);
  tts_option->set_alignment(false);
  tts_option->set_detail_output(false);
  tts_option->set_callback_frames(50);
  tts_option->set_speed(kDefaultSpeed);
  tts_option->set_last_sentence(true);
  tts_option->set_break_time(kPuncBreakTime);  // \n break time (ms)
  tts_option->set_user_dict("");
  tts_option->set_split_bylen(true);
  tts_option->set_bgm("");
  tts_option->set_bgm_volume(1.0);
  tts_option->set_pitch(0);
  tts_option->set_audio_volume(1.0);
  tts_option->set_insert_audio(false);
  tts_option->set_for_voice_maker(false);
  tts_option->set_bgm_offset(0);
  tts_option->set_tone_rule(true);
  tts_option->set_audio_is_id(true);
}

Json::Value InitialFrontendDataInfo(const string& initial_str) {
  Json::Value frontend_data;
  Json::Value format_json(Json::arrayValue);
  frontend_data["g2pTnText"] = initial_str;
  frontend_data["g2pTnJson"] = format_json;
  frontend_data["originJson"] = format_json;
  frontend_data["originText"] = initial_str;
  frontend_data["prosodyText"] = initial_str;
  frontend_data["tnText"] = initial_str;
  frontend_data["originTnlistJson"] = format_json;
  return frontend_data;
}

Json::Value ConstuctBlankOriginJson(size_t length) {
  Json::Value blank_info(Json::arrayValue);
  for (size_t i = 0; i < length; ++i) {
    Json::Value word_infos;
    word_infos["w"] = " ";
    blank_info.append(word_infos);
  }
  return blank_info;
}

LanguageType GetLanguageType(const string& lang_str) {
  if (lang_str == kMandarinTypeString) {
    return LanguageType::kMandarin;
  } else if (lang_str == kEnglishTypeString) {
    return LanguageType::kEnglish;
  } else {
    return LanguageType::kUnknown;
  }
}

bool IsGruModel(const string& speaker) {
  if (speaker == "cissy" || speaker == "tina" || speaker == "emily_gru" ||
      speaker == "lucy_gru" || speaker == "dora_gru" ||
      speaker == "billy_gru" || speaker == "angela_gru") {
    return true;
  }
  return false;
}

bool IsSingleConsonant(char ch) {
  for (size_t i = 0; i < arraysize(kSingleConsonants); ++i) {
    if (ch == kSingleConsonants[i]) {
      return true;
    }
  }
  return false;
}

void CutOffText(string* text, int max_count) {
  const char* start = text->data();
  const char* s = text->data();
  size_t len = text->size();
  int codepoint_num = 0;
  while (static_cast<size_t>(s - start) < len) {
    util::Rune r = 0;
    int l = util::chartorune(&r, s);
    ++codepoint_num;
    s += l;
    if (codepoint_num >= max_count) {
      text->resize(s - start);
      break;
    }
  }
}

bool IsEngVowel(const string& phoneme) {
  if (phoneme.empty()) {
    LOG(WARNING) << "empty phoneme: " << phoneme;
    return false;
  }
  char ch = phoneme[0];
  if (ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U' ||
      ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
    return true;
  }
  return false;
}

bool AllDigit(const string& text) {
  static re2::RE2 all_digit_pattern_obj("\\d+");
  return re2::RE2::FullMatch(text, all_digit_pattern_obj);
}

bool AllLetter(const string& text) {
  auto func = [](char c) {
    if (c < 'A' || c > 'z' || (c > 'Z' && c < 'a')) return false;
    return true;
  };
  return std::all_of(text.begin(), text.end(), func);
}

bool AllUpper(const string& text) {
  auto func = [](char c) {
    if (c < 'A' || c > 'Z') return false;
    return true;
  };
  return std::all_of(text.begin(), text.end(), func);
}

bool AllLower(const string& text) {
  auto func = [](char c) {
    if (c < 'a' || c > 'z') return false;
    return true;
  };
  return std::all_of(text.begin(), text.end(), func);
}

bool IsChineseWord(const string& ch) { return RE2::FullMatch(ch, ch_pattern); }
bool IsChinesePron(const string& pron) {
  return RE2::FullMatch(pron, ch_pron_pattern);
}
bool IsEnglishWord(const string& ch) { return RE2::FullMatch(ch, eng_pattern); }
void GetConfigCenterLines(const string& path, vector<string>* lines) {
  if (IsHttpUrl(path)) {
#ifndef FOR_PORTABLE
    if (FLAGS_load_config_center) {
      VLOG(1) << "load config center url: " << path;
      if (!util::GetConfigCenterContentToLines(path, "#", lines)) {
        LOG(FATAL) << "get config centor failed";
      }
    } else {
      VLOG(2) << "version don't support config center";
    }
#else
    LOG(FATAL) << "not support config center";
#endif
  } else {
    if (path.empty()) return;
    file::SimpleLineReader file_reader(path, true, "#");
    file_reader.ReadLines(lines);
  }
}

void GetConfigCenterAsJson(const string& path, Json::Value* content) {
  if (IsHttpUrl(path)) {
#ifndef FOR_PORTABLE
    if (FLAGS_load_config_center) {
      VLOG(1) << "load config center url: " << path;
      if (!util::GetConfigCenterContentAsJson(path, content)) {
        LOG(FATAL) << "get config centor failed";
      }
    } else {
      VLOG(2) << "version don't support config center";
    }
#else
    LOG(FATAL) << "not support config center";
#endif
  } else {
    if (path.empty()) return;
    string text;
    mobvoi::File::ReadFileToStringOrDie(path, &text);
    Json::Reader reader;
    reader.parse(text, *content);
  }
}

float ParseTime(const string& text) {
  float time = 0.0;
  string time_str, unit_str;
  re2::RE2 time_pattern("(\\d+(?:\\.\\d+)?)(s|ms)");
  if (RE2::FullMatch(text, time_pattern, &time_str, &unit_str)) {
    time = StringToFloat(time_str);
    if (unit_str == kSsmlBreakTimeMs) {
      time /= 1000;
    }
  }
  return time;
}

bool IsHttpUrl(const string& path) {
  return (mobvoi::StartsWithASCII(path, "http://", true) ||
          mobvoi::StartsWithASCII(path, "https://", true));
}

int MapSsmlPause(const string& level) {
  if (level == kSsmlPauseLevelBreak) return kPauseLevelLP;
  if (level == kSsmlPauseLevelPhrase) return kPauseLevelPhrase;
  if (level == kSsmlPauseLevelProsody) return kPauseLevelWord;
  if (level == kSsmlPauseLevelNon) return kPauseLevelPhoneme;
  return kPauseLevelPhoneme;
}

// transform english string to lower case
string ToLower(const string& upper_str) {
  int nsize = upper_str.size();
  int kBufSize = 128;

  auto func = [upper_str](char* result) {
    for (size_t i = 0; i < upper_str.size(); ++i) {
      char c = upper_str[i];
      if (c >= 'A' && c <= 'Z') {
        result[i] = c + 32;
      } else {
        result[i] = c;
      }
    }
  };
  if (kBufSize > nsize) {
    char buf[kBufSize];
    func(buf);
    return string(buf, nsize);
  } else {
    char* large_buf = new char[nsize + 1];
    func(large_buf);
    string str(large_buf, nsize);
    delete[] large_buf;
    return str;
  }
}

// transform english string to upper case
string ToUpper(const string& lower_str) {
  int nsize = lower_str.size();
  int kBufSize = 128;

  auto func = [lower_str](char* result) {
    for (size_t i = 0; i < lower_str.size(); ++i) {
      char c = lower_str[i];
      if (c >= 'a' && c <= 'z') {
        result[i] = c - 32;
      } else {
        result[i] = c;
      }
    }
  };
  if (kBufSize > nsize) {
    char buf[kBufSize];
    func(buf);
    return string(buf, nsize);
  } else {
    char* large_buf = new char[nsize + 1];
    func(large_buf);
    string str(large_buf, nsize);
    delete[] large_buf;
    return str;
  }
}

void LoadStdVectorFromFile(const string& filename, vector<float>* output) {
  string content;
  mobvoi::File::ReadFileToStringWithMmap(filename, &content);
  vector<string> segs;
  SplitString(content, ' ', &segs);
  for (const auto& str : segs) {
    output->push_back(StringToFloat(str));
  }
}

void LoadMatrixFromFile(const string& filename,
                        vector<vector<double>>* output) {
  vector<string> lines;
  file::SimpleLineReader reader(filename);
  reader.ReadLines(&lines);
  for (const auto& line : lines) {
    vector<double> oneline;
    vector<string> segs;
    SplitString(line, ' ', &segs);
    for (const auto& str : segs) {
      oneline.push_back(StringToDouble(str));
    }
    output->push_back(oneline);
  }
}

void LoadStdVectorFromFile(const string& filename, vector<double>* output) {
  string content;
  CHECK(mobvoi::File::ReadFileToStringWithMmap(filename, &content))
      << "Failed to read file : " << filename;
  vector<string> segs;
  SplitString(content, ' ', &segs);
  for (const auto& str : segs) {
    output->push_back(StringToDouble(str));
  }
}

void LoadSetFromFile(const string& filename,
                     mobvoi::unordered_set<string>* output) {
  if (filename.empty()) return;
  if (!mobvoi::File::Exists(filename)) {
    LOG(FATAL) << "file not exist: " << filename;
  }
  vector<string> lines;
  file::SimpleLineReader reader(filename);
  reader.ReadLines(&lines);
  for (auto i : lines) output->insert(i);
}

void LoadMapFromFile(const string& filename,
                     mobvoi::unordered_map<string, string>* output) {
  if (filename.empty()) return;
  if (!mobvoi::File::Exists(filename)) {
    LOG(FATAL) << "file not exist: " << filename;
  }
  vector<string> lines;
  file::SimpleLineReader reader(filename);
  reader.ReadLines(&lines);
  for (auto line : lines) {
    vector<string> segs;
    SplitString(line, '\t', &segs);
    if (segs.size() != 2) {
      LOG(WARNING) << "format error: " << line;
      continue;
    }
    output->insert(std::make_pair(segs[0], segs[1]));
  }
}

static bool IsDoubleConsonant(const string& str) {
  for (size_t i = 0; i < arraysize(kDoubleConsonants); ++i) {
    if (str == kDoubleConsonants[i]) {
      return true;
    }
  }
  return false;
}

bool SplitSyllable(const string& syllable, vector<string>* phonemes) {
  if (syllable.empty()) return false;

  if (IsDoubleConsonant(syllable.substr(0, 2))) {
    phonemes->push_back(syllable.substr(0, 2));
    phonemes->push_back(syllable.substr(2));
  } else if (IsSingleConsonant(syllable[0])) {
    phonemes->push_back(syllable.substr(0, 1));
    phonemes->push_back(syllable.substr(1));
  } else {
    phonemes->push_back(syllable);
  }
  return true;
}

string GetDomainFromXml(const string& xml) {
  static string start_str = "tts::prompt domain=\"";
  string::size_type start = xml.find(start_str);
  if (start != string::npos) {
    string::size_type end = xml.find("\"", start + start_str.size());
    if (end != string::npos) {
      return xml.substr(start + start_str.size(),
                        end - start - start_str.size());
    }
  }
  return string();
}

enum SplitLevel {
  kLevelLP = 0,
  kLevelSP,
  kLevelPhrase,
  kLevelWord,
  kLevelNone,
  kLevelAllNum,
};
SplitLevel JudgeLevel(const string& label) {
  static re2::RE2 b10_pattern("#[\\d|X]-(\\d|X)\\|");
  static re2::RE2 p3_pattern("-([a-zA-Z]+)\\+");
  string b10, p3;
  RE2::Extract(label, p3_pattern, "\\1", &p3);
  RE2::Extract(label, b10_pattern, "\\1", &b10);
  if (p3 == kPhoneLP) {
    return SplitLevel::kLevelLP;
  } else if (p3 == kPhoneSP) {
    return SplitLevel::kLevelSP;
  } else if (b10 == IntToString(kPauseLevelPhrase)) {
    return SplitLevel::kLevelPhrase;
  } else if (b10 == IntToString(kPauseLevelWord)) {
    return SplitLevel::kLevelWord;
  }
  return SplitLevel::kLevelNone;
}

void SplitLabelsByLP(const vector<string>& full_labels, const string& language,
                     vector<vector<string>>* sliced_labels) {
  VLOG(2) << "begin to split labels by lp";
  static uint32_t first_sp_size = 25;
  static uint32_t man_sp_step = 5;
  static uint32_t eng_sp_step = 15;
  static uint32_t man_max_sp_size = 70;   // should be sp_size + n * sp_step
  static uint32_t eng_max_sp_size = 100;  // should be sp_size + n * sp_step

  uint32_t sp_step;
  uint32_t max_sp_size;
  if (language == kEnglishTypeString) {
    sp_step = eng_sp_step;
    max_sp_size = eng_max_sp_size;
  } else {
    sp_step = man_sp_step;
    max_sp_size = man_max_sp_size;
  }

  uint32_t sp_size = first_sp_size;
  SplitPoint split_offset(SplitLevel::kLevelAllNum);
  uint32_t begin = 0;
  for (size_t i = 0; i < full_labels.size(); ++i) {
    uint32_t sp_len = i + 1 - begin;
    SplitLevel cur_level = JudgeLevel(full_labels[i]);
    // first split part should at least cut in a phrase boundary
    // until reach to the max_sp_size, then find a word boundary
    if (cur_level != SplitLevel::kLevelWord || sp_size == max_sp_size) {
      split_offset.SetLevelValue(cur_level, sp_len);
    }

    if (sp_len >= sp_size) {
      int split_level = SplitLevel::kLevelNone;
      split_offset.GetSplitLevel(&split_level);
      if (split_level != SplitLevel::kLevelNone) {
        int offset = split_offset.GetLevelValue(split_level);
        sliced_labels->emplace_back(full_labels.begin() + begin,
                                    full_labels.begin() + begin + offset);
        split_offset.RemoveLevelAndRefresh(split_level);
        begin += offset;
        sp_size = max_sp_size;
      } else {
        if (sp_size < max_sp_size) {
          sp_size += sp_step;
        } else {
          sliced_labels->emplace_back(full_labels.begin() + begin,
                                      full_labels.begin() + begin + sp_size);
          begin += sp_size;
        }
      }
    }
  }
  if (begin < full_labels.size()) {
    sliced_labels->emplace_back(full_labels.begin() + begin, full_labels.end());
  }
  VLOG(2) << "split labels by lp finished ...";
}

bool SplitPoint::GetSplitLevel(int* level) const {
  for (size_t i = 0; i < level_values_.size(); ++i) {
    if (level_values_[i]) {
      *level = i;
      return true;
    }
  }
  return false;
}

int SplitPoint::GetLevelValue(int level) const {
  return level_values_.at(level);
}

void SplitPoint::SetLevelValue(int level, int value) {
  for (size_t i = level; i < level_values_.size(); ++i) {
    level_values_[i] = value;
  }
}

void SplitPoint::RemoveLevelAndRefresh(int level) {
  int split_value = level_values_.at(level);
  for (size_t i = level; i < level_values_.size(); ++i) {
    level_values_[i] -= split_value;
  }
}

void SplitLabelsByLanguage(const vector<string>& sliced_labels,
                           vector<string>* languages,
                           vector<vector<string>>* language_labels) {
  // cur word pos
  static RE2 b4_pattern("-([a-zA-Z]+)@");
  static RE2 p3_all_lower_pattern("-([a-z]+)\\+");
  vector<string> b4s;
  vector<bool> p3s;
  for (const auto& sliced_label : sliced_labels) {
    string b4;
    RE2::Extract(sliced_label, b4_pattern, "\\1", &b4);
    b4s.emplace_back(b4);
    p3s.push_back(RE2::PartialMatch(sliced_label, p3_all_lower_pattern));
  }

  string language_tmp = kMandarinTypeString;
  vector<string> labels_tmp;
  for (size_t i = 0; i < b4s.size(); ++i) {
    if (i == 0) {
      labels_tmp.emplace_back(sliced_labels[i]);
      // first one
      if (b4s[i] == "En" && !p3s[i]) {
        language_tmp = kEnglishTypeString;
      } else if (b4s[i] == "X") {
        if (i != b4s.size() - 1 && b4s[i + 1] == "En") {
          language_tmp = kEnglishTypeString;
        }
      }
    } else {
      if (b4s[i] == "X") {
        if (i == b4s.size() - 1 || language_tmp == kMandarinTypeString ||
            (b4s[i + 1] == "En" && !p3s[i + 1])) {
          // TODO(zhengzhang): fix "En" "X" as static variable in the future
          labels_tmp.emplace_back(sliced_labels[i]);
        } else {
          // not last one, cur language is English, next language is Mandarin
          //  ignore continues sp and lp
          languages->emplace_back(std::move(language_tmp));
          language_labels->emplace_back(std::move(labels_tmp));
          language_tmp = kMandarinTypeString;
          labels_tmp.emplace_back(sliced_labels[i]);
        }
      } else if (b4s[i] == "En" && !p3s[i]) {
        if (language_tmp == kEnglishTypeString) {
          labels_tmp.emplace_back(sliced_labels[i]);
        } else {
          languages->emplace_back(std::move(language_tmp));
          language_labels->emplace_back(std::move(labels_tmp));
          language_tmp = kEnglishTypeString;
          labels_tmp.emplace_back(sliced_labels[i]);
        }
      } else {  // mandarin
        if (language_tmp == kMandarinTypeString) {
          labels_tmp.emplace_back(sliced_labels[i]);
        } else {
          languages->emplace_back(std::move(language_tmp));
          language_labels->emplace_back(std::move(labels_tmp));
          language_tmp = kMandarinTypeString;
          labels_tmp.emplace_back(sliced_labels[i]);
        }
      }
    }
  }
  if (!labels_tmp.empty()) {
    languages->emplace_back(std::move(language_tmp));
    language_labels->emplace_back(std::move(labels_tmp));
  }
  return;
}

string AppendPath(const string& dir, const string& rela_path) {
  if (rela_path.empty() || IsHttpUrl(rela_path)) return rela_path;
  return dir + rela_path;
}

void SplitStringToVector(const string& full, const string& split_string,
                         bool omit_empty_strings, vector<string>* out) {
  CHECK(out != NULL);
  out->clear();

  size_t start = 0, end = full.size();
  size_t found = 0;
  while (found != string::npos) {
    found = full.find(split_string, start);

    // start != end condition is for when the delimiter is at the end.
    if (!omit_empty_strings || (found != start && start != end))
      out->push_back(full.substr(start, found - start));
    start = found + split_string.size();
  }
}

#ifndef FOR_PORTABLE
bool RunOsSytemCmd(const string& cmd) {
  pid_t status;
  status = system(cmd.c_str());
  if (WIFEXITED(status)) {
    if (WEXITSTATUS(status) == 0) {
      return true;
    } else {
      LOG(ERROR) << "fail run: " << cmd << ",code: " << WEXITSTATUS(status);
      return false;
    }
  } else {
    LOG(ERROR) << "fail run: " << cmd << ",code: " << WIFEXITED(status);
    return false;
  }
}
#endif

};  // namespace tts
