// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/util/tts_util/test_perf.h"
#include "third_party/gtest/gtest.h"

namespace tts {

TEST(TestPerfTest, AccuracyTest) {
  TestPerf performance;
  performance.add_tp();
  performance.add_tn();
  performance.add_fp();
  performance.add_fn();
  ASSERT_EQ(0.5, performance.Accuracy());
}

TEST(TestPerfTest, PreciseTest) {
  TestPerf performance;
  performance.add_tp(3);
  performance.add_tn();
  performance.add_fp();
  performance.add_fn();
  ASSERT_EQ(0.75, performance.Precise());
}

TEST(TestPerfTest, RecallTest) {
  TestPerf performance;
  performance.add_tp(1);
  performance.add_tn(3);
  performance.add_fp();
  performance.add_fn(3);
  ASSERT_EQ(0.25, performance.Recall());
}

}  // namespace tts
