// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_UTIL_ENCODER_MP3_ENCODER_H_
#define TTS_UTIL_ENCODER_MP3_ENCODER_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"

namespace encoder {

bool ConvertWaveToMp3(const vector<int16>& data, int sampling_frequency,
                      bool high_quality, string* mp3_data);

bool ConvertWaveToMp3(const int16* data, int size, int sampling_frequency,
                      bool high_quality, string* mp3_data, int* padding_size);

// mp3 data include 4 bytes padding size, 4 bytes data size, rest data
bool ConvertWaveToMp3Streaming(const vector<int16>& data,
                               int sampling_frequency, bool high_quality,
                               string* mp3_data);

// mp3 data include 4 bytes padding size, 4 bytes data size, rest data
bool ConvertWaveToMp3Streaming(const int16* data, int size,
                               int sampling_frequency, bool high_quality,
                               string* mp3_data);

// Decode mp3 data into pcm data and not remove padding data
bool DecodeMp3(const string& mp3_data, vector<int16>* data,
               int* sampling_frequency);

// Decode mp3 data to pcm data with removing extra padding data
bool DecodeMp3(const string& mp3_data, int padding_size, vector<int16>* data,
               int* sampling_frequency);

// Decode streaming mp3 data to pcm
bool DecodeMp3Streaming(const string& mp3_data, vector<int16>* data,
                        int* sampling_frequency);

}  // namespace encoder
#endif  // TTS_UTIL_ENCODER_MP3_ENCODER_H_
