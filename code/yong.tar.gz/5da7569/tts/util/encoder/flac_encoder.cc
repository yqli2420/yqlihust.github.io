// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: yunlinchen@mobvoi.com (Yunlin Chen)

#include "tts/util/encoder/flac_encoder.h"

#include <algorithm>
#include <cstring>
#include <string>
#include <vector>

#include "mobvoi/base/compat.h"
#include "mobvoi/base/log.h"
#include "third_party/flac-1.3.2/include/FLAC++/encoder.h"
#include "third_party/flac-1.3.2/include/FLAC++/metadata.h"
#include "third_party/flac-1.3.2/include/share/compat.h"

DEFINE_int32(flac_compression_level, 4,
             "0 (fastest, least compression) to 8 (slowest, most compression)");

namespace encoder {

bool ConvertWaveToFlac(const vector<int16>& data, int sampling_frequency,
                       FlacEncoder* encoder, string* flac_data) {
  int chunk_size = 1024;
  int data_size = data.size();
  while (data_size > 0) {
    int encode_size = data_size - chunk_size > 0 ? chunk_size : data_size;
    encoder->EncodeInterleaved(data.data() + data.size() - data_size,
                               encode_size, false);
    data_size -= encode_size;
    //     encoder->Finish();
    flac_data->append(encoder->GetAvailableEncodedData());
  }
  VLOG(1) << data.size();
  return true;
}
}  // namespace encoder
