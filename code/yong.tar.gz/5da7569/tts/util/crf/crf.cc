// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaoqin.feng@mobvoi.com

#include "tts/util/crf/crf.h"

namespace crf {

CrfModel::CrfModel(const string& crf_file) {
  LoadModel(crf_file);
  for (size_t i = 0; i < model_size_.size(); ++i) {
    LoadCrfModel(model_size_[i], model_string_[i],
                 decoder_feature_list_[i].get());
  }
}

CrfModel::~CrfModel() {
  for (int i = 0; i < total_model_level_; i++) {
    delete[] model_string_[i];
  }
}

void CrfModel::LoadCrfModel(const int size, const char* model,
                            CRFPP::DecoderFeatureIndex* decoder_feature) const {
  // TODO(xiaoqinfeng): support mmap in the future
  if (!decoder_feature->openFromArray(model, size)) {
    LOG(FATAL) << decoder_feature->what();
  }
}

void CrfModel::LoadModel(const string& crf_file) {
  FILE* fp = fopen(crf_file.c_str(), "rb");
  CHECK(fp) << "can't find" << crf_file;
  fread(&total_model_level_, sizeof(int), 1, fp);
  VLOG(3) << "crf model file : " << crf_file;
  VLOG(3) << "total model level : " << total_model_level_;
  decoder_feature_list_.resize(total_model_level_);
  for (int i = 0; i < total_model_level_; ++i) {
    double temp_factor = 0;
    fread(&temp_factor, sizeof(double), 1, fp);
    decoder_model_factor_.emplace_back(temp_factor);
    decoder_feature_list_[i].reset(new CRFPP::DecoderFeatureIndex);
  }
  for (int i = 0; i < total_model_level_; ++i) {
    int temp_size = 0;
    fread(&temp_size, sizeof(int), 1, fp);
    model_size_.emplace_back(temp_size);
    model_string_.emplace_back(new char[model_size_[i]]);
  }
  for (int i = 0; i < total_model_level_; ++i) {
    fread(model_string_[i], model_size_[i], 1, fp);
  }
  fclose(fp);
}

bool CrfModel::DoCrfPred(const int model_level, vector<string> feat_lines,
                         vector<string>* pred_result) const {
  CRFPP::TaggerImpl tagger;
  const int kNbest = 1;
  const int kVerboseLevel = 0;
  if (!tagger.open(DecoderFeatureIndex(model_level), kNbest, kVerboseLevel,
                   feat_lines.size())) {
    LOG(ERROR) << tagger.what();
    return false;
  }
  tagger.set_cost_factor(DecoderModelFactor(model_level));
  for (auto feat_line : feat_lines) {
    tagger.add(feat_line.c_str(), feat_line.size());
  }
  if (!tagger.parse()) {
    VLOG(2) << "Fail to parse";
    return false;
  }
  if (tagger.empty()) {
    VLOG(2) << "tagger is empty.";
    return false;
  }
  VLOG(3) << tagger.toString();
  size_t tlen = tagger.size();
  for (size_t i = 0; i < tlen; ++i) {
    pred_result->emplace_back(tagger.y2(i));
  }
  return true;
}

bool CrfModel::DoCrfPred(const int model_level, const vector<string> feat_lines,
                         vector<string>* pred_result,
                         vector<map<string, float>>* top_result) const {
  CRFPP::TaggerImpl tagger;
  const int kNbest = 1;
  const int kVerboseLevel = 0;
  if (!tagger.open(DecoderFeatureIndex(model_level), kNbest, kVerboseLevel,
                   feat_lines.size())) {
    LOG(ERROR) << tagger.what();
    return false;
  }
  tagger.set_cost_factor(DecoderModelFactor(model_level));
  for (auto feat_line : feat_lines) {
    tagger.add(feat_line.c_str(), feat_line.size());
  }
  if (!tagger.parse()) {
    VLOG(2) << "Fail to parse";
    return false;
  }
  if (tagger.empty()) {
    VLOG(2) << "tagger is empty.";
    return false;
  }
  VLOG(3) << tagger.toString();
  size_t tlen = tagger.size();
  for (size_t i = 0; i < tlen; ++i) {
    pred_result->emplace_back(tagger.y2(i));
    map<string, float> temp;
    for (size_t j = 0; j < tagger.ysize(); ++j) {
      temp.insert(std::make_pair(tagger.yname(j), tagger.prob(i, j)));
    }
    top_result->emplace_back(temp);
  }
  return true;
}

}  // namespace crf
