// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaoqin.feng@mobvoi.com

#include "tts/util/crf/crf.h"

#include "mobvoi/base/string_util.h"
#include "third_party/gtest/gtest.h"

namespace crf {

class CrfTest : public ::testing::Test {
 protected:
  virtual void SetUp() {
    const string crf_file =
        "external/config/front_end/polyphone/"
        "polyphone_model_wei";
    crf_model_.reset(new CrfModel(crf_file));
  }
  void PredTest(const int model_level, const vector<string> &feat_lines,
                const vector<string> &result) const {
    vector<string> pred_result;
    crf_model_->DoCrfPred(model_level, feat_lines, &pred_result);
    for (size_t i = 0; i < result.size(); ++i) {
      EXPECT_EQ(result[i], pred_result[i]);
    }
  }

  std::unique_ptr<CrfModel> crf_model_;
};

#ifndef FOR_PORTABLE
TEST_F(CrfTest, CrfModelTest) {
  vector<string> feat_lines;
  vector<string> result;
  const vector<string> feat_word = {
      "word", "word", "他",  "自",  "以",  "为",  "不",  "得",  "了",
      "word", "word", "pos", "pos", "pos", "pos", "pos", "pos", "pos"};
  const string target = "wei2";
  feat_lines.emplace_back(JoinVector(feat_word, '\t'));
  result.emplace_back(target);
  PredTest(0, feat_lines, result);
}
#endif

}  // namespace crf
