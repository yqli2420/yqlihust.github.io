// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: yongqiangli@mobvoi.com

#include "mobvoi/base/file.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/string_util.h"
#include "tts/util/tts_util/util.h"

DEFINE_string(save_path, "", "");
DEFINE_string(pack_dict, "", "");
DEFINE_string(crf_cost_factor, "", "");

void GenModelData(const string& file_dict, vector<string>* model_string,
                  vector<int>* model_size) {
  string temp_string;
  mobvoi::File::ReadFileToStringOrDie(file_dict, &temp_string);
  model_string->push_back(temp_string);
  model_size->push_back(temp_string.size());
}

// Packs crf_model infos (use by tts-trainer).
int main(int argc, char** argv) {
  google::ParseCommandLineFlags(&argc, &argv, false);
  vector<int> model_size;
  vector<string> model_string;
  vector<string> pack_paths;
  SplitString(FLAGS_pack_dict, ',', &pack_paths);
  vector<string> crf_cost_factors;
  SplitString(FLAGS_crf_cost_factor, ',', &crf_cost_factors);
  for (auto pack_path : pack_paths) {
    LOG(INFO) << "start pack " << pack_path;
    GenModelData(pack_path.c_str(), &model_string, &model_size);
  }
  FILE* fp = fopen(FLAGS_save_path.c_str(), "wb");
  size_t total_level = model_size.size();
  fwrite(&total_level, sizeof(int), 1, fp);
  for (size_t i = 0; i < total_level; ++i) {
    double temp_factor = StringToDouble(crf_cost_factors[i]);
    fwrite(&temp_factor, sizeof(double), 1, fp);
  }
  for (size_t i = 0; i < total_level; ++i) {
    fwrite(&model_size[i], sizeof(int), 1, fp);
  }
  for (size_t i = 0; i < total_level; ++i) {
    fwrite(model_string[i].c_str(), model_size[i], 1, fp);
  }
  fclose(fp);
  return 0;
}
