// Copyright 2005-2009 The RE2 Authors.  All Rights Reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Modified from Google perftools's tcmalloc_unittest.cc.

#include "tts/util/random/random.h"

namespace util {

int32 ACMRandom::Next() {
  const int32 M = 2147483647L;  // 2^31-1
  const int32 A = 16807;
  // In effect, we are computing seed_ = (seed_ * A) % M, where M = 2^31-1
  uint32 lo = A * (int32)(seed_ & 0xFFFF);       // NOLINT
  uint32 hi = A * (int32)((uint32)seed_ >> 16);  // NOLINT
  lo += (hi & 0x7FFF) << 16;
  if (lo > static_cast<uint32>(M)) {
    lo &= M;
    ++lo;
  }
  lo += hi >> 15;
  if (lo > static_cast<uint32>(M)) {
    lo &= M;
    ++lo;
  }
  return (seed_ = (int32)lo);  // NOLINT
}

int32 ACMRandom::Uniform(int32 n) { return Next() % n; }

UnifRealRandom::UnifRealRandom(uint64_t seed, double left, double right)
    : left_(left), right_(right) {
  std::seed_seq ss{uint32_t(seed & 0xffffffff), uint32_t(seed >> 32)};
  rng_.seed(ss);
  unif_.reset(new std::uniform_real_distribution<double>(left_, right_));
}

double UnifRealRandom::Uniform() { return (*(unif_.get()))(rng_); }

}  // namespace util
