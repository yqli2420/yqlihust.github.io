// Copyright 2005-2009 The RE2 Authors.  All Rights Reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// Modified from Google perftools's tcmalloc_unittest.cc.

#ifndef TTS_UTIL_RANDOM_RANDOM_H_
#define TTS_UTIL_RANDOM_RANDOM_H_

#include <chrono>  // NOLINT
#include <random>

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"

namespace util {

// ACM minimal standard random number generator.  (re-entrant.)
class ACMRandom {
 public:
  explicit ACMRandom(int32 seed) : seed_(seed) {}

  int32 Next();
  int32 Uniform(int32);

  void Reset(int32 seed) { seed_ = seed; }

 private:
  int32 seed_;
};

// Uniform sampling based on std::uniform_real_distribution
class UnifRealRandom {
 public:
  UnifRealRandom(uint64_t seed, double left, double right);

  double Uniform();

 private:
  double left_;
  double right_;
  std::mt19937_64 rng_;
  std::unique_ptr<std::uniform_real_distribution<double>> unif_;
};

}  // namespace util

#endif  // TTS_UTIL_RANDOM_RANDOM_H_
