// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/util/ssml/ssml_parser.h"

#include "mobvoi/base/file.h"
#include "mobvoi/base/string_util.h"
#include "third_party/gtest/gtest.h"
#include "tts/util/tts_util/util.h"

namespace tts {

static const string kTestDataDir = "tts/util/ssml/testdata/";  // NOLINT

void SsmlTest(const vector<string>& expect_texts,
              const vector<string>& expect_tags,
              const vector<SsmlText>& ssml_texts) {
  EXPECT_EQ(expect_texts.size(), expect_tags.size());
  EXPECT_EQ(expect_texts.size(), ssml_texts.size());
  for (size_t i = 0; i < ssml_texts.size(); ++i) {
    EXPECT_EQ(expect_texts[i], ssml_texts[i].text);
    EXPECT_EQ(expect_tags[i], LogSsmlTag(ssml_texts[i].tag));
  }
}

TEST(IsSsml, IsSsmlCase) {
  xmlDocPtr doc1;
  string text;

  text = "<speak>test</speak>";
  EXPECT_TRUE(SsmlParser::Instance().IsSsml(text, &doc1));

  xmlDocPtr doc2;
  text = "speak><xxx hello <xxx>></speak>";
  EXPECT_FALSE(SsmlParser::Instance().IsSsml(text, &doc2));
  xmlFreeDoc(doc1);
  xmlFreeDoc(doc2);
}

TEST(IsSsmlFast, IsSsmlCase2) {
  string text;
  text = "<speak>test</speak>";
  EXPECT_TRUE(SsmlParser::Instance().IsSsmlFast(text));

  text = "<speak>hello";
  EXPECT_FALSE(SsmlParser::Instance().IsSsmlFast(text));
}

// TODO(zhengzhang): add error format ssml checking test

TEST(ParseText, ssml1) {
  const string test_file = kTestDataDir + "ssml1.xml";
  string text;
  mobvoi::File::ReadFileToStringOrDie(test_file, &text);

  vector<SsmlText> ssml_texts;
  SsmlParser::Instance().ParseText(text, &ssml_texts);
  // SsmlParser::Instance().LogSsml(ssml_texts);

  vector<string> expect_texts;
  vector<string> expect_tags;
  expect_texts.push_back("");
  expect_texts.push_back("\n    杨浦区今天多云，30°C到40°C，");
  expect_texts.push_back("xyz");
  expect_texts.push_back(
      "当前温度是33°C。夏日炎炎，衣物轻薄透气，室外注意遮阳避暑，"
      "室内酌情添加空调衫，不建议在露天场所逛街。\n");

  expect_tags.push_back("audio path: http://abc/123.wav");
  expect_tags.push_back("");
  expect_tags.push_back("audio path: http://abc/123.wav");
  expect_tags.push_back("");

  SsmlTest(expect_texts, expect_tags, ssml_texts);
}

TEST(ParseText, ssml2) {
  string test_file = kTestDataDir + "ssml2.xml";
  string text;
  mobvoi::File::ReadFileToStringOrDie(test_file, &text);

  vector<SsmlText> ssml_texts;
  SsmlParser::Instance().ParseText(text, &ssml_texts);
  // SsmlParser::Instance().LogSsml(ssml_texts);

  vector<string> expect_texts;
  vector<string> expect_tags;
  expect_texts.push_back("");
  expect_texts.push_back("\n    杨浦区今天多云，30°C到40°C，");
  expect_texts.push_back("xyz");
  expect_texts.push_back("当前温度是33°C。夏日炎炎，给");
  expect_texts.push_back("单田芳");
  expect_texts.push_back("和");
  expect_texts.push_back("解朝阳");
  expect_texts.push_back("打个电话，衣物轻薄透气，室外注意遮阳避暑，室内酌情");
  expect_texts.push_back("");
  expect_texts.push_back("添加空调衫，不建议在露天场所逛街。\n");

  expect_tags.push_back("audio path: http://abc/123.wav");
  expect_tags.push_back("");
  expect_tags.push_back("audio path: http://abc/123.wav");
  expect_tags.push_back("");
  expect_tags.push_back("say-as interpret-as: contact");
  expect_tags.push_back("");
  expect_tags.push_back("say-as interpret-as: contact");
  expect_tags.push_back("");
  expect_tags.push_back("break time: 1000ms");
  expect_tags.push_back("");

  SsmlTest(expect_texts, expect_tags, ssml_texts);
}

TEST(ParseText, ssml3) {
  string test_file = kTestDataDir + "ssml3.xml";
  string text;
  mobvoi::File::ReadFileToStringOrDie(test_file, &text);

  vector<SsmlText> ssml_texts;
  SsmlParser::Instance().ParseText(text, &ssml_texts);
  // SsmlParser::Instance().LogSsml(ssml_texts);

  vector<string> expect_texts;
  vector<string> expect_tags;
  expect_texts.push_back("");
  expect_texts.push_back("\n    杨浦区今天多云，30°C到40°C，");
  expect_texts.push_back("xyz");
  expect_texts.push_back("当前温度是33°C。夏日炎炎，给");
  expect_texts.push_back("单田芳");
  expect_texts.push_back("和");
  expect_texts.push_back("解朝阳");
  expect_texts.push_back("打个电话，衣物轻薄透气，室外注意遮阳避暑，室");
  expect_texts.push_back("真逆龄有声书摘-5");
  expect_texts.push_back("内酌情添加空调衫，不建议在露天场所逛街。\n");

  expect_tags.push_back("audio path: http://abc/123.wav");
  expect_tags.push_back("");
  expect_tags.push_back("audio path: http://abc/123.wav");
  expect_tags.push_back("");
  expect_tags.push_back("say-as interpret-as: contact");
  expect_tags.push_back("");
  expect_tags.push_back("say-as interpret-as: contact");
  expect_tags.push_back("");
  expect_tags.push_back("say-as interpret-as: book-name");
  expect_tags.push_back("");

  SsmlTest(expect_texts, expect_tags, ssml_texts);
}

TEST(ParseText, ssml6) {
  string test_file = kTestDataDir + "ssml6.xml";
  string text;
  mobvoi::File::ReadFileToStringOrDie(test_file, &text);

  vector<SsmlText> ssml_texts;
  SsmlParser::Instance().ParseText(text, &ssml_texts);
  // SsmlParser::Instance().LogSsml(ssml_texts);

  vector<string> expect_texts;
  vector<string> expect_tags;

  expect_texts.push_back("");
  expect_texts.push_back("这是");
  expect_texts.push_back("");
  expect_texts.push_back("一个测试样例");
  expect_texts.push_back("");
  expect_texts.push_back("");

  expect_tags.push_back("break time: 1000ms");
  expect_tags.push_back("");
  expect_tags.push_back("break time: 1000ms");
  expect_tags.push_back("");
  expect_tags.push_back("break time: 1000ms");
  expect_tags.push_back("break time: 1000ms");

  SsmlTest(expect_texts, expect_tags, ssml_texts);
}

TEST(ParseText, IllegalSsml) {
  string test_file = kTestDataDir + "ssml7.xml";
  string text;
  mobvoi::File::ReadFileToStringOrDie(test_file, &text);

  vector<SsmlText> ssml_texts;
  SsmlParser::Instance().ParseText(text, &ssml_texts);
  // SsmlParser::Instance().LogSsml(ssml_texts);

  vector<string> expect_texts;
  vector<string> expect_tags;

  expect_texts.push_back("这是");
  expect_texts.push_back("测试");

  expect_tags.push_back("");
  expect_tags.push_back("");

  SsmlTest(expect_texts, expect_tags, ssml_texts);
}

SsmlText FormBreakSsml(const string& time_attr) {
  SsmlTag ssml_tag(kSsmlBreakKey);
  ssml_tag.attrs.insert(std::make_pair(kSsmlBreakTime, time_attr));
  return SsmlText("", ssml_tag);
}

TEST(UtilUnitTest, ParseBreakTime) {
  string time_attr;
  float expect_time;

  time_attr = "100ms";
  expect_time = 0.1;
  EXPECT_EQ(expect_time, ParseBreakTime(FormBreakSsml(time_attr)));

  time_attr = "2.23s";
  expect_time = 2.23;
  EXPECT_EQ(expect_time, ParseBreakTime(FormBreakSsml(time_attr)));

  time_attr = "2.23ss";
  expect_time = 0;
  EXPECT_EQ(expect_time, ParseBreakTime(FormBreakSsml(time_attr)));

  time_attr = "322.2ms";
  expect_time = 0.3222;
  EXPECT_EQ(expect_time, ParseBreakTime(FormBreakSsml(time_attr)));
}

}  // namespace tts
