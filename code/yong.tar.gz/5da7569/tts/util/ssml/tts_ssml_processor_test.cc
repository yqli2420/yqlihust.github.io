// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com

#include <string>
#include <list>

#include "mobvoi/base/log.h"
#include "third_party/gtest/gtest.h"
#include "tts/util/ssml/tts_ssml_entity.h"
#include "tts/util/ssml/tts_ssml_processor.h"

namespace mobvoi {

DEFINE_string(server, "localhost:8080", "grpc server");
DEFINE_string(host, "localhost", "service host");
DEFINE_string(port, "8080", "service port");

class TtsSsmlTest {
 public:
  bool Test(const std::string& text,
      std::list<TtsSsmlEntity>* ssml_entity_list_in) {
    std::list<TtsSsmlEntity> ssml_entity_list_out;
    TtsSsmlProcessor ssml_processor;
    ssml_processor.Analyze(text, &ssml_entity_list_out);

    bool success = true;
    if (ssml_entity_list_in->size() == ssml_entity_list_out.size()) {
      std::list<TtsSsmlEntity>::iterator it1;
      std::list<TtsSsmlEntity>::iterator it2;
      for (it1 = ssml_entity_list_in->begin(),
           it2 = ssml_entity_list_out.begin();
           it1 != ssml_entity_list_in->end() &&
           it2 != ssml_entity_list_out.end();
           ++it1, ++it2) {
        LOG(INFO) << "size: " << ssml_entity_list_in->size();
        if (!((*it1) == (*it2))) {
          success = false;
        }
        LOG(INFO) << "label: [" << it1->GetSsmlLabel()
                  << "], [" << it2->GetSsmlLabel() << "]";
        LOG(INFO) << "text: [" << it1->GetSsmlText()
                  << "], [" << it2->GetSsmlText() << "]";
        LOG(INFO) << "ssml: [" << it1->GetValueAsSsml()
                  << "], [" << it2->GetValueAsSsml() << "]";
        LOG(INFO) << "voice: [" << it1->GetVoiceName()
                  << "], [" << it2->GetVoiceName() << "]";
        LOG(INFO) << "rate: [" << it1->GetProsodyRate()
                  << "], [" << it2->GetProsodyRate() << "]";
        LOG(INFO) << "content: [" << it1->GetSsmlContent()
                  << "], [" << it2->GetSsmlContent() << "]";
      }
    } else {
      LOG(INFO) << "size error";
      success = false;
    }

    for (auto& it : *ssml_entity_list_in) {
       VLOG(1) << "ssml text: " << it.GetSsmlText()
          << ", label: " << it.GetSsmlLabel()
          << ", speed: " << it.GetProsodyRate()
          << ", volume: " << it.GetProsodyVolume();
    }

    for (auto& it : ssml_entity_list_out) {
      VLOG(1) << "ssml text: " << it.GetSsmlText()
          << ", label: " << it.GetSsmlLabel()
          << ", speed: " << it.GetProsodyRate()
          << ", volume: " << it.GetProsodyVolume();
    }

    return success;
  }
};

TEST(TtsSsmlProcessor, SsmlTest) {
  std::string text0 = "<speak>\n"
                      "  <prosody rate=\"1.2\" volume=\"1.2\">"
                      "    <audio src=\"1.wav\" />\n"
                      "    <audio src=\"2.wav\" />\n"
                      "  </prosody>\n"
                      "  <audio src=\"3.wav\" />\n"
                      "  <prosody rate=\"1.3\" volume=\"1.3\">"
                      "    出门问问\n"
                      "  </prosody>\n"
                      "  <p>12345</p>"
                      "</speak>";

  std::list<TtsSsmlEntity> ssml_entity_list_in0;
  TtsSsmlEntity ssml_entity;
  ssml_entity.Clear();
  ssml_entity.SetSsmlLabel("audio");
  ssml_entity.SetAudioSrc("1.wav");
  ssml_entity.SetProsodyRate("1.2");
  ssml_entity.SetProsodyVolume("1.2");
  ssml_entity_list_in0.push_back(ssml_entity);
  ssml_entity.Clear();
  ssml_entity.SetSsmlLabel("audio");
  ssml_entity.SetAudioSrc("2.wav");
  ssml_entity.SetProsodyRate("1.2");
  ssml_entity.SetProsodyVolume("1.2");
  ssml_entity_list_in0.push_back(ssml_entity);
  ssml_entity.Clear();
  ssml_entity.SetSsmlLabel("audio");
  ssml_entity.SetAudioSrc("3.wav");
  ssml_entity.SetProsodyRate("1.0");
  ssml_entity.SetProsodyVolume("1.0");
  ssml_entity_list_in0.push_back(ssml_entity);
  ssml_entity.Clear();
  ssml_entity.SetSsmlLabel("text");
  ssml_entity.SetProsodyRate("1.3");
  ssml_entity.SetProsodyVolume("1.3");
  ssml_entity.SetSsmlText("出门问问");
  ssml_entity_list_in0.push_back(ssml_entity);
  ssml_entity.Clear();
  ssml_entity.SetSsmlLabel("text");
  ssml_entity.SetProsodyRate("1.0");
  ssml_entity.SetProsodyVolume("1.0");
  ssml_entity.SetSsmlText("12345");
  ssml_entity_list_in0.push_back(ssml_entity);

  std::string text1 = "<speak>\n"
                     "  <audio src=\"1.wav\" />\n"
                     "  <audio src=\"2.wav\" />\n"
                     "</speak>";
  std::list<TtsSsmlEntity> ssml_entity_list_in1;
  ssml_entity.Clear();
  ssml_entity.SetSsmlLabel("audio");
  ssml_entity.SetAudioSrc("1.wav");
  ssml_entity_list_in1.push_back(ssml_entity);
  ssml_entity.Clear();
  ssml_entity.SetSsmlLabel("audio");
  ssml_entity.SetAudioSrc("2.wav");
  ssml_entity_list_in1.push_back(ssml_entity);

  std::string text2 = "<speak>\n"
                      "  <audio src=\"1.wav\" />\n"
                      "  出门问问\n"
                      "  <audio src=\"2.wav\" />\n"
                      "</speak>";
  std::list<TtsSsmlEntity> ssml_entity_list_in2;
  ssml_entity.Clear();
  ssml_entity.SetSsmlLabel("audio");
  ssml_entity.SetAudioSrc("1.wav");
  ssml_entity_list_in2.push_back(ssml_entity);
  ssml_entity.Clear();
  ssml_entity.SetSsmlLabel("text");
  ssml_entity.SetSsmlText("出门问问");
  ssml_entity_list_in2.push_back(ssml_entity);
  ssml_entity.Clear();
  ssml_entity.SetSsmlLabel("audio");
  ssml_entity.SetAudioSrc("2.wav");
  ssml_entity_list_in2.push_back(ssml_entity);

  std::string text3 =
      "<speak>\n"
      "  <audio src=\"1.wav\" />\n"
      "  <prosody rate=\"1.2\" volume=\"1.2\">出门问问</prosody>\n"
      "  <audio src=\"2.wav\" />\n"
      "</speak>";
  std::list<TtsSsmlEntity> ssml_entity_list_in3;
  ssml_entity.Clear();
  ssml_entity.SetSsmlLabel("audio");
  ssml_entity.SetAudioSrc("1.wav");
  ssml_entity_list_in3.push_back(ssml_entity);
  ssml_entity.Clear();
  ssml_entity.SetSsmlLabel("text");
  ssml_entity.SetSsmlText("出门问问");
  ssml_entity.SetProsodyRate("1.2");
  ssml_entity.SetProsodyVolume("1.2");
  ssml_entity_list_in3.push_back(ssml_entity);
  ssml_entity.Clear();
  ssml_entity.SetSsmlLabel("audio");
  ssml_entity.SetAudioSrc("2.wav");
  ssml_entity_list_in3.push_back(ssml_entity);

  std::string text4 = "<speak>\n"
                      "  <prosody rate=\"1.3\">"
                      "  <prosody rate=\"1.2\" volume=\"1.2\">"
                      "    <audio src=\"1.wav\" />\n"
                      "  </prosody>"
                      "  <prosody rate=\"1.2\" volume=\"1.2\">"
                      "    出门问问"
                      "  </prosody>\n"
                      "  <audio src=\"2.wav\" />\n"
                      "  </prosody>\n"
                      "</speak>";
  std::list<TtsSsmlEntity> ssml_entity_list_in4;
  ssml_entity.Clear();
  ssml_entity.SetSsmlLabel("audio");
  ssml_entity.SetAudioSrc("1.wav");
  ssml_entity.SetProsodyRate("1.2");
  ssml_entity.SetProsodyVolume("1.2");
  ssml_entity_list_in4.push_back(ssml_entity);
  ssml_entity.Clear();
  ssml_entity.SetSsmlLabel("text");
  ssml_entity.SetSsmlText("出门问问");
  ssml_entity.SetProsodyRate("1.2");
  ssml_entity.SetProsodyVolume("1.2");
  ssml_entity_list_in4.push_back(ssml_entity);
  ssml_entity.Clear();
  ssml_entity.SetSsmlLabel("audio");
  ssml_entity.SetAudioSrc("2.wav");
  ssml_entity.SetProsodyRate("1.3");
  ssml_entity_list_in4.push_back(ssml_entity);

  std::string text5 = "<speak>\n"
                      "  <prosody rate=\"1.2\" volume=\"1.2\">"
                      "    我是"
                      "  </prosody>"
                      "  <prosody rate=\"1.2\" volume=\"1.2\">"
                      "    出门问问"
                      "  </prosody>\n"
                      "</speak>";
  std::list<TtsSsmlEntity> ssml_entity_list_in5;
  ssml_entity.Clear();
  ssml_entity.SetSsmlLabel("text");
  ssml_entity.SetSsmlText("我是出门问问");
  ssml_entity.SetProsodyRate("1.2");
  ssml_entity.SetProsodyVolume("1.2");
  ssml_entity_list_in5.push_back(ssml_entity);

  std::string text6 = "<speak>\n"
                      "  <prosody rate=\"1.0\" volume=\"1.0\">"
                      "    我是"
                      "  </prosody>"
                      "  <prosody rate=\"1.2\" volume=\"1.2\">"
                      "    出门问问"
                      "  </prosody>\n"
                      "</speak>";
  std::list<TtsSsmlEntity> ssml_entity_list_in6;
  ssml_entity.Clear();
  ssml_entity.SetSsmlLabel("text");
  ssml_entity.SetSsmlText("我是");
  ssml_entity.SetProsodyRate("1.0");
  ssml_entity.SetProsodyVolume("1.0");
  ssml_entity_list_in6.push_back(ssml_entity);
  ssml_entity.Clear();
  ssml_entity.SetSsmlLabel("text");
  ssml_entity.SetSsmlText("出门问问");
  ssml_entity.SetProsodyRate("1.2");
  ssml_entity.SetProsodyVolume("1.2");
  ssml_entity_list_in6.push_back(ssml_entity);

  std::string text7 = "<speak>\n"
                      "  <say-as interpret-as=\"building\">"
                      "    我是"
                      "  </say-as>"
                      "  <w phoneme=\"1234\">"
                      "    出门问问"
                      "  </w>\n"
                      "</speak>";
  std::list<TtsSsmlEntity> ssml_entity_list_in7;
  ssml_entity.Clear();
  ssml_entity.SetSsmlLabel("text");
  ssml_entity.SetSsmlText("我是出门问问");
  ssml_entity.SetSayAsInterpretAs("building");
  ssml_entity.SetWPhoneme("1234");
  ssml_entity_list_in7.push_back(ssml_entity);

  std::string text8 = "<speak>\n"
                      "    我是"
                      "  <w phoneme=\"1234\">"
                      "    出门问问"
                      "  </w>\n"
                      "</speak>";
  std::list<TtsSsmlEntity> ssml_entity_list_in8;
  ssml_entity.Clear();
  ssml_entity.SetSsmlLabel("text");
  ssml_entity.SetSsmlText("我是出门问问");
  ssml_entity.SetWPhoneme("1234");
  ssml_entity_list_in8.push_back(ssml_entity);

  std::string text9 = "<speak grammar=\"http://www.test.com\">\n"
                      "</speak>";
  std::list<TtsSsmlEntity> ssml_entity_list_in9;
  TtsSsmlProcessor ssml_processor;
  ssml_processor.Analyze(text9, &ssml_entity_list_in9);
  EXPECT_EQ(ssml_processor.GetAudioSaveUrl(), "http://www.test.com");

  TtsSsmlTest test;
  EXPECT_EQ(test.Test(text0, &ssml_entity_list_in0), true);
  EXPECT_EQ(test.Test(text1, &ssml_entity_list_in1), true);
  EXPECT_EQ(test.Test(text2, &ssml_entity_list_in2), true);
  EXPECT_EQ(test.Test(text3, &ssml_entity_list_in3), true);
  EXPECT_EQ(test.Test(text4, &ssml_entity_list_in4), true);
  EXPECT_EQ(test.Test(text5, &ssml_entity_list_in5), true);
  EXPECT_EQ(test.Test(text6, &ssml_entity_list_in6), true);
  EXPECT_EQ(test.Test(text7, &ssml_entity_list_in7), true);
  EXPECT_EQ(test.Test(text8, &ssml_entity_list_in8), true);
}
}  // namespace mobvoi
