// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengnzhang@mobvoi.com (Allen)

#include "tts/util/ssml/ssml_parser.h"

#include "mobvoi/base/file.h"
#include "mobvoi/base/flags.h"

DEFINE_string(input_file, "", "");
DEFINE_string(key_name, "", "");

int main(int argc, char** argv) {
  google::ParseCommandLineFlags(&argc, &argv, false);

  string text;
  mobvoi::File::ReadFileToStringOrDie(FLAGS_input_file, &text);

  vector<tts::SsmlText> ssml_texts;
  if (!FLAGS_key_name.empty()) {
    tts::SsmlParser::Instance().ParseText(text, FLAGS_key_name, &ssml_texts);
  } else {
    tts::SsmlParser::Instance().ParseText(text, &ssml_texts);
  }

  tts::SsmlParser::Instance().LogSsml(ssml_texts);
  return 0;
}
