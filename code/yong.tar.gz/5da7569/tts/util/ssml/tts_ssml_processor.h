// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com

#ifndef TTS_UTIL_SSML_TTS_SSML_PROCESSOR_H_
#define TTS_UTIL_SSML_TTS_SSML_PROCESSOR_H_

#include <list>
#include <string>

#include "third_party/xml2/libxml/parser.h"
#include "tts/util/ssml/tts_ssml_entity.h"

namespace mobvoi {

class TtsSsmlProcessor {
 public:
  TtsSsmlProcessor();
  virtual ~TtsSsmlProcessor();

 public:
  bool Analyze(const std::string& synth_text,
               std::list<TtsSsmlEntity>* tts_text_info_list);
  void SetRequestSpeed(const std::string& value);
  void SetRequestSpeaker(const std::string& value);
  void SetRequestSampleRate(int sample_rate);
  void SetAudioSaveUrl(const std::string& audio_save_url);
  std::string GetAudioSaveUrl();

  std::string TrimString(const std::string& str);
  std::string ReplaceString(
      const std::string& str,
      const std::string& str_src,
      const std::string& str_dst);

 private:
  std::string GetPropFromSsml(
      xmlNodePtr xml_cur, const char* key,
      const std::string& default_value = "");
  std::string GetStringFromSsml(xmlDocPtr xml_doc, xmlNodePtr xml_cur);
  std::string GetContentFromSsml(xmlDocPtr xml_doc, xmlNodePtr xml_cur);
  std::string GetNameFromSsml(xmlNodePtr xml_cur);
  bool AnalyzeSsmlText(
      xmlDocPtr xml_doc,
      xmlNodePtr xml_cur,
      TtsSsmlEntity* tts_ssml_entity,
      std::list<TtsSsmlEntity>* tts_text_info_list);

 private:
  std::string request_speed_;
  std::string request_speaker_;
  std::string audio_save_url_;
  int request_sample_rate_;
};

}  // namespace mobvoi

#endif  // TTS_UTIL_SSML_TTS_SSML_PROCESSOR_H_
