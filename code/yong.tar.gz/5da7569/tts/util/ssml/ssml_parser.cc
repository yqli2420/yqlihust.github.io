// Copyright 2017 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/util/ssml/ssml_parser.h"

#include "mobvoi/base/log.h"
#include "mobvoi/base/string_util.h"
#include "re2/re2.h"
#include "tts/util/tts_util/util.h"

namespace tts {

static const string kSsmlName = "speak";          // NOLINT
static const string kOptionName = "tts::prompt";  // NOLINT
static const char kXmlText[] = "text";
static re2::RE2 kTimePattern("(\\d+(?:\\.\\d+)?)(s|ms)");
static const int kSsmlTextMaxLen = 60;

bool IllegalSsml(const SsmlText& ssml_text) {
  if (ssml_text.tag.name.empty()) return false;
  if (util::utflen(ssml_text.text.c_str()) >= kSsmlTextMaxLen) {
    LOG(ERROR) << "ssml error (length limit): " << LogOneSsml(ssml_text);
    return true;
  }
  if (ssml_text.tag.name == kSsmlBreakKey) {
    if (ssml_text.tag.attrs.empty()) {
      LOG(ERROR) << "ssml error (miss break attrs): " << LogOneSsml(ssml_text);
      return true;
    }
    auto it = ssml_text.tag.attrs.find(kSsmlBreakTime);
    if (it != ssml_text.tag.attrs.end() &&
        !re2::RE2::FullMatch(it->second, kTimePattern)) {
      LOG(ERROR) << "ssml error (break pattern error): "
                 << LogOneSsml(ssml_text);
      return true;
    }
  }
  return false;
}

bool UnusedTag(const SsmlText& ssml_text) {
  return ssml_text.tag.name == kOptionName;
}

string LogSsmlTag(const SsmlTag& ssml_tag) {
  string dis_string = ssml_tag.name;
  for (const auto& attr : ssml_tag.attrs) {
    dis_string.append(" " + attr.first + ": " + attr.second);
  }
  return dis_string;
}

string LogOneSsml(const SsmlText& ssml_text) {
  string text_log = ssml_text.text;
  text_log += " -- " + LogSsmlTag(ssml_text.tag);
  return text_log;
}

string NodeToString(const xmlNode& node) {
  string output;
  string name = reinterpret_cast<const char*>(node.name);
  if (name == kXmlText) {
    output = reinterpret_cast<const char*>(node.content);
  } else {
    string name_content = name;
    for (xmlAttr* attr = node.properties; attr; attr = attr->next) {
      name_content +=
          string() + " " + reinterpret_cast<const char*>(attr->name) + "=\"" +
          reinterpret_cast<const char*>(attr->children->content) + "\"";
    }
    if (!node.children) {
      output = "<" + name_content + "/>";
    } else {
      string front = "<" + name_content + ">";
      string text;
      for (xmlNode* node2 = node.children; node2; node2 = node2->next) {
        text += NodeToString(*node2);
      }
      string end = "</" + name + ">";
      output = front + text + end;
    }
  }
  return output;
}

SsmlParser& SsmlParser::Instance() {
  static SsmlParser instance;
  return instance;
}

// extract ssml from text
void SsmlParser::ParseText(const string& text, vector<SsmlText>* ssml_texts) {
  string trimed;
  mobvoi::TrimWhitespaceASCII(text, mobvoi::TRIM_ALL, &trimed);
#ifndef FOR_PORTABLE
  RemoveUnsupportedTag(&trimed);
#endif
  xmlDocPtr doc;
  vector<SsmlText> ssml_texts_tmp;
  if (IsSsml(trimed, &doc)) {
    VLOG(2) << "is ssml";
    ParseSsml(doc, &ssml_texts_tmp);
  } else {
    VLOG(2) << "is not ssml";
    ssml_texts_tmp.emplace_back(trimed);
  }
  xmlFreeDoc(doc);
  ReplaceBreakTag(ssml_texts_tmp, ssml_texts);
  RestrictSsmlTag(ssml_texts);
  RemoveUnusedTag(ssml_texts);

  if (VLOG_IS_ON(2)) LogSsml(*ssml_texts);
}

void SsmlParser::ParseText(const string& text, const string& key_name,
                           vector<SsmlText>* ssml_texts) {
  string trimed;
  mobvoi::TrimWhitespaceASCII(text, mobvoi::TRIM_ALL, &trimed);
#ifndef FOR_PORTABLE
  RemoveUnsupportedTag(&trimed);
#endif
  xmlDocPtr doc;
  vector<SsmlText> ssml_texts_tmp;
  if (IsSsml(trimed, &doc)) {
    VLOG(2) << "is ssml";
    ParseSsml(doc, key_name, ssml_texts);
  } else {
    VLOG(2) << "is not ssml";
    ssml_texts->emplace_back(trimed);
  }
  xmlFreeDoc(doc);
  if (VLOG_IS_ON(2)) LogSsml(*ssml_texts);
}

SsmlText SsmlParser::GenBreakSsmlText(int ms) {
  SsmlTag break_tag(kSsmlBreakKey);
  // portable has no DoubleToString function
  string time_str = IntToString(static_cast<int>(kSilenceTagDuration * ms)) +
                    kSsmlBreakTimeMs;
  break_tag.attrs.insert(std::make_pair(kSsmlBreakTime, time_str));
  return SsmlText("", break_tag);
}

void SsmlParser::LogSsml(const vector<SsmlText>& ssml_texts) {
  for (const auto& ssml_text : ssml_texts) {
    LOG(INFO) << LogOneSsml(ssml_text);
  }
}

string SsmlParser::JoinText(const vector<SsmlText>& ssml_texts) {
  string text;
  for (const auto& ssml_text : ssml_texts) {
    text.append(ssml_text.text);
  }
  return text;
}

bool SsmlParser::IsSsmlFast(const string& text) {
  string ssml_start = "<speak";
  string ssml_end = "</speak>";
  if (!text.find(ssml_start) &&
      (text.find(ssml_end) + ssml_end.size() == text.size())) {
    LOG(INFO) << "is ssml: " << text;
    return true;
  }
  LOG(INFO) << "is not ssml: " << text;
  return false;
}

int SsmlParser::CountWordNum(const string& text) {
  static re2::RE2 ssml_mark("<[^>]*>");
  string text_tmp = text;
  re2::RE2::GlobalReplace(&text_tmp, ssml_mark, "");
  VLOG(2) << "source text " << text_tmp;
  return util::utflen(text_tmp.c_str());
}

// check if text is ssml
bool SsmlParser::IsSsml(const string& text, xmlDocPtr* doc) {
  // check xml
  *doc =
      xmlReadMemory(text.data(), text.size(), NULL, NULL,
                    XML_PARSE_RECOVER | XML_PARSE_NOBLANKS | XML_PARSE_NOERROR);
  if (*doc == nullptr) {
    VLOG(2) << "is not xml : " << text;
    return false;
  }
  // if is xml, check ssml
  // include html decode
  xmlNode* root = xmlDocGetRootElement(*doc);
  if (root == nullptr) {
    VLOG(2) << "is not xml : " << text;
    return false;
  }
  return (reinterpret_cast<const char*>(root->name) == kSsmlName);
}

// TODO(zhengzhang): add error format ssml checking
void SsmlParser::ParseSsml(const xmlDocPtr& doc, vector<SsmlText>* ssml_texts) {
  // process ssml text
  xmlNode* root = xmlDocGetRootElement(doc);
  for (xmlNode* node = root->children; node; node = node->next) {
    string name = reinterpret_cast<const char*>(node->name);
    if (name == kXmlText) {
      ssml_texts->emplace_back(reinterpret_cast<const char*>(node->content));
    } else {
      SsmlTag ssml_tag_tmp;
      ssml_tag_tmp.name = name;
      for (xmlAttr* attr = node->properties; attr; attr = attr->next) {
        ssml_tag_tmp.attrs.emplace(std::make_pair(
            reinterpret_cast<const char*>(attr->name),
            reinterpret_cast<const char*>(attr->children->content)));
      }
      string text_tmp;
      for (xmlNode* node2 = node->children; node2; node2 = node2->next) {
        if (node2->children) {
          text_tmp += reinterpret_cast<const char*>(node2->children->content);
        } else if (node2->content) {
          text_tmp += reinterpret_cast<const char*>(node2->content);
        }
      }
      ssml_texts->emplace_back(text_tmp, ssml_tag_tmp);
    }
  }
}

// TODO(zhengzhang): add error format ssml checking
void SsmlParser::ParseSsml(const xmlDocPtr& doc, const string& key_name,
                           vector<SsmlText>* ssml_texts) {
  string content_tmp;
  // process ssml text
  xmlNode* root = xmlDocGetRootElement(doc);
  for (xmlNode* node = root->children; node; node = node->next) {
    string name = reinterpret_cast<const char*>(node->name);
    if (name != key_name) {
      content_tmp += NodeToString(*node);
    } else {
      if (!content_tmp.empty()) {
        ssml_texts->emplace_back(content_tmp);
        content_tmp.clear();
      }
      SsmlTag ssml_tag_tmp;
      ssml_tag_tmp.name = name;
      for (xmlAttr* attr = node->properties; attr; attr = attr->next) {
        ssml_tag_tmp.attrs.emplace(std::make_pair(
            reinterpret_cast<const char*>(attr->name),
            reinterpret_cast<const char*>(attr->children->content)));
      }
      string text_tmp;
      for (xmlNode* node2 = node->children; node2; node2 = node2->next) {
        text_tmp += NodeToString(*node2);
      }
      ssml_texts->emplace_back(text_tmp, ssml_tag_tmp);
    }
  }
  if (!content_tmp.empty()) {
    ssml_texts->emplace_back(content_tmp);
    content_tmp.clear();
  }
}

void SsmlParser::ReplaceBreakTag(const vector<SsmlText>& input,
                                 vector<SsmlText>* result) {
  for (const auto& ssml_text : input) {
    if (ssml_text.tag.name.empty() &&
        ssml_text.text.find(kTextBreakTag) != string::npos) {
      vector<string> segs;
      SplitStringToVector(ssml_text.text, kTextBreakTag, false, &segs);
      SsmlText break_ssml = GenBreakSsmlText();
      for (size_t i = 0; i < segs.size(); ++i) {
        if (i != 0) result->emplace_back(break_ssml);
        if (!segs[i].empty()) result->emplace_back(segs[i]);
      }
    } else {
      result->emplace_back(ssml_text);
    }
  }
}

void SsmlParser::RestrictSsmlTag(vector<SsmlText>* result) {
  result->erase(std::remove_if(result->begin(), result->end(), IllegalSsml),
                result->end());
}

void SsmlParser::RemoveUnsupportedTag(string* result) const {
  static re2::RE2 begin_voice("<voice[^>]*>");
  static re2::RE2 end_voice("</voice>");
  re2::RE2::GlobalReplace(result, begin_voice, "");
  re2::RE2::GlobalReplace(result, end_voice, "");
}

float ParseBreakTime(const tts::SsmlText& ssml_text) {
  float time = 0.0;
  auto it = ssml_text.tag.attrs.find(kSsmlBreakTime);
  if (it == ssml_text.tag.attrs.end()) return time;

  string time_str;
  string unit_str;
  if (RE2::FullMatch(it->second, kTimePattern, &time_str, &unit_str)) {
    time = StringToFloat(time_str);
    if (unit_str == kSsmlBreakTimeMs) {
      time /= 1000;
    }
  }
  return time;
}

void SsmlParser::RemoveUnusedTag(vector<SsmlText>* result) {
  result->erase(std::remove_if(result->begin(), result->end(), UnusedTag),
                result->end());
}

}  // namespace tts
