// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com

#ifndef TTS_UTIL_SSML_TTS_SSML_ENTITY_H_
#define TTS_UTIL_SSML_TTS_SSML_ENTITY_H_

#include <list>
#include <string>
#include "mobvoi/base/mutex.h"

namespace mobvoi {

class TtsSsmlEntity {
 public:
  TtsSsmlEntity();
  virtual ~TtsSsmlEntity();

  bool operator==(const TtsSsmlEntity& entity) const;
  /*
   * only text label entity (not audio label) can be +=
   * only rate and volume are same with each other can be +=
   * for example 1 (valid):
   *    <speak><prosody rate="1.0">AAA</psosody></speak>
   *  + <speak><prosody rate="1.0">BBB</psosody></speak>
   *  = <speak><prosody rate="1.0">AAABBB</psosody></speak>
   *
   * for example 2 (valid):
   *    <speak><w phoneme="sheng1 xiao1">生肖</w></speak>
   *  + <speak><w phoneme="sheng2 xiao2">生肖</w></speak>
   *  = <speak><w phoneme="sheng1 xiao1">生肖</w>
   *           <w phoneme="sheng2 xiao2">生肖</w></speak>
   *
   * for example 3 (invalid):
   *    <speak><prosody rate="1.0">AAA</psosody></speak>
   *  + <speak><prosody rate="1.2">BBB</psosody></speak>
   *  = <speak><prosody rate="1.0">AAA</psosody></speak>
   *
   * for example 4 (invalid):
   *    <speak><audio src="1.wav" /></speak>
   *  + <speak>BBB</speak>
   *  = <speak><audio src="1.wav" /></speak>
   *
   */
  TtsSsmlEntity& operator+=(const TtsSsmlEntity& entity);

 public:
  std::string GetOutputAudioData(int length);
  void AppendAudioData(const std::string& audio_data);
  void SetAppendAudioFinished(bool audio_append_finished);
  bool IsAudioOutputFinished();
  std::string GetValueAsSsml() const;

  void Lock();
  void Unlock();

  int GetAudioLength();
  int GetAudioOutputIndex();
  void SetResampleRate(int sample_rate);
  int GetResampleRate();
  void SetErrorFlag(bool error_flag);
  bool GetErrorFlag();
  const TtsSsmlEntity& Clear();
  bool GetValidFlag();
  void SetValidFlag(bool flag);
  std::string GetDefaultVoiceName();
  std::string GetDefaultSynthRate();

  std::string GetAudioData();
  std::string GetSsmlLabel();
  std::string GetSsmlText();
  std::string GetSsmlContent();
  std::string GetAudioSrc();
  std::string GetBreakStrength();
  std::string GetBreakTime();
  std::string GetEmphasisLevel();
  std::string GetLanguage();
  std::string GetPhonemeAlphabet();
  std::string GetPhonemePh();
  std::string GetProsodyRate();
  std::string GetProsodyPitch();
  std::string GetProsodyVolume();
  std::string GetSayAsInterpretAs();
  std::string GetSayAsFormat();
  std::string GetSubAlias();
  std::string GetVoiceName();
  std::string GetWRole();

  void SetAudioData(const std::string& value);
  void SetSsmlLabel(const std::string& value);
  void SetSsmlText(const std::string& value);
  void SetSsmlContent(const std::string& value);
  void SetAudioSrc(const std::string& value);
  void SetBreakStrength(const std::string& value);
  void SetBreakTime(const std::string& value);
  void SetEmphasisLevel(const std::string& value);
  void SetLanguage(const std::string& value);
  void SetPhonemeAlphabet(const std::string& value);
  void SetPhonemePh(const std::string& value);
  void SetProsodyRate(const std::string& value);
  void SetProsodyPitch(const std::string& value);
  void SetProsodyVolume(const std::string& value);
  void SetSayAsInterpretAs(const std::string& value);
  void SetSayAsFormat(const std::string& value);
  void SetSubAlias(const std::string& value);
  void SetVoiceName(const std::string& value);
  void SetWRole(const std::string& value);
  void SetWPhoneme(const std::string& value);

 private:
  std::string audio_data_;

  std::string ssml_label_;
  std::string ssml_text_;
  std::string ssml_content_;

  std::string audio_src_;
  std::string amazon_effect_name_;
  std::string break_strength_;
  std::string break_time_;
  std::string emphasis_level_;
  std::string language_;
  std::string phoneme_alphabet_;
  std::string phoneme_ph_;
  std::string prosody_rate_;
  std::string prosody_pitch_;
  std::string prosody_volume_;
  std::string say_as_interpret_as_;
  std::string say_as_format_;
  std::string sub_alias_;
  std::string voice_name_;
  std::string w_role_;
  std::string w_phoneme_;  // not standard label (tts custom)

  mutable std::list<std::string> ssml_value_list_;
  mutable std::list<std::string> text_value_list_;

 private:
  int audio_output_index_;
  bool audio_append_finished_;
  int resample_rate_;
  bool error_flag_;
  bool valid_flag_;
  mutable Mutex mutex_;
};

}  // namespace mobvoi

#endif  // TTS_UTIL_SSML_TTS_SSML_ENTITY_H_
