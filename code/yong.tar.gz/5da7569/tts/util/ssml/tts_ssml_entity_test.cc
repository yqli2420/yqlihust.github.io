// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com

#include <list>
#include <string>

#include "mobvoi/base/log.h"
#include "third_party/gtest/gtest.h"
#include "tts/util/ssml/tts_ssml_entity.h"

namespace mobvoi {

DEFINE_string(server, "localhost:8080", "grpc server");
DEFINE_string(host, "localhost", "service host");
DEFINE_string(port, "8080", "service port");

TEST(TtsSsmlEntity, SsmlTest) {
  TtsSsmlEntity ssml_entity1;
  TtsSsmlEntity ssml_entity2;
  EXPECT_EQ(ssml_entity1 == ssml_entity2, true);
  EXPECT_EQ(ssml_entity1.Clear() == ssml_entity2.Clear(), true);

  ssml_entity1.SetAudioData("1");
  ssml_entity2.SetAudioData("2");
  EXPECT_EQ(ssml_entity1 == ssml_entity2, false);
  EXPECT_EQ(ssml_entity1.Clear() == ssml_entity2.Clear(), true);

  ssml_entity1.SetSsmlLabel("1");
  ssml_entity2.SetSsmlLabel("2");
  EXPECT_EQ(ssml_entity1 == ssml_entity2, false);
  EXPECT_EQ(ssml_entity1.Clear() == ssml_entity2.Clear(), true);

  ssml_entity1.SetSsmlText("1");
  ssml_entity2.SetSsmlText("2");
  EXPECT_EQ(ssml_entity1 == ssml_entity2, false);
  EXPECT_EQ(ssml_entity1.Clear() == ssml_entity2.Clear(), true);

  ssml_entity1.SetAudioSrc("1");
  ssml_entity2.SetAudioSrc("2");
  EXPECT_EQ(ssml_entity1 == ssml_entity2, false);
  EXPECT_EQ(ssml_entity1.Clear() == ssml_entity2.Clear(), true);

  ssml_entity1.SetBreakStrength("1");
  ssml_entity2.SetBreakStrength("2");
  EXPECT_EQ(ssml_entity1 == ssml_entity2, false);
  EXPECT_EQ(ssml_entity1.Clear() == ssml_entity2.Clear(), true);

  ssml_entity1.SetBreakTime("1");
  ssml_entity2.SetBreakTime("2");
  EXPECT_EQ(ssml_entity1 == ssml_entity2, false);
  EXPECT_EQ(ssml_entity1.Clear() == ssml_entity2.Clear(), true);

  ssml_entity1.SetEmphasisLevel("1");
  ssml_entity2.SetEmphasisLevel("2");
  EXPECT_EQ(ssml_entity1 == ssml_entity2, false);
  EXPECT_EQ(ssml_entity1.Clear() == ssml_entity2.Clear(), true);

  ssml_entity1.SetLanguage("1");
  ssml_entity2.SetLanguage("2");
  EXPECT_EQ(ssml_entity1 == ssml_entity2, false);
  EXPECT_EQ(ssml_entity1.Clear() == ssml_entity2.Clear(), true);

  ssml_entity1.SetPhonemeAlphabet("1");
  ssml_entity2.SetPhonemeAlphabet("2");
  EXPECT_EQ(ssml_entity1 == ssml_entity2, false);
  EXPECT_EQ(ssml_entity1.Clear() == ssml_entity2.Clear(), true);

  ssml_entity1.SetPhonemePh("1");
  ssml_entity2.SetPhonemePh("2");
  EXPECT_EQ(ssml_entity1 == ssml_entity2, false);
  EXPECT_EQ(ssml_entity1.Clear() == ssml_entity2.Clear(), true);

  ssml_entity1.SetProsodyRate("1");
  ssml_entity2.SetProsodyRate("2");
  EXPECT_EQ(ssml_entity1 == ssml_entity2, false);
  EXPECT_EQ(ssml_entity1.Clear() == ssml_entity2.Clear(), true);

  ssml_entity1.SetProsodyPitch("1");
  ssml_entity2.SetProsodyPitch("2");
  EXPECT_EQ(ssml_entity1 == ssml_entity2, false);
  EXPECT_EQ(ssml_entity1.Clear() == ssml_entity2.Clear(), true);

  ssml_entity1.SetProsodyVolume("1");
  ssml_entity2.SetProsodyVolume("2");
  EXPECT_EQ(ssml_entity1 == ssml_entity2, false);
  EXPECT_EQ(ssml_entity1.Clear() == ssml_entity2.Clear(), true);

  ssml_entity1.SetSayAsInterpretAs("1");
  ssml_entity2.SetSayAsInterpretAs("2");
  EXPECT_EQ(ssml_entity1 == ssml_entity2, false);
  EXPECT_EQ(ssml_entity1.Clear() == ssml_entity2.Clear(), true);

  ssml_entity1.SetSayAsFormat("1");
  ssml_entity2.SetSayAsFormat("2");
  EXPECT_EQ(ssml_entity1 == ssml_entity2, false);
  EXPECT_EQ(ssml_entity1.Clear() == ssml_entity2.Clear(), true);

  ssml_entity1.SetSubAlias("1");
  ssml_entity2.SetSubAlias("2");
  EXPECT_EQ(ssml_entity1 == ssml_entity2, false);
  EXPECT_EQ(ssml_entity1.Clear() == ssml_entity2.Clear(), true);

  ssml_entity1.SetVoiceName("1");
  ssml_entity2.SetVoiceName("2");
  EXPECT_EQ(ssml_entity1 == ssml_entity2, false);
  EXPECT_EQ(ssml_entity1.Clear() == ssml_entity2.Clear(), true);

  ssml_entity1.SetWRole("1");
  ssml_entity2.SetWRole("2");
  EXPECT_EQ(ssml_entity1 == ssml_entity2, false);
  EXPECT_EQ(ssml_entity1.Clear() == ssml_entity2.Clear(), true);
}
}  // namespace mobvoi
