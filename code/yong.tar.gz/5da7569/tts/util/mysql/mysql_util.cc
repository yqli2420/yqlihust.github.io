// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/util/mysql/mysql_util.h"

#include <string>

#include "mobvoi/base/compat.h"
#include "mobvoi/base/log.h"
#include "third_party/jsoncpp/json.h"
#include "third_party/mysql_client_cpp/include/mysql_connection.h"
#include "third_party/mysql_client_cpp/include/mysql_driver.h"
#include "third_party/mysql_client_cpp/include/cppconn/driver.h"
#include "third_party/mysql_client_cpp/include/cppconn/exception.h"
#include "third_party/mysql_client_cpp/include/cppconn/resultset.h"
#include "third_party/mysql_client_cpp/include/cppconn/statement.h"

namespace util {
// TODO(shunping) : Move it to some common file as mysql utility.
void MysqlUtil::MysqlRecordToJson(sql::ResultSet* res, Json::Value* node) {
  Json::Value& data = *node;
  sql::ResultSetMetaData* meta = res->getMetaData();
  for (size_t i = 1; i <= meta->getColumnCount(); ++i) {
    string column_name = meta->getColumnLabel(i).asStdString();
    VLOG(3) << "name: " << meta->getColumnName(i)
            << ", type: " << meta->getColumnType(i)
            << ", type name: " << meta->getColumnTypeName(i).asStdString()
            << ", isSigned: " << meta->isSigned(i);
    int type = meta->getColumnType(i);
    switch (type) {
      case sql::DataType::BIT:
        data[column_name] = res->getBoolean(i);
        break;
      case sql::DataType::SMALLINT:
      case sql::DataType::TINYINT:
      case sql::DataType::MEDIUMINT:
      case sql::DataType::INTEGER:
        if (meta->isSigned(i)) {
          data[column_name] = Json::Value::Int(res->getInt(i));
        } else {
          data[column_name] = Json::Value::UInt(res->getUInt(i));
        }
        break;
      case sql::DataType::BIGINT:
        if (meta->isSigned(i)) {
          data[column_name] = Json::Value::UInt64(res->getInt64(i));
        } else {
          data[column_name] = Json::Value::UInt64(res->getUInt64(i));
        }
        break;
      case sql::DataType::REAL:
      case sql::DataType::DOUBLE:
      case sql::DataType::DECIMAL:
        data[column_name] = static_cast<double>(res->getDouble(i));
        break;
      case sql::DataType::BINARY:
        data[column_name] =
            string(std::istreambuf_iterator<char>(*res->getBlob(i)),
                   std::istreambuf_iterator<char>());
        break;
      case sql::DataType::VARCHAR:
      case sql::DataType::LONGVARCHAR:
        data[column_name] = res->getString(i).asStdString();
        break;
      case sql::DataType::ENUM:
        data[column_name] = res->getInt(i);
        break;
      // TODO(shunping) : Convert below data type later.
      case sql::DataType::NUMERIC:
      case sql::DataType::CHAR:
      case sql::DataType::SET:
      case sql::DataType::SQLNULL:
      case sql::DataType::VARBINARY:
      case sql::DataType::LONGVARBINARY:
      case sql::DataType::TIMESTAMP:
      case sql::DataType::DATE:
      case sql::DataType::TIME:
      case sql::DataType::YEAR:
      case sql::DataType::GEOMETRY:
      case sql::DataType::UNKNOWN :
        CHECK(false) << "Not supported type:"
                     << meta->getColumnTypeName(i).asStdString()
                     << ", type:" << type;
        break;
      default:
        break;
    }
  }
}
}  // namespace util
