// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "third_party/gtest/gtest.h"
#include "tts/util/trie/marisa_trie.h"

namespace trie {

class TrieTest : public ::testing::Test {
 protected:
  virtual void SetUp(const string& trie_dict) {
    trie_.reset(new MarisaTrie(trie_dict));
  }

  void FindTest(const string& word, int word_id) const {
    vector<util::Rune> unicode;
    util::Utf8ToUnicode(word, &unicode);
    EXPECT_EQ(word_id, trie_->Find(unicode.begin(), unicode.end()));
  }
  void FindPrefixTest(const string& word,
                      const vector<DagNode> dag_nodes) const {
    vector<util::Rune> unicode;
    util::Utf8ToUnicode(word, &unicode);
    vector<DagNode> res_dag;
    trie_->FindPrefix(unicode.begin(), unicode.end(), &res_dag);
    EXPECT_EQ(dag_nodes.size(), res_dag.size());
    for (size_t i = 0; i < dag_nodes.size(); ++i) {
      EXPECT_EQ(dag_nodes[i].id, res_dag[i].id);
      EXPECT_EQ(dag_nodes[i].u_len, res_dag[i].u_len);
    }
  }

  std::unique_ptr<MarisaTrie> trie_;
};

#ifndef FOR_PORTABLE
TEST_F(TrieTest, MarisaTrieTest) {
  const string trie_dict =
      "external/config/front_end/segmenter/"
      "mandarin_segmenter_word_dict.trie";

  SetUp(trie_dict);

  const string word1 = "来到";
  int word_id = 259358;
  const vector<DagNode> dag_nodes1({{6658, 1}, {259358, 2}});  // 来 来到

  FindTest(word1, word_id);
  FindPrefixTest(word1, dag_nodes1);

  // oov words
  const string word2 = "我擦咧";
  const vector<DagNode> dag_nodes2({{5294, 1}});  // 我

  FindTest(word2, kNotFound);
  FindPrefixTest(word2, dag_nodes2);
}
#endif

TEST(MarisaTrieTest, CreateTest) {
  const vector<string> words = {"出门", "问问"};
  const vector<int> expect_ids = {1, 2};
  vector<vector<util::Rune>> unicodes;
  vector<int> word_id;
  for (size_t i = 0; i < words.size(); ++i) {
    vector<util::Rune> unicode;
    util::Utf8ToUnicode(words[i], &unicode);
    unicodes.emplace_back(unicode);
    word_id.emplace_back(i);
  }
  MarisaTrie trie(unicodes, &word_id);
  EXPECT_EQ(expect_ids, word_id);
}

}  // namespace trie
