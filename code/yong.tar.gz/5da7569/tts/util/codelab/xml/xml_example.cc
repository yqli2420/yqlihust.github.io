// Copyright 2016 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "mobvoi/base/file.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"
#include "third_party/xml2/libxml/parser.h"
#include "third_party/xml2/libxml/xpath.h"

DEFINE_string(xpath, "//Content", "");

xmlXPathObjectPtr getnodeset(xmlDocPtr doc, xmlChar *xpath) {
  xmlXPathContextPtr context;
  xmlXPathObjectPtr result;

  context = xmlXPathNewContext(doc);
  if (context == NULL) {
    printf("Error in xmlXPathNewContext\n");
    return NULL;
  }
  result = xmlXPathEvalExpression(xpath, context);
  xmlXPathFreeContext(context);
  if (result == NULL) {
    printf("Error in xmlXPathEvalExpression\n");
    return NULL;
  }
  if (xmlXPathNodeSetIsEmpty(result->nodesetval)) {
    xmlXPathFreeObject(result);
    printf("No result\n");
    return NULL;
  }
  return result;
}

int main(int argc, char **argv) {
  google::ParseCommandLineFlags(&argc, &argv, false);
  xmlChar *xpath = (xmlChar *)FLAGS_xpath.c_str();  // NOLINT
  xmlNodeSetPtr nodeset;
  xmlXPathObjectPtr result;
  int i;
  xmlChar *keyword;

  string data;
  string name = "codelab/xml/test.xml";
  mobvoi::File::ReadFileToStringWithMmap(name, &data);
  xmlDocPtr doc =
      xmlReadMemory(data.data(), data.size(), NULL, NULL, XML_PARSE_NOBLANKS);
  result = getnodeset(doc, xpath);
  if (result) {
    nodeset = result->nodesetval;
    for (i = 0; i < nodeset->nodeNr; i++) {
      keyword =
          xmlNodeListGetString(doc, nodeset->nodeTab[i]->xmlChildrenNode, 1);
      printf("keyword: %s\n", keyword);
      xmlFree(keyword);
    }
    xmlXPathFreeObject(result);
  }
  xmlFreeDoc(doc);
  xmlCleanupParser();
  return (1);
}
