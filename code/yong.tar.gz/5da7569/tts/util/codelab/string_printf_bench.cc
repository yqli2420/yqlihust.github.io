// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "mobvoi/base/compat.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/base/time.h"
#include "tts/synthesizer/label_generator/fast_printf.h"

// Full label.
// t^ong-y+ou=t@1_2/
// A:1_ong_2+v/
// B:2-X=2-v@2-1&4-1#1-0|ou/
// C:1+ong+2_v/
// D:4-2/
// E:4_2@2+1&X+X#X+X/
// F:4=2/
// G:4_2/
// H:4=2^2=3|X/
// I:5=2/
// J:17+8-4

void TestStringPrintf() {
  int times = 100000;
  mobvoi::BenchTimer timer("StringPrintf", times);
  int64 total_len = 0;
  for (int i = 0; i < times; ++i) {
    // Use i for last param, to prevent compile to move str
    // out of loop.
    string str = StringPrintf(
        "%s^%s-%s+%s=%s@%d_%d"
        "/A:%s_%s_%s+%s"
        "/B:%d-X=%d-%s@%d-%d&%s-%s#%d-%d|%s"
        "/C:%s+%s+%s_%s"
        "/D:%s-%s"
        "/E:%d_%d@%d+%d&X+X#X+X"
        "/F:%s=%s"
        "/G:%s_%s"
        "/H:%d=%d^%d=%d|%s"
        "/I:%s=%s"
        "/J:%d+%d-%d",
        "t", "ong", "y", "ou", "t", 1, 2,       // first line
        "1", "ong", "2", "v",                   // A group
        2, 2, "v", 2, 1, "4", "1", 1, 0, "ou",  // B
        "1", "ong", "2", "v",                   // C
        "4", "2",                               // D
        4, 2, 2, 1,                             // E
        "4", "2",                               // F
        "4", "2",                               // G
        4, 2, 2, 3, "X",                        // H
        "5", "2",                               // I
        17, 8, i);                              // J
    total_len += str.size();
  }
  LOG(INFO) << "total len : " << total_len;
}

void TestSnprintf() {
  int times = 100000;
  mobvoi::BenchTimer timer("faststring::snprintf", times);
  int64 total_len = 0;
  for (int i = 0; i < times; ++i) {
    // Use i for last param, to prevent compile to move str
    // out of loop.
    char buffer[200];
    int s =
        faststring::snprintf(buffer, sizeof(buffer),
                             "%s^%s-%s+%s=%s@%d_%d"
                             "/A:%s_%s_%s+%s"
                             "/B:%d-X=%d-%s@%d-%d&%s-%s#%d-%d|%s"
                             "/C:%s+%s+%s_%s"
                             "/D:%s-%s"
                             "/E:%d_%d@%d+%d&X+X#X+X"
                             "/F:%s=%s"
                             "/G:%s_%s"
                             "/H:%d=%d^%d=%d|%s"
                             "/I:%s=%s"
                             "/J:%d+%d-%d",
                             "t", "ong", "y", "ou", "t", 1, 2,  // first line
                             "1", "ong", "2", "v",              // A group
                             2, 2, "v", 2, 1, "4", "1", 1, 0, "ou",  // B
                             "1", "ong", "2", "v",                   // C
                             "4", "2",                               // D
                             4, 2, 2, 1,                             // E
                             "4", "2",                               // F
                             "4", "2",                               // G
                             4, 2, 2, 3, "X",                        // H
                             "5", "2",                               // I
                             17, 8, i);                              // J
    total_len += string(buffer, s).size();
  }
  LOG(INFO) << "total len : " << total_len;
}

int main(int argc, char** argv) {
  TestStringPrintf();
  TestSnprintf();
  return 0;
}
