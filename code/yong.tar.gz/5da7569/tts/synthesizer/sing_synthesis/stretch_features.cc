// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng Yang)

#include <algorithm>

#include "tts/synthesizer/sing_synthesis/stretch_features.h"

namespace sing_synthesizer {

vector<string> StringSplitToVector(const string &str, const string &pattern) {
  char *strc = new char[strlen(str.c_str()) + 1];
  char *tmp = strc;
  snprintf(strc, str.length() + 1, "%s", str.c_str());
  vector<string> resultVec;
  char *token;
  while ((token = strtok_r(strc, pattern.c_str(), &strc))) {
    resultVec.push_back(string(token));
  }
  delete[] tmp;
  return resultVec;
}

int SingleListSum(vector<int> v_data) {
  int sum = 0;
  for (int i = 0; i < v_data.size(); i++) {
    sum += v_data[i];
  }
  return sum;
}

int DoubleListSum(vector<vector<int> > v_data) {
  int sum = 0;
  for (int i = 0; i < v_data.size(); i++) {
    for (int j = 0; j < v_data[0].size(); j++) {
      sum += v_data[i][j];
    }
  }
  return sum;
}

int TribleListSum(vector<vector<vector<int> > > v_data) {
  int sum = 0;
  for (int i = 0; i < v_data.size(); i++) {
    for (int j = 0; j < v_data[0].size(); j++) {
      for (int k = 0; k < v_data[0].size(); k++) {
        sum += v_data[i][j][k];
      }
    }
  }
  return sum;
}

int HandleSym(const string &_sym, vector<vector<string> > *_src_phn,
              vector<vector<int> > *_src_dur, vector<string> *_src_syl,
              double frame_period) {
  vector<string> v_items = StringSplitToVector(_sym, " ");
  if (v_items.size() <= 1) {
    return -1;
  }
  for (int i = 0; i < v_items.size(); i++) {
    vector<string> v_it = StringSplitToVector(v_items[i], ":");
    if (v_it[0] != "") {
      _src_syl->push_back(v_it[0]);
      vector<int> tmp_dur;
      vector<string> tmp_phn;
      for (int j = 1; j < v_it.size(); j++) {
        vector<string> v = StringSplitToVector(v_it[j], "_");
        tmp_dur.push_back(atoi(v[1].c_str()) /
                          static_cast<int>(frame_period / 5));
        tmp_phn.push_back(v[0]);
      }
      _src_dur->push_back(tmp_dur);
      _src_phn->push_back(tmp_phn);
    }
  }
  return 0;
}

int HandleDur(const string &_tar, vector<string> *_tar_syl,
              vector<vector<int> > *_tar_dur, vector<vector<string> > *_pyn) {
  vector<string> tar = StringSplitToVector(_tar, " ");
  if (tar.size() <= 1) {
    return -1;
  }
  for (int i = 0; i < tar.size(); i++) {
    vector<string> v_str = StringSplitToVector(tar[i], ":");
    string syl = v_str[0].substr(0, v_str[0].find("_"));
    _tar_syl->push_back(syl);
    vector<int> tmp_dur;
    vector<string> tmp_pyn;
    for (int j = 1; j < v_str.size(); j++) {
      tmp_dur.push_back(atoi(v_str[j].substr(v_str[j].find("_") + 1).c_str()));
      string pyn = v_str[j].substr(v_str[j].find("_") + 1).c_str();
      tmp_pyn.push_back(pyn);
    }
    _tar_dur->push_back(tmp_dur);
    _pyn->push_back(tmp_pyn);
  }
  return 0;
}

vector<vector<double> > StreathingFeature::Interp(int im,
                                                  const vector<double> _left,
                                                  const vector<double> _right) {
  int order = 0;
  order = working_order_;
  vector<vector<double> > data;
  data.push_back(_left);
  if (im == 1) {
    return data;
  }
  vector<double> off;
  for (int i = 0; i < order; i++) {
    off.push_back((_right[i] - _left[i]) / im);
  }
  for (int i = 1; i < im; i++) {
    vector<double> tmp;
    for (int j = 0; j < order; j++) {
      tmp.push_back(off[j] * i + _left[j]);
    }
    data.push_back(tmp);
  }
  return data;
}

StreathingFeature::StreathingFeature(const vector<vector<double> > &mgc_pau,
                                     const vector<vector<double> > &bap_pau,
                                     int mgc_order, int bap_order,
                                     double frame_period = 5.0,
                                     int vuv_order = 1) {
  string init = "b p m f d t n l g k h j q x r z c s y w zh ch sh";
  initial_ = StringSplitToVector(init, " ");
  this->mgc_pau_ = mgc_pau;
  this->bap_pau_ = bap_pau;
  this->bap_order_ = bap_order;
  this->mgc_order_ = mgc_order;
  this->vuv_order_ = vuv_order;
  this->offset_ = 0.2;
  this->frame_period_ = frame_period;
  this->working_order_ = 0;
}

StreathingFeature::StreathingFeature(int mgc_order, int bap_order,
                                     double frame_period = 5.0,
                                     int vuv_order = 1) {
  string init = "b p m f d t n l g k h j q x r z c s y w zh ch sh";
  initial_ = StringSplitToVector(init, " ");
  this->bap_order_ = bap_order;
  this->mgc_order_ = mgc_order;
  this->vuv_order_ = vuv_order;
  this->offset_ = 0.2;
  this->working_order_ = 0;
  this->frame_period_ = frame_period;
}

StreathingFeature::StreathingFeature(const vector<vector<double> > &mgc_pau,
                                     const vector<vector<double> > &bap_pau,
                                     double frame_period = 5.0) {
  string init = "b p m f d t n l g k h j q x r z c s y w zh ch sh";
  initial_ = StringSplitToVector(init, " ");

  this->mgc_pau_ = mgc_pau;
  this->bap_pau_ = bap_pau;
  this->bap_order_ = 5;
  this->mgc_order_ = 41;
  this->vuv_order_ = 1;
  this->offset_ = 0.2;
  this->frame_period_ = frame_period;
  this->working_order_ = 0;
}

StreathingFeature::~StreathingFeature() {}

int StreathingFeature::InterpFunc(int _tar, int _src, int _idx,
                                  const vector<vector<double> > &_source,
                                  vector<vector<double> > *data) {
  int im = 0;
  if (_tar > _src) {
    if (_source.size() == 2) {
      vector<vector<double> > tmp =
          Interp(_tar, _source[_idx], _source[_idx + 1]);
      data->insert(data->end(), tmp.begin(), tmp.end());
    } else {
      int mutile = _tar / _src;
      int substract = _tar - _src * mutile;
      for (int i = 0; i < _src; i++) {
        if (substract > 0) {
          im = mutile + 1;
          substract -= 1;
        } else {
          im = mutile;
        }
        if (_idx + i >= _source.size() - 1) {
          for (int j = 0; j < im; j++) {
            data->push_back(_source[_idx + i]);
          }
        } else {
          vector<vector<double> > tmp =
              Interp(im, _source[_idx + i], _source[_idx + i + 1]);
          data->insert(data->end(), tmp.begin(), tmp.end());
        }
      }
    }
  } else {
    int mutile = _src / _tar;
    int substract = _src - _tar * mutile;
    int s, e;
    if (substract % 2 == 0) {
      s = substract / 2;
      e = substract / 2;
    } else {
      s = substract / 2;
      e = substract / 2 + 1;
    }
    for (int i = s; i < _src - e; i++) {
      if ((i + 1) % mutile == 0) {
        data->push_back(_source[_idx + i]);
      }
    }
  }
  return 0;
}

int StreathingFeature::MidStreth(int tar, int states, int idx,
                                 const vector<vector<double> > &_source,
                                 vector<vector<double> > *data) {
  int tmp;
  tmp = InterpFunc(tar, states, idx, _source, data);
  return tmp;
}

int StreathingFeature::InitialProcess(int tar, int src_states, int idx,
                                      const vector<vector<double> > &_source,
                                      string py,
                                      vector<vector<double> > *data) {
  int tmp = 0;
  /*int nRet = count(popping.begin(), popping.end(), py);
  if (nRet > 0) {
  tmp = mid_streth(tar, src_states, idx, _source,data);
  }
  else {
  tmp = mid_streth(tar, src_states, idx, _source,data);
  }*/
  tmp = MidStreth(tar, src_states, idx, _source, data);
  return tmp;
}

int StreathingFeature::FinalsProcess(int tar, vector<int> src_states, int idx,
                                     const vector<vector<double> > &_source,
                                     vector<string> src_phn,
                                     vector<vector<double> > *data) {
  int src = SingleListSum(src_states);
  int tmp = InterpFunc(tar, src, idx, _source, data);
  return tmp;
}

vector<vector<double> > StreathingFeature::StrethSyllables(
    const vector<vector<int> > &_tar_dur, const vector<string> &_tar_syl,
    const vector<vector<int> > &_src_dur, const vector<string> &_src_syl,
    const vector<vector<string> > &_src_phn,
    const vector<vector<double> > &_source) {
  int src_idx = 0;
  int idx = 0;
  int tar_idx = 0;
  vector<vector<double> > data;
  int tmp;
  while (tar_idx < _tar_syl.size() && src_idx < _src_syl.size()) {
    if (_tar_syl[tar_idx] == "pau" || _src_syl[src_idx] == "sil") {
      if (_tar_syl[tar_idx] == "pau" && _src_syl[src_idx] == "sil") {
        tmp = InterpFunc(_tar_dur[tar_idx][0], _src_dur[src_idx][0], idx,
                         _source, &data);
        idx += _src_dur[src_idx][0];
        tar_idx += 1;
        src_idx += 1;
      } else if (_tar_syl[tar_idx] == "pau") {
        int tar = _tar_dur[tar_idx][0];
        vector<vector<double> > v_tmp_pau;
        if (idx == _source.size() - 1) {
          idx--;
        }
        if (is_mgc_) {
          v_tmp_pau.insert(v_tmp_pau.end(), mgc_pau_.begin(), mgc_pau_.end());
        } else {
          v_tmp_pau.insert(v_tmp_pau.end(), bap_pau_.begin(), bap_pau_.end());
        }
        tmp = InterpFunc(tar, v_tmp_pau.size(), 0, v_tmp_pau, &data);
        tar_idx += 1;
      } else {
        idx += _src_dur[src_idx][0];
        src_idx += 1;
      }
    } else {
      if (_tar_dur[tar_idx].size() == 1) {
        int src_tmp = SingleListSum(_src_dur[src_idx]);
        int tmp =
            InterpFunc(_tar_dur[tar_idx][0], src_tmp, idx, _source, &data);
        idx += SingleListSum(_src_dur[src_idx]);
        tar_idx += 1;
        src_idx += 1;
      } else {
        int initial_num = 0;
        int nRet =
            count(initial_.begin(), initial_.end(), _src_phn[src_idx][0]);
        if (nRet > 0) {
          tmp = MidStreth(_tar_dur[tar_idx][0], _src_dur[src_idx][0], idx,
                          _source, &data);
          idx += _src_dur[src_idx][0];
          initial_num = 1;
        }
        vector<int> src_dur;
        src_dur.assign(_src_dur[src_idx].begin() + initial_num,
                       _src_dur[src_idx].end());
        int src_tmp = SingleListSum(src_dur);
        int tmp =
            InterpFunc(_tar_dur[tar_idx][1], src_tmp, idx, _source, &data);
        idx += SingleListSum(src_dur);
        tar_idx += 1;
        src_idx += 1;
      }
    }
  }
  if (tar_idx < _tar_syl.size() && tar_idx == _tar_syl.size() - 1) {
    if (_tar_syl[tar_idx] == "pau") {
      int tar = _tar_dur[tar_idx][0];
      vector<vector<double> > v_tmp_pau;
      if (idx == _source.size() - 1) {
        idx--;
      }
      v_tmp_pau.push_back(_source[idx]);
      v_tmp_pau.push_back(_source[idx + 1]);
      tmp = InterpFunc(tar, v_tmp_pau.size(), 0, v_tmp_pau, &data);
      tar_idx += 1;
    } else {
      LOG(ERROR) << " _tar_syl  data error ";
    }
  }
  return data;
}

void v2f2(const vector<vector<double> > &v_f2, double **f2) {
  int v_len = v_f2.size();
  for (int i = 0; i < v_len; i++) {
    f2[i] = new double[v_f2[i].size()];
    for (int j = 0; j < v_f2[i].size(); j++) {
      f2[i][j] = v_f2[i][j];
    }
  }
}

int StreathingFeature::Process(const string &_tar, string _sym,
                               const vector<vector<double> > &_mgc,
                               const vector<vector<double> > &_bap,
                               const vector<vector<double> > &_vuv,
                               double **_tmgc, double **_tbap, double **_tvuv) {
  //去除句末的空格、回车等符号
  size_t n = _sym.find_last_not_of(" \r\n\t");
  if (n != string::npos) {
    _sym.erase(n + 1, _sym.size() - n);
  }
  vector<vector<string> > src_phn;
  vector<vector<int> > src_dur;
  vector<string> src_syl;
  vector<string> tar_syl;
  vector<vector<int> > tar_dur;
  vector<vector<string> > pyn;
  int tar_idx = 0;
  int sym_idx = 0;
  int tar_count = 0;
  int sym_count = 0;
  int ret1 = HandleDur(_tar, &tar_syl, &tar_dur, &pyn);
  int ret2 = HandleSym(_sym, &src_phn, &src_dur, &src_syl, frame_period_);
  if (ret1 == -1 || ret2 == -1) {
    return 0;
  }
  for (int i = 0; i < tar_syl.size(); i++) {
    if (tar_syl[i] != "pau") {
      tar_count++;
    }
  }
  for (int i = 0; i < src_syl.size(); i++) {
    if (src_syl[i] != "sil" && src_syl[i] != "\n") {
      sym_count++;
    }
  }
  if (sym_count != tar_count) {
    LOG(ERROR) << "syllable length asr: " << sym_count << " tar: " << tar_count;
    return 0;
  }

  working_order_ = mgc_order_;
  is_mgc_ = true;
  vector<vector<double> > mgc =
      StrethSyllables(tar_dur, tar_syl, src_dur, src_syl, src_phn, _mgc);
  working_order_ = bap_order_;
  is_mgc_ = false;
  vector<vector<double> > bap =
      StrethSyllables(tar_dur, tar_syl, src_dur, src_syl, src_phn, _bap);
  working_order_ = vuv_order_;
  vector<vector<double> > vuv =
      StrethSyllables(tar_dur, tar_syl, src_dur, src_syl, src_phn, _vuv);

  v2f2(mgc, _tmgc);
  v2f2(bap, _tbap);
  v2f2(vuv, _tvuv);
  return mgc.size();
}
}  // namespace sing_synthesizer
