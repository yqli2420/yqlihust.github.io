// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng yang)

#include "tts/synthesizer/sing_synthesis/sing_mysql_utils.h"

#include <fstream>  // NOLINT

#include "mobvoi/base/log.h"
#include "mobvoi/util/mysql/mysql_connection_pool.h"
#include "mobvoi/util/mysql/mysql_connection_pool_manager.h"
#include "mobvoi/util/mysql/mysql_util.h"
#include "third_party/jsoncpp/json.h"
#include "third_party/mysql_client_cpp/include/cppconn/prepared_statement.h"

#include "tts/synthesizer/vocoder/world_vocoder/world/world_vocoder.h"

DEFINE_string(resource_file, "tts/synthesizer/sing_synthesis/resource/",
              "song data resource");
DEFINE_string(mysql_server_conf, "./tts_song_feature_db.conf", "");

namespace sing_synthesizer {

static const int kSamplePeriod = 5;
static const int kNBit = 16;

bool SingMysqlUtils::CreateSongFeatureTable() {
  string command =
      "CREATE TABLE song_features (id INT NOT NULL AUTO_INCREMENT, update_time "
      "timestamp, song_name varchar(60) NOT NULL, song_id varchar(60) NOT "
      "NULL, song_f0 mediumblob NOT NULL, song_bgm mediumblob NOT NULL, "
      "song_duration text NOT NULL, song_text text NOT NULL, frame_size INT "
      "NOT NULL, nbit INT DEFAULT 16, sample_period INT DEFAULT 5, bgm_start "
      "INT NOT NULL,bgm_end INT NOT NULL, "
      "PRIMARY KEY (id) ) ; ";
  LOG(INFO) << command << endl;
  util::RunMysqlCommand(FLAGS_mysql_server_conf, command);
  return true;
}

SingMysqlUtils::SingMysqlUtils() {}

SingMysqlUtils::~SingMysqlUtils() {}

vector<string> split_str_to_vector(const string &str, const string &pattern) {
  char *strc = new char[strlen(str.c_str()) + 1];
  snprintf(strc, str.length(), "%s", str.c_str());
  vector<string> resultVec;
  char *tmpStr = strtok(strc, pattern.c_str());  // NOLINT
  while (tmpStr != NULL) {
    resultVec.push_back(string(tmpStr));
    tmpStr = strtok(NULL, pattern.c_str());  // NOLINT
  }
  delete[] strc;
  return resultVec;
}

void read_bgm_from_file(const char *bgm_fn, double *data, int length) {
  if (length <= 0) {
    if (length == 0) {
      LOG(ERROR) << "Error! " << bgm_fn << " not found. ";
    } else {
      LOG(ERROR) << "Error! The file " << bgm_fn << "  is not .wav format ";
    }
    data = NULL;
  } else {
    int fs, nbit;
    world_vocoder::wavread(bgm_fn, &fs, &nbit, data);
  }
}

void init_song_features(const string &line, const string &base_path,
                        SongFeatureParam *sfp) {
  vector<string> v_items = split_str_to_vector(line, ";");
  sfp->bgm_start = atoi(v_items[1].c_str());
  sfp->bgm_end = atoi(v_items[2].c_str());
  sfp->song_duration = v_items[3];
  sfp->song_name = split_str_to_vector(v_items[0], "-")[0];
  sfp->f0_fn = base_path + "f0/" + v_items[0] + ".dtf0";
  sfp->bgm_fn = base_path + "bgm/" + sfp->song_name + "-bgm.wav";
  sfp->bgm_length = world_vocoder::GetAudioLength(sfp->bgm_fn.c_str());
  sfp->bgm = new double[sfp->bgm_length];
  read_bgm_from_file(sfp->bgm_fn.c_str(), sfp->bgm, sfp->bgm_length);
  sfp->song_text = "a";
  sfp->updata_time = "NULL";
  sfp->song_id = sfp->song_name + "-0001";
}

void SingMysqlUtils::InsertSongFeatures(string base_dir) {
  util::MysqlConnectionPoolManager *manager =
      Singleton<util::MysqlConnectionPoolManager>::get();
  util::MysqlConnectionPool *connect_pool =
      manager->GetPool(FLAGS_mysql_server_conf);
  sql::Connection *con = connect_pool->GetConnection();
  int count_down = 10;
  while (con == nullptr && count_down > 0) {
    mobvoi::Sleep(2);
    con = connect_pool->GetConnection();
    --count_down;
  }
  std::auto_ptr<sql::PreparedStatement> stmt;
  string song_target = base_dir + "tar_dur/time.txt";
  std::ifstream fin(song_target.c_str());
  string line;
  while (getline(fin, line)) {
    SongFeatureParam sfp;
    init_song_features(line, base_dir, &sfp);
    std::filebuf file_in;
    if (!file_in.open(sfp.f0_fn.c_str(), std::ios::in)) {
      LOG(ERROR) << "fail to open file" << std::endl;
      return;
    }
    std::istream iss_f0(&file_in);
    double *foo = new double[sfp.f0_length];
    // iss_f0.read(reinterpret_cast<char*>(foo), sizeof(double) *
    // sfp.f0_length);
    // for(int i = 0;i<sfp.f0_length;i++){
    //   LOG(INFO) << foo[i]  << "  " << sfp.f0[i] << endl;
    // }

    string bgm_data;
    double *bgms = new double[sfp.bgm_length];
    for (int i = 0; i < sfp.bgm_length; i++) {
      bgm_data.append(reinterpret_cast<const char *>(&sfp.bgm[i]),
                      sizeof(double));
    }
    std::istringstream bgm_iss(bgm_data);
    // bgm_iss.read(reinterpret_cast<char*>(bgms), sizeof(double) *
    // sfp.bgm_length);
    // for(int i = 0;i<sfp.bgm_length;i++){
    //   LOG(INFO) << bgms[i]  << "  " << sfp.bgm[i] << endl;
    // }
    string sql_cmd =
        "INSERT INTO song_features(song_name, song_id, "
        "song_f0, song_bgm, song_duration, song_text, frame_size, nbit, "
        "sample_period, bgm_start, bgm_end, bgm_length) VALUES "
        "(?,?,?,?,?,?,?,?,?,?,?,?)";
    stmt.reset(con->prepareStatement(sql_cmd));
    stmt->setString(1, sfp.song_name);
    stmt->setString(2, sfp.song_id);
    stmt->setBlob(3, &iss_f0);
    stmt->setBlob(4, reinterpret_cast<istream *>(&bgm_iss));
    stmt->setString(5, sfp.song_duration);
    stmt->setString(6, sfp.song_text);
    stmt->setInt(7, sfp.f0_length);
    stmt->setInt(8, kNBit);
    stmt->setInt(9, kSamplePeriod);
    stmt->setInt(10, sfp.bgm_start);
    stmt->setInt(11, sfp.bgm_end);
    stmt->setInt(12, sfp.bgm_length);
    int ret_code = stmt->execute();
    VLOG(2) << "execute mysql update return code: " << ret_code;
  }
  connect_pool->RecycleConnection(con);
}

bool SingMysqlUtils::GetSongFeatures(string song_id,
                                     SongFeatureParam *feature) {
  Json::Value data;
  GetAllFromSql(song_id, &data);
  feature->song_name = data["song_name"].asString();
  feature->song_id = song_id;
  string f0_str = data["song_f0"].asString();
  std::istringstream f0_iss(f0_str.c_str());
  string bgm_str = data["song_f0"].asString();
  std::istringstream bgm_iss(bgm_str.c_str());
  feature->song_duration = data["song_duration"].asString();
  feature->song_text = (string)data["song_text"].asString();
  feature->song_name = (string)data["song_name"].asString();
  feature->f0_length = data["frame_size"].asInt();
  feature->bgm_start = data["bgm_start"].asInt();
  feature->bgm_end = data["bgm_end"].asInt();
}
sql::Connection *get_sql_connection() {
  Json::Value data;
  util::MysqlConnectionPoolManager *manager =
      Singleton<util::MysqlConnectionPoolManager>::get();
  util::MysqlConnectionPool *connect_pool =
      manager->GetPool(FLAGS_mysql_server_conf);
  sql::Connection *con = connect_pool->GetConnection();
  int count_down = 10;
  while (con == nullptr && count_down > 0) {
    mobvoi::Sleep(2);
    con = connect_pool->GetConnection();
    --count_down;
  }
  return con;
}

bool SingMysqlUtils::GetAllFromSql(string song_id, Json::Value *data) {
  string command = "";
  util::MysqlConnectionPoolManager *manager =
      Singleton<util::MysqlConnectionPoolManager>::get();
  util::MysqlConnectionPool *connect_pool =
      manager->GetPool(FLAGS_mysql_server_conf);
  sql::Connection *con = connect_pool->GetConnection();
  int count_down = 10;
  while (con == nullptr && count_down > 0) {
    mobvoi::Sleep(2);
    con = connect_pool->GetConnection();
    --count_down;
  }
  try {
    std::auto_ptr<sql::PreparedStatement> stmt(con->prepareStatement(
        "SELECT * FROM INTO song_features while song_id = ?"));
    stmt->setString(1, song_id);
    std::unique_ptr<sql::ResultSet> res(stmt->executeQuery());
    while (res->next()) {
      util::MysqlRecordToJson(res.get(), data);
      break;
    }
    connect_pool->RecycleConnection(con);
  } catch (sql::SQLException &e) {
    LOG(WARNING) << "# ERR: " << e.what();
    connect_pool->RecycleConnection(con);
    return false;
  }
  return true;
}
bool SingMysqlUtils::GetMessageFromSql(string song_id, SongFeatureParam *sfp) {
  Json::Value data;
  util::MysqlConnectionPoolManager *manager =
      Singleton<util::MysqlConnectionPoolManager>::get();
  util::MysqlConnectionPool *connect_pool =
      manager->GetPool(FLAGS_mysql_server_conf);
  sql::Connection *con = connect_pool->GetConnection();
  int count_down = 10;
  while (con == nullptr && count_down > 0) {
    mobvoi::Sleep(2);
    con = connect_pool->GetConnection();
    --count_down;
  }
  try {
    std::auto_ptr<sql::PreparedStatement> stmt(con->prepareStatement(
        "SELECT song_duration, frame_size, bgm_start, "
        "bgm_end, bgm_length FROM song_features where song_id = ? "));
    stmt->setString(1, song_id);

    std::unique_ptr<sql::ResultSet> res(stmt->executeQuery());
    while (res->next()) {
      util::MysqlRecordToJson(res.get(), &data);
      break;
    }
    connect_pool->RecycleConnection(con);
  } catch (sql::SQLException &e) {
    LOG(WARNING) << "# ERR: " << e.what();
    connect_pool->RecycleConnection(con);
    return false;
  }
  sfp->f0_length = data["frame_size"].asInt();
  sfp->bgm_start = data["bgm_start"].asInt();
  sfp->bgm_end = data["bgm_end"].asInt();
  sfp->song_duration = data["song_duration"].asString();
  sfp->bgm_length = data["bgm_length"].asInt();
  return true;
}

double *SingMysqlUtils::GetF0(const string &song_id, int f0_length) {
  double *ret = NULL;
  util::MysqlConnectionPoolManager *manager =
      Singleton<util::MysqlConnectionPoolManager>::get();
  util::MysqlConnectionPool *connect_pool =
      manager->GetPool(FLAGS_mysql_server_conf);
  sql::Connection *con = connect_pool->GetConnection();
  int count_down = 10;
  while (con == nullptr && count_down > 0) {
    mobvoi::Sleep(2);
    con = connect_pool->GetConnection();
    --count_down;
  }
  try {
    std::auto_ptr<sql::PreparedStatement> stmt(con->prepareStatement(
        "SELECT song_f0 FROM song_features where song_id = ? "));
    stmt->setString(1, song_id);
    std::unique_ptr<sql::ResultSet> res(stmt->executeQuery());
    sql::ResultSetMetaData *meta = res->getMetaData();
    while (res->next()) {
      ret = new double[f0_length];
      std::istream *iss = res->getBlob(1);
      iss->read(reinterpret_cast<char *>(ret), sizeof(double) * f0_length);
      break;
    }
    connect_pool->RecycleConnection(con);
  } catch (sql::SQLException &e) {
    LOG(WARNING) << "# ERR: " << e.what();
    connect_pool->RecycleConnection(con);
    return NULL;
  }
  return ret;
}

bool SingMysqlUtils::GetAllSongId(vector<string> *song_ids) {
  Json::Value data;
  util::MysqlConnectionPoolManager *manager =
      Singleton<util::MysqlConnectionPoolManager>::get();
  util::MysqlConnectionPool *connect_pool =
      manager->GetPool(FLAGS_mysql_server_conf);
  sql::Connection *con = connect_pool->GetConnection();
  int count_down = 10;
  while (con == nullptr && count_down > 0) {
    mobvoi::Sleep(2);
    con = connect_pool->GetConnection();
    --count_down;
  }
  try {
    std::auto_ptr<sql::PreparedStatement> stmt(
        con->prepareStatement("SELECT song_id FROM song_features "));
    std::unique_ptr<sql::ResultSet> res(stmt->executeQuery());
    sql::ResultSetMetaData *meta = res->getMetaData();
    while (res->next()) {
      song_ids->push_back(res->getString(1));
    }
    connect_pool->RecycleConnection(con);
  } catch (sql::SQLException &e) {
    LOG(WARNING) << "# ERR: " << e.what();
    connect_pool->RecycleConnection(con);
    return false;
  }
}

double *SingMysqlUtils::GetBgm(const string &song_id, int bgm_length) {
  double *bgms = NULL;
  util::MysqlConnectionPoolManager *manager =
      Singleton<util::MysqlConnectionPoolManager>::get();
  util::MysqlConnectionPool *connect_pool =
      manager->GetPool(FLAGS_mysql_server_conf);
  sql::Connection *con = connect_pool->GetConnection();
  int count_down = 10;
  while (con == nullptr && count_down > 0) {
    mobvoi::Sleep(2);
    con = connect_pool->GetConnection();
    --count_down;
  }
  try {
    std::auto_ptr<sql::PreparedStatement> stmt(con->prepareStatement(
        "SELECT song_bgm FROM song_features where song_id = ? "));
    stmt->setString(1, song_id);

    std::unique_ptr<sql::ResultSet> res(stmt->executeQuery());
    sql::ResultSetMetaData *meta = res->getMetaData();
    while (res->next()) {
      bgms = new double[bgm_length];
      std::istringstream *iss = (std::istringstream *)res->getBlob(1);
      iss->read(reinterpret_cast<char *>(bgms), sizeof(double) * bgm_length);
      break;
    }
    connect_pool->RecycleConnection(con);
  } catch (sql::SQLException &e) {
    LOG(WARNING) << "# ERR: " << e.what();
    connect_pool->RecycleConnection(con);
    return false;
  }
  return bgms;
}
}  // namespace sing_synthesizer
