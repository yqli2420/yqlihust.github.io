// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng yang)

#include "tts/synthesizer/sing_synthesis/sing_synthesis.h"

#include <algorithm>  // NOLINT
#include <fstream>    // NOLINT

#include "mobvoi/base/at_exit.h"

#include "tts/synthesizer/sing_synthesis/sing_pau_default.h"
#include "tts/synthesizer/sing_synthesis/stretch_features.h"
#include "tts/synthesizer/vocoder/world_vocoder/world/audioio.h"

DEFINE_bool(if_use_song_bgm, true, "");
DEFINE_double(bgm_volume_rate, 1.0, "");
DEFINE_double(song_volume_rate, 0.3, "");
DEFINE_double(f0_adjust_rate, 0, "");

namespace sing_synthesizer {

static const int kMgcOrder = 59;
static const int kNbit = 16;
static const int kFramPeriod = 10;

#define abs(x) (x > 0 ? x : -x)
#define min(x, y) (x > y ? y : x)

void SingingSyntheszer::ReadFeature(vector<vector<double> > *feature,
                                    int pau_order, bool is_ap) {
  int pau_features_count = 3;
  if (is_ap) {  // read ap features
    for (int i = 0; i < pau_features_count; i++) {
      vector<double> tmp;
      for (int j = 0; j < pau_order; j++) {
        tmp.push_back(ap_1_sil_features[i][j]);
      }
      feature->push_back(tmp);
    }
  } else {
    for (int i = 0; i < pau_features_count; i++) {
      vector<double> tmp;
      for (int j = 0; j < pau_order; j++) {
        if (use_mgc_) {
          tmp.push_back(mgc_60_sil_features[i][j]);
        } else {
          tmp.push_back(mgc_60_sil_features[i][j]);
        }
      }
      feature->push_back(tmp);
    }
  }
}

double *SingingSyntheszer::ReadF0(string f0_fn, int len) {
  FILE *fp;
  double *ori_f0 = NULL;
  fp = fopen(f0_fn.c_str(), "rb");
  if (fp == NULL) {
    LOG(ERROR) << "open f0 file failed.";
  } else {
    ori_f0 = new double[len];
    for (int i = 0; i < len; i++) {
      fread(&ori_f0[i], sizeof(double), 1, fp);
    }
    fclose(fp);
  }
  return ori_f0;
}

double *SingingSyntheszer::GetF0(string song_id, int *len) {
  if (song_map_.find(song_id) != song_map_.end()) {
    if (use_sql_) {
      *len = song_map_[song_id].f0_length;
      double *ret = smu_.GetF0(song_id, *len);
      if (ret == NULL) {
        LOG(ERROR) << "get fail from map :get_f0 ";
      }
      return ret;
    } else {
      *len = song_map_[song_id].f0_length;
      return song_map_[song_id].ori_f0;
    }

  } else {
    LOG(ERROR) << "get fail from map :get_f0.";
    *len = 0;
    return NULL;
  }
}

BgmParameters SingingSyntheszer::ReadBgm(const char *bgm_fn) {
  BgmParameters bp;
  int x_length = world_vocoder::GetAudioLength(bgm_fn);
  if (x_length <= 0) {
    if (x_length == 0) {
      LOG(ERROR) << "Error! " << bgm_fn << " not found. ";
    } else {
      LOG(ERROR) << "Error! The file " << bgm_fn << "  is not .wav format ";
    }
    bp.length = -1;
    bp.data = NULL;
  } else {
    double *x = new double[x_length];
    int fs, nbit;
    world_vocoder::wavread(bgm_fn, &fs, &nbit, x);
    bp.length = x_length;
    bp.data = x;
  }
  return bp;
}

void SingingSyntheszer::GetParamsFromFs(int fs, int *ap_order, int *sp_order) {
  *ap_order = static_cast<int>(
      world_vocoder::MyMinDouble(world_vocoder::kUpperLimit,
                                 fs / 2.0 - world_vocoder::kFrequencyInterval) /
      world_vocoder::kFrequencyInterval);
  if (fs == 16000) {
    *sp_order = 513;
  } else if (fs == 22050) {
    *sp_order = 513;
  } else if (fs == 44100) {
    *sp_order = 1025;
  } else if (fs == 48000) {
    *sp_order = 1025;
  } else {
    LOG(WARNING)
        << "FS not in default list , plase change to 16000 22050 44100 48000 ";
    *sp_order = 513;
  }
}

SingingSyntheszer::SingingSyntheszer(const string base_fn, int fs,
                                     bool use_mgc) {
  use_sql_ = false;
  use_mgc_ = use_mgc;
  int sp_order = 0, ap_order = 0;
  GetParamsFromFs(fs, &ap_order, &sp_order);
  this->resource_ = base_fn;
  fs_ = fs;

  // read pau
  ReadFeature(&mgc_pau_, sp_order, false);
  ReadFeature(&bap_pau_, ap_order, true);

  ap_order_ = ap_order;
  sp_order_ = sp_order;
  if (use_mgc) {
    sp_order_ = kMgcOrder + 1;
  }
  frame_period_ = kFramPeriod;

  // read bgm cut time and music target duration
  string song = base_fn + "tar_dur/time.txt";
  string line;
  std::ifstream fin(song.c_str());
  if (!fin.is_open()) {
    LOG(ERROR) << "time init failed";
  }
  while (getline(fin, line)) {
    SongParameters sp;
    vector<string> v_items = StringSplitToVector(line, ";");
    sp.start_point = atoi(v_items[1].c_str());
    sp.end_point = atoi(v_items[2].c_str());
    sp.bgm_id = StringSplitToVector(v_items[0], "-")[0];
    string f0fn = base_fn + "f0/" + v_items[0] + ".dtf0";
    int len = world_vocoder::file_size(f0fn.c_str());
    sp.ori_f0 = ReadF0(f0fn, len);
    sp.f0_length = len;
    sp.tar_str = v_items[3];
    sp.force_voice_seq = " ";
    /*sp.tar_len = atoi(v_items[4].c_str());*/
    sp.tar_len = 1200;
    song_map_[v_items[0]] = sp;

    if (bgm_map_.empty()) {
      string bgm_fn = this->resource_ + "bgm/" + sp.bgm_id + "-bgm.wav";
      bgm_map_[sp.bgm_id] = ReadBgm(bgm_fn.c_str());
    }
    if (bgm_map_.find(sp.bgm_id) == bgm_map_.end()) {
      string bgm_fn = this->resource_ + "bgm/" + sp.bgm_id + "-bgm.wav";
      bgm_map_[sp.bgm_id] = ReadBgm(bgm_fn.c_str());
    }
    if (stime_map_.empty()) {
      stime_map_[sp.bgm_id].start = sp.start_point;
      stime_map_[sp.bgm_id].end = sp.end_point;
    } else if (stime_map_.find(sp.bgm_id) ==
               stime_map_.end()) {  // stime_map_ is not empty, but new song is
                                    // not included it
      stime_map_[sp.bgm_id].start = sp.start_point;
      stime_map_[sp.bgm_id].end = sp.end_point;
    } else {
      if (stime_map_[sp.bgm_id].start > sp.start_point)
        stime_map_[sp.bgm_id].start = sp.start_point;
      if (stime_map_[sp.bgm_id].end < sp.end_point)
        stime_map_[sp.bgm_id].end = sp.end_point;
    }
  }
  fin.close();
}

SingingSyntheszer::SingingSyntheszer(int fs, bool use_mgc) {
  base::AtExitManager at_exit;
  use_sql_ = true;
  use_mgc_ = use_mgc;
  int sp_order = 0, ap_order = 0;
  GetParamsFromFs(fs, &ap_order, &sp_order);
  ap_order_ = ap_order;
  sp_order_ = sp_order;
  fs_ = fs;
  frame_period_ = kFramPeriod;
  if (use_mgc) {
    sp_order_ = kMgcOrder + 1;
  }
  // read pau
  ReadFeature(&mgc_pau_, sp_order_, false);
  ReadFeature(&bap_pau_, ap_order_, true);

  SongFeatureParam sfp;
  vector<string> song_ids;
  smu_.GetAllSongId(&song_ids);
  for (int i = 0; i < song_ids.size(); i++) {
    SongParameters sp;
    if (smu_.GetMessageFromSql(song_ids[i], &sfp)) {
      sp.start_point = sfp.bgm_start;
      sp.end_point = sfp.bgm_end;
      sp.bgm_id = sfp.song_name;
      sp.ori_f0 = NULL;
      sp.f0_length = sfp.f0_length;
      sp.tar_str = sfp.song_duration;
      sp.force_voice_seq = "";
      sp.tar_len = 1200;
      sp.bgm_length = sfp.bgm_length;
      song_map_[song_ids[i]] = sp;

      if (stime_map_.empty()) {
        stime_map_[sp.bgm_id].start = sp.start_point;
        stime_map_[sp.bgm_id].end = sp.end_point;
      } else if (stime_map_.find(sp.bgm_id) ==
                 stime_map_.end()) {  // stime_map_ is not empty, but new song
                                      // is not included it
        stime_map_[sp.bgm_id].start = sp.start_point;
        stime_map_[sp.bgm_id].end = sp.end_point;
      } else {
        if (stime_map_[sp.bgm_id].start > sp.start_point)
          stime_map_[sp.bgm_id].start = sp.start_point;
        if (stime_map_[sp.bgm_id].end < sp.end_point)
          stime_map_[sp.bgm_id].end = sp.end_point;
      }
    }
  }
}
void SingingSyntheszer::SetPagamsFromFs(int fs, bool use_mgc) {
  int sp_order = 0, ap_order = 0;
  LOG(INFO) << "current wav fs : " << fs;
  GetParamsFromFs(fs, &ap_order, &sp_order);
  ap_order_ = ap_order;
  sp_order_ = sp_order;
  frame_period_ = kFramPeriod;
  if (use_mgc) {
    sp_order_ = kMgcOrder + 1;
  }
  fs_ = fs;
}
SingingSyntheszer::~SingingSyntheszer() {
  map<string, BgmParameters>::iterator it_bgm = bgm_map_.begin();
  map<string, SongParameters>::iterator it_song = song_map_.begin();

  while (it_bgm != bgm_map_.end()) {
    if (it_bgm->second.data != NULL) {
      delete[] it_bgm->second.data;
    }
    it_bgm++;
  }

  while (it_song != song_map_.end()) {
    if (it_song->second.ori_f0 != NULL) {
      delete[] it_song->second.ori_f0;
    }
    it_song++;
  }
}

double SingingSyntheszer::GetConfigDouble(const char *key) {
  bool use_default_value = true;
  if (use_default_value) {
    double ret_value = 0;
    if (!strcmp(key, "noise_threshold")) {
      ret_value = 1000.0;
    } else if (!strcmp(key, "max_volume")) {
      ret_value = 0.3;
    } else if (!strcmp(key, "frame_period")) {
      ret_value = 10;
    } else {
      LOG(ERROR) << "ERROR: key [" << key
                 << "] not found in both config file and default values!";
      return 0;
    }
    return ret_value;
  }
}

double *SingingSyntheszer::GetF0(string song_id) {
  if (use_sql_ && song_map_.find(song_id) != song_map_.end()) {
    int f0_length = song_map_[song_id].f0_length;
    double *ret = smu_.GetF0(song_id, f0_length);
    if (ret == NULL) {
      LOG(ERROR) << "get fail from map :get_f0 ";
    }
    return ret;
  }
  if (song_map_.find(song_id) != song_map_.end()) {
    return song_map_[song_id].ori_f0;
  } else {
    LOG(ERROR) << "get fail from map :get_f0 ";
    return NULL;
  }
}

string SingingSyntheszer::GetTar(string song_id, int *len) {
  if (song_map_.find(song_id) != song_map_.end()) {
    *len = song_map_[song_id].tar_len;
    return song_map_[song_id].tar_str;
  } else {
    LOG(ERROR) << "get fail from map :get_tar.";
    *len = 0;
    return "";
  }
}

string SingingSyntheszer::GetForceUV(string asr_align) {
  string char_type = "bpfdtgkhjqxzcszhchsh";
  vector<string> syls = StringSplitToVector(asr_align, " ");
  string uv_out;
  for (int i = 0; i < syls.size(); i++) {
    vector<string> syl_phns = StringSplitToVector(syls[i], ":");
    string c_phone = syl_phns[0];
    if (c_phone == "sil") {
      continue;
    }
    uv_out += c_phone + ":";
    for (int j = 1; j < syl_phns.size(); j++) {
      vector<string> phns = StringSplitToVector(syl_phns[j], "_");
      if (char_type.find(phns[0]) >= 0) {
        uv_out += phns[0] + "_0";
      } else {
        uv_out += phns[0] + "_1";
      }
      if (j != syl_phns.size() - 1) {
        uv_out += ":";
      }
    }
    uv_out += " ";
  }
  return uv_out;
}

double *SingingSyntheszer::GetBgm(string sent_id, int *sent_start,
                                  int *sent_end, int *song_bgm_length,
                                  int *song_start, int *song_end) {
  *song_bgm_length = -1;
  *sent_start = -1;
  *song_start = -1;
  *song_end = -1;
  *sent_end = -1;
  double *p = NULL;
  if (song_map_.find(sent_id) != song_map_.end()) {
    *sent_start = song_map_[sent_id].start_point;
    *sent_end = song_map_[sent_id].end_point;
    string bgm_id = song_map_[sent_id].bgm_id;
    *song_start = stime_map_[bgm_id].start;
    *song_end = stime_map_[bgm_id].end;
    if (use_sql_) {
      *song_bgm_length = song_map_[sent_id].bgm_length;
      p = smu_.GetBgm(sent_id, *song_bgm_length);
    } else {
      *song_bgm_length = bgm_map_[bgm_id].length;
      p = bgm_map_[bgm_id].data;
    }
  }
  return p;
}

int SingingSyntheszer::GetTime(string song_id, int *start, int *end) {
  if (song_map_.find(song_id) != song_map_.end()) {
    *start = song_map_[song_id].start_point;
    *end = song_map_[song_id].end_point;
    return 0;
  } else {
    *start = 0;
    *end = 0;
    return -1;
  }
}

// 将读入的void* 数据转化为double *
double *char2Todouble(void *data, int *nbit, int x_length) {
  double *x = new double[x_length];

  unsigned char *d = (unsigned char *)data;
  int quantization_byte = *nbit / 8;
  double zero_line = pow(2.0, *nbit - 1);
  double tmp, sign_bias;
  unsigned char for_int_number[2];
  for (int i = 0; i < x_length; ++i) {
    sign_bias = tmp = 0.0;
    for_int_number[0] = *d;
    for_int_number[1] = *(d + 1);
    d = d + 2;
    if (for_int_number[quantization_byte - 1] >= 128) {
      sign_bias = pow(2.0, *nbit - 1);
      for_int_number[quantization_byte - 1] =
          for_int_number[quantization_byte - 1] & 0x7F;
    }
    for (int j = quantization_byte - 1; j >= 0; --j)
      tmp = tmp * 256.0 + for_int_number[j];
    x[i] = (tmp - sign_bias) / zero_line;
  }
  return x;
}

void Samples2PCM(const double *y, int y_length, void **pcm);

double *SingingSyntheszer::SongMix(double *y, string sent_id, int *y_length) {
  int sent_bgm_length = 0;
  int sent_song_length = 0;
  int sent_bgm_start = 0;   // 与该句歌曲对应的背景音乐的开始
  int sent_bgm_end = 0;     // 与该句歌曲对应的背景音乐的结束
  int song_bgm_length = 0;  // 整首歌bgm的长度
  int song_start = 0;       // 整首歌的开始时间
  int song_end = 0;         // 整首歌的结束时间
  double *song_bgm = GetBgm(sent_id, &sent_bgm_start, &sent_bgm_end,
                            &song_bgm_length, &song_start, &song_end);
  if (song_bgm == NULL || y == NULL || *y_length == 0) {
    return NULL;
  }
  double rate = static_cast<double>(fs_) / 16000.0;
  sent_bgm_start = song_start = song_start * rate;
  sent_bgm_end = song_end = song_end * rate;
  for (int i = 0; i < song_bgm_length; i++) {
    song_bgm[i] = song_bgm[i] * FLAGS_bgm_volume_rate;
  }
  int cut_start = sent_bgm_start;
  int cut_end = sent_bgm_end;
  int insert_start = 0;
  int insert_end = 0;
  if (sent_bgm_start == song_start) {
    sent_bgm_length = sent_bgm_end;
    cut_start = 0;
    insert_start = sent_bgm_start;
    insert_end = sent_bgm_end;
  } else if (sent_bgm_end == song_end) {
    sent_bgm_length = song_bgm_length - sent_bgm_start;
    insert_end = song_bgm_length - sent_bgm_start;
  } else {
    sent_bgm_length = sent_bgm_end - sent_bgm_start;
    insert_end = sent_bgm_length;
  }
  double *sent_bgm = new double[sent_bgm_length];
  memcpy(sent_bgm, song_bgm + cut_start, sent_bgm_length * sizeof(double));
  if (use_sql_ && song_bgm != NULL) {
    delete[] song_bgm;
  }
  song_bgm = NULL;
  int bgm_song_diff = (insert_end - insert_start - *y_length) / 2;

  for (int i = 0;
       i < min(*y_length, sent_bgm_length - 1 - insert_start - bgm_song_diff);
       i++)
    sent_bgm[i + insert_start + bgm_song_diff] =
        sent_bgm[i + insert_start + bgm_song_diff] + y[i];
  *y_length = sent_bgm_length;
  return sent_bgm;
}

double *SingingSyntheszer::FixF0ByAsrUV(string asr_dur, double *f0,
                                        int f0_length) {
  int *vuv = new int[f0_length];
  double *fixed_f0 = new double[f0_length];  // return, free outside

  memset(vuv, 0, f0_length * sizeof(int));
  memset(fixed_f0, 0, f0_length * sizeof(double));

  // unvoice = ['d','f','h','p','t','c','k','q','s','sh','ch','zh','x','z','b']
  // string unvoice1[] = {"d", "f", "sil", "h", "p", "t", "c", "k", "q", "sh",
  // "ch", "zh", "x"};
  const string unvoice1[] = {"sil"};

  const string voice_list[] = {
      "a",   "o",   "e",   "i",   "u",  "v",  "ai", "ei", "ui", "ao",
      "ou",  "iu",  "ie",  "ue",  "er", "an", "en", "in", "un", "vn",
      "ang", "eng", "ing", "ong", "b",  "p",  "m",  "f",  "d",  "r",
      "t",   "n",   "l",   "g",   "k",  "h",  "j",  "q",  "x",  "z",
      "c",   "s",   "zh",  "ch",  "sh", "y",  "w"};  // sh, t, q 不行
  vector<string> voice(voice_list, voice_list + 24 + 23);
  /* asr_dur example: 'sil:sil_38 ren:r_32:e_10:n_24'
   * syl_info example: 'ren:r_32:e_10:n_24' */
  vector<string> syl_info = StringSplitToVector(asr_dur, " ");

  /* generate vuv value by phone duration */
  int idx = 0;
  string syllabel, first_phone;
  for (int i = 0; i < f0_length; ++i) {
    if (f0[i] > 0) {
      vuv[i] = 1;
    }
  }
  if (force_voice_seq_ == " ") {
    for (int i = 0; i < syl_info.size(); i++) {
      /* phone_info example: 'ren' 'r_32' 'e_10' 'n_24' */
      vector<string> phone_info = StringSplitToVector(syl_info[i], ":");
      if (phone_info.size() < 2) {
        /* The phone might be some blank*/
        break;
      }

      int phone_dur = 0;
      int vuv_phone = 0;
      string phone_name = "";
      syllabel = phone_info[0];
      first_phone = StringSplitToVector(phone_info[1], "_")[0];
      vector<string>::iterator it =
          find(voice.begin(), voice.end(), first_phone);
      /* 'j' start from 1, because the 0th token is the 'full syllabel' */
      for (int j = 1; j < phone_info.size(); j++) {
        if (it == voice.end()) {
          /* The first phone is CONSONENT*/
          vuv_phone = j == 1 ? 0 : 1;
        } else {
          /* The first phone is VOWEL
           * "ang" will be treated as all VOICE */
          vuv_phone = 1;
        }
        phone_dur = atoi(StringSplitToVector(phone_info[j], "_")[1].c_str()) /
                    (static_cast<int>(frame_period_ / 5));
        phone_name = StringSplitToVector(phone_info[j], "_")[0];

        /* check whether the current phone is unvoice
         * NOTE: if current phone IS NOT unvoice, then set it '1' */
        for (int i = idx; i < idx + phone_dur; i++) {
          if (vuv_phone == 1) {
            vuv[i] = 1;
          }
        }
        idx += phone_dur;
      }
    }
  } else {
    vector<string> voice_flag_seq = StringSplitToVector(force_voice_seq_, " ");
    int flag_index = -1;
    vector<string> voice_flag;

    for (int i = 0; i < syl_info.size(); i++) {
      /* phone_info example: 'ren' 'r_32' 'e_10' 'n_24' */
      vector<string> phone_info = StringSplitToVector(syl_info[i], ":");
      if (phone_info.size() < 2) {
        /* The phone might be some blank*/
        break;
      }

      if (phone_info[0] != "pau" && phone_info[0] != "sil") {
        flag_index++;
        if (flag_index >= voice_flag_seq.size()) {
          LOG(ERROR) << "warning: phone of asr_dur is more than flag_seq.";
          break;
        }
        voice_flag = StringSplitToVector(voice_flag_seq[flag_index], ":");
      }

      int phone_dur = 0;
      int vuv_phone = 0;
      syllabel = phone_info[0];
      for (int j = 1; j < phone_info.size(); j++) {
        phone_dur = atoi(StringSplitToVector(phone_info[j], "_")[1].c_str()) /
                    static_cast<int>(frame_period_ / 5);

        if (StringSplitToVector(phone_info[j], "_")[0] == "pau" ||
            StringSplitToVector(phone_info[j], "_")[0] == "sil") {
          vuv_phone = 0;
        } else {
          vuv_phone = atoi(StringSplitToVector(voice_flag[j], "_")[1].c_str());
        }
        /* check whether the current phone is unvoice
         * NOTE: if current phone IS NOT unvoice, then set it '1' */
        for (int i = idx; i < idx + phone_dur; i++) {
          if (vuv_phone == 1) {
            vuv[i] = 1;
          }
        }
        idx += phone_dur;
      }
    }
  }

  /* Linear interpolate the F0(tf0, not lf0) for the "f0-unextracted" frames.*/
  int index = 0;
  /* find the 1st '1' index */
  while (index < f0_length && f0[index] == 0) ++index;
  /* all the f0 before the first '1' set to the first '1' f0
   * if all '0', then remain them all '0' */
  if (index < f0_length) {
    for (int i = 0; i < index; ++i) fixed_f0[i] = f0[index] * vuv[i];
  }
  int begin = index;
  while (index < f0_length) {
    /* find the next '0' index */
    while (index < f0_length && f0[index] > 0) ++index;

    /* before the next '0', all '1' f0 keep unchanged */
    for (int i = begin; i < index; ++i) fixed_f0[i] = f0[i] * vuv[i];
    begin = index - 1;

    /* find the next '1' index */
    while (index < f0_length && f0[index] == 0) ++index;

    if (index == f0_length) { /* if no next '1', set all the rest the final 1 */
      for (int i = begin; i < index; ++i) fixed_f0[i] = f0[begin - 1] * vuv[i];
    } else {
      /* if found next '1', linear interpolate them
       * (TODO: yxp) it should be interpolated in LOG domain */
      for (int i = begin; i < index; ++i)
        fixed_f0[i] =
            (f0[begin] +
             (f0[index] - f0[begin]) / (index - begin) * (i - begin)) *
            vuv[i];
    }
    begin = index;
  }
  delete[] vuv;
  delete[] f0;
  return fixed_f0;
}

bool SingingSyntheszer::NoiseRate(const string asr_dur, const double *x,
                                  int x_length) {
  const string silence = "sil";
  const int samples_per_frame = 80; /* 5ms audio per frame for 16kHz */
  const double noise_threshold = GetConfigDouble(
      "noise_threshold"); /* TODO(yxp): need to find a good value */

  /* asr_dur example: 'sil:sil_38 ren:r_32:e_10:n_24'
   * syl_info example: 'ren:r_32:e_10:n_24' */
  vector<string> syl_info = StringSplitToVector(asr_dur, " ");

  int idx = 0;
  double energy = 0;
  int energy_samples_count = 0;
  int energy_frame_count = 0;
  int begin_index = 0, end_index = 0;
  for (int i = 0; i < syl_info.size(); i++) {
    /* phone_info example: 'ren' 'r_32' 'e_10' 'n_24' */
    vector<string> phone_info = StringSplitToVector(syl_info[i], ":");

    int phone_dur = 0;
    string phone_name = "";
    /* 'j' start from 1, because the 0th token is the 'full syllabel' */
    for (int j = 1; j < phone_info.size(); j++) {
      phone_dur = atoi(StringSplitToVector(phone_info[j], "_")[1].c_str()) /
                  static_cast<int>(frame_period_ / 5);
      phone_name = StringSplitToVector(phone_info[j], "_")[0];

      /* if match the silence phone */
      if (!phone_name.compare(silence)) {
        /* change the frame duration to signal position */
        begin_index = min(x_length - 1, idx * samples_per_frame);
        end_index = min(x_length, (idx + phone_dur) * samples_per_frame);
        for (int i = begin_index; i < end_index; ++i) {
          energy += abs(x[i]);
          ++energy_samples_count;
        }
        energy_frame_count += phone_dur;
      }
      idx += phone_dur;
    }
  }
  // energy_samples_count, energy_frame_count, energy / energy_frame_count);
  return (energy / energy_frame_count) > noise_threshold;
}

void SingingSyntheszer::NormalizeVolume(double *x, int x_length) {
  double max_x = 0;
  double max_volume = GetConfigDouble("max_volume");
  static const int window = 1024;
  if (FLAGS_song_volume_rate == 0) {
    max_volume = FLAGS_song_volume_rate;
  }
  double volume_sum = 0.0;
  for (int i = 0; i < x_length; ++i) {
    if (i >= window) volume_sum -= abs(x[i - window]);
    volume_sum += abs(x[i]);

    max_x = std::max(max_x, volume_sum);
  }
  if (max_x != 0) {
    for (int i = 0; i < x_length; ++i) {
      x[i] = x[i] / (max_x / window) * max_volume;
    }
  }
}

void SingingSyntheszer::InterpTf0Seq(const double *f0, int f0_length,
                                     double *cf0) {
  double *cont_song_f0 = new double[f0_length];
  double *before = new double[f0_length];
  double *index = new double[f0_length];
  double *new_index = new double[f0_length];
  int samples = 0;

  samples = 0;
  for (int i = 0; i < f0_length; ++i) {
    if (f0[i] > 0) {
      /* if the 1st signal is not 1, set it 1 */
      if (samples == 0 && i != 0) {
        before[samples] = f0[i];
        index[samples] = 0;
        samples += 1;
      }
      before[samples] = f0[i];
      index[samples] = i;
      samples += 1;
    }
    new_index[i] = i;
  }
  if (index[samples - 1] != f0_length - 1) {
    index[samples] = f0_length - 1;
    before[samples] = f0[static_cast<int>(index[samples - 1])];
    ++samples;
  }
  world_vocoder::interp1(index, before, samples, new_index, f0_length, cf0);
  delete[] new_index;
  delete[] index;
  delete[] before;
  delete[] cont_song_f0;
}

double *SingingSyntheszer::CutSilence(double *x, string *_sym, int *x_length) {
  vector<string> v_x = StringSplitToVector(*_sym, " ");
  int offset = 0;
  int s = 0;
  int e = v_x.size();
  vector<string> v_syl_start = StringSplitToVector(v_x[0], ":");
  vector<string> v_syl_end = StringSplitToVector(v_x[v_x.size() - 1], ":");
  if (v_syl_start[0] == "sil") {
    for (int i = 1; i < v_syl_start.size(); i++) {
      *x_length -=
          80 * atoi(StringSplitToVector(v_syl_start[i], "_")[1].c_str());
      offset += 80 * atoi(StringSplitToVector(v_syl_start[i], "_")[1].c_str());
    }
    s++;
  }
  if (v_syl_end[0] == "sil") {
    for (int i = 1; i < v_syl_start.size(); i++) {
      *x_length -= 80 * atoi(StringSplitToVector(v_syl_end[i], "_")[1].c_str());
    }
    e--;
  }
  *_sym = "";
  for (int i = s; i < e; i++) {
    *_sym += v_x[i] + " ";
  }
  double *r_x = new double[*x_length];
  memcpy(r_x, x + offset, (*x_length) * sizeof(double));
  delete[] x;
  x = NULL;
  return r_x;
}

void delete_arrys(double **data, int len) {
  if (data != NULL) {
    for (int i = 0; i < len; i++) {
      if (data[i] != NULL) {
        delete[] data[i];
      }
    }
    delete[] data;
  }
}

double average_doubles(double *d, int len) {
  double sum = 0.0;
  int count = 0;
  for (int i = 0; i < len; i++) {
    if (d[i] != 0) {
      sum += d[i];
      count++;
    }
  }
  return sum / count;
}

void adjust_songf0_by_user(double user_f0_avg, double *song_f0,
                           int song_f0_len) {
  double song_f0_avg = average_doubles(song_f0, song_f0_len);
  double rate = user_f0_avg / song_f0_avg;
  if (FLAGS_f0_adjust_rate != 0) {
    rate = FLAGS_f0_adjust_rate;
  }
  for (int i = 0; i < song_f0_len; i++) {
    song_f0[i] = song_f0[i] * rate;
  }
}

double *SingingSyntheszer::sing_synthesis(void *x_v, int x_length,
                                          int *y_length, string asr_dur,
                                          string tar_dur, string sent_id) {
  base::AtExitManager at_exit;
  int elapsed_time;
  world_vocoder::WorldVocoder vocoder(fs_, frame_period_);
  if (use_mgc_) {
    vocoder.set_mgc_order(kMgcOrder);
  }
  // 转化 void*数据到double*
  double *x = reinterpret_cast<double *>(x_v);

  force_voice_seq_ = GetForceUV(asr_dur);
  // 切除前后sil 减少计算量
  // x = CutSilence(x, &(asr_dur), &x_length);

  // 判断是否需要降噪 以及降噪
  // denoise(x, x_length, str_json);

  vector<double> f0;
  vector<vector<double> > dsp;
  vector<vector<double> > dap;

  // 提取特征 并根据 asr_dur 对 f0 进行校准
  vocoder.AnalysisFromPCM(fs_, 10, x, x_length, &f0, &dsp, &dap);
  vector<vector<double> > df0;
  double user_f0_rate = 0;
  int count = 0;
  for (int i = 0; i < f0.size(); i++) {
    vector<double> tmp;
    tmp.push_back(f0[i]);
    df0.push_back(tmp);
    tmp.clear();
    if (f0[i] != 0) {
      user_f0_rate += f0[i];
      count++;
    }
  }
  user_f0_rate = user_f0_rate / count;

  // 得到歌唱 f0
  int song_f0_length, dur_len;
  double *song_f0 = GetF0(sent_id, &song_f0_length);
  if (tar_dur == "") tar_dur = GetTar(sent_id, &dur_len);
  if (tar_dur == "" || song_f0 == NULL || song_f0_length == 0) {
    LOG(ERROR) << "tar_dur is empty or no song_f0 or song_f0_length is 0 ";
    *y_length = 0;
    delete[] x;
    return NULL;
  }

  // 对歌曲 f0 进行插值，使得潜在的uv不准可以补全
  InterpTf0Seq(song_f0, song_f0_length, song_f0);

  // 对歌曲 f0 进行变调调整，使其适合发音人
  adjust_songf0_by_user(user_f0_rate, song_f0, song_f0_length);

  // 拉伸音频特征
  vector<vector<double> > vuv;
  for (int i = 0; i < f0.size(); ++i) {
    vector<double> tmp;
    if (f0[i] > 0) {
      tmp.push_back(1.0);
    } else {
      tmp.push_back(0.0);
    }
    vuv.push_back(tmp);
  }
  double **tmgc = new double *[song_f0_length];
  double **tbap = new double *[song_f0_length];
  double **tvuv = new double *[song_f0_length];
  StreathingFeature sf(mgc_pau_, mgc_pau_, sp_order_, ap_order_, frame_period_,
                       1);
  int sp_length = sf.Process(tar_dur, asr_dur, dsp, dap, vuv, tmgc, tbap, tvuv);
  if (sp_length == 0 || sp_length != song_f0_length) {
    delete_arrys(tmgc, song_f0_length);
    delete_arrys(tbap, song_f0_length);
    delete_arrys(tvuv, song_f0_length);
    if (use_sql_ && song_f0 != NULL) {
      delete[] song_f0;
      song_f0 = NULL;
    }
    LOG(ERROR) << "matched sp_length : different from song_f0_length "
               << sp_length << " " << song_f0_length;
  }
  vector<vector<double> > dap_song;
  vector<double> df0_song;
  vector<double> data;
  vector<vector<double> > sp_song;
  for (int i = 0; i < sp_length; i++) {
    df0_song.push_back(song_f0[i]);
    vector<double> tmp;
    for (int j = 0; j < sp_order_; j++) {
      tmp.push_back(tmgc[i][j]);
    }
    sp_song.push_back(tmp);
    tmp.clear();
    for (int j = 0; j < ap_order_; j++) {
      tmp.push_back(tbap[i][j]);
      // cout << tbap[i][j] << endl;
    }
    dap_song.push_back(tmp);
  }
  if (use_sql_ && song_f0 != NULL) {
    delete[] song_f0;
    song_f0 = NULL;
  }
  delete_arrys(tmgc, song_f0_length);
  delete_arrys(tbap, song_f0_length);
  delete_arrys(tvuv, song_f0_length);
  vocoder.SynthesizeFeaFromFea(df0_song, sp_song, dap_song, &data);
  double *y = new double[data.size()];
  for (int i = 0; i < data.size(); i++) {
    y[i] = data[i];
  }

  // 归一化音量
  *y_length = data.size();
  NormalizeVolume(y, *y_length);
  // Mix背景音乐
  delete[] x;
  double *wav = NULL;

  if (FLAGS_if_use_song_bgm) {
    wav = SongMix(y, sent_id, y_length);
    delete[] y;
  } else {
    wav = y;
  }
  return wav;
}

// 将PCM波形点数据转化返回
void Samples2PCM(const double *y, int y_length, void **pcm) {
  *pcm = calloc(2, y_length);

  int16_t tmp_signal;
  for (int i = 0; i < y_length; ++i) {
    tmp_signal = static_cast<int16_t>(world_vocoder::MyMaxInt(
        -32768,
        world_vocoder::MyMinInt(32767, static_cast<int>(y[i] * 32767))));
    (reinterpret_cast<char *>(*pcm))[i * 2] =
        *(reinterpret_cast<char *>(&tmp_signal));
    (reinterpret_cast<char *>(*pcm))[i * 2 + 1] =
        *((reinterpret_cast<char *>(&tmp_signal)) + 1);
  }
}
}  // namespace sing_synthesizer
