// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng yang)

#ifndef TTS_SYNTHESIZER_SING_SYNTHESIS_SING_MYSQL_UTILS_H_
#define TTS_SYNTHESIZER_SING_SYNTHESIS_SING_MYSQL_UTILS_H_

#include "mobvoi/util/mysql/mysql_util.h"

namespace sing_synthesizer {

struct SongFeatureParam {
  double *bgm;
  int bgm_length;
  float *f0;
  int f0_length;
  string bgm_fn;
  string f0_fn;
  int bgm_start;
  int bgm_end;
  string song_id;
  string song_name;
  string song_duration;
  string song_text;
  string updata_time;
};

class SingMysqlUtils {
 private:
  SongFeatureParam *sfp_;

 public:
  SingMysqlUtils();
  ~SingMysqlUtils();
  bool GetSongFeatures(string song_id, SongFeatureParam *feature);
  void InsertSongFeatures(string base_dir);
  bool CreateSongFeatureTable();
  bool GetAllFromSql(string song_id, Json::Value *data);
  bool GetMessageFromSql(string song_id, SongFeatureParam *sfp);
  double *GetF0(const string &song_id, int f0_length);
  bool GetAllSongId(vector<string> *song_ids);
  double *GetBgm(const string &song_id, int bgm_length);
};
}  // namespace sing_synthesizer
#endif  // TTS_SYNTHESIZER_SING_SYNTHESIS_SING_MYSQL_UTILS_H_
