// Copyright 2012-2016 Masanori Morise. All Rights Reserved.
// Author: mmorise [at] yamanashi.ac.jp (Masanori Morise)

#include <fstream>  // NOLINT

#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"

#include "tts/synthesizer/sing_synthesis/sing_synthesis.h"
#include "tts/synthesizer/vocoder/world_vocoder/world/world_vocoder.h"

static const int kSamplingRate = 16000;

DEFINE_string(base_dir, "tts/synthesizer/sing_synthesis/data/",
              "base_dir file path");
DEFINE_string(res_dir, "tts/synthesizer/sing_synthesis/data/resource/",
              "resource path");
DEFINE_string(dur_file, "tts/synthesizer/sing_synthesis/data/dur.txt",
              "dur_file path");
DEFINE_bool(if_use_mgc, true, "");

int main(int argc, char *argv[]) {
  google::ParseCommandLineFlags(&argc, &argv, false);
  std::ifstream fin(FLAGS_dur_file.c_str());
  if (!fin.is_open()) {
    LOG(ERROR) << "asr_durs init failed" << endl;
    return -1;
  }
  sing_synthesizer::SingingSyntheszer sing_syn(FLAGS_res_dir, kSamplingRate,
                                               FLAGS_if_use_mgc);
  int y_length = 0;
  double *y;
  string line;
  while (getline(fin, line)) {
    vector<string> v_s = sing_synthesizer::StringSplitToVector(line, ";");
    string speaker_id = v_s[0];
    string asr_dur = v_s[1];
    string wav_file = FLAGS_base_dir + "/" + speaker_id + ".wav";
    string out_file = FLAGS_base_dir + "/trans_" + speaker_id + ".wav";
    int x_length = world_vocoder::GetAudioLength(wav_file.c_str());
    double *pcm = new double[x_length];
    int fs = 0, nbit = 0;
    world_vocoder::wavread(wav_file.c_str(), &fs, &nbit, pcm);
    sing_syn.SetPagamsFromFs(fs, FLAGS_if_use_mgc);
    void *wav = reinterpret_cast<void *>(pcm);
    y = sing_syn.sing_synthesis(wav, x_length, &y_length, asr_dur, "",
                                speaker_id);

    world_vocoder::WavWriteUtils(y, y_length, fs, nbit, out_file.c_str());
    delete[] y;
  }
  fin.close();
  return 0;
}
