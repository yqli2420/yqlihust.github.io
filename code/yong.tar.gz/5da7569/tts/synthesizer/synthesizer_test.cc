// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/synthesizer/synthesizer.h"
#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/file/proto_util.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/string_util.h"
#include "third_party/gtest/gtest.h"

DEFINE_int32(test_sen_num, 20, "");

namespace tts {

static const string kTestDataDir = "tts/synthesizer/testdata";  // NOLINT

class SynthesizerTest : public ::testing::Test {
 protected:
  virtual void SetUp() {
    const string speaker_info_file =
        "external/config/config_file/speakers.json";
    tts_.reset(new Synthesizer(speaker_info_file));
  }

  std::unique_ptr<Synthesizer> tts_;
};

#ifndef FOR_PORTABLE
TEST_F(SynthesizerTest, GetSupLanguageTest) {
  vector<string> languages = tts_->GetSupLanguages();
  vector<string> expect_languages = {kMandarinTypeString, kEnglishTypeString,
                                     kCantoneseTypeString, kTaiwaneseTypeString,
                                     kSichuaneseTypeString};
  ASSERT_EQ(expect_languages.size(), languages.size());
  for (auto& language : expect_languages) {
    EXPECT_TRUE(std::find(languages.begin(), languages.end(), language) !=
                languages.end());
  }
}
// portable will core dump in multi thread precache because main thread is
// already closed
TEST_F(SynthesizerTest, EdgeTest) {
  string text = "???";
  vector<int16> data;
  tts::TTSOption tts_option;
  tts::SetDefaultTTSOption(&tts_option);
  tts_->Synthesize(text, tts_option, &data);
  EXPECT_EQ(0, data.size());
}
#endif

TEST_F(SynthesizerTest, ApiTest) {
  string text =
      "腾讯科技讯（郑可君 管慕飞） "
      "7月16日，奇点·极客公园创新者峰会在上海科技馆召开。出门问问CEO李志飞在会"
      "上表示：手机已经真正成为人身体的一部分，未来我们的身体里也可能会集成芯片"
      "，不用再携带身份证和信用卡。随着未来的发展，很多机器都会成为人的身体的一"
      "部分，未来人类可能是半人半机器的。 "
      "想要实现这些，需要从语言、声音、视觉方面建立计算机模型，包括大量的数据、"
      "算法、深度学习，机器是无法自己去学习和创意的。 "
      "AI产品化的思路有两种，一种是将AI放到地图、邮箱等现有产品中，提升产品的竞"
      "争力，这是谷歌(微博)"
      "这样已经有产品和用户基础的大公司在做的；另一种是以API的方式开放给第三方"
      "，但是这样难免会忽略产品与AI结合的效果，用户体验难以保障。";
  tts::TTSOption tts_option;
  tts::SetDefaultTTSOption(&tts_option);
  tts_option.set_file_format("wav");
#ifndef FOR_PORTABLE
  ASSERT_TRUE(tts_->LoadSpeaker("cissy"));
  ASSERT_TRUE(tts_->LoadSpeaker("angela_gru"));
#else
#ifdef FOR_CNS
  ASSERT_TRUE(tts_->LoadSpeaker("cissy"));
  ASSERT_TRUE(tts_->LoadSpeaker("angela"));
#else
  tts_option.set_speaker("cissy_hts");
  ASSERT_TRUE(tts_->LoadSpeaker("cissy_hts"));
  ASSERT_TRUE(tts_->LoadSpeaker("angela_hts"));
#endif  // FOR_CNS
#endif  // FOR_PORTABLE

  string string_data;
  tts_->Synthesize(text, tts_option, &string_data);
  CHECK_LT(0, string_data.size());

  vector<int16> int16_data;
  tts_->Synthesize(text, tts_option, &int16_data);
  CHECK_LT(0, int16_data.size());

  class TestInterface : public SynthesizerEventInterface {
   public:
    TestInterface() {}
    virtual ~TestInterface() {}

    virtual void OnStart() {}
    virtual bool OnSynthesizeData(const string& data) { return true; }
    virtual void OnFinish() {}
    virtual string GetResult() { return string(); }
    virtual bool GetChunkDuration(const std::string& duration) { return true; }
  };
  TestInterface callback;
  tts_->Synthesize(text, tts_option, &callback);
}

TEST_F(SynthesizerTest, FeStressTest) {
  vector<string> lines;
  string text_file = mobvoi::File::JoinPath(kTestDataDir, "stress.txt");
  file::SimpleLineReader reader(text_file);
  reader.ReadLines(&lines);
  LOG(INFO) << lines.size();
  TTSOption tts_option;
  tts::SetDefaultTTSOption(&tts_option);
  tts_option.set_only_frontend(true);
  vector<int16> data;
  for (int i = 0; i < FLAGS_test_sen_num; ++i) {
    LOG(INFO) << lines[i];
    tts_->Synthesize(lines[i], tts_option, &data);
  }
}

TEST_F(SynthesizerTest, LoadUnloadSpeaker) {
  vector<std::pair<string, bool>> speakers =
      tts_->GetSpeakers(kMandarinTypeString);
  for (const auto speaker : speakers) {
    EXPECT_TRUE(tts_->LoadSpeaker(speaker.first));
    EXPECT_TRUE(tts_->UnloadSpeaker(speaker.first));
  }
}

}  // namespace tts
