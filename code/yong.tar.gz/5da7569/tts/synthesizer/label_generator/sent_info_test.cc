// Copyright 2017 Mobvoi Inc. All Rights Reserved.
// Author: zalu@mobvoi.com (Ziang Lu)

#include "tts/synthesizer/label_generator/sent_info.h"
#include "tts/synthesizer/label_generator/label_util.h"

#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/string_util.h"
#include "third_party/gtest/gtest.h"

static const char* kTestUpdateToneFile =
    "tts/synthesizer/testdata/test_update_word_tone.txt";
static const char* kToneSoftWordFile =
    "external/config/front_end/dict/soft_word.dict";
namespace tts {

// Testing SplitSyllable
TEST(SentInfoTest, SplitSyllableTest) {
  vector<string> prons;
  prons.push_back("ce4");
  string pos = "v";
  int phone_num;
  int man_phone_num = 0;
  vector<SyllableInfo> syl_infos;
  map<int, int> polyphone_prob;
  SplitSyllable(prons, polyphone_prob, pos, WordLanguage::kMandarinWord,
                kMandarinTypeString, &syl_infos, &phone_num, &man_phone_num);

  EXPECT_EQ(syl_infos[0].prons[0], "c");
  EXPECT_EQ(syl_infos[0].vowel, "e");
  EXPECT_EQ(syl_infos[0].tone, 4);
}

// Testing GenWordInfo
TEST(SentInfoTest, GenWordInfoTest) {
  const string text = "中国";
  const string word_pron = "zhong1 guo2";
  const string word_pos_s = "ns";
  vector<WordToken> word_token;
  WordToken token_tmp;
  token_tmp.word = text;
  token_tmp.pos = word_pos_s;
  token_tmp.language = WordLanguage::kMandarinWord;
  SplitString(word_pron, ' ', &token_tmp.prons);
  word_token.push_back(token_tmp);

  vector<WordInfo> word_info;
  const map<int, int> polyphone_prob;
  GenWordInfo(word_token, polyphone_prob, kMandarinTypeString, &word_info);

  EXPECT_EQ(word_info[0].word, "中国");
  EXPECT_EQ(word_info[0].pause_level, 5);
  EXPECT_EQ(word_info[0].phone_num, 4);
  EXPECT_EQ(word_info[0].syllables[1].tone, 2);
}

struct UpdateToneTestPiece {
  string text;
  string prons;
  string pos_s;
  string expect_prons;
};

void SetUpdateToneTestPiece(const vector<string>& segs,
                            UpdateToneTestPiece* test_piece) {
  assert(segs.size() == 4);
  test_piece->text = segs[0];
  test_piece->prons = segs[1];
  test_piece->pos_s = segs[2];
  test_piece->expect_prons = segs[3];
}

void ReadUpdateToneTestPieces(const string& filename,
                              vector<UpdateToneTestPiece>* test_pieces) {
  file::SimpleLineReader reader(filename, true, "#");
  vector<string> lines;
  reader.ReadLines(&lines);
  for (const string& line : lines) {
    vector<string> segs;
    SplitString(line, '&', &segs);
    UpdateToneTestPiece test_piece;
    SetUpdateToneTestPiece(segs, &test_piece);
    test_pieces->push_back(test_piece);
  }
}

void ConstructSylPron(const SyllableInfo& syl_info, string* syl_pron) {
  for (const string& pron : syl_info.prons) {
    syl_pron->append(pron);
  }
  syl_pron->append(IntToString(syl_info.tone));
}

void GetPronsFromWordInfo(const vector<WordInfo>& word_info, string* prons) {
  vector<string> syl_prons;
  for (const WordInfo& one_word_info : word_info) {
    for (const SyllableInfo& syl_info : one_word_info.syllables) {
      string syl_pron;
      ConstructSylPron(syl_info, &syl_pron);
      syl_prons.push_back(syl_pron);
    }
  }
  *prons = JoinVector(syl_prons, ' ');
}

// Test UpdateWordTone
TEST(SentInfoTest, UpdateWordToneTest) {
  string filename = kTestUpdateToneFile;
  vector<UpdateToneTestPiece> test_pieces;
  ReadUpdateToneTestPieces(filename, &test_pieces);
  mobvoi::unordered_set<string> soft_word;
  LoadSetFromFile(kToneSoftWordFile, &soft_word);
  for (size_t i = 0; i < test_pieces.size(); i++) {
    const string& text = test_pieces[i].text;
    const string& test_prons = test_pieces[i].prons;
    const string& test_pos_s = test_pieces[i].pos_s;
    const string& expect_prons = test_pieces[i].expect_prons;
    vector<WordToken> word_tokens;
    WordToken word_token;
    word_token.word = text;
    word_token.pos = test_pos_s;
    word_token.language = WordLanguage::kMandarinWord;
    SplitString(test_prons, ' ', &word_token.prons);
    word_tokens.push_back(word_token);
    vector<WordInfo> word_info;
    const map<int, int> polyphone_prob;
    GenWordInfo(word_tokens, polyphone_prob, kMandarinTypeString, &word_info);
    UpdateWordTone(soft_word, &word_info);
    string after_prons;
    GetPronsFromWordInfo(word_info, &after_prons);
    EXPECT_EQ(expect_prons, after_prons);
  }
}

TEST(SentInfoTest, GenSentInfo) {
  const string text = "中国";
  const string word_pron = "zhong1 guo2";
  const string word_pos_s = "ns";
  const int pause_level = kPauseLevelLP;

  vector<WordToken> word_tokens;
  WordToken token_tmp;
  token_tmp.word = text;
  token_tmp.pos = word_pos_s;
  token_tmp.language = WordLanguage::kMandarinWord;
  token_tmp.pause_level = pause_level;
  SplitString(word_pron, ' ', &token_tmp.prons);
  word_tokens.push_back(token_tmp);
  vector<WordInfo> word_info;
  const map<int, int> polyphone_prob;

  GenWordInfo(word_tokens, polyphone_prob, kMandarinTypeString, &word_info);

  SentInfo sent_info;
  LabelOption label_option;
  TnDetail detail;
  SetDefaultLabelOption(&label_option);
  GenSentInfo(detail, word_info, label_option, true, &sent_info);

  sent_info.Aplay(0);
  // EXPECT_EQ(word_info[0].word, "中国");
  // EXPECT_EQ(word_info[0].pause_level, 5);
  // EXPECT_EQ(word_info[0].phone_num, 4);
  // EXPECT_EQ(word_info[0].syllables[1].tone, 2);
}

}  // namespace tts
