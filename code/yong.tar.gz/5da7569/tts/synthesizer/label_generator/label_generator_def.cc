// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/synthesizer/label_generator/label_generator_def.h"
#include "tts/util/tts_util/util.h"

namespace tts {

void SetDefaultLabelOption(LabelOption* label_option) {
  label_option->set_speaker("cissy");
  label_option->set_language(kMandarinTypeString);
  label_option->set_domain("");
  label_option->set_use_erhua(true);
  label_option->set_use_robot(false);
  label_option->set_adjust_label(true);
  label_option->set_last_seg(true);
  label_option->set_tone_rule(true);
}
}  // namespace tts
