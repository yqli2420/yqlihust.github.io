// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_SYNTHESIZER_LABEL_GENERATOR_LABEL_GENERATOR_DEF_H_
#define TTS_SYNTHESIZER_LABEL_GENERATOR_LABEL_GENERATOR_DEF_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"

#include "tts/synthesizer/label_generator/proto/label.pb.h"

namespace tts {

void SetDefaultLabelOption(LabelOption* label_option);

}  // namespace tts
#endif  // TTS_SYNTHESIZER_LABEL_GENERATOR_LABEL_GENERATOR_DEF_H_
