// Copyright 2017 Mobvoi Inc. All Rights Reserved.
// Author: ranzhang@mobvoi.com (Dylan)

#ifndef TTS_SYNTHESIZER_LABEL_GENERATOR_SENT_INFO_H_
#define TTS_SYNTHESIZER_LABEL_GENERATOR_SENT_INFO_H_

#include "mobvoi/base/compat.h"
#include "tts/synthesizer/label_generator/label_def.h"
#include "tts/synthesizer/label_generator/label_generator_def.h"
#include "tts/util/tts_util/util.h"

namespace tts {

struct TnCandidate {
  TnCandidate(const string& _key, const string& _value, bool _is_used)
      : key(_key), value(_value), is_used(_is_used) {}
  string key;
  string value;
  bool is_used;
};

struct WordDetailInfo {
  WordDetailInfo(const string& _word, const string& _pron_of_tone,
                 const string& _pron_of_alpha, const string& _pause_level,
                 const int _pron_prob)
      : word(_word),
        pron_of_tone(_pron_of_tone),
        pron_of_alpha(_pron_of_alpha),
        pause_level(_pause_level),
        pron_prob(_pron_prob) {}
  string word;
  string pron_of_tone;
  string pron_of_alpha;
  string pause_level;
  int pron_prob;
};

struct PlatformInfo {
  PlatformInfo(const string& _word, const string& _pron_of_tone,
               const string& _pron_of_alpha, const string& _tone,
               const string& _pause_level, const int _pron_prob,
               vector<TnCandidate> _tn_candidates)
      : word(_word),
        pron_of_tone(_pron_of_tone),
        pron_of_alpha(_pron_of_alpha),
        tone(_tone),
        pause_level(_pause_level),
        pron_prob(_pron_prob),
        tn_candidates(_tn_candidates) {}

  PlatformInfo(const string& _word, const string& _pron_of_tone,
               const string& _pron_of_alpha, const string& _tone,
               const string& _pause_level, const int _pron_prob)
      : word(_word),
        pron_of_tone(_pron_of_tone),
        pron_of_alpha(_pron_of_alpha),
        tone(_tone),
        pause_level(_pause_level),
        pron_prob(_pron_prob) {}
  string word;
  string pron_of_tone;   // pinyin -> tone jin1 -> jīn
  string pron_of_alpha;  // pinyin with no tone
  string tone;           // tone of pinyin
  string pause_level;    // pause_level of current word
  int pron_prob;         // probability of pron (scale 0-100, non polyphone
                         // default=100)
  vector<TnCandidate> tn_candidates;  // tn candidates of word
};

struct PhraseInfo {
  PhraseInfo() : phone_num(0), syl_num(0), pause_level(0) {}
  int phone_num;
  int syl_num;
  int pause_level;
  vector<WordInfo> words;
  void Aplay(int level, int flevel);
};

struct BreakInfo {
  int phone_num;
  int syl_num;
  int word_num;
  int pause_level;
  int break_type;
  vector<PhraseInfo> phrases;

  BreakInfo();
  ~BreakInfo();
  void Reset();
  void GetTextString(string* break_text);
  void Aplay(int level, int flevel);
};

struct SubSen {
  int phone_num;
  int syl_num;
  int word_num;
  int phrase_num;
  vector<BreakInfo> breaks;

  SubSen();
  ~SubSen();
  void Reset();
  void GetTextString(string* sub_sen_text);
  void Aplay(int level, int flevel);
};

struct SentInfo {
  Json::Value debug_info;
  vector<SubSen> sub_sens;
  void Aplay(int level);
};
void ConstructDefaultSentInfo(const TnDetail& detail,
                              const LabelOption& label_option,
                              Json::Value* frontend_data);

void GenPhraseInfo(const vector<WordInfo>& word_info,
                   vector<PhraseInfo>* phrase_info);
void GenBreakInfo(const vector<PhraseInfo>& phrase_info,
                  vector<BreakInfo>* break_info);
void GenSubSenInfo(const vector<BreakInfo>& break_info, bool last_seg,
                   vector<SubSen>* subsen);
bool GenSentInfo(const TnDetail& detail, const vector<WordInfo>& word_infos,
                 const LabelOption& label_option, bool is_online,
                 SentInfo* sentence);
}  // namespace tts

#endif  // TTS_SYNTHESIZER_LABEL_GENERATOR_SENT_INFO_H_
