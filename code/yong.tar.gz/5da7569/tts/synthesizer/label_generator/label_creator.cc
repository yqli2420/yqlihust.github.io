// Copyright 2017 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/synthesizer/label_generator/label_creator.h"

#include "mobvoi/base/log.h"
#include "tts/synthesizer/label_generator/fast_printf.h"
#include "tts/synthesizer/label_generator/label_util.h"
#include "tts/synthesizer/label_generator/proto/label.pb.h"

DEFINE_bool(use_append_features, true, "if true, use d2 e2 f2");
DEFINE_int32(max_phrase_num, 5, "max phrase num in sentence");
DEFINE_bool(remove_last_sil, false, "if true, remove sentence last sil");

namespace tts {
LabelCreator::LabelCreator() {}
LabelCreator::~LabelCreator() {}

void LabelCreator::GenMapList(const SubSen& sentence) {
  break_list_ = sentence.breaks;
  // insert undef phones at the begining
  for (size_t i = 0; i < (size_t)kUndefLen; ++i) {
    phone_list_.emplace_back(kUndefPhone);
  }
  // insert begin sil
  phone_list_.emplace_back(kPhoneSilence);

  for (size_t break_idx = 0; break_idx < break_list_.size(); ++break_idx) {
    const vector<PhraseInfo>& cur_phrases = break_list_[break_idx].phrases;
    for (size_t phrase_idx = 0; phrase_idx < cur_phrases.size(); ++phrase_idx) {
      const vector<WordInfo>& cur_words = cur_phrases[phrase_idx].words;
      phrase_list_.emplace_back(cur_phrases[phrase_idx]);
      for (size_t word_idx = 0; word_idx < cur_words.size(); ++word_idx) {
        const vector<SyllableInfo>& cur_syls = cur_words[word_idx].syllables;
        word_list_.emplace_back(cur_words[word_idx]);
        for (size_t syl_idx = 0; syl_idx < cur_syls.size(); ++syl_idx) {
          const vector<string>& cur_phones = cur_syls[syl_idx].prons;
          syl_list_.emplace_back(cur_syls[syl_idx]);
          for (size_t phone_idx = 0; phone_idx < cur_phones.size();
               ++phone_idx) {
            const string& cur_phone = cur_phones[phone_idx];
            phone_list_.emplace_back(cur_phone);
          }
        }
        if (cur_words[word_idx].pause_level == kPauseLevelSP) {
          phone_list_.emplace_back(kPhoneSP);
        } else if (cur_words[word_idx].pause_level == kPauseLevelLP) {
          phone_list_.emplace_back(kPhoneLP);
        } else if (cur_words[word_idx].pause_level == kPauseLevelSilence) {
          phone_list_.emplace_back(kPhoneSilence);
        }
      }
    }
  }

  // insert undef phones at the end
  for (size_t i = 0; i < (size_t)kUndefLen; ++i) {
    phone_list_.emplace_back(kUndefPhone);
  }
}

string LabelCreator::CreateLabel(const Label& label) {
  if (label.p3() == kPhoneSilence || label.p3() == kPhoneSP ||
      label.p3() == kPhoneLP) {
    return CreateLabelFormatSilence(label);
  } else {
    return CreateLabelFormatContent(label);
  }
}
string LabelCreator::CreateLabelFormatContent(const Label& label) {
  string a4, b4, c4;
  if (IsEnglishPhone(label.p3())) {
    a4 = b4 = c4 = "En";
  } else {
    a4 = label.a4().empty() ? kDefaultString : label.a4();
    b4 = label.b4();
    c4 = label.c4().empty() ? kDefaultString : label.c4();
  }
  // NOTE: If we use formatter %d, %s, we can use faststring::snprintf
  // for high performance. If NOT, use StringPrintf please.
  const int kBuffSize = 300;
  char buffer[kBuffSize];
  int s = faststring::snprintf(
      buffer, kBuffSize,
      "%s^%s-%s+%s=%s@%d_%d"
      "/A:%s_%s_%s+%s"
      "/B:%d-X=%d-%s@%d-%d&%s-%s#%d-%d|%s"
      "/C:%s+%s+%s_%s"
      "/D:%s-%s"
      "/E:%d_%d@%d+%d&X+X#X+X"
      "/F:%s=%s"
      "/G:%s_%s"
      "/H:%d=%d^%d=%d|%s"
      "/I:%s=%s"
      "/J:%d+%d-%d", /* */
      label.p1().c_str(),
      label.p2().c_str(), label.p3().c_str(), label.p4().c_str(),
      label.p5().c_str(), label.p6(), label.p7(),
      label.a1() == 0 ? kDefaultString : IntToString(label.a1()).c_str(),
      label.a2().empty() ? kDefaultString : label.a2().c_str(),
      label.a3() == 0 ? kDefaultString : IntToString(label.a3()).c_str(),
      a4.c_str(), label.b1(), label.b3(), b4.c_str(), label.b5(), label.b6(),
      label.b7() == 0 ? kDefaultString : IntToString(label.b7()).c_str(),
      label.b8() == 0 ? kDefaultString : IntToString(label.b8()).c_str(),
      label.b9(), label.b10(), label.b16().c_str(),
      label.c1() == 0 ? kDefaultString : IntToString(label.c1()).c_str(),
      label.c2().empty() ? kDefaultString : label.c2().c_str(),
      label.c3() == 0 ? kDefaultString : IntToString(label.c3()).c_str(),
      c4.c_str(),
      label.d2() == 0 ? kDefaultString : IntToString(label.d2()).c_str(),
      label.d3() == 0 ? kDefaultString : IntToString(label.d3()).c_str(),
      label.e2(), label.e3(), label.e4(), label.e5(),
      label.f2() == 0 ? kDefaultString : IntToString(label.f2()).c_str(),
      label.f3() == 0 ? kDefaultString : IntToString(label.f3()).c_str(),
      label.g1() == 0 ? kDefaultString : IntToString(label.g1()).c_str(),
      label.g2() == 0 ? kDefaultString : IntToString(label.g2()).c_str(),
      label.h1(), label.h2(), label.h3(), label.h4(), label.h5().c_str(),
      label.i1() == 0 ? kDefaultString : IntToString(label.i1()).c_str(),
      label.i2() == 0 ? kDefaultString : IntToString(label.i2()).c_str(),
      label.j1(), label.j2(), label.j3());
  return string(buffer, s);
}

string LabelCreator::CreateLabelFormatSilence(const Label& label) {
  const int kBuffSize = 300;
  char buffer[kBuffSize];
  int s = faststring::snprintf(
      buffer, kBuffSize,
      "%s^%s-%s+%s=%s@X_X"
      "/A:%s_%s_%s+%s"
      "/B:X-X=X-X@X-X&X-X#X-X|X"
      "/C:%s+%s+%s_%s"
      "/D:%s-%s"
      "/E:X_X@X+X&X+X#X+X"
      "/F:%s=%s"
      "/G:%s_%s"
      "/H:X=X^X=X|X/"
      "I:%s=%s/"
      "J:%d+%d-%d",
      label.p1().c_str(), label.p2().c_str(), label.p3().c_str(), /* p3 */
      label.p4().c_str(), label.p5().c_str(),
      label.a1() == 0 ? kDefaultString : IntToString(label.a1()).c_str(),
      label.a2().empty() ? kDefaultString : label.a2().c_str(),
      label.a3() == 0 ? kDefaultString : IntToString(label.a3()).c_str(),
      label.a4().empty() ? kDefaultString : label.a4().c_str(),
      label.c1() == 0 ? kDefaultString : IntToString(label.c1()).c_str(),
      label.c2().empty() ? kDefaultString : label.c2().c_str(),
      label.c3() == 0 ? kDefaultString : IntToString(label.c3()).c_str(),
      label.c4().empty() ? kDefaultString : label.c4().c_str(),
      label.d2() == 0 ? kDefaultString : IntToString(label.d2()).c_str(),
      label.d3() == 0 ? kDefaultString : IntToString(label.d3()).c_str(),
      label.f2() == 0 ? kDefaultString : IntToString(label.f2()).c_str(),
      label.f3() == 0 ? kDefaultString : IntToString(label.f3()).c_str(),
      label.g1() == 0 ? kDefaultString : IntToString(label.g1()).c_str(),
      label.g2() == 0 ? kDefaultString : IntToString(label.g2()).c_str(),
      label.i1() == 0 ? kDefaultString : IntToString(label.i1()).c_str(),
      label.i2() == 0 ? kDefaultString : IntToString(label.i2()).c_str(),
      label.j1(), label.j2(), label.j3());
  return string(buffer, s);
}

void LabelCreator::SetFrontSilLabel() {
  label_.set_p1(phone_list_[0]);
  label_.set_p2(phone_list_[1]);
  label_.set_p3(phone_list_[2]);
  label_.set_p4(phone_list_[3]);
  label_.set_p5(phone_list_[4]);
  label_.set_c1(syl_list_[0].tone);
  label_.set_c3(syl_list_[0].prons.size());
  label_.set_f2(word_list_[0].phone_num);
  label_.set_f3(word_list_[0].syllables.size());
  label_.set_i1(phrase_list_[0].syl_num);
  label_.set_i2(phrase_list_[0].words.size());
}

void LabelCreator::SetBreakLabel(int phone_idx_in_sent, int break_idx_in_sent,
                                 const vector<PhraseInfo>& cur_phrases) {
  label_.set_p1(phone_list_[phone_idx_in_sent - 2]);
  label_.set_p2(phone_list_[phone_idx_in_sent - 1]);
  label_.set_p3(phone_list_[phone_idx_in_sent]);
  label_.set_p4(phone_list_[phone_idx_in_sent + 1]);
  label_.set_p5(phone_list_[phone_idx_in_sent + 2]);

  SyllableInfo p_syl = cur_phrases.back().words.back().syllables.back();
  label_.set_a1(p_syl.tone);
  label_.set_a2(p_syl.vowel);
  label_.set_a3(p_syl.prons.size());
  label_.set_a4(p_syl.pos);

  SyllableInfo n_syl;
  if ((size_t)break_idx_in_sent + 1 < break_list_.size()) {
    n_syl = break_list_[break_idx_in_sent + 1].phrases[0].words[0].syllables[0];
    label_.set_c1(n_syl.tone);
    label_.set_c2(n_syl.vowel);
    label_.set_c3(n_syl.prons.size());
    label_.set_c4(n_syl.pos);
  }

  if (FLAGS_use_append_features) {
    label_.set_d2(label_.e2());
  }
  label_.set_d3(label_.e3());
  label_.set_g1(label_.h1());
  label_.set_g2(label_.h2());
}

void LabelCreator::SetPLabel(int phone_idx_in_syl, int phone_idx_in_sent,
                             const vector<string>& cur_phones) {
  label_.set_p1(phone_list_[phone_idx_in_sent - 2]);
  label_.set_p2(phone_list_[phone_idx_in_sent - 1]);
  label_.set_p3(phone_list_[phone_idx_in_sent]);
  label_.set_p4(phone_list_[phone_idx_in_sent + 1]);
  label_.set_p5(phone_list_[phone_idx_in_sent + 2]);
  label_.set_p6(phone_idx_in_syl + 1);
  label_.set_p7(cur_phones.size() - phone_idx_in_syl);
}

void LabelCreator::SetALabel(int syl_idx_in_word, int syl_idx_in_sent,
                             int phrase_syl_num_before_cword,
                             int break_syl_num_before_cphrase) {
  if ((syl_idx_in_word + phrase_syl_num_before_cword +
       break_syl_num_before_cphrase) > 0) {
    label_.set_a1(syl_list_[syl_idx_in_sent - 1].tone);
    label_.set_a2(syl_list_[syl_idx_in_sent - 1].vowel);
    label_.set_a3(syl_list_[syl_idx_in_sent - 1].prons.size());
    label_.set_a4(syl_list_[syl_idx_in_sent - 1].pos);
  } else {
    label_.set_a1(kDefaultInt);
    label_.set_a2(kDefaultString);
    label_.set_a3(kDefaultInt);
    label_.set_a4(kDefaultString);
  }
}

void LabelCreator::SetBLabel(int phone_idx_in_syl, int syl_idx_in_word,
                             int syl_idx_in_sent,
                             int phrase_syl_num_before_cword,
                             int word_idx_in_sent, int phrase_idx_in_break,
                             const vector<string>& cur_phones,
                             const vector<SyllableInfo>& cur_syls,
                             const vector<PhraseInfo>& cur_phrases) {
  label_.set_b1(syl_list_[syl_idx_in_sent].tone);
  label_.set_b3(syl_list_[syl_idx_in_sent].prons.size());
  label_.set_b4(syl_list_[syl_idx_in_sent].pos);
  label_.set_b5(syl_idx_in_word + 1);
  label_.set_b6(cur_syls.size() - syl_idx_in_word);
  label_.set_b7(syl_idx_in_word + phrase_syl_num_before_cword + 1);
  label_.set_b8(cur_phrases[phrase_idx_in_break].syl_num - label_.b7() + 1);
  if (phone_idx_in_syl > 0) {
    label_.set_b9(kPauseLevelPhoneme);
  } else {
    if (syl_idx_in_word > 0) {
      label_.set_b9(kPauseLevelSyl);
    } else {
      if (word_idx_in_sent > 0) {
        label_.set_b9(std::max(kPauseLevelWord,
                               word_list_[word_idx_in_sent - 1].pause_level));
      } else {
        label_.set_b9(kPauseLevelSilence);
      }
    }
  }
  if ((size_t)phone_idx_in_syl + 1 < cur_phones.size()) {
    label_.set_b10(kPauseLevelPhoneme);
  } else {
    if ((size_t)syl_idx_in_word + 1 < cur_syls.size()) {
      label_.set_b10(kPauseLevelSyl);
    } else {
      label_.set_b10(
          std::max(kPauseLevelWord, word_list_[word_idx_in_sent].pause_level));
    }
  }
  label_.set_b16(syl_list_[syl_idx_in_sent].vowel);
}

void LabelCreator::SetCLabel(int syl_idx_in_word, int syl_idx_in_sent,
                             int phrase_syl_num_before_cword,
                             int break_syl_num_before_cphrase,
                             int break_idx_in_sent) {
  if (syl_idx_in_word + phrase_syl_num_before_cword +
          break_syl_num_before_cphrase + 1 <
      break_list_[break_idx_in_sent].syl_num) {
    label_.set_c1(syl_list_[syl_idx_in_sent + 1].tone);
    label_.set_c2(syl_list_[syl_idx_in_sent + 1].vowel);
    label_.set_c3(syl_list_[syl_idx_in_sent + 1].prons.size());
    label_.set_c4(syl_list_[syl_idx_in_sent + 1].pos);
  } else {
    label_.set_c1(kDefaultInt);
    label_.set_c2(kDefaultString);
    label_.set_c3(kDefaultInt);
    label_.set_c4(kDefaultString);
  }
}

void LabelCreator::SetDLabel(int word_idx_in_sent) {
  if (word_idx_in_sent > 0) {
    if (FLAGS_use_append_features) {
      label_.set_d2(word_list_[word_idx_in_sent - 1].phone_num);
    }
    label_.set_d3(word_list_[word_idx_in_sent - 1].syllables.size());
  } else {
    // label_.set_d1(kDefaultString);
    label_.set_d2(kDefaultInt);
    label_.set_d3(kDefaultInt);
  }
}

void LabelCreator::SetELabel(int word_idx_in_phrase, int word_idx_in_sent,
                             int phrase_idx_in_break,
                             const vector<PhraseInfo>& cur_phrases) {
  if (FLAGS_use_append_features) {
    label_.set_e2(word_list_[word_idx_in_sent].phone_num);
  }
  label_.set_e3(word_list_[word_idx_in_sent].syllables.size());
  label_.set_e4(word_idx_in_phrase + 1);
  label_.set_e5(cur_phrases[phrase_idx_in_break].words.size() -
                word_idx_in_phrase);
}

void LabelCreator::SetFLabel(int word_idx_in_sent) {
  if ((size_t)word_idx_in_sent + 1 < word_list_.size()) {
    if (FLAGS_use_append_features) {
      label_.set_f2(word_list_[word_idx_in_sent + 1].phone_num);
    }
    label_.set_f3(word_list_[word_idx_in_sent + 1].syllables.size());
  } else {
    label_.set_f2(kDefaultInt);
    label_.set_f3(kDefaultInt);
  }
}

void LabelCreator::SetGLabel(int phrase_idx_in_sent) {
  if (phrase_idx_in_sent > 0) {
    label_.set_g1(phrase_list_[phrase_idx_in_sent - 1].syl_num);
    label_.set_g2(phrase_list_[phrase_idx_in_sent - 1].words.size());
  } else {
    label_.set_g1(kDefaultInt);
    label_.set_g2(kDefaultInt);
  }
}

void LabelCreator::SetHLabel(bool adjust_label, int phrase_idx_in_sent) {
  label_.set_h1(phrase_list_[phrase_idx_in_sent].syl_num);
  label_.set_h2(phrase_list_[phrase_idx_in_sent].words.size());
  label_.set_h3(phrase_idx_in_sent + 1);
  if (adjust_label && label_.h3() > kPhrasePositionLimit) {
    label_.set_h3(kPhrasePositionLimit);
  }
  label_.set_h4(phrase_list_.size() - phrase_idx_in_sent);
  if (adjust_label && label_.h4() > kPhrasePositionLimit) {
    label_.set_h4(kPhrasePositionLimit);
  }
  label_.set_h5(kDefaultString);
}

void LabelCreator::SetILabel(int phrase_idx_in_sent) {
  if ((size_t)phrase_idx_in_sent + 1 < phrase_list_.size()) {
    label_.set_i1(phrase_list_[phrase_idx_in_sent + 1].syl_num);
    label_.set_i2(phrase_list_[phrase_idx_in_sent + 1].words.size());
  } else {
    label_.set_i1(kDefaultInt);
    label_.set_i2(kDefaultInt);
  }
}

void LabelCreator::SetJLabel() {
  label_.set_j1(syl_list_.size());
  label_.set_j2(word_list_.size());
  label_.set_j3(phrase_list_.size());
}

void LabelCreator::AdjustLabel(int phrase_idx_in_sent) {
  // 空气状况为良好，空气很清新哦
  if (speaker_ == "tina") {
    if (label_.p1() == "x" && label_.p2() == "in" && label_.p3() == "o") {
      label_.set_a1(2);
      label_.set_a2("ou");
      label_.set_b1(3);
    }
    if (label_.p2() == "x" && label_.p3() == "ve" && label_.p4() == "l" &&
        label_.b1() == 2) {
      label_.set_b5(1);
      label_.set_b6(3);
    }
  }
  if (speaker_ == "dora") {  // 取消
    if (label_.p2() == "s" && label_.p3() == "iu" && label_.p4() == "SIL" &&
        label_.b1() == 1) {
      label_.set_b10(kPauseLevelSyl);
    }
  }
  // adjust the right boundary type of shi
  if (speaker_ == "billy_hybrid") {
    if (label_.p2() == "sh" && label_.p3() == "i" && label_.p4() == "SIL" &&
        label_.b1() == 4) {
      label_.set_b10(1);
      label_.set_b7(2);
    }
  }

  // 倒计时５分钟
  if (label_.p2() == "zh" && label_.p3() == "ong" && label_.p4() == "pau" &&
      label_.p5() == "XX") {
    label_.set_b4("n");
  }

  // 开始关闭
  if (label_.p2() == "uan" && label_.p3() == "b") {
    label_.set_a1(3);
  }

  if (label_.h3() + label_.h4() > FLAGS_max_phrase_num + 1) {
    if (label_.h3() > FLAGS_max_phrase_num) {
      label_.set_h3(FLAGS_max_phrase_num);
    }
    label_.set_h4(FLAGS_max_phrase_num + 1 - label_.h3());
  }

  // 这个功能
  if (label_.p1() == "e" && label_.p2() == "g" && label_.p3() == "ong" &&
      label_.p4() == "n") {
    label_.set_a1(3);
    label_.set_a2("i");
  }

  // 已连接互联网
  if (label_.p1() == "u" && label_.p2() == "l" && label_.p3() == "ian") {
    label_.set_a1(3);
    label_.set_a2("o");
  }

  // 网络有点小问题马上就好
  if (label_.p2() == "t" && label_.p3() == "i" && label_.p4() == "pau" &&
      label_.p5() == "m") {
    label_.set_p5("XX");
  }
}

void LabelCreator::ParseOption(const LabelOption& label_option) {
  speaker_ = label_option.speaker();
  adjust_label_ = label_option.adjust_label();
  last_seg_ = label_option.last_seg();
}

void LabelCreator::CreateLabels(const LabelOption& label_option,
                                const SentInfo& sent_info,
                                vector<string>* labels) {
  ParseOption(label_option);
  for (auto sub_sen : sent_info.sub_sens) {
    CreateLabelsForSubSen(sub_sen, labels);
  }
}

void LabelCreator::CreateLabelsForSubSen(const SubSen& sub_sen,
                                         vector<string>* labels) {
  ResetMapList();
  GenMapList(sub_sen);
  VLOG(2) << "phone lists: " << JoinVector(phone_list_, ' ');

  VLOG(2) << "Start Generate  Labels...";
  if (syl_list_.empty()) {
    LOG(WARNING) << "empty text input";
    return;
  }
  // J: sentence
  SetJLabel();
  // insert front sil
  SetFrontSilLabel();
  // jump the begining sil in synthesis
  if (!adjust_label_) {
    labels->emplace_back(CreateLabel(label_));
  }

  int sent_phone_num_before_cbreak = 0;
  int sent_syl_num_before_cbreak = 0;
  int sent_word_num_before_cbreak = 0;
  int sent_phrase_num_before_cbreak = 0;
  for (size_t break_idx = 0; break_idx < break_list_.size(); ++break_idx) {
    const vector<PhraseInfo>& cur_phrases = break_list_[break_idx].phrases;
    int break_phone_num_before_cphrase = 0;
    int break_syl_num_before_cphrase = 0;
    int break_word_num_before_cphrase = 0;
    for (size_t phrase_idx = 0; phrase_idx < cur_phrases.size(); ++phrase_idx) {
      const vector<WordInfo>& cur_words = cur_phrases[phrase_idx].words;
      int phrase_phone_num_before_cword = 0;
      int phrase_syl_num_before_cword = 0;
      int phrase_idx_in_sent = phrase_idx + sent_phrase_num_before_cbreak;
      for (size_t word_idx = 0; word_idx < cur_words.size(); ++word_idx) {
        const vector<SyllableInfo>& cur_syls = cur_words[word_idx].syllables;
        int word_phone_num_before_csyl = 0;
        int word_idx_in_sent = word_idx + break_word_num_before_cphrase +
                               sent_word_num_before_cbreak;
        for (size_t syl_idx = 0; syl_idx < cur_syls.size(); ++syl_idx) {
          const vector<string>& cur_phones = cur_syls[syl_idx].prons;
          int syl_idx_in_sent = syl_idx + phrase_syl_num_before_cword +
                                break_syl_num_before_cphrase +
                                sent_syl_num_before_cbreak;
          for (size_t phone_idx = 0; phone_idx < cur_phones.size();
               ++phone_idx) {
            int phone_idx_in_sent =
                phone_idx + word_phone_num_before_csyl +
                phrase_phone_num_before_cword + break_phone_num_before_cphrase +
                sent_phone_num_before_cbreak + break_idx + kUndefLen + 1;

            // P: current phone seq
            SetPLabel(phone_idx, phone_idx_in_sent, cur_phones);
            // A: previous syl
            SetALabel(syl_idx, syl_idx_in_sent, phrase_syl_num_before_cword,
                      break_syl_num_before_cphrase);
            // B: current syl
            SetBLabel(phone_idx, syl_idx, syl_idx_in_sent,
                      phrase_syl_num_before_cword, word_idx_in_sent, phrase_idx,
                      cur_phones, cur_syls, cur_phrases);
            // C: next syl
            SetCLabel(syl_idx, syl_idx_in_sent, phrase_syl_num_before_cword,
                      break_syl_num_before_cphrase, break_idx);
            // D: previous word
            SetDLabel(word_idx_in_sent);
            // E: current word
            SetELabel(word_idx, word_idx_in_sent, phrase_idx, cur_phrases);
            // F: next word
            SetFLabel(word_idx_in_sent);
            // G: previous phrase
            SetGLabel(phrase_idx_in_sent);
            // H: current phrase
            SetHLabel(adjust_label_, phrase_idx_in_sent);
            // I: next phrase
            SetILabel(phrase_idx_in_sent);
            // J: sentence
            SetJLabel();

            // Adjust label for specified sentence
            if (adjust_label_) {
              AdjustLabel(phrase_idx_in_sent);
            }
            labels->emplace_back(CreateLabel(label_));
            // VLOG(2) << "label: " << LabelCreator::CreateLabel(label_);
          }
          word_phone_num_before_csyl += cur_phones.size();
        }
        phrase_phone_num_before_cword += word_phone_num_before_csyl;
        phrase_syl_num_before_cword += cur_syls.size();
      }
      break_phone_num_before_cphrase += phrase_phone_num_before_cword;
      break_syl_num_before_cphrase += phrase_syl_num_before_cword;
      break_word_num_before_cphrase += cur_words.size();
    }
    sent_phone_num_before_cbreak += break_phone_num_before_cphrase;
    sent_syl_num_before_cbreak += break_syl_num_before_cphrase;
    sent_word_num_before_cbreak += break_word_num_before_cphrase;
    sent_phrase_num_before_cbreak += cur_phrases.size();

    // insert break
    int phone_idx_in_sent =
        sent_phone_num_before_cbreak + break_idx + kUndefLen + 1;
    SetBreakLabel(phone_idx_in_sent, break_idx, cur_phrases);
    labels->emplace_back(LabelCreator::CreateLabel(label_));
    // VLOG(2) << "label:" << LabelCreator::CreateLabel(label_);
  }

  for (auto& label : *labels) {
    VLOG(2) << label;
  }
  if (FLAGS_remove_last_sil && last_seg_ && !labels->empty()) {
    labels->pop_back();
  }

  VLOG(1) << "Generate  Labels Complete!";
}

}  // namespace tts
