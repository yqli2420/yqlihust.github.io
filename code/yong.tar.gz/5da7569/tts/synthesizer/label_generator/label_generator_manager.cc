// Copyright 2017 Mobvoi Inc. All Rights Reserved.
// Author: ranzhang@mobvoi.com (Dylan)

#include "tts/synthesizer/label_generator/label_generator_manager.h"

namespace tts {

LabelGeneratorManager::LabelGeneratorManager() {}

LabelGeneratorManager::~LabelGeneratorManager() {}

std::shared_ptr<LabelGenerator> LabelGeneratorManager::CreateLabelGenerator(
    const string& language, const string& resource_file) {
  auto it = label_generators_.find(language);
  if (it != label_generators_.end() && !it->second.expired()) {
    LOG(INFO) << language << " frontend exist, load directly";
    return it->second.lock();
  }
  LOG(INFO) << language << " frontend not exist, create from resource";
  std::shared_ptr<LabelGenerator> label_generator;
  if (language == kEnglishTypeString) {
    label_generator.reset(static_cast<LabelGenerator*>(
        new EnglishLabelGenerator(language, resource_file)));
  } else {
    label_generator.reset(static_cast<LabelGenerator*>(
        new MandarinLabelGenerator(language, resource_file)));
  }
  label_generators_[language] = label_generator;
  return label_generator;
}

}  // namespace tts
