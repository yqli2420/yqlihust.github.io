// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: hbcao@mobvoi.com (Haibing Cao)

#include "tts/synthesizer/label_generator/label_generator.h"
#include "gtest/gtest.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/file/proto_util.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/string_util.h"
#include "tts/synthesizer/label_generator/label_generator_manager.h"
#include "tts/synthesizer/proto/tts.pb.h"
#include "tts/util/tts_util/util.h"

namespace tts {

static const string kTestDataDir =  // NOLINT
    "tts/synthesizer/label_generator/testdata";
static const string kMandarinOnlineExpectFile =  // NOLINT
    "expect_online_mandarin.lab";
static const string kMandarinPortableExpectFile =  // NOLINT
    "expect_portable_mandarin.lab";
static const string kCantoneseOnlineExpectFile =  // NOLINT
    "expect_online_cantonese.lab";
static const string kCantonesePortableExpectFile =  // NOLINT
    "expect_portable_cantonese.lab";
static const string kManOfflineServer = "man_offline_server.lab";      // NOLINT
static const string kManOfflinePortable = "man_offline_portable.lab";  // NOLINT

static const char kLabelSep = '\t';
enum FileFormat {
  kName = 0,
  kContent,
  kLabelAllNum,
};

static bool ProcessLine(const string& line, string* name, string* content) {
  vector<string> segs;
  SplitString(line, kLabelSep, &segs);
  if (segs.size() < FileFormat::kLabelAllNum) return false;
  *name = segs[FileFormat::kName];
  *content = segs[FileFormat::kContent];
  for (size_t i = FileFormat::kContent + 1; i < segs.size(); ++i) {
    *content += kLabelSep + segs[i];
  }
  return true;
}

void GenLabelsOnlineTest(const string& language) {
  LabelGeneratorManager manager;
  string resource_file;
  string file_prefix;
  if (language == kMandarinTypeString) {
    resource_file = "external/config/front_end/man_frontend.conf";
#ifndef FOR_PORTABLE
    file_prefix = kMandarinOnlineExpectFile;
#else
    file_prefix = kMandarinPortableExpectFile;
#endif
  } else if (language == kCantoneseTypeString) {
    resource_file = "external/config/front_end/can_frontend.conf";
#ifndef FOR_PORTABLE
    file_prefix = kCantoneseOnlineExpectFile;
#else
    file_prefix = kCantonesePortableExpectFile;
#endif
  } else {
    return;
  }
  std::shared_ptr<LabelGenerator> label_generator;
  label_generator = manager.CreateLabelGenerator(language, resource_file);

  LabelOption label_option;
  tts::SetDefaultLabelOption(&label_option);
  label_option.set_language(language);

  string filename =
      mobvoi::File::JoinPath(kTestDataDir, "label_online_test.txt");
  file::SimpleLineReader reader(filename, false, "#");
  vector<string> lines;
  reader.ReadLines(&lines);

  for (const auto& line : lines) {
    string name, text;
    if (!ProcessLine(line, &name, &text)) continue;
    vector<SsmlText> input;
    SsmlParser::Instance().ParseText(text, &input);
    vector<string> labels;
    label_generator->GenLabels(input, label_option, true /*online*/, &labels,
                               nullptr);
    string expect_file = name + "_" + file_prefix;
    expect_file = mobvoi::File::JoinPath(kTestDataDir, expect_file);
    file::SimpleLineReader label_reader(expect_file, false, "#");
    vector<string> expect_labels;
    label_reader.ReadLines(&expect_labels);

    LOG(INFO) << expect_file;
    ASSERT_EQ(expect_labels.size(), labels.size()) << text;
    for (size_t i = 0; i < labels.size(); ++i) {
      EXPECT_EQ(expect_labels[i], labels[i]);
    }
  }
}

#ifndef FOR_PORTABLE
TEST(LabelGeneratorTest, GenLabelsOnline) {
  GenLabelsOnlineTest(kMandarinTypeString);
  GenLabelsOnlineTest(kCantoneseTypeString);
}
#endif

TEST(LabelGeneratorTest, GenLabelsOffline) {
  LabelGeneratorManager manager;
  LabelOption label_option;
  tts::SetDefaultLabelOption(&label_option);
  const string& resource_file = "external/config/front_end/man_frontend.conf";
  std::shared_ptr<LabelGenerator> label_generator =
      manager.CreateLabelGenerator(kMandarinTypeString, resource_file);

  string filename =
      mobvoi::File::JoinPath(kTestDataDir, "label_offline_test.txt");
  vector<string> lines;
  file::SimpleLineReader reader(filename, false, "#");
  reader.ReadLines(&lines);

  for (const auto& line : lines) {
    string name, text;
    if (!ProcessLine(line, &name, &text)) continue;
    vector<SsmlText> input;
    SsmlParser::Instance().ParseText(text, &input);
    vector<string> labels;
    label_generator->GenLabels(input, label_option, false /*offline*/, &labels,
                               nullptr);

#ifndef FOR_PORTABLE
    string expect_file = name + "_" + kManOfflineServer;
#else
    string expect_file = name + "_" + kManOfflinePortable;
#endif
    expect_file = mobvoi::File::JoinPath(kTestDataDir, expect_file);
    file::SimpleLineReader label_reader(expect_file, false, "#");
    vector<string> expect_labels;
    label_reader.ReadLines(&expect_labels);

    LOG(INFO) << expect_file;
    ASSERT_EQ(expect_labels.size(), labels.size()) << text;
    for (size_t i = 0; i < labels.size(); ++i) {
      EXPECT_EQ(expect_labels[i], labels[i]);
    }
  }
}

}  // namespace tts
