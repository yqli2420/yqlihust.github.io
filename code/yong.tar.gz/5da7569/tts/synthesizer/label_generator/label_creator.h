// Copyright 2017 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_SYNTHESIZER_LABEL_GENERATOR_LABEL_CREATOR_H_
#define TTS_SYNTHESIZER_LABEL_GENERATOR_LABEL_CREATOR_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "tts/synthesizer/label_generator/proto/label.pb.h"
#include "tts/synthesizer/label_generator/sent_info.h"

namespace tts {
class LabelCreator {
 public:
  LabelCreator();
  ~LabelCreator();
  void CreateLabels(const LabelOption& label_option, const SentInfo& sent_info,
                    vector<string>* labels);

 private:
  void ParseOption(const LabelOption& label_option);
  void GenMapList(const SubSen& sentence);
  void CreateLabelsForSubSen(const SubSen& subsen, vector<string>* labels);
  string CreateLabel(const Label& label);
  string CreateLabelFormatContent(const Label& label);
  string CreateLabelFormatSilence(const Label& label);

  // set label
  void SetFrontSilLabel();
  void SetBackSilLabel();
  void SetBreakLabel(int phone_idx_in_sent, int break_idx_in_sent,
                     const vector<PhraseInfo>& cur_phrases);
  void SetPLabel(int phone_idx_in_syl, int phone_idx_in_sent,
                 const vector<string>& cur_phones);
  void SetALabel(int syl_idx_in_word, int syl_idx_in_sent,
                 int phrase_syl_num_before_cword,
                 int break_syl_num_before_cphrase);
  void SetBLabel(int phone_idx_in_syl, int syl_idx_in_word, int syl_idx_in_sent,
                 int phrase_syl_num_before_cword, int word_idx_in_sent,
                 int phrase_idx_in_break, const vector<string>& cur_phones,
                 const vector<SyllableInfo>& cur_syls,
                 const vector<PhraseInfo>& cur_phrases);
  void SetCLabel(int syl_idx_in_word, int syl_idx_in_sent,
                 int phrase_syl_num_before_cword,
                 int break_syl_num_before_cphrase, int break_idx_in_sent);
  void SetDLabel(int word_idx_in_sent);
  void SetELabel(int word_idx_in_phrase, int word_idx_in_sent,
                 int phrase_idx_in_break,
                 const vector<PhraseInfo>& cur_phrases);
  void SetFLabel(int word_idx_in_sent);
  void SetGLabel(int phrase_idx_in_sent);
  void SetHLabel(bool is_online, int phrase_idx_in_sent);
  void SetILabel(int phrase_idx_in_sent);
  void SetJLabel();
  void AdjustLabel(int phrase_idx_in_sent);
  void ResetMapList() {
    phone_list_.clear();
    syl_list_.clear();
    word_list_.clear();
    phrase_list_.clear();
    break_list_.clear();
  }

  vector<string> phone_list_;
  vector<SyllableInfo> syl_list_;
  vector<WordInfo> word_list_;
  vector<PhraseInfo> phrase_list_;
  vector<BreakInfo> break_list_;
  Label label_;
  string speaker_;
  bool adjust_label_;
  bool last_seg_;
};

}  // namespace tts

#endif  // TTS_SYNTHESIZER_LABEL_GENERATOR_LABEL_CREATOR_H_
