// Copyright 2017 Mobvoi Inc. All Rights Reserved.
// Author: ranzhang@mobvoi.com (Dylan)

#ifndef TTS_SYNTHESIZER_LABEL_GENERATOR_LABEL_DEF_H_
#define TTS_SYNTHESIZER_LABEL_GENERATOR_LABEL_DEF_H_

#include <algorithm>
#include "mobvoi/base/compat.h"

namespace tts {

enum WordLanguage {
  kMandarinWord = 0,
  kEnglishWord = 1,
};

enum Stress {
  kNonStress = 7,
  kStress = 8,
  kSubStress = 9,
};

enum Accent {
  kNonAccent = 0,
  kAccent = 1,
};

static const char kPausePron[] = "sil0";
static const char kFrontendInitialStr[] = "[#initial code#]";

static const int kPauseLevelNotFound = -1;
static const int kPauseLevelPhoneme = 0;
static const int kPauseLevelSyl = 1;
static const int kPauseLevelWord = 2;
static const int kPauseLevelPhrase = 3;
static const int kPauseLevelSP = 4;
static const int kPauseLevelLP = 5;
static const int kPauseLevelSilence = 6;

// high level max value better be multiple of lower value
static const int kWordMin = 1;     // min word number in a prosody word
static const int kWordMax = 3;     // max word number in a prosody word
static const int kPhraseMin = 1;   // min word number in a phrase
static const int kPhraseMax = 10;  // max word number in a phrase
static const int kBreakMin = 3;    // min word number in a break
static const int kBreakMax = 20;   // max word number in a break

static const char kSepMarkNone[] = "";
static const char kSepMarkWord[] = "`";
static const char kSepMarkPhrase[] = "^";
static const char kSepMarkLP[] = ",";
static const char kSepMarkSP[] = "@";
static const char kSepMarkSilence[] = ".";
static const char kSepMarkNonePauseLevel[] = "#0";

static const int kMinWordNumInBreak = 3;
static const int kMaxProsodyWordLen = 8;

static const int kMaxTnCandidatesLen = 9;

struct Splice {
  string str;
  WordLanguage language;
};
struct WordToken {
  string word;
  WordLanguage language;
  int word_id = 0;
  int pause_level = 0;
  string pos;
  vector<string> prons;
  bool pron_fixed = false;  // fixed flag for word level
  bool pause_fixed = false;
  map<size_t, bool> p_pron_fixeds;  // fixed flag for phone level
  vector<std::pair<int, string>> seted_pauses;
};
struct SyllableInfo {
  SyllableInfo() : tone(0), pron_prob(100) {}
  string character;
  vector<string> prons;
  string vowel;
  string pos;
  // 1-5
  int tone;
  int pron_prob;
  void Aplay(int level, int flevel);
};

struct WordInfo {
  WordInfo() : word_id(0), pause_level(0), phone_num(0), punc(false) {}
  string word;
  int word_id;
  int pause_level;
  int phone_num;
  bool punc;
  vector<SyllableInfo> syllables;
  vector<string> pron_of_tones;
  bool pron_fixed = false;
  map<size_t, bool> p_pron_fixeds;
  void Aplay(int level, int flevel);
};

static const char kUndefPhone[] = "XX";      // default phone
static const char kDefaultString[] = "X";    // default label
static const char kEnDefaultString[] = "x";  // default label
static const int kDefaultInt = 0;            // default label
static const int kEnDefaultInt = -1;         // default label
static const char kPhoneSP[] = "sp";         // phone for short break
static const char kPhoneLP[] = "lp";         // phone for long break
static const char kPhoneSilence[] = "SIL";   // phone for silence
static const char kPhoneRhotic[] = "xr";     // phone for silence

static constexpr char const* kPostfixWord[] = {
    "的", "地", "得", "呢", "了", "着", "里", "上", "前", "中", "后",
    "内", "外", "下", "起", "底", "啊", "呀", "唉", "哎", "等", "说"};

static constexpr char const* kPrefixWord[] = {"我", "你", "他", "她",
                                              "不", "别", "它"};

static constexpr char const* kSandhiWord[] = {
    "小老鼠", "党小组", "小两口", "纸老虎", "海产品",
    "马组长", "冷处理", "买水果", "好导演", "耍笔杆",
    "老保守", "老两口", "小雨伞", "小永远", "李小姐",
    "只偶尔"  // 323
};

#define CONTAINS_WORD(words, word) \
  (std::find(std::begin(words), std::end(words), word) != std::end(words))

static const int kBreakTypeNone = 0;     // default break type
static const int kBreakTypePredict = 1;  // crf based breaks
static const int kBreakTypePunc = 2;     // punc based breaks
static const int kCrfPuncBreak = 2;      // punctuation list for break
static const int kBreakFrontMinLen = 5;  // min syl num in one break from front
static const int kBreakBackMinLen =
    5;  // min syl num in one break from back, should less than front

static const int kUndefLen =
    2;  // X length before begining and after end phones
static const int kSubSenMinLen = 20;  // the min length of a sub sentence
static const int kPhrasePositionLimit =
    12;                              // phrase position limit for h3 and h4
static const int kBreakSylNum = 10;  // phrase position limit for h3 and h4

static const char kPreAppendMand[] = "张那";
static const char kPostAppendMand[] = "沙尘";
static const int kPreAppendMandNum = 4;
static const int kPostAppendMandNum = 5;
static const char kSpecTimeWord[] = "点整";

static const char kPreAppendEng[] = "He`said,";
static const char kPostAppendEng[] = ",go`home";
static const int kPreAppendEngNum = 6;
static const int kPostAppendEngNum = 7;

}  // namespace tts

#endif  // TTS_SYNTHESIZER_LABEL_GENERATOR_LABEL_DEF_H_
