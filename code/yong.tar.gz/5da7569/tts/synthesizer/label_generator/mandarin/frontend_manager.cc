// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaoqin.feng@mobvoi.com

#include "tts/synthesizer/label_generator/mandarin/frontend_manager.h"
#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/log.h"
#include "tts/util/tts_util/util.h"

DEFINE_string(polyphone_dict, "external/config/front_end/dict/word_pron.dict",
              "model polyphone dict resource");

namespace tts {
FrontendManager& FrontendManager::Instance() {
  static FrontendManager instance;
  return instance;
}

FrontendManager::~FrontendManager() {}

// TODO(xiaoqin.feng) initial all frontend resource
void FrontendManager::InitAllFrontend(const string& language,
                                      const string& resource_file) {}
#ifndef FOR_PORTABLE
bool FrontendManager::DoExtractFrontendModel(const string& frontend_dir,
                                             const string& language,
                                             const string& frontend_type) {
  if (frontend_type == tts::kFrontendPolyphone) {
    if (polyphone_.find(language) != polyphone_.end()) return true;
    string model_path = frontend_dir + "model/" + frontend_type + ".tar.gz";
    if (mobvoi::File::Exists(model_path)) {
      string target_model_path = frontend_dir + frontend_type + "/";
      string cmd = StringPrintf("tar -zxf %s -C %s", model_path.c_str(),
                                target_model_path.c_str());
      if (!tts::RunOsSytemCmd(cmd)) {
        LOG(ERROR) << "unzip " << model_path.c_str() << " error.";
        return false;
      }
    }
  }
  return true;
}
#endif

void FrontendManager::InitPolyphone(const string& language,
                                    const string& resource_file,
                                    const bool reset_flag) {
  mobvoi::WriteLock write_lock(&poly_lock_);
  if (polyphone_.find(language) == polyphone_.end() || reset_flag)
    polyphone_[language].reset(new nlp::polyphone::Polyphone(resource_file));
}

void FrontendManager::UpdatePolyphone(const string& language,
                                      const string& resource_file) {
  InitPolyphone(language, resource_file, true);
}
void FrontendManager::PolyphoneProcess(
    const string& language,
    vector<nlp::polyphone::PolyphoneToken>* polyphone_tokens,
    map<int, int>* polyphone_prob) {
  mobvoi::ReadLock read_lock(&poly_lock_);
  polyphone_.at(language)->PolyphoneProcess(polyphone_tokens, polyphone_prob);
}

void FrontendManager::InitProsody(const string& language,
                                  const string& resource_file,
                                  const bool reset_flag) {
  mobvoi::WriteLock write_lock(&prosody_lock_);
#ifndef FOR_PORTABLE
  if (prosody_.find(language) == prosody_.end() || reset_flag)
    prosody_[language].reset(new nlp::prosody::Prosody(resource_file));
#else
  if (pause_level_.find(language) == pause_level_.end() || reset_flag)
    pause_level_[language].reset(
        new nlp::prosody::PausePredictor(resource_file));
#endif
}

void FrontendManager::UpdateProsody(const string& language,
                                    const string& resource_file) {
  InitProsody(language, resource_file, true);
}

void FrontendManager::ProsodyProcess(const string& language,
#ifndef FOR_PORTABLE
                                     vector<int> tokens,
#else
                                     vector<nlp::prosody::InputToken> tokens,
#endif
                                     vector<int>* result) {
  mobvoi::ReadLock read_lock(&prosody_lock_);
#ifndef FOR_PORTABLE
  prosody_.at(language)->InferenceProsody(tokens, result);
#else
  pause_level_.at(language)->Predict(tokens, result);
#endif
}

void FrontendManager::LoadAllPolyphoneDict() {
  if (!FLAGS_polyphone_dict.empty() && polyphone_map_.empty()) {
    vector<string> lines;
    GetConfigCenterLines(FLAGS_polyphone_dict, &lines);
    for (auto line : lines) {
      vector<string> values;
      mobvoi::SplitStringToVector(line, "\t", false, &values);
      vector<string> prons;
      mobvoi::SplitStringToVector(values[2], ",", false, &prons);
      if (prons.size() > 1) {
        polyphone_map_[values[0]].insert(std::make_pair(values[1], false));
      }
    }
  }
}

void FrontendManager::LoadModelPolyphoneDict(const string& language) {
  mobvoi::unordered_set<string> polyphone_model_dict =
      polyphone_.at(language)->GetPolyphoneModelDict();
  string type = string();
  if (language == kMandarinTypeString) type = kFrontendTypeMan;
  if (language == kTaiwaneseTypeString) type = kFrontendTypeTw;
  if (polyphone_map_.find(type) == polyphone_map_.end()) return;
  for (auto poly : polyphone_model_dict) {
    if (polyphone_map_[type].find(poly) != polyphone_map_[type].end()) {
      polyphone_map_[type][poly] = true;
    }
  }
}

bool FrontendManager::IsContainInPolyDict(const string& type,
                                          const string& word, bool* in_model) {
  if (polyphone_map_.find(type) == polyphone_map_.end()) {
    return false;
  } else {
    auto poly_find = polyphone_map_[type].find(word);
    if (poly_find != polyphone_map_[type].end()) {
      *in_model = polyphone_map_[type][word];
      return true;
    } else {
      return false;
    }
  }
}

void FrontendManager::UnloadModel(const string& language) {
  mobvoi::WriteLock write_lock_polyphone(&poly_lock_);
  auto polyphone_it = polyphone_.find(language);
  if (polyphone_it != polyphone_.end()) polyphone_.erase(polyphone_it);
  mobvoi::WriteLock write_lock_prosody(&prosody_lock_);
#ifndef FOR_PORTABLE
  auto prosody_it = prosody_.find(language);
  if (prosody_it != prosody_.end()) prosody_.erase(prosody_it);
#else
  auto pause_it = pause_level_.find(language);
  if (pause_it != pause_level_.end()) pause_level_.erase(pause_it);
#endif
}

}  // namespace tts
