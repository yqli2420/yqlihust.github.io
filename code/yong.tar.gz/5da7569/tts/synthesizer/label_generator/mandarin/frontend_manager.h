// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaoqin.feng@mobvoi.com
#ifndef TTS_SYNTHESIZER_LABEL_GENERATOR_MANDARIN_FRONTEND_MANAGER_H_
#define TTS_SYNTHESIZER_LABEL_GENERATOR_MANDARIN_FRONTEND_MANAGER_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/mutex.h"
#include "tts/nlp/polyphone/polyphone.h"
#ifndef FOR_PORTABLE
#include "tts/nlp/pause_level/prosody.h"
#else
#include "tts/nlp/pause_level/pause_predictor.h"
#endif

namespace tts {
class FrontendManager {
 public:
  static FrontendManager& Instance();
  ~FrontendManager();

  void InitAllFrontend(const string& language, const string& resource_file);
#ifndef FOR_PORTABLE
  bool DoExtractFrontendModel(const string& frontend_dir,
                              const string& language,
                              const string& frontend_type);
#endif
  void InitPolyphone(const string& language, const string& resource_file,
                     const bool reset_flag);
  void UpdatePolyphone(const string& language, const string& resource_file);
  void PolyphoneProcess(
      const string& language,
      vector<nlp::polyphone::PolyphoneToken>* polyphone_tokens,
      map<int, int>* polyphone_prob);
  void InitProsody(const string& language, const string& resource_file,
                   const bool reset_flag);
  void UpdateProsody(const string& language, const string& resource_file);
  void ProsodyProcess(const string& language,
#ifndef FOR_PORTABLE
                      vector<int> tokens,
#else
                      vector<nlp::prosody::InputToken> tokens,
#endif
                      vector<int>* result);
  void LoadAllPolyphoneDict();
  void LoadModelPolyphoneDict(const string& language);
  bool IsContainInPolyDict(const string& type, const string& word,
                           bool* in_model);

  void UnloadModel(const string& language);

 private:
  FrontendManager() = default;
  mobvoi::SharedMutex poly_lock_;
  mobvoi::SharedMutex prosody_lock_;
  map<string, std::unique_ptr<nlp::polyphone::Polyphone>> polyphone_;
#ifndef FOR_PORTABLE
  map<string, std::unique_ptr<nlp::prosody::Prosody>> prosody_;
#else
  map<string, std::unique_ptr<nlp::prosody::PausePredictor>> pause_level_;
#endif
  mobvoi::unordered_map<string, mobvoi::unordered_map<string, bool>>
      polyphone_map_;

  DISALLOW_COPY_AND_ASSIGN(FrontendManager);
};
}  // namespace tts

#endif  // TTS_SYNTHESIZER_LABEL_GENERATOR_MANDARIN_FRONTEND_MANAGER_H_
