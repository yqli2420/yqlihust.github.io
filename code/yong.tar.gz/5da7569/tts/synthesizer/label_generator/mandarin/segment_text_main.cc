// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "mobvoi/base/at_exit.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/string_util.h"
#include "tts/nlp/segmenter/segmenter.h"

DEFINE_string(input_file, "", "");
DEFINE_string(output_file, "", "");

int main(int argc, char **argv) {
  base::AtExitManager at_exit;
  google::ParseCommandLineFlags(&argc, &argv, false);

  // vector<string> lines;
  // file::SimpleLineReader reader(FLAGS_input_file);
  // reader.ReadLines(&lines);

  // unique_ptr<nlp::segmenter::Segmenter> segmenter(
  //    nlp::segmenter::SegmenterManager::GetSegmenter("comb", ""));

  // FILE* fp = fopen(FLAGS_output_file.c_str(), "w");
  // for (size_t i = 0; i < lines.size(); ++i) {
  //  vector<string> segs;
  //  SplitString(lines[i], ' ', &segs);
  //  if (segs.size() != 2) {
  //    LOG(ERROR)<< "Bad line:" << lines[i];
  //    continue;
  //  }
  //  string buff;
  //  vector<nlp::segmenter::Word> segment_words;
  //  segmenter->WordSegmentation(segs[1]);
  //  for (const nlp::segmenter::Word& segment_word : segment_words) {
  //    buff.append(segment_word.word + " ");
  //  }
  //  buff.resize(buff.size() - 1);
  //  fprintf(fp, "%s %s\n", segs[0].c_str(), buff.c_str());
  //}
  // fclose(fp);
  return 0;
}
