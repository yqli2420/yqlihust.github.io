// Copyright 2017 Mobvoi Inc. All Rights Reserved.
// Author: ranzhang@mobvoi.com (Dylan)

#ifndef TTS_SYNTHESIZER_LABEL_GENERATOR_LABEL_UTIL_H_
#define TTS_SYNTHESIZER_LABEL_GENERATOR_LABEL_UTIL_H_

#include "mobvoi/base/compat.h"
#include "tts/nlp/g2p/g2p.h"
#include "tts/synthesizer/label_generator/label_def.h"
#include "tts/synthesizer/label_generator/label_generator_def.h"
#include "tts/util/tts_util/util.h"

namespace tts {

void RemoveFrontEndBreak(vector<int>* result);
string GetDebugPauseFromPauseLevel(int pause_level);
int PauseMark2Level(const string& s);
bool IsSeperator(const string& ch);
void ParseMandSyllable(const string& pron, vector<string>* phonemes,
                       string* vowel, int* tone);
void ParseCanSyllable(const string& pron, vector<string>* phonemes,
                      string* vowel, int* tone);
void SplitMandOrCanSyllable(const vector<string>& prons, const string& language,
                            vector<vector<string>>* syllable_prons,
                            vector<string>* vowels, vector<int>* tones);
void SplitEnSyllable(const vector<string>& prons,
                     vector<vector<string>>* syllable_prons,
                     vector<string>* vowels, vector<int>* tones);
bool IsChineseNumber(const string& ch);
void ErhuayinProcess(const mobvoi::unordered_set<string>& erhua_set,
                     vector<WordToken>* word_token);
void RemoveWordLP(vector<WordToken>* word_tokens);
// restrict pause level length api
void RestrictLevel(vector<WordToken>* word_tokens);
// set ssml seted level
void ProcessSsmlLevel(vector<WordToken>* word_token);
// restrict word number limit of target pause level
void RestrictTargetLevel(int restrict_level, int min, int max,
                         vector<WordToken>* word_tokens);

void MergeWord(vector<WordToken>* word_token);

// merge word i and i+1 to word i+1, then delete word i
void UpdateWordTone(const mobvoi::unordered_set<string>& soft_word,
                    vector<WordInfo>* word_info);
bool SplitSyllable(const vector<string>& prons,
                   const map<int, int> polyphone_prob, const string& pos,
                   const WordLanguage& word_language, const string& language,
                   vector<SyllableInfo>* syllable_infos, int* phone_num,
                   int* man_phone_num);
bool GenWordInfos(const vector<WordToken>& word_tokens,
                  const map<int, int> polyphone_prob,
                  const mobvoi::unordered_set<string>& soft_word,
                  const LabelOption& label_option, bool is_online,
                  vector<WordInfo>* word_infos);

bool GenWordInfo(const vector<WordToken>& word_tokens,
                 const map<int, int> polyphone_prob, const string& language,
                 vector<WordInfo>* word_info);

bool IsManVowel(const char& ch);
bool IsCanVowel(const char& ch);
bool IsEngVowel(const char& ch);
bool IsSingleAbc(const string& phoneme);
bool IsEnglishPhone(const string& phoneme);

void RevisePuncByMono(const string norm, const vector<string> mono_syl,
                      string* output);
string AppendText(const string& text, PuncType is_punc,
                  std::pair<string, string> append_char);
bool DeleteAppendLabel(vector<string>* labels, PuncType is_punc,
                       std::pair<int, int> append_phone_num);
}  // namespace tts

#endif  // TTS_SYNTHESIZER_LABEL_GENERATOR_LABEL_UTIL_H_
