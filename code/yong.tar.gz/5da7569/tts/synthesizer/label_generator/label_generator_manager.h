// Copyright 2017 Mobvoi Inc. All Rights Reserved.
// Author: ranzhang@mobvoi.com (Dylan)

#ifndef TTS_SYNTHESIZER_LABEL_GENERATOR_LABEL_GENERATOR_MANAGER_H_
#define TTS_SYNTHESIZER_LABEL_GENERATOR_LABEL_GENERATOR_MANAGER_H_

#include "tts/synthesizer/label_generator/english/english_label_generator.h"
#include "tts/synthesizer/label_generator/mandarin/mandarin_label_generator.h"

namespace tts {

class LabelGeneratorManager {
 public:
  LabelGeneratorManager();
  ~LabelGeneratorManager();

  std::shared_ptr<LabelGenerator> CreateLabelGenerator(
      const string& language, const string& resource_file);

 private:
  std::map<string, std::weak_ptr<LabelGenerator>> label_generators_;
  DISALLOW_COPY_AND_ASSIGN(LabelGeneratorManager);
};

}  // namespace tts

#endif  // TTS_SYNTHESIZER_LABEL_GENERATOR_LABEL_GENERATOR_MANAGER_H_
