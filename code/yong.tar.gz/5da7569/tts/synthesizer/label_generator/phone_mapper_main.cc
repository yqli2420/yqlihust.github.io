// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaoqin.feng@mobvoi.com

#include "tts/synthesizer/label_generator/phone_mapper.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/time.h"
#include "mobvoi/util/utf8/utf8_util.h"
#include "tts/util/tts_util/util.h"

DEFINE_string(phone_mapper_dict,
              "external/config/front_end/dict/phone_mapping.dict",
              "phone mapping dict");
DEFINE_string(text, "", "text to be mapping");
DEFINE_string(text_file, "", "");
DEFINE_string(output_file, "", "");
DEFINE_string(frontend_type, "", "phone mapping for target type man/eng");
static const char kTextSegSepMark = '\t';
static const char kResSegSepMark = ' ';
static const string kTextConvertFail = "none";  // NOLINT

int main(int argc, char** argv) {
  google::ParseCommandLineFlags(&argc, &argv, false);
  tts::PhoneMapper phone_mapper(FLAGS_phone_mapper_dict);
  vector<string> lines;
  if (!FLAGS_text.empty()) {
    lines.emplace_back(FLAGS_text);
  } else if (!FLAGS_text_file.empty()) {
    file::SimpleLineReader reader(FLAGS_text_file);
    reader.ReadLines(&lines);
  } else {
    LOG(ERROR) << "set --text or --text_file";
    return 0;
  }
  int64 begin_time = mobvoi::GetTimeInMs();
  int bytes = 0;
  vector<string> results;
  for (const string& line : lines) {
    bytes += util::utflen(line.c_str());
    vector<string> slices;
    SplitString(line, kResSegSepMark, &slices);
    vector<string> tmp_result;
    string last_type = "none";
    for (auto slice : slices) {
      bool tmp_convert_flag;
      string tmp_pinyin;
      if (!FLAGS_frontend_type.empty()) {
        tmp_convert_flag =
            phone_mapper.ToneToPinyin(FLAGS_frontend_type, slice, &tmp_pinyin);
        if (!tmp_convert_flag) tmp_pinyin = kTextConvertFail;
      } else {
        tmp_convert_flag = phone_mapper.ToneToPinyin("man", slice, &tmp_pinyin);
        if (!tmp_convert_flag) {
          if (!phone_mapper.ToneToPinyin("eng", slice, &tmp_pinyin)) {
            tmp_pinyin = kTextConvertFail;
          }
        }
      }

      if (tts::IsChinesePron(tmp_pinyin)) {
        if (last_type == "eng") {
          tmp_pinyin = "/ " + tmp_pinyin;
        }
        last_type = "man";
      } else {
        if (last_type != "none") tmp_pinyin = "/ " + tmp_pinyin;
        last_type = "eng";
      }
      tmp_result.emplace_back(tmp_pinyin);
    }
    string tmp_pinyin = JoinVector(tmp_result, kResSegSepMark);
    re2::RE2::GlobalReplace(&tmp_pinyin, "_", " . ");
    tmp_pinyin = StringPrintf("%s%c%s", line.c_str(), kTextSegSepMark,
                              tmp_pinyin.c_str());
    results.emplace_back(tmp_pinyin);
    std::cout << tmp_pinyin << std::endl;
    VLOG(2) << tmp_pinyin;
  }
  int64 end_time = mobvoi::GetTimeInMs();
  int64 used_time = end_time - begin_time;
  if (used_time) {
    VLOG(2) << "convert bytes:" << bytes << ", used time in Ms:" << used_time
            << ", performance :" << bytes * 1000 / used_time << " bytes/second";
  }
  if (!FLAGS_output_file.empty()) {
    mobvoi::File::WriteStringToFile(JoinVector(results, '\n'),
                                    FLAGS_output_file);
  }
  return 0;
}
