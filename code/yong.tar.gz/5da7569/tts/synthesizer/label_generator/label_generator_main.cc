// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include <future>  // NOLINT
#include <regex>   // NOLINT
#include "tts/synthesizer/label_generator/label_generator_manager.h"
#include "tts/util/tts_util/util.h"

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/file/proto_util.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"

DEFINE_string(text, "给朋友过生日，送了Teqvila Shot。哈哈。", "");
DEFINE_string(text_file, "", "");
DEFINE_bool(gen_label_from_mono, true, "if true, generate training data");
DEFINE_string(mono_dir, "mono", "");
DEFINE_string(mono_dir_out, "mono_out", "");
DEFINE_string(dir, "full", "");
DEFINE_bool(revise_mono, true,
            "if true, revise mono label according to full label");
DEFINE_bool(adjust_label, false, "adjust the label or not");
DEFINE_bool(gen_label_for_alignment, false,
            "if true, generate full_lab and phone_seq for tts alignment");
DEFINE_string(phone_seq_file, "phone_seq.txt", "");
DEFINE_string(resource_file, "external/config/front_end/man_frontend.conf",
              "frontend resource file");
DEFINE_string(language, "Mandarin", "support Mandarin | English");
DEFINE_int64(num_thread, 16, "number of multi-threads");
DEFINE_bool(collect_phone, false, "get the occurrence of phones");
DEFINE_string(mono_file, "./monophones.txt",
              "file containing monophones and occurrence");
DEFINE_string(tri_file, "./triphones.txt",
              "file containing triphones and occurrence");

struct MonoLabel {
  int start_time;
  int end_time;
  string phone;
};

bool ReadMonoFile(const string& mono_file, vector<MonoLabel>* mono_labels) {
  if (!mobvoi::File::Exists(mono_file)) {
    LOG(WARNING) << "No mono file for :" << mono_file;
    return false;
  }
  file::SimpleLineReader reader(mono_file);
  vector<string> lines;
  reader.ReadLines(&lines);
  for (size_t i = 0; i < lines.size(); ++i) {
    vector<string> segs;
    SplitString(lines[i], ' ', &segs);
    if (segs.size() != 3UL) {
      LOG(ERROR) << "Bad line:" << lines[i] << ", filename:" << mono_file;
      return false;
    }
    MonoLabel label;
    label.start_time = StringToInt(segs[0]);
    label.end_time = StringToInt(segs[1]);
    if (segs[2] == "ng") segs[2] = "en";
    label.phone = segs[2];
    mono_labels->push_back(label);
  }
  if (mono_labels->empty()) {
    LOG(WARNING) << "mono file is empty:" << mono_file;
    return false;
  }
  return true;
}

bool ReviseMonoPhone(const vector<string>& labels,
                     vector<MonoLabel>* mono_labels) {
  for (size_t i = 0; i < mono_labels->size(); ++i) {
    string::size_type start = labels[i].find('-') + 1;
    string::size_type end = labels[i].find('+');
    mono_labels->at(i).phone = labels[i].substr(start, end - start);
  }
  return true;
}

bool WriteMonoFile(const string& filename,
                   const vector<MonoLabel>& mono_labels) {
  string content;
  for (size_t i = 0; i < mono_labels.size(); ++i) {
    content.append(StringPrintf("%d %d %s\n", mono_labels[i].start_time,
                                mono_labels[i].end_time,
                                mono_labels[i].phone.c_str()));
  }
  mobvoi::File::WriteStringToFile(content, filename);
  return true;
}

void ReadText(vector<string>* lines) {
  if (!FLAGS_text.empty() && !FLAGS_gen_label_from_mono) {
    lines->push_back(FLAGS_text);
  } else {
    file::SimpleLineReader reader(FLAGS_text_file, true, "#");
    reader.ReadLines(lines);
  }
}

bool cmp(const std::pair<string, int>& a, const std::pair<string, int>& b) {
  return a.second < b.second;
}

void WriteCollection(const string& filename, map<string, int>* phone_count) {
  string ret = "";
  vector<std::pair<string, int>> vec(phone_count->begin(), phone_count->end());
  sort(vec.begin(), vec.end(), cmp);
  for (auto iter = vec.begin(); iter != vec.end(); iter++) {
    string tmp_ret =
        StringPrintf("%s: %d\n", (iter->first).c_str(), iter->second);
    ret += tmp_ret;
  }
  mobvoi::File::WriteStringToFile(ret, filename);
}

void CollectPhone(string phone, map<string, int>* phone_count) {
  auto iter = phone_count->find(phone);
  if (iter != phone_count->end()) {
    iter->second += 1;
  } else {
    phone_count->insert(std::make_pair(phone, 1));
  }
}

void GenLabelsForTextData(std::shared_ptr<tts::LabelGenerator> generator,
                          const tts::LabelOption& label_option) {
  vector<string> lines;
  ReadText(&lines);
  map<string, int> monophone_count;
  map<string, int> triphone_count;
  std::smatch result;
  std::regex pattern("\\w+\\^([A-Za-z]+-([A-Za-z]+)\\+[A-Za-z]+).*");
  LOG(INFO) << "Line number: " << lines.size();
  for (const string& line : lines) {
    vector<tts::SsmlText> input;
    tts::SsmlParser::Instance().ParseText(line, &input);
    vector<string> labels;
    generator->GenLabels(input, label_option, true /*offline*/, &labels,
                         nullptr);
    for (const string& label : labels) {
      LOG(INFO) << label;
      if (std::regex_match(label, result, pattern)) {
        CollectPhone(result[2], &monophone_count);
        CollectPhone(result[1], &triphone_count);
      }
    }
  }
  WriteCollection(FLAGS_mono_file, &monophone_count);
  WriteCollection(FLAGS_tri_file, &triphone_count);
}

void GenLabelsForAlignment(std::shared_ptr<tts::LabelGenerator> generator,
                           const tts::LabelOption& label_option) {
  vector<string> lines;
  ReadText(&lines);
  map<string, int> monophone_count;
  map<string, int> triphone_count;
  std::smatch result;
  std::regex pattern("\\w+\\^([A-Za-z]+-([A-Za-z]+)\\+[A-Za-z]+).*");
  std::regex pattern_tone("\\w+.*/B:(\\d)-.*");
  LOG(INFO) << "Line number: " << lines.size();
  string phone_list_out;
  for (const string& line : lines) {
    vector<tts::SsmlText> input;
    vector<string> segs;
    SplitString(line, '\t', &segs);
    if (segs.size() != 2) {
      LOG(ERROR) << "Bad line:" << line;
      continue;
    }
    tts::SsmlParser::Instance().ParseText(segs[1], &input);
    vector<string> labels;
    generator->GenLabels(input, label_option, true /*offline*/, &labels,
                         nullptr);
    string content;
    string file = mobvoi::File::JoinPath(FLAGS_dir, segs[0] + ".lab");
    string phone_list = "";
    for (const string& label : labels) {
      VLOG(1) << label;
      content.append(StringPrintf("%s\n", label.c_str()));
      if (std::regex_match(label, result, pattern)) {
        CollectPhone(result[2], &monophone_count);
        CollectPhone(result[1], &triphone_count);
        phone_list += result[2];
      }
      if (std::regex_match(label, result, pattern_tone)) {
        phone_list += result[1];
      }
      phone_list += " ";
    }
    mobvoi::File::WriteStringToFile(content, file);
    VLOG(1) << segs[0] << "\t" << phone_list << std::endl;
    phone_list_out += segs[0] + "\t" + phone_list + "\n";
  }
  mobvoi::File::WriteStringToFile(phone_list_out, FLAGS_phone_seq_file);
  WriteCollection(FLAGS_mono_file, &monophone_count);
  WriteCollection(FLAGS_tri_file, &triphone_count);
}

int GenLabelsFromBatchScript(std::shared_ptr<tts::LabelGenerator> generator,
                             const tts::LabelOption& label_option,
                             const int index, const vector<string>& batch_text,
                             vector<string>* mis_content) {
  string batch_mis_content = "";
  int batch_mis_num = 0;
  for (size_t i = 0; i < batch_text.size(); i++) {
    vector<string> segs;
    SplitString(batch_text[i], '\t', &segs);
    if (segs.size() != 3) {
      LOG(ERROR) << "Bad line:" << batch_text[i];
      continue;
    }
    string mono_file = mobvoi::File::JoinPath(FLAGS_mono_dir, segs[0] + ".lab");
    string file = mobvoi::File::JoinPath(FLAGS_dir, segs[0] + ".lab");

    vector<MonoLabel> mono_labels;
    if (!ReadMonoFile(mono_file, &mono_labels)) {
      continue;
    }

    if (label_option.adjust_label()) mono_labels.erase(mono_labels.begin());

    vector<string> labels;

    LOG(INFO) << "id:" << segs[0] << ", text:" << segs[1];
    vector<tts::SsmlText> input;
    tts::SsmlParser::Instance().ParseText(segs[1] + "\t" + segs[2], &input);
    generator->GenLabels(input, label_option, false /*offline*/, &labels,
                         nullptr);

    if (mono_labels.size() != labels.size()) {
      LOG(WARNING) << "mono_labels.size() != labels.size(), Skip:"
                   << mono_labels.size() << " : " << labels.size() << ", "
                   << segs[0] << "\t" << segs[1];
      if (mono_labels.size() < labels.size())
        mono_labels.resize(labels.size());
      else
        labels.resize(mono_labels.size());

      batch_mis_content.append(StringPrintf("%s\n", batch_text[i].c_str()));
      for (size_t i = 0; i < mono_labels.size(); ++i) {
        batch_mis_content.append(
            StringPrintf("%s\t", mono_labels[i].phone.c_str()));
        batch_mis_content.append(StringPrintf("%s\n", labels[i].c_str()));
      }
      batch_mis_num += 1;
      continue;
    }

    string content;
    for (size_t j = 0; j < labels.size(); ++j) {
      content.append(StringPrintf("%d %d %s\n", mono_labels[j].start_time,
                                  mono_labels[j].end_time, labels[j].c_str()));
    }

    mobvoi::File::WriteStringToFile(content, file);
    if (FLAGS_revise_mono) {
      string mono_file =
          mobvoi::File::JoinPath(FLAGS_mono_dir_out, segs[0] + ".lab");
      ReviseMonoPhone(labels, &mono_labels);
      WriteMonoFile(mono_file, mono_labels);
    }
  }
  if (batch_mis_content != "") {
    mis_content->at(index) = batch_mis_content;
  }

  return batch_mis_num;
}

// can't make it const because english label generator do not support
void GenLabelsFromScript(std::shared_ptr<tts::LabelGenerator> generator,
                         const tts::LabelOption& label_option,
                         size_t num_threads) {
  vector<string> lines;
  ReadText(&lines);
  int mis_match = 0;

  LOG(INFO) << "Line number:" << lines.size();
  vector<string> texts;
  for (size_t i = 0; i < lines.size(); i += 2) {
    string tmp1, tmp2;
    mobvoi::TrimWhitespaceASCII(lines[i], mobvoi::TRIM_TRAILING, &tmp1);
    mobvoi::TrimWhitespaceASCII(lines[i + 1], mobvoi::TRIM_ALL, &tmp2);
    string utt_text = tmp1 + "\t" + tmp2;
    texts.push_back(utt_text);
  }

  size_t text_num = texts.size();
  size_t batch_num = text_num / num_threads;
  vector<std::future<int>> futures;
  vector<string> mis_labels(num_threads);

  vector<vector<string>> all_text;
  for (size_t i = 0; i < num_threads; i++) {
    vector<string> batch_text;
    if (i == num_threads - 1) {
      batch_text.assign(texts.begin() + i * batch_num,
                        texts.begin() + text_num);
    } else {
      batch_text.assign(texts.begin() + i * batch_num,
                        texts.begin() + (i + 1) * batch_num);
    }
    all_text.push_back(batch_text);
  }
  for (size_t i = 0; i < num_threads; i++) {
    futures.push_back(async(std::launch::async, GenLabelsFromBatchScript,
                            generator, label_option, i, std::ref(all_text[i]),
                            &mis_labels));
  }
  for (auto& f : futures) mis_match += f.get();
  LOG(INFO) << "mis_match:" << mis_match;

  string all_mis = "";
  for (auto& batch_mis : mis_labels) all_mis.append(batch_mis);
  mobvoi::File::WriteStringToFile(all_mis, "misfile.txt");
}

int main(int argc, char** argv) {
  google::ParseCommandLineFlags(&argc, &argv, false);
  tts::LabelGeneratorManager generator_manager;
  std::shared_ptr<tts::LabelGenerator> label_generator =
      generator_manager.CreateLabelGenerator(FLAGS_language,
                                             FLAGS_resource_file);
  tts::LabelOption label_option;
  tts::SetDefaultLabelOption(&label_option);
  label_option.set_language(FLAGS_language);
  label_option.set_adjust_label(FLAGS_adjust_label);
  if (FLAGS_gen_label_from_mono) {
    GenLabelsFromScript(label_generator, label_option, FLAGS_num_thread);
  } else if (FLAGS_gen_label_for_alignment) {
    GenLabelsForAlignment(label_generator, label_option);
  } else {
    GenLabelsForTextData(label_generator, label_option);
  }
  return 0;
}
