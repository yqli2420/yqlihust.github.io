// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/synthesizer/engine/hmm/hts_sstream.h"

#include <math.h>
#include <stdlib.h>

#include <string>
#include <vector>

#include "mobvoi/base/log.h"
#include "tts/synthesizer/engine/hmm/hts_label.h"
#include "tts/synthesizer/engine/hmm/hts_model.h"
#include "tts/synthesizer/engine/hmm/hts_model_util.h"
#include "tts/synthesizer/engine/hmm/hts_util.h"
#include "tts/synthesizer/engine/hmm/types.h"

DEFINE_double(sil_duration, 10.0, "sil duration 10 frames per state");

namespace hts {
// Set default duration from state duration probability distribution
static double HTS_set_default_duration(size_t *duration, double *mean,
                                       double *vari, size_t size) {
  size_t i;
  double temp;
  size_t sum = 0;

  for (i = 0; i < size; ++i) {
    temp = mean[i] + 0.5;
    if (temp < 1.0) {
      duration[i] = 1;
    } else {
      duration[i] = (size_t)temp;
    }
    sum += duration[i];
  }

  return (double)sum;  // NOLINT(*)
}

// Set duration from state duration probability distribution
// and specified frame length
static double HTS_set_specified_duration(size_t *duration, double *mean,
                                         double *vari, size_t size,
                                         double frame_length) {
  size_t i;
  int j;
  double temp1, temp2;
  double rho = 0.0;
  size_t sum = 0;
  size_t target_length;

  // Get the target frame length
  if (frame_length + 0.5 < 1.0)
    target_length = 1;
  else
    target_length = (size_t)(frame_length + 0.5);

  // Check the specified duration
  if (target_length <= size) {
    if (target_length < size)
      LOG(ERROR) << "Specified frame length is too short.";
    for (i = 0; i < size; ++i) duration[i] = 1;
    return (double)size;  // NOLINT(*)
  }

  // RHO calculation
  temp1 = 0.0;
  temp2 = 0.0;
  for (i = 0; i < size; ++i) {
    temp1 += mean[i];
    temp2 += vari[i];
  }
  rho = ((double)target_length - temp1) / temp2;  // NOLINT(*)

  // First estimation
  for (i = 0; i < size; ++i) {
    temp1 = mean[i] + rho * vari[i] + 0.5;
    if (temp1 < 1.0)
      duration[i] = 1;
    else
      duration[i] = (size_t)temp1;
    sum += duration[i];
  }

  // Loop estimation
  while (target_length != sum) {
    // Search flexible state and modify its duration
    if (target_length > sum) {
      j = -1;
      for (i = 0; i < size; ++i) {
        temp2 = fabs(
            rho - ((double)duration[i] + 1 - mean[i]) / vari[i]);  // NOLINT(*)
        if (j < 0 || temp1 > temp2) {
          j = i;
          temp1 = temp2;
        }
      }
      sum++;
      duration[j]++;
    } else {
      j = -1;
      for (i = 0; i < size; ++i) {
        if (duration[i] > 1) {
          temp2 =
              fabs(rho -
                   ((double)duration[i] - 1 - mean[i]) / vari[i]);  // NOLINT(*)
          if (j < 0 || temp1 > temp2) {
            j = i;
            temp1 = temp2;
          }
        }
      }
      sum--;
      duration[j]--;
    }
  }

  return (double)target_length;  // NOLINT(*)
}

void SStreamSet::Init() {
  nstream_ = 0;
  nstate_ = 0;
  total_state_ = 0;
  total_frame_ = 0;
}

bool SStreamSet::Create(const ModelSet &ms, const Label &label,
                        bool phoneme_alignment_flag, double speed,
                        vector<double> &duration_iw,
                        vector<vector<double>> &parameter_iw,
                        vector<vector<double>> &gv_iw,
                        tts::LanguageType language_type) {
  size_t i, j, k;
  double temp;
  int shift;
  size_t state;
  double *duration_mean, *duration_vari;
  double frame_length;
  size_t next_time;
  size_t next_state;

  //  Get phonemes from labels
  for (i = 0; i < label.Size(); ++i) {
    string context = label.GetString(i);
    size_t pos_s = context.find_first_of("-");
    size_t pos_e = context.find_first_of("+");
    if (pos_s != string::npos && pos_s != string::npos) {
      string phoneme = context.substr(pos_s + 1, pos_e - pos_s - 1);
      this->phonemes_.push_back(phoneme);
    } else {
      LOG(FATAL) << "Failed to get current phoneme from full label string:"
                 << context;
    }
  }
  VLOG(3) << "phoneme  size " << phonemes_.size();
  VLOG(2) << "nvoices:" << ms.GetVoiceNumber();
  // Check interpolation weights
  temp = 0.0;
  for (i = 0; i < ms.GetVoiceNumber(); ++i) {
    temp += duration_iw[i];
  }
  if (temp == 0.0) {
    return false;
  } else if (temp != 1.0) {
    for (i = 0; i < ms.GetVoiceNumber(); ++i) {
      if (duration_iw[i] != 0.0) {
        duration_iw[i] /= temp;
      }
    }
  }

  for (i = 0; i < ms.GetStreamNumber(); ++i) {
    temp = 0.0;
    for (j = 0; j < ms.GetVoiceNumber(); ++j) {
      temp += parameter_iw[i][j];
    }
    if (temp == 0.0) {
      return false;
    } else if (temp != 1.0) {
      for (j = 0; j < ms.GetVoiceNumber(); ++j)
        if (parameter_iw[i][j] != 0.0) parameter_iw[i][j] /= temp;
    }

    bool use_gv = ms.UseGv(i);
    VLOG(2) << "use gv for stream " << i << " : " << use_gv;
    if (use_gv) {
      for (j = 0, temp = 0.0; j < ms.GetVoiceNumber(); ++j) {
        temp += gv_iw[i][j];
      }
      if (temp == 0.0) {
        return false;
      } else if (temp != 1.0) {
        for (j = 0; j < ms.GetVoiceNumber(); ++j) {
          if (gv_iw[i][j] != 0.0) {
            gv_iw[i][j] /= temp;
          }
        }
      }
    }
  }

  // Initialize state sequence
  nstate_ = ms.GetStateNumber();
  nstream_ = ms.GetStreamNumber();
  total_frame_ = 0;
  VLOG(2) << "label size:" << label.Size();
  total_state_ = label.Size() * nstate_;
  VLOG(2) << "sstream info, nstate:" << nstate_ << ", nstream :" << nstream_
          << ", total_state:" << total_state_;
  duration_.reserve(total_state_);
  for (i = 0; i < nstream_; ++i) {
    sstream_.push_back(HTS_SStream());
    HTS_SStream &sst = sstream_.back();
    sst.vector_length = ms.VertorLenght(i);
    VLOG(2) << "stream index:" << i
            << " ,sstream vector length:" << sst.vector_length
            << ", use msd:" << ms.IsMsd(i) << ", use gv:" << ms.UseGv(i);
    sst.mean =
        (double **)HtsCalloc(total_state_, sizeof(double *));  // NOLINT(*)
    sst.vari =
        (double **)HtsCalloc(total_state_, sizeof(double *));  // NOLINT(*)

    if (ms.IsMsd(i)) {
      sst.msd = (double *)HtsCalloc(total_state_, sizeof(double));  // NOLINT(*)
    } else {
      sst.msd = NULL;
    }

    for (j = 0; j < total_state_; ++j) {
      sst.mean[j] = (double *)HtsCalloc(
          sst.vector_length * ms.GetWindowSize(i),  // NOLINT(*)
          sizeof(double));
      sst.vari[j] = (double *)HtsCalloc(
          sst.vector_length * ms.GetWindowSize(i),  // NOLINT(*)
          sizeof(double));
    }

    if (ms.UseGv(i)) {
      sst.gv_switch =
          (bool *)HtsCalloc(total_state_, sizeof(bool));  // NOLINT(*)
      for (j = 0; j < total_state_; ++j) sst.gv_switch[j] = true;
    } else {
      sst.gv_switch = NULL;
    }
  }

  // Determine state duration
  duration_mean =
      (double *)HtsCalloc(total_state_, sizeof(double));  // NOLINT(*)
  duration_vari =
      (double *)HtsCalloc(total_state_, sizeof(double));  // NOLINT(*)
  for (i = 0; i < label.Size(); ++i) {
    ms.GetDuration(label.GetString(i), duration_iw, &duration_mean[i * nstate_],
                   &duration_vari[i * nstate_]);
    if (language_type == tts::kMandarin && !phoneme_alignment_flag) {
      if (this->phonemes_[i] == "SIL") {
        for (j = 0; j < nstate_; ++j) {
          duration_mean[i * nstate_ + j] = FLAGS_sil_duration;
        }
      }
    }
  }

  if (phoneme_alignment_flag) {
    VLOG(1) << "use duration info offered by user.";
    // Uses duration set by user
    next_time = 0;
    next_state = 0;
    state = 0;
    for (i = 0; i < label.Size(); ++i) {
      temp = label.GetEndFrame(i);
      if (temp >= 0) {
        next_time += (size_t)HTS_set_specified_duration(
            duration_.data() + next_state, &duration_mean[next_state],
            &duration_vari[next_state], state + nstate_ - next_state,
            temp - next_time);
        next_state = state + nstate_;
      } else if (i + 1 == label.Size()) {
        LOG(ERROR) << "The time of final label is not specified.";
        HTS_set_default_duration(
            duration_.data() + next_state, &duration_mean[next_state],
            &duration_vari[next_state], state + nstate_ - next_state);
      }
      state += nstate_;
    }
  } else {
    // Determines frame length
    if (speed != 1.0) {
      temp = 0.0;
      for (i = 0; i < total_state_; ++i) {
        temp += duration_mean[i];
      }
      frame_length = temp / speed;
      HTS_set_specified_duration(duration_.data(), duration_mean, duration_vari,
                                 total_state_, frame_length);
    } else {
      HTS_set_default_duration(duration_.data(), duration_mean, duration_vari,
                               total_state_);
    }
  }
  if (VLOG_IS_ON(1)) {
    VLOG(2) << "========== Duration info  ============";
    PrintDoubleArray(duration_.data(), total_state_);
  }
  HtsFree(duration_mean);
  HtsFree(duration_vari);

  // Get parameter
  for (i = 0, state = 0; i < label.Size(); ++i) {
    for (j = 2; j <= nstate_ + 1; ++j) {
      total_frame_ += duration_[state];
      for (k = 0; k < nstream_; k++) {
        HTS_SStream &sst = sstream_[k];
        if (sst.msd) {
          ms.GetParameter(k, j, label.GetString(i), parameter_iw[k],
                          sst.mean[state], sst.vari[state], &sst.msd[state]);
        } else {
          ms.GetParameter(k, j, label.GetString(i), parameter_iw[k],
                          sst.mean[state], sst.vari[state], NULL);
        }
      }
      state++;
    }
  }
  VLOG(2) << "Total frame:" << total_frame_;

  // Copy dynamic window
  for (i = 0; i < nstream_; ++i) {
    HTS_SStream &sst = sstream_[i];
    sst.win_size = ms.GetWindowSize(i);
    sst.win_max_width = ms.MaxWidthOfWindow(i);
    sst.win_l_width = (int *)HtsCalloc(sst.win_size, sizeof(int));  // NOLINT(*)
    sst.win_r_width = (int *)HtsCalloc(sst.win_size, sizeof(int));  // NOLINT(*)
    sst.win_coefficient =
        (double **)HtsCalloc(sst.win_size, sizeof(double));  // NOLINT(*)
    for (j = 0; j < sst.win_size; ++j) {
      sst.win_l_width[j] = ms.GetWindowLeftWidth(i, j);
      sst.win_r_width[j] = ms.GetWindowRightWidth(i, j);
      if (sst.win_l_width[j] + sst.win_r_width[j] == 0) {
        sst.win_coefficient[j] = (double *)HtsCalloc(
            -2 * sst.win_l_width[j] + 1, sizeof(double));  // NOLINT(*)
      } else {
        sst.win_coefficient[j] = (double *)HtsCalloc(
            -2 * sst.win_l_width[j], sizeof(double));  // NOLINT(*)
      }
      sst.win_coefficient[j] -= sst.win_l_width[j];
      for (shift = sst.win_l_width[j]; shift <= sst.win_r_width[j]; shift++) {
        sst.win_coefficient[j][shift] = ms.GetWindowCofficient(i, j, shift);
      }
    }
  }

  // Determine GV
  for (i = 0; i < nstream_; ++i) {
    HTS_SStream &sst = sstream_[i];
    if (ms.UseGv(i)) {
      sst.gv_mean =
          (double *)HtsCalloc(sst.vector_length, sizeof(double));  // NOLINT(*)
      sst.gv_vari =
          (double *)HtsCalloc(sst.vector_length, sizeof(double));  // NOLINT(*)
      ms.GetGv(i, label.GetString(0), gv_iw[i], sst.gv_mean, sst.gv_vari);
    } else {
      sst.gv_mean = NULL;
      sst.gv_vari = NULL;
    }
  }

  for (i = 0; i < label.Size(); ++i) {
    if (!ms.GetGvFlag(label.GetString(i), label.GetStrLen(i))) {
      for (j = 0; j < nstream_; ++j) {
        if (ms.UseGv(j)) {
          for (k = 0; k < nstate_; k++) {
            sstream_[j].gv_switch[i * nstate_ + k] = false;
          }
        }
      }
    }
  }

  return true;
}

size_t SStreamSet::GetStreamNumber() { return nstream_; }

size_t SStreamSet::GetVectorLength(size_t stream_index) {
  return sstream_[stream_index].vector_length;
}

bool SStreamSet::IsMsd(size_t stream_index) {
  return sstream_[stream_index].msd ? true : false;
}

size_t SStreamSet::GetStateNumber() { return total_state_; }

const string &SStreamSet::GetCurPhoneme(size_t index) const {
  return phonemes_[index];
}

size_t SStreamSet::GetTotalFrame() {
  VLOG(2) << "total frame:" << total_frame_;
  return total_frame_;
}

double SStreamSet::GetMsd(size_t stream_index, size_t state_index) {
  return sstream_[stream_index].msd[state_index];
}

size_t SStreamSet::GetWindowSize(size_t stream_index) {
  return sstream_[stream_index].win_size;
}

int SStreamSet::GetWindowLeftWidth(size_t stream_index, size_t window_index) {
  return sstream_[stream_index].win_l_width[window_index];
}

int SStreamSet::GetWindowRightWidth(size_t stream_index, size_t window_index) {
  return sstream_[stream_index].win_r_width[window_index];
}

double SStreamSet::GetWindowCofficient(size_t stream_index, size_t window_index,
                                       int coefficient_index) {
  return sstream_[stream_index].win_coefficient[window_index]
                                               [coefficient_index];
}

size_t SStreamSet::GetWindowMaxWidth(size_t stream_index) {
  return sstream_[stream_index].win_max_width;
}

bool SStreamSet::UseGv(size_t stream_index) {
  return sstream_[stream_index].gv_mean ? true : false;
}

void SStreamSet::SetMean(size_t stream_index, size_t state_index,
                         size_t vector_index, double f) {
  sstream_[stream_index].mean[state_index][vector_index] = f;
}

void SStreamSet::SetVariance(size_t stream_index, size_t state_index,
                             size_t vector_index, double f) {
  sstream_[stream_index].vari[state_index][vector_index] = f;
}

double SStreamSet::GetGvMean(size_t stream_index, size_t vector_index) {
  return sstream_[stream_index].gv_mean[vector_index];
}

double SStreamSet::GetGvVariance(size_t stream_index, size_t vector_index) {
  return sstream_[stream_index].gv_vari[vector_index];
}

void SStreamSet::SetGvSwitch(size_t stream_index, size_t state_index, bool i) {
  sstream_[stream_index].gv_switch[state_index] = i;
}

bool SStreamSet::GetGvSwitch(size_t stream_index, size_t state_index) {
  return sstream_[stream_index].gv_switch[state_index];
}

void SStreamSet::Clear() {
  for (size_t i = 0; i < nstream_; ++i) {
    HTS_SStream &sst = sstream_[i];
    for (size_t j = 0; j < total_state_; ++j) {
      HtsFree(sst.mean[j]);
      HtsFree(sst.vari[j]);
    }

    if (sst.msd) {
      HtsFree(sst.msd);
    }
    HtsFree(sst.mean);
    HtsFree(sst.vari);
    for (size_t j = 0; j < sst.win_size; ++j) {
      sst.win_coefficient[j] += sst.win_l_width[j];
      HtsFree(sst.win_coefficient[j]);
    }

    HtsFree(sst.win_coefficient);
    HtsFree(sst.win_l_width);
    HtsFree(sst.win_r_width);
    if (sst.gv_mean) {
      HtsFree(sst.gv_mean);
    }
    if (sst.gv_vari) {
      HtsFree(sst.gv_vari);
    }
    if (sst.gv_switch) {
      HtsFree(sst.gv_switch);
    }
  }

  Init();
}
}  // namespace hts
