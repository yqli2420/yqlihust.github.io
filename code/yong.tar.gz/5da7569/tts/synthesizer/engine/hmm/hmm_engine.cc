// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: ranzhang@mobvoi.com (Dylan)

#include "tts/synthesizer/engine/hmm/hmm_engine.h"

namespace engine {

HMMEngine::HMMEngine(tts::LanguageType language_type, const string& model_name,
                     float speed, bool is_fixed_point)
    : language_type_(language_type) {
  hts_model_.reset(new hts::ModelSet());
  hts_model_->Init(model_name, speed, is_fixed_point);
}

HMMEngine::~HMMEngine() {}

string HMMEngine::GetEngineModelType() const {
  return string();
}

bool HMMEngine::SynthesizeFromLabel(const tts::TTSOption& tts_option,
                                    const vector<string>& labels,
                                    tts::RawData* raw_data) const {
  hts::HtsEngine engine(hts_model_.get(), tts_option);
  engine.SynthesizeFromLabelStrings(labels, language_type_,
                                    tts_option.detail_output(), raw_data);
  return true;
}
}  // namespace engine
