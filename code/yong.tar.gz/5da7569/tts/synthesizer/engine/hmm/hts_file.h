// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_SYNTHESIZER_ENGINE_HMM_HTS_FILE_H_
#define TTS_SYNTHESIZER_ENGINE_HMM_HTS_FILE_H_

#include <stdio.h>

#include <string>

#include "tts/synthesizer/engine/hmm/hts_util.h"
#include "mobvoi/base/compat.h"

namespace hts {
class HTS_File {
 public:
  // Call HTS_free to delete HTS_File
  static HTS_File* Open(const char* name, const char* opt);
  static HTS_File* Open(HTS_File* fp, size_t size);
  static HTS_File* OpenFromData(void* data, size_t size);

  void WriteFileToString(string* data);

  void Close();
  int GetChar();
  int Eof();
  int Seek(int64 offset, int origin);
  size_t TellOffset();

  // fread with byteswap
  size_t ReadBigEndian(void* buf, size_t size, size_t n);

  // fread with byteswap
  size_t ReadLittleEndian(void* buf, size_t size, size_t n);

  // fwrite with byteswap
  static size_t WriteLittleEndian(const void* buf, size_t size, size_t n,
                                  FILE* fp);

  // get pattern token (single/double quote can be used)
  bool GetPatternToken(char* buff);

  // get token from file pointer (separators are space,tab,line break)
  bool GetTokenFromFile(char* buff);

  // get token from file pointer with specified separator
  bool GetTokenFromFile(char* buff, char separator);

 private:
  size_t Read(void* buf, size_t size, size_t n);

  unsigned char type_;
  void* pointer_;
};
}  // namespace hts
#endif  // TTS_SYNTHESIZER_ENGINE_HMM_HTS_FILE_H_
