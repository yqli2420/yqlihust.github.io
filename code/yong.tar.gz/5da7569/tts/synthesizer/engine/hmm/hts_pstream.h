// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_SYNTHESIZER_ENGINE_HMM_HTS_PSTREAM_H_
#define TTS_SYNTHESIZER_ENGINE_HMM_HTS_PSTREAM_H_

#include <stdio.h>

#include "mobvoi/base/compat.h"
#include "tts/synthesizer/engine/hmm/hts_sstream.h"

namespace hts {
// Matrices/vectors used in the speech parameter generation algorithm.
struct HTS_SMatrices {
  double** mean;               //  mean vector sequence
  double** ivar;               //  inverse diag variance sequence
  double* g;                   //  vector used in the forward substitution
  double** wuw;                //  W' U^-1 W
  double* wum;                 //  W' U^-1 mu
};

// Individual PDF stream.
struct HTS_PStream {
  uint16 vector_length;        //  vector length (static features only)
  uint16 length;               //  stream length
  uint16 width;                //  width of dynamic window
  uint16 gv_length;            //  frame length for GV calculation
  double** par;                //  output parameter vector
  HTS_SMatrices sm;            //  matrices for parameter generation
  size_t win_size;             //  # of windows (static + deltas)
  int* win_l_width;            //  left width of windows
  int* win_r_width;            //  right width of windows
  double** win_coefficient;    //  window coefficients
  bool* msd_flag;       //  Boolean sequence for MSD
  double* gv_mean;             //  mean vector of GV
  double* gv_vari;             //  variance vector of GV
  bool* gv_switch;      //  GV flag sequence
};

// Set of PDF streams.
class PStreamSet {
 public:
  // Initialize parameter stream set
  void Init();

  // Parameter generation using GV weight
  bool Create(SStreamSet*  sss,
              const vector<double>& msd_threshold,
              const vector<double>& gv_weight,
              tts::LanguageType type);

  size_t GetStreamNumber();

  // get feature length
  inline size_t GetVectorLength(size_t stream_index) {
    return pstream_[stream_index].vector_length;
  }
  size_t GetTotalFrame();

  // get parameter
  inline double GetParameter(size_t stream_index, size_t frame_index,
                                  size_t vector_index) {
    return pstream_[stream_index].par[frame_index][vector_index];
  }
  double* GetParameterVector(size_t stream_index, size_t frame_index);

  // get generated MSD flag per frame
  bool GetMsdFlag(size_t stream_index, size_t frame_index);

  bool IsMsd(size_t stream_index);
  void Clear();

  HTS_PStream* pstream_;        //  PDF streams
  size_t nstream_;              //  # of PDF streams
  size_t total_frame_;          //  total frame
};

double HTS_finv(const double x);
void HTS_PStream_mlpg(HTS_PStream* pst);
}  // namespace hts
#endif  // TTS_SYNTHESIZER_ENGINE_HMM_HTS_PSTREAM_H_
