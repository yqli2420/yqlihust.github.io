// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_SYNTHESIZER_ENGINE_HMM_HTS_NODE_H_
#define TTS_SYNTHESIZER_ENGINE_HMM_HTS_NODE_H_

#include "mobvoi/base/basictypes.h"

namespace hts {
struct HTS_Node {
  HTS_Node() {
    no_pdf = 0;
    yes_pdf = 0;
    yes_index = 0;
    no_index = 0;
    quest_index = 0;
  }
  uint16 no_pdf;       // index of PDF for this node(pdf > 0)
  uint16 yes_pdf;      // index of PDF for this node(pdf > 0)
  uint16 yes_index;    // yes branch index
  uint16 no_index;     // no branch index
  uint16 quest_index;  // question index
};

}  // namespace hts

#endif  // TTS_SYNTHESIZER_ENGINE_HMM_HTS_NODE_H_
