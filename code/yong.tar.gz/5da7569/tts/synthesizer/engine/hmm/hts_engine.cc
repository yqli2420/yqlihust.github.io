// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/synthesizer/engine/hmm/hts_engine.h"

#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "mobvoi/base/compat.h"
#include "mobvoi/base/file/proto_util.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/string_util.h"
#include "tts/synthesizer/engine/hmm/hts_file.h"
#include "tts/synthesizer/engine/hmm/hts_util.h"
#include "tts/synthesizer/engine/hmm/types.h"

namespace hts {

static const int kMgcStreamIndex = 0;
static const int kPitchStreamIndex = 1;
HtsEngine::HtsEngine(const ModelSet* model_set,
                     const tts::TTSOption& tts_option)
    : model_set_(model_set) {
  option_.reset(new HtsOption());
  option_->Init(model_set);
  option_->SetOption(tts_option);
  sstream_set_.Init();
  pstream_set_.Init();
}

HtsEngine::~HtsEngine() {
  pstream_set_.Clear();
  sstream_set_.Clear();
}

void HtsEngine::SetStateMean(size_t stream_index, size_t state_index,
                             size_t vector_index, double f) {
  sstream_set_.SetMean(stream_index, state_index, vector_index, f);
}

bool HtsEngine::GenStateSequence(tts::LanguageType language_type) {
  VLOG(2) << "Generate state sequence...";
  if (!sstream_set_.Create(*model_set_, label_, option_->phoneme_alignment_flag,
                           option_->speed, option_->duration_iw,
                           option_->parameter_iw, option_->gv_iw,
                           language_type)) {
    return false;
  }
  VLOG(2) << "additio double* mean, double* vari,nal_half_tone:"
          << option_->additional_half_tone;

  return true;
}

bool HtsEngine::GenParameterSequence(tts::LanguageType language_type) {
  return pstream_set_.Create(&sstream_set_, option_->msd_threshold,
                             option_->gv_weight, language_type);
}

bool HtsEngine::GenParams(tts::LanguageType language_type) {
  if (!GenStateSequence(language_type)) {
    return false;
  }
  if (!GenParameterSequence(language_type)) {
    return false;
  }
  return true;
}

bool HtsEngine::SynthesizeFromLabelFile(const char* fn,
                                        tts::LanguageType language_type) {
  label_.LoadFromFile(option_->sampling_frequency, option_->frame_period, fn);
  return GenParams(language_type);
}

bool HtsEngine::SynthesizeFromLabelStrings(const vector<string>& lines,
                                           tts::LanguageType language_type) {
  label_.LoadFromStringVector(option_->sampling_frequency,
                              option_->frame_period, lines);
  return GenParams(language_type);
}

bool HtsEngine::SynthesizeFromLabelStrings(const vector<string>& lines,
                                           tts::LanguageType language_type,
                                           bool detail_output,
                                           tts::RawData* raw_data) {
  if (!SynthesizeFromLabelStrings(lines, language_type)) return false;
  SaveFeature(&raw_data->feature);
  if (detail_output) {
    SaveAlignedLabel(&(raw_data->durations), &(raw_data->phonemes));
  }
  return true;
}

// mgc pitch uv
void HtsEngine::SaveFeature(vector<float>* fea) {
  const int kMgcIndex = 0;
  const int kPitchIndex = 1;
  int frame_num = pstream_set_.GetTotalFrame();
  int mgc_dim = pstream_set_.GetVectorLength(kMgcIndex);
  int fea_dim = mgc_dim + 2;
  fea->resize(frame_num * fea_dim, 0.0);
  int msd_frame = 0;
  for (size_t i = 0; static_cast<int>(i) < frame_num; ++i) {
    for (size_t j = 0; static_cast<int>(j) < mgc_dim; ++j) {
      (*fea)[i * fea_dim + j] =
          static_cast<float>(pstream_set_.GetParameter(kMgcIndex, i, j));
    }
    if (pstream_set_.GetMsdFlag(kPitchIndex, i)) {
      (*fea)[i * fea_dim + mgc_dim] = exp(static_cast<float>(
          pstream_set_.GetParameter(kPitchIndex, msd_frame, 0)));
      (*fea)[i * fea_dim + mgc_dim + 1] = 1;
      ++msd_frame;
    }
  }
}

void HtsEngine::SaveAlignedLabel(vector<int>* durations,
                                 vector<string>* phonemes) {
  size_t nstate = model_set_->GetStateNumber();
  double rate = option_->frame_period * 1.0e+07 / option_->sampling_frequency;

  size_t dur = 0;
  durations->reserve(label_.Size());
  phonemes->reserve(label_.Size());
  for (size_t i = 0, state = 0, frame = 0; i < label_.Size(); ++i) {
    dur = 0;
    for (size_t j = 0; j < nstate; ++j) {
      dur += sstream_set_.GetDuration(state++);
    }
    string label = label_.GetString(i);
    int sIdx = label.find('-');
    int eIdx = label.find('+');
    string pho = label.substr(sIdx + 1, eIdx - sIdx - 1);
    durations->push_back(frame * rate);
    phonemes->push_back(pho);
    frame += dur;
  }
}

void HtsEngine::SavePitch(vector<float>* pitch) {
  const int kPitchIndex = 1;
  const int kPitchStart = 0;
  int frame_num = pstream_set_.GetTotalFrame();
  pitch->resize(frame_num, 0.0);
  int msd_frame = 0;
  for (size_t i = 0; i < pstream_set_.GetTotalFrame(); ++i) {
    if (pstream_set_.GetMsdFlag(kPitchIndex, i)) {
      float temp = static_cast<float>(
          pstream_set_.GetParameter(kPitchIndex, msd_frame, kPitchStart));
      pitch->at(i) = exp(temp);
      ++msd_frame;
    }
  }
}

void HtsEngine::SaveMgc(vector<vector<float>>* mgc) {
  const int kMgcIndex = 0;
  mgc->resize(pstream_set_.GetTotalFrame());
  for (auto it = mgc->begin(); it != mgc->end(); ++it) {
    it->resize(pstream_set_.GetVectorLength(kMgcIndex));
  }
  for (size_t i = 0; i < pstream_set_.GetTotalFrame(); ++i) {
    for (size_t j = 0; j < pstream_set_.GetVectorLength(kMgcIndex); ++j) {
      float temp =
          static_cast<float>(pstream_set_.GetParameter(kMgcIndex, i, j));
      (*mgc)[i][j] = temp;
    }
  }
}
}  // namespace hts
