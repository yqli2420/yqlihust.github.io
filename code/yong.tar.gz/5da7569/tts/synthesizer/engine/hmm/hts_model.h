// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_SYNTHESIZER_ENGINE_HMM_HTS_MODEL_H_
#define TTS_SYNTHESIZER_ENGINE_HMM_HTS_MODEL_H_

#include <stdio.h>
#include <map>
#include <string>
#include <vector>

#include "mobvoi/base/compat.h"
#include "tts/synthesizer/engine/hmm/hts_model_util.h"
#include "tts/synthesizer/engine/hmm/hts_node.h"
#include "tts/synthesizer/engine/hmm/hts_question.h"
#include "tts/synthesizer/engine/hmm/hts_tree.h"
#include "tts/synthesizer/engine/hmm/hts_util.h"
#include "tts/synthesizer/engine/hmm/hts_window.h"
#include "tts/synthesizer/engine/hmm/proto/hts_model.pb.h"

namespace hts {
//  set of duration models, HMMs and GV models.
class ModelSet {
 public:
  // must call Init
  ModelSet();
  ~ModelSet();

  bool Init(const string& proto_file,
            float default_speed,
            bool is_fixed_point);

  bool LoadProtobufModel(const hts::HtsModel& proto_model);

  string hts_voice_version() const { return hts_voice_version_; }

  // get sampling frequency of HTS voices
  size_t SamplingFrequency() const;

  // get frame period of HTS voices
  size_t FramePeriod() const;

  // get stream option
  const char* GetOption(size_t stream_index) const;

  // get GV flag
  bool GetGvFlag(const char* str, size_t len) const;

  // get number of state
  size_t GetStateNumber() const;

  // get full-context label format
  string GetFullLabelFormat() const;

  // get full-context label version
  string FullLabelVersion() const;

  // get number of stream
  size_t GetStreamNumber() const;

  // get number of HTS voices
  size_t GetVoiceNumber() const;

  // get vector length
  size_t VertorLenght(size_t stream_index) const;

  // get MSD flag
  bool IsMsd(size_t stream_index) const;

  // get dynamic window size
  size_t GetWindowSize(size_t stream_index) const;

  // get left width of dynamic window
  int GetWindowLeftWidth(size_t stream_index, size_t window_index) const;

  // get right width of dynamic window
  int GetWindowRightWidth(size_t stream_index, size_t window_index) const;

  // get coefficient of dynamic window
  double GetWindowCofficient(size_t stream_index, size_t window_index,
                             size_t coefficient_index) const;

  // get max width of dynamic window
  size_t MaxWidthOfWindow(size_t stream_index) const;

  // get GV flag
  bool UseGv(size_t stream_index) const;

  // get index of duration tree and PDF
  void GetDurationIndex(size_t voice_index, const char* string,
                        size_t* tree_index, size_t* pdf_index) const;
  float GetDefaultSpeed() const { return default_speed_; }

  size_t GetStage() const;
  bool UseLogGain() const;
  double GetAlpha() const;

  // get duration using interpolation weight
  void GetDuration(const char* string, const vector<double>& iw, double* mean,
                   double* vari) const;

  // get index of parameter tree and PDF
  void GetParameterIndex(size_t voice_index, size_t stream_index,
                         size_t state_index, const char* string,
                         size_t* tree_index, size_t* pdf_index) const;

  // get parameter using interpolation weight
  void GetParameter(size_t stream_index, size_t state_index, const char* string,
                    const vector<double>& iw, double* mean, double* vari,
                    double* msd) const;

  void GetGvIndex(size_t voice_index, size_t stream_index, const char* string,
                  size_t* tree_index, size_t* pdf_index) const;

  // get GV using interpolation weight
  void GetGv(size_t stream_index, const char* string, const vector<double>& iw,
             double* mean, double* vari) const;

  // get KLD Matrix
  float CalculateKLD(const HTS_Model& model, size_t tree_index,
                     size_t pdf_index_A, size_t pdf_index_B) const;

  void SaveKLDMatrix(FILE* fp) const;
  void SaveKLDMatrix(const string& kld_table_proto) const;


 private:
  string hts_voice_version_;    //  version of HTS voice format
  string stream_type_;          //  stream type
  string fullcontext_format_;   //  fullcontext label format
  string fullcontext_version_;  //  version of fullcontext label

  uint16 sampling_frequency_;   //  sampling frequency
  uint16 frame_period_;         //  frame period
  uint16 num_voices_;           //  # of HTS voices
  uint16 num_streams_;          //  # of streams
  uint32 num_states_;           //  # of HMM states
  // Spectrum option
  uint32 stage_;
  float default_speed_ = 1.0;
  bool use_log_gain_;
  double alpha_;
  bool is_fixed_point_ = false;

  HTS_Question gv_off_context_;  //  GV switch
  vector<string> option_;        //  options for each stream
  // [voice_index]
  vector<HTS_Model> duration_;  //  duration PDFs and trees

  vector<HtsWindow> window_;  //  window coefficients for delta
  // [voice_index][stream_index]
  vector<vector<HTS_Model>> stream_;  //  parameter PDFs and trees
  vector<vector<HTS_Model>> gv_;      //  GV PDFs and trees
};
}  // namespace hts

#endif  // TTS_SYNTHESIZER_ENGINE_HMM_HTS_MODEL_H_
