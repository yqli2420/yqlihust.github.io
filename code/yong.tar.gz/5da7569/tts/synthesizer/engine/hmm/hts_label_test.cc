// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/synthesizer/engine/hmm/hts_label.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "third_party/gtest/gtest.h"

namespace hts {
TEST(LabelTest, LoadFromFile) {
  int sampling_frequency = 44100;
  int fperiod = 44100 * 0.005;
  Label label;
  const char* filename = "tts/synthesizer/engine/testdata/label.txt";
  label.LoadFromFile(sampling_frequency, fperiod, filename);
  EXPECT_EQ(label.Size(), 41UL);
  EXPECT_DOUBLE_EQ(label.GetStartFrame(1), -1);
  EXPECT_DOUBLE_EQ(label.GetEndFrame(1), -1);
}

TEST(LabelTest, LoadFromStringVector) {
  int sampling_frequency = 44100;
  int fperiod = 44100 * 0.005;
  Label label;
  const string filename = "tts/synthesizer/engine/testdata/label.txt";
  vector<string> lines;
  file::SimpleLineReader reader(filename);
  reader.ReadLines(&lines);
  label.LoadFromStringVector(sampling_frequency, fperiod, lines);
  EXPECT_EQ(label.Size(), 41UL);
  EXPECT_DOUBLE_EQ(label.GetStartFrame(1), -1);
  EXPECT_DOUBLE_EQ(label.GetEndFrame(1), -1);
}

TEST(LabelTest, with_frame_info) {
  int sampling_frequency = 44100;
  int fperiod = 44100 * 0.005;
  Label label;
  const string filename =
      "tts/synthesizer/engine/testdata/label_with_frame_info.txt";
  vector<string> lines;
  file::SimpleLineReader reader(filename);
  reader.ReadLines(&lines);
  label.LoadFromStringVector(sampling_frequency, fperiod, lines);
  EXPECT_EQ(label.Size(), 26UL);
  EXPECT_DOUBLE_EQ(label.GetStartFrame(1), 14.99999359090909);
  EXPECT_DOUBLE_EQ(label.GetEndFrame(1), 33.999997499999999);
}
}  // namespace hts
