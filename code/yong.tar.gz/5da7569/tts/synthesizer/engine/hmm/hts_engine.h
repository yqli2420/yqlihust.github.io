// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_SYNTHESIZER_ENGINE_HMM_HTS_ENGINE_H_
#define TTS_SYNTHESIZER_ENGINE_HMM_HTS_ENGINE_H_

#include <stdio.h>

#include <string>
#include <vector>

#include "mobvoi/base/compat.h"
#include "tts/synthesizer/engine/hmm/hts_gstream.h"
#include "tts/synthesizer/engine/hmm/hts_label.h"
#include "tts/synthesizer/engine/hmm/hts_model.h"
#include "tts/synthesizer/engine/hmm/hts_option.h"
#include "tts/synthesizer/engine/hmm/hts_pstream.h"
#include "tts/synthesizer/engine/hmm/hts_sstream.h"
#include "tts/synthesizer/engine/hmm/proto/hts_model.pb.h"
#include "tts/synthesizer/proto/tts.pb.h"
#include "tts/util/tts_util/util.h"

namespace hts {

// not thread safe, instantiate this class in each thread
class HtsEngine {
 public:
  HtsEngine(const ModelSet* model_set, const tts::TTSOption& tts_option);
  ~HtsEngine();

  bool SynthesizeFromLabelFile(const char* fn, tts::LanguageType language_type);

  bool SynthesizeFromLabelStrings(const vector<string>& lines,
                                  tts::LanguageType language_type);
  bool SynthesizeFromLabelStrings(const vector<string>& lines,
                                  tts::LanguageType language_type,
                                  bool detail_output, tts::RawData* raw_data);

  void SaveFeature(vector<float>* fea);
  void SavePitch(vector<float>* pitch);
  void SaveMgc(vector<vector<float>>* mgc);
  void SaveAlignedLabel(vector<int>* durations, vector<string>* phonemes);

 private:
  bool GenStateSequence(tts::LanguageType language_type);
  bool GenParameterSequence(tts::LanguageType language_type);
  bool GenParams(tts::LanguageType language_type);
  void SetStateMean(size_t stream_index, size_t state_index,
                    size_t vector_index, double f);

  unique_ptr<HtsOption> option_;
  const ModelSet* model_set_;  // set of duration models, HMMs and GV models
  Label label_;                // label
  SStreamSet sstream_set_;     // set of state streams
  PStreamSet pstream_set_;     // set of PDF streams
};
}  // namespace hts
#endif  // TTS_SYNTHESIZER_ENGINE_HMM_HTS_ENGINE_H_
