// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_SYNTHESIZER_ENGINE_HMM_HTS_UTIL_H_
#define TTS_SYNTHESIZER_ENGINE_HMM_HTS_UTIL_H_

#include <stdio.h>

#include <string>
#include <vector>

#include "mobvoi/base/compat.h"
#include "mobvoi/base/log.h"
#include "tts/util/tts_util/util.h"

namespace hts {

static const float global_var[126] = {
    5.640377e-02, 3.197473e-06, 8.777401e-06, 1.825930e-05, 3.072502e-05,
    4.780362e-05, 5.178994e-05, 4.877701e-05, 5.039358e-05, 5.266718e-05,
    5.825368e-05, 6.284997e-05, 5.901087e-05, 4.628880e-05, 3.843233e-05,
    3.433965e-05, 3.140174e-05, 3.037063e-05, 3.277091e-05, 3.437028e-05,
    3.216051e-05, 3.556552e-05, 4.004574e-05, 3.841782e-05, 4.213909e-05,
    4.816621e-05, 5.327686e-05, 4.555233e-05, 3.131552e-05, 2.231145e-05,
    2.021174e-05, 1.783297e-05, 1.503442e-05, 1.317450e-05, 1.172092e-05,
    1.025772e-05, 9.416685e-06, 9.370310e-06, 9.911818e-06, 6.977148e-06,
    1.213977e-05, 1.151292e-03, 5.842712e-07, 7.775709e-07, 1.223565e-06,
    1.720159e-06, 2.291978e-06, 2.436514e-06, 2.398127e-06, 2.438165e-06,
    2.223782e-06, 2.271671e-06, 2.168210e-06, 2.075818e-06, 1.933712e-06,
    1.886272e-06, 2.014138e-06, 2.084299e-06, 1.993517e-06, 1.864208e-06,
    1.865142e-06, 1.877724e-06, 2.152341e-06, 2.495730e-06, 2.207225e-06,
    2.059473e-06, 2.246494e-06, 2.585333e-06, 2.930866e-06, 2.729756e-06,
    2.323042e-06, 2.045284e-06, 1.940552e-06, 1.891839e-06, 1.959039e-06,
    1.907139e-06, 1.760712e-06, 1.499967e-06, 1.461998e-06, 1.367066e-06,
    1.200884e-06, 1.074784e-06, 4.360945e-03, 2.914803e-06, 3.160555e-06,
    4.325675e-06, 5.748744e-06, 7.075176e-06, 7.770303e-06, 8.294084e-06,
    9.111347e-06, 8.702476e-06, 8.978967e-06, 8.846435e-06, 8.803156e-06,
    8.863110e-06, 8.849812e-06, 9.675005e-06, 1.031207e-05, 1.012474e-05,
    9.363686e-06, 9.080067e-06, 9.335263e-06, 1.060512e-05, 1.267663e-05,
    1.142724e-05, 1.052090e-05, 1.151427e-05, 1.360338e-05, 1.693144e-05,
    1.673558e-05, 1.436564e-05, 1.265860e-05, 1.241323e-05, 1.257276e-05,
    1.332910e-05, 1.316415e-05, 1.219998e-05, 1.025805e-05, 9.972974e-06,
    9.314907e-06, 8.601371e-06, 7.034303e-06, 6.143235e-04, 7.967003e-06,
    5.069518e-05,
};
// get token from string (separator are space,tab,line break)
bool GetTokenFromString(const char *string, size_t *index, char *buff);

// get token from string with specified separator
bool GetTokenFromStringWithSeperator(const char *str, size_t *index, char *buff,
                                     char separator);

bool IsVoicePhoneme(const string &pho, tts::LanguageType language_type);

// wrapper for calloc
void *HtsCalloc(const size_t num, const size_t size);

// wrapper for strdup
char *HtsStrdup(const char *string);

// allocate double matrix
double **AllocMatrix(size_t x, size_t y);

// free double matrix
void FreeMatrix(double **p, size_t x);

// wrapper for free
void HtsFree(void *p);

// output error message
void HtsError(int error, const char *message, ...);

bool MatchPattern(const char *string, size_t str_len, const char *pattern,
                  size_t pattern_len);
bool MatchPattern(const char *string, const char *pattern);

bool IsNumber(const char *buff);
size_t NameToNumber(const char *buff);
size_t GetStateNumber(const char *string);

void PrintDoubleVector(const vector<double> &vec);

template <class T>
void PrintDoubleArray(T *array, size_t len) {
  for (size_t i = 0; i < len; ++i) {
    VLOG(3) << array[i] << " ";
  }
  VLOG(3) << endl;
}
}  // namespace hts

#endif  // TTS_SYNTHESIZER_ENGINE_HMM_HTS_UTIL_H_
