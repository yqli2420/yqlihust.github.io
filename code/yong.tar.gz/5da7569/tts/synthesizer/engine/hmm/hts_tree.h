// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_SYNTHESIZER_ENGINE_HMM_HTS_TREE_H_
#define TTS_SYNTHESIZER_ENGINE_HMM_HTS_TREE_H_

#include <stdio.h>

#include <string>
#include <map>
#include <vector>

#include "tts/synthesizer/engine/hmm/hts_question.h"
#include "tts/synthesizer/engine/hmm/hts_node.h"
#include "mobvoi/base/basictypes.h"

namespace hts {

//  list of decision trees in a model.
struct HTS_Tree {
  HTS_Tree();
  ~HTS_Tree();

  vector<string> patterns;  //  pointer to the head of
                            // pattern list for this tree
  struct HTS_Tree* next;    //  pointer to next tree
  vector<HTS_Node> vnode;
  uint8 state;            //  state index of this tree
};

void HTS_Tree_parse_pattern(HTS_Tree* tree, char* string);
bool HTS_Tree_load(HTS_Tree* tree,
                   HTS_File* fp,
                   const map<string, int>& questions);
size_t HTS_Tree_search_node(HTS_Tree* tree,
                            const char* str, size_t len,
                            const vector<HTS_Question>& questions);
}  // namespace hts
#endif  // TTS_SYNTHESIZER_ENGINE_HMM_HTS_TREE_H_
