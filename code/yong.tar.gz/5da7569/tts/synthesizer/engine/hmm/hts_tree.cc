// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/synthesizer/engine/hmm/hts_tree.h"

#include <string.h>

#include "mobvoi/base/log.h"
#include "tts/synthesizer/engine/hmm/types.h"
#include "tts/synthesizer/engine/hmm/hts_file.h"
#include "tts/synthesizer/engine/hmm/hts_util.h"

namespace hts {

// Initialize tree
HTS_Tree::HTS_Tree() {
  next = NULL;
  state = 0;
}

// Clear given tree
HTS_Tree::~HTS_Tree() {
  patterns.clear();
}

// Parse pattern specified for each tree
void HTS_Tree_parse_pattern(HTS_Tree* tree, char* str) {
  char *left, *right;
  // parse tree pattern
  if ((left = strchr(str, '{')) != NULL) {  // pattern is specified
    str = left + 1;
    if (*str == '(')
      ++str;

    right = strrchr(str, '}');
    if (str < right &&* (right - 1) == ')')
      --right;
    *right = ',';

    // parse pattern
    while ((left = strchr(str, ',')) != NULL) {
      *left = '\0';
      string s(str);
      tree->patterns.emplace_back(s);
      str = left + 1;
    }
  }
  // To Make sure size() == capacity().
  tree->patterns.shrink_to_fit();
}

// Load trees
bool HTS_Tree_load(HTS_Tree* tree,
                   HTS_File* fp,
                   const map<string, int>& questions) {
  char buff[kMaxBuffLen];
  if (tree == NULL || fp == NULL) {
    return false;
  }

  if (!fp->GetPatternToken(buff)) {
    return false;
  }

  if (strcmp(buff, "{") == 0) {
    while (fp->GetPatternToken(buff) && strcmp(buff, "}") != 0) {
      // Each line looks like:
      // -364 L-sh  -652 -798
      // -375 R-ing -411 "dur_s2_129"
      // NodeId \t question name, no branch, yes branch
      // Node id，即数组下标
      HTS_Node node;
      // qustion name
      if (fp->GetPatternToken(buff) == false) {
        return false;
      }

      // Node name
      auto it = questions.find(buff);
      if (it == questions.end()) {
        HtsError(0, "Cannot find question %s.\n", buff);
        return false;
      }
      node.quest_index = it->second;
      if (!fp->GetPatternToken(buff)) {
        return false;
      }

      // No branch
      if (IsNumber(buff)) {
        node.no_index = abs(atoi(buff));
      } else {
        node.no_index = 0;
        node.no_pdf = NameToNumber(buff);
      }

      if (!fp->GetPatternToken(buff)) {
        return false;
      }
      // Yes branch
      if (IsNumber(buff)) {
        node.yes_index = abs(atoi(buff));
      } else {
        node.yes_index = 0;
        node.yes_pdf = NameToNumber(buff);
      }
      tree->vnode.emplace_back(node);
      VLOG(3) << "cur index = " << tree->vnode.size() + 1
                << ", no_index = " << node.no_index
                << ", no_pdf = " << node.no_pdf
                << ", yes_index = " << node.yes_index
                << ", yes_pdf = " << node.yes_pdf
                << ", quest name = " << it->first;
    }
  } else {
    HTS_Node node;
    node.quest_index = 0;
    node.yes_pdf = NameToNumber(buff);
    node.no_pdf = NameToNumber(buff);
    node.no_index = 0;
    node.yes_index = 0;
    tree->vnode.emplace_back(node);
  }
  tree->vnode.shrink_to_fit();
  return true;
}

size_t HTS_Tree_search_node(HTS_Tree* tree,
                            const char* str, size_t len,
                            const vector<HTS_Question>& questions) {
  if (questions.empty()) {
    return 1;
  }

  int n = tree->vnode.size();
  const HTS_Node* node = &tree->vnode[0];
  for (int i = 0; i < n; ++i) {
    // name is NOT empty.
    DCHECK(!questions[node->quest_index].name.empty());
    const HTS_Question& question = questions[node->quest_index];
    if (HTS_Question_match(question, str, len)) {
      if (node->yes_pdf > 0) {
        return node->yes_pdf;
      }
      node = &tree->vnode[node->yes_index];
    } else {
      if (node->no_pdf > 0) {
        return node->no_pdf;
      }
      node = &tree->vnode[node->no_index];
    }
  }

  LOG(ERROR) << "Cannot find node.";
  return 1;
}

}  // namespace hts
