// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/synthesizer/engine/hmm/hts_file.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "tts/synthesizer/engine/hmm/types.h"
#include "mobvoi/base/log.h"

namespace hts {
#define HTS_FILE 0
#define HTS_DATA 1

struct HTS_Data {
  unsigned char* data;
  uint32 size;
  uint32 index;
};

// TODO(shunping): Use new/delete instead of malloc/free
HTS_File* HTS_File::Open(const char* name, const char* opt) {
  HTS_File* fp = reinterpret_cast<HTS_File*>(HtsCalloc(1, sizeof(HTS_File)));

  fp->type_ = HTS_FILE;
  fp->pointer_ = reinterpret_cast<void*>(fopen(name, opt));

  if (fp->pointer_ == NULL) {
    HtsError(0, "HTS_fopen: Cannot open %s.\n", name);
    HtsFree(fp);
    return NULL;
  }

  return fp;
}

HTS_File* HTS_File::Open(HTS_File* fp, size_t size) {
  if (fp == NULL || size == 0) {
    return NULL;
  } else if (fp->type_ == HTS_FILE) {
    HTS_Data* d;
    HTS_File* f;
    d = reinterpret_cast<HTS_Data*>(HtsCalloc(1, sizeof(HTS_Data)));
    d->data = (unsigned char*)HtsCalloc(size, sizeof(unsigned char));
    d->size = size;
    d->index = 0;
    if (fread(d->data, sizeof(unsigned char), size,
              reinterpret_cast<FILE*>(fp->pointer_)) != size) {
      free(d->data);
      free(d);
      return NULL;
    }
    f = reinterpret_cast<HTS_File*>(HtsCalloc(1, sizeof(HTS_File)));
    f->type_ = HTS_DATA;
    f->pointer_ = reinterpret_cast<void*>(d);
    return f;
  } else if (fp->type_ == HTS_DATA) {
    HTS_File* f;
    HTS_Data *tmp1, *tmp2;
    tmp1 = reinterpret_cast<HTS_Data*>(fp->pointer_);
    if (tmp1->index + size > tmp1->size) return NULL;
    tmp2 = reinterpret_cast<HTS_Data*>(HtsCalloc(1, sizeof(HTS_Data)));
    tmp2->data = (unsigned char*)HtsCalloc(size, sizeof(unsigned char));
    tmp2->size = size;
    tmp2->index = 0;
    memcpy(tmp2->data, &tmp1->data[tmp1->index], size);
    tmp1->index += size;
    f = reinterpret_cast<HTS_File*>(HtsCalloc(1, sizeof(HTS_File)));
    f->type_ = HTS_DATA;
    f->pointer_ = reinterpret_cast<void*>(tmp2);
    return f;
  }

  HtsError(0, "HTS_fopen_from_fp: Unknown file type.\n");
  return NULL;
}

HTS_File* HTS_File::OpenFromData(void* data, size_t size) {
  VLOG(3) << "Read from data , size : " << size;
  HTS_Data* d;
  HTS_File* f;

  if (data == NULL || size == 0) return NULL;

  d = reinterpret_cast<HTS_Data*>(HtsCalloc(1, sizeof(HTS_Data)));
  d->data = (unsigned char*)HtsCalloc(size, sizeof(unsigned char));
  d->size = size;
  d->index = 0;

  memcpy(d->data, data, size);

  f = reinterpret_cast<HTS_File*>(HtsCalloc(1, sizeof(HTS_File)));
  f->type_ = HTS_DATA;
  f->pointer_ = reinterpret_cast<void*>(d);

  return f;
}

void HTS_File::WriteFileToString(string* data) {
  if (type_ == HTS_FILE) {
    FILE* fp = reinterpret_cast<FILE*>(pointer_);
    fseek(fp, 0, SEEK_END);
    size_t size = ftell(fp);
    data->resize(size);
    size_t read_len =
        fread((void*)data->data(), sizeof(char), size, fp);  // NOLINT
    CHECK_EQ(read_len, size);
  } else if (type_ == HTS_DATA) {
    HTS_Data* d = reinterpret_cast<HTS_Data*>(pointer_);
    data->assign((const char*)d->data, d->size);
  }
}

void HTS_File::Close() {
  if (type_ == HTS_FILE) {
    if (pointer_ != NULL) fclose(reinterpret_cast<FILE*>(pointer_));
    HtsFree(this);
    return;
  } else if (type_ == HTS_DATA) {
    if (pointer_ != NULL) {
      HTS_Data* d = reinterpret_cast<HTS_Data*>(pointer_);
      if (d->data != NULL) HtsFree(d->data);
      HtsFree(d);
    }
    HtsFree(this);
    return;
  }
  HtsError(0, "HTS_fclose: Unknown file type.\n");
}

int HTS_File::GetChar() {
  if (type_ == HTS_FILE) {
    return fgetc(reinterpret_cast<FILE*>(pointer_));
  } else if (type_ == HTS_DATA) {
    HTS_Data* d = reinterpret_cast<HTS_Data*>(pointer_);
    if (d->size <= d->index) return EOF;
    return static_cast<int>(d->data[d->index++]);
  }
  HtsError(0, "HTS_fgetc: Unknown file type.\n");
  return EOF;
}

int HTS_File::Eof() {
  if (type_ == HTS_FILE) {
    return feof(reinterpret_cast<FILE*>(pointer_));
  } else if (type_ == HTS_DATA) {
    HTS_Data* d = reinterpret_cast<HTS_Data*>(pointer_);
    return d->size <= d->index ? 1 : 0;
  }
  HtsError(0, "HTS_feof: Unknown file type.\n");
  return 1;
}

int HTS_File::Seek(int64 offset, int origin) {
  if (type_ == HTS_FILE) {
    return fseek(reinterpret_cast<FILE*>(pointer_), offset, origin);
  } else if (type_ == HTS_DATA) {
    HTS_Data* d = reinterpret_cast<HTS_Data*>(pointer_);
    if (origin == SEEK_SET) {
      d->index = (size_t)offset;
    } else if (origin == SEEK_CUR) {
      d->index += offset;
    } else if (origin == SEEK_END) {
      d->index = d->size + offset;
    } else {
      return 1;
    }
    return 0;
  }
  HtsError(0, "HTS_fseek: Unknown file type.\n");
  return 1;
}

size_t HTS_File::TellOffset() {
  if (type_ == HTS_FILE) {
    fpos_t pos;
    fgetpos(reinterpret_cast<FILE*>(pointer_), &pos);
#if defined(_WIN32) || defined(__CYGWIN__) || defined(__APPLE__) || \
    defined(__ANDROID__)  // NOLINT
    return (size_t)pos;
#elif defined(_QNX_SOURCE)
    return (size_t)pos._Off;
#else
    return (size_t)pos.__pos;
#endif  // _WIN32 || __CYGWIN__ || __APPLE__ || __ANDROID__
  } else if (type_ == HTS_DATA) {
    HTS_Data* d = reinterpret_cast<HTS_Data*>(pointer_);
    return d->index;
  }
  HtsError(0, "HTS_ftell: Unknown file type.\n");
  return 0;
}

/* HTS_fread: wrapper for fread */
size_t HTS_File::Read(void* buf, size_t size, size_t n) {
  if (size == 0 || n == 0) {
    return 0;
  }
  if (type_ == HTS_FILE) {
    return fread(buf, size, n, reinterpret_cast<FILE*>(pointer_));
  } else if (type_ == HTS_DATA) {
    HTS_Data* d = reinterpret_cast<HTS_Data*>(pointer_);
    size_t i, length = size * n;
    unsigned char* c = (unsigned char*)buf;
    for (i = 0; i < length; i++) {
      if (d->index < d->size)
        c[i] = d->data[d->index++];
      else
        break;
    }
    if (i == 0)
      return 0;
    else
      return i / size;
  }
  HtsError(0, "HTS_fread: Unknown file type.\n");
  return 0;
}

static void HTS_byte_swap(void* p, size_t size, size_t block) {
  char *q, tmp;
  size_t i, j;

  q = reinterpret_cast<char*>(p);

  for (i = 0; i < block; i++) {
    for (j = 0; j < (size / 2); j++) {
      tmp = *(q + j);
      *(q + j) = *(q + (size - 1 - j));
      *(q + (size - 1 - j)) = tmp;
    }
    q += size;
  }
}

size_t HTS_File::ReadBigEndian(void* buf, size_t size, size_t n) {
  size_t block = Read(buf, size, n);

#ifdef WORDS_LITTLEENDIAN
  HTS_byte_swap(buf, size, block);
#endif /* WORDS_LITTLEENDIAN */

  return block;
}

size_t HTS_File::ReadLittleEndian(void* buf, size_t size, size_t n) {
  size_t block = Read(buf, size, n);

#ifdef WORDS_BIGENDIAN
  HTS_byte_swap(buf, size, block);
#endif /* WORDS_BIGENDIAN */

  return block;
}

size_t HTS_File::WriteLittleEndian(const void* buf, size_t size, size_t n,
                                   FILE* fp) {
#ifdef WORDS_BIGENDIAN
  HTS_byte_swap(buf, size, n * size);
#endif /* WORDS_BIGENDIAN */
  return fwrite(buf, size, n, fp);
}

bool HTS_File::GetPatternToken(char* buff) {
  char c;
  size_t i;
  bool squote = false, dquote = false;

  if (Eof()) return false;
  c = GetChar();

  while (c == ' ' || c == '\n') {
    if (Eof()) return false;
    c = GetChar();
  }

  if (c == '\'') { /* single quote case */
    if (Eof()) return false;
    c = GetChar();
    squote = true;
  }

  if (c == '\"') { /*double quote case */
    if (Eof()) return false;
    c = GetChar();
    dquote = true;
  }

  if (c == ',') { /*special character ',' */
    snprintf(buff, sizeof(buff), ",");
    return true;
  }

  i = 0;
  while (1) {
    buff[i++] = c;
    c = GetChar();
    if (squote && c == '\'') break;
    if (dquote && c == '\"') break;
    if (!squote && !dquote) {
      if (c == ' ') break;
      if (c == '\n') break;
      if (Eof()) break;
    }
  }

  buff[i] = '\0';
  return true;
}

bool HTS_File::GetTokenFromFile(char* buff) {
  char c;
  size_t i;

  if (Eof()) return false;
  c = GetChar();
  while (c == ' ' || c == '\n' || c == '\t') {
    if (Eof()) return false;
    c = GetChar();
    if (c == EOF) return false;
  }

  for (i = 0; c != ' ' && c != '\n' && c != '\t';) {
    buff[i++] = c;
    if (Eof()) break;
    c = GetChar();
    if (c == EOF) break;
  }

  buff[i] = '\0';
  return true;
}

bool HTS_File::GetTokenFromFile(char* buff, char separator) {
  char c;
  size_t i;

  if (Eof()) return false;
  c = GetChar();
  while (c == separator) {
    if (Eof()) return false;
    c = GetChar();
    if (c == EOF) return false;
  }

  for (i = 0; c != separator;) {
    buff[i++] = c;
    if (Eof()) break;
    c = GetChar();
    if (c == EOF) break;
  }

  buff[i] = '\0';
  return true;
}
}  // namespace hts
