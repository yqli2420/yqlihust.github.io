// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: ranzhang@mobvoi.com (dylan)

#ifndef TTS_SYNTHESIZER_ENGINE_HMM_HTS_OPTION_H_
#define TTS_SYNTHESIZER_ENGINE_HMM_HTS_OPTION_H_

#include <string>
#include <vector>

#include "mobvoi/base/compat.h"
#include "mobvoi/base/flags.h"
#include "tts/synthesizer/engine/hmm/hts_model.h"
#include "tts/synthesizer/engine/hmm/proto/hts_model.pb.h"
#include "tts/synthesizer/proto/tts.pb.h"

namespace hts {
struct HtsOption {
  HtsOption();
  ~HtsOption();
  void Init(const ModelSet *model_set);
  void SetOption(const tts::TTSOption &tts_option);

  void PrintInfo() const;
  int sampling_frequency;
  size_t frame_period;
  size_t audio_buff_size;
  bool stop;
  double volume;
  vector<double> msd_threshold;
  vector<double> gv_weight;

  bool phoneme_alignment_flag;
  double speed = 1.0;
  size_t stage;
  bool use_log_gain;
  double alpha;
  double beta;
  double additional_half_tone;

  vector<double> duration_iw;
  vector<vector<double>> parameter_iw;
  vector<vector<double>> gv_iw;
  void set_volume(double f);
  double get_volume() const;
};
}  // namespace hts
#endif  // TTS_SYNTHESIZER_ENGINE_HMM_HTS_OPTION_H_
