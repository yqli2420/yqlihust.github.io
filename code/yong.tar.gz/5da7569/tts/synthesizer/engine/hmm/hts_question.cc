// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/synthesizer/engine/hmm/hts_question.h"

#include <string.h>

#include "tts/synthesizer/engine/hmm/types.h"
#include "tts/synthesizer/engine/hmm/hts_file.h"
#include "tts/synthesizer/engine/hmm/hts_util.h"

namespace hts {

// Initialize question
void HTS_Question_initialize(HTS_Question* question) {}

// Load questions from file
bool HTS_Question_load(HTS_Question* question, HTS_File* fp) {
  char buff[kMaxBuffLen];
  if (question == NULL || fp == NULL)
    return false;

  // Get question name
  if (fp->GetPatternToken(buff) == false)
    return false;
  question->name = string(buff);

  // Get pattern list
  if (fp->GetPatternToken(buff) == false) {
    return false;
  }

  if (strcmp(buff, "{") == 0) {
    while (1) {
      if (fp->GetPatternToken(buff) == false) {
        return false;
      }
      question->patterns.emplace_back(string(buff));
      if (fp->GetPatternToken(buff) == false) {
        return false;
      }
      if (!strcmp(buff, "}"))
        break;
    }
  }
  // Use this trick to make sure size equal to capacity.
  question->patterns.shrink_to_fit();
  return true;
}

// Check given string match given question
bool HTS_Question_match(const HTS_Question& question,
                        const char* str, size_t len) {
  for (size_t i = 0; i < question.patterns.size(); ++i) {
    // pattern looks like : "*-m+*", "*|iong/C:*"
    if (MatchPattern(str, len, question.patterns[i].c_str(),
        question.patterns[i].size())) {
      return true;
    }
  }

  return false;
}
}  // namespace hts
