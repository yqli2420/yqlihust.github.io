// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: ranzhang@mobvoi.com (dylan)

#ifndef TTS_SYNTHESIZER_ENGINE_HMM_HMM_ENGINE_H_
#define TTS_SYNTHESIZER_ENGINE_HMM_HMM_ENGINE_H_

#include <memory>
#include <string>
#include <vector>

#include "mobvoi/base/basictypes.h"

#include "tts/synthesizer/engine/engine.h"
#include "tts/synthesizer/engine/hmm/hts_engine.h"
#include "tts/synthesizer/engine/hmm/hts_util.h"
#include "tts/synthesizer/proto/tts.pb.h"

namespace engine {

class HMMEngine : public Engine {
 public:
  HMMEngine(tts::LanguageType language_type, const string& model_name,
            float speed, bool is_fixed_point);
  virtual ~HMMEngine();

  bool SynthesizeFromLabel(const tts::TTSOption& tts_option,
                           const vector<string>& labels,
                           tts::RawData* raw_data) const override;
  string GetEngineModelType() const override;

 private:
  tts::LanguageType language_type_;
  std::unique_ptr<hts::ModelSet> hts_model_;
  DISALLOW_COPY_AND_ASSIGN(HMMEngine);
};

}  // namespace engine
#endif  // TTS_SYNTHESIZER_ENGINE_HMM_HMM_ENGINE_H_
