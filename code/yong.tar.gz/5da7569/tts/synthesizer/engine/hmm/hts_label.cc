// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/synthesizer/engine/hmm/hts_label.h"

#include <ctype.h>   //  for isgraph(),isdigit()
#include <stdlib.h>  //  for atof()

#include "mobvoi/base/log.h"
#include "tts/synthesizer/engine/hmm/hts_file.h"
#include "tts/synthesizer/engine/hmm/hts_util.h"
#include "tts/synthesizer/engine/hmm/types.h"

namespace hts {
static bool isdigit_string(const char *str) {
  int i;

  if (sscanf(str, "%d", &i) == 1)
    return true;
  else
    return false;
}

Label::Label() {}

Label::~Label() {}

void Label::CheckTime() {
  if (!labels_.empty()) {
    labels_[0].start = 0.0;
  } else {
    LOG(WARNING) << "label is empty";
    return;
  }

  for (size_t i = 0; i < labels_.size() - 1; ++i) {
    if (labels_[i].end < 0.0 && labels_[i + 1].start >= 0.0) {
      labels_[i].end = labels_[i + 1].start;
    } else if (labels_[i].end >= 0.0 && labels_[i + 1].start < 0.0) {
      labels_[i + 1].start = labels_[i].end;
    }
    if (labels_[i].start < 0.0) labels_[i].start = -1.0;
    if (labels_[i].end < 0.0) labels_[i].end = -1.0;
  }
}

void Label::Load(size_t sampling_rate, size_t fperiod, HTS_File *fp) {
  char buff[kMaxBuffLen];
  double start, end;
  const double rate = static_cast<double>(sampling_rate) /
                      (static_cast<double>(fperiod) * 1e+7);
  /* parse label file */
  while (fp->GetTokenFromFile(buff)) {
    if (!isgraph(static_cast<int>(buff[0]))) break;

    LabelString label;
    // Has frame infomation
    if (isdigit_string(buff)) {
      start = atof(buff);
      fp->GetTokenFromFile(buff);
      end = atof(buff);
      fp->GetTokenFromFile(buff);
      label.start = rate * start;
      label.end = rate * end;
    } else {
      label.start = -1.0;
      label.end = -1.0;
    }
    label.name = string(buff);
    labels_.emplace_back(label);
  }
  labels_.shrink_to_fit();
  CheckTime();
}

void Label::LoadFromFile(size_t sampling_rate, size_t fperiod, const char *fn) {
  labels_.clear();
  HTS_File *fp = HTS_File::Open(fn, "r");
  Load(sampling_rate, fperiod, fp);
  fp->Close();
}

void Label::LoadFromStringVector(size_t sampling_rate, size_t fperiod,
                                 const vector<string> &lines) {
  labels_.clear();
  char buff[kMaxBuffLen];
  size_t i;
  size_t data_index;
  double start, end;
  const double rate = static_cast<double>(sampling_rate) /
                      (static_cast<double>(fperiod) * 1e+7);
  VLOG(2) << "rate:" << rate;

  /* copy label */
  for (i = 0; i < lines.size(); i++) {
    if (!isgraph(static_cast<int>(lines[i][0]))) break;

    LabelString label;
    data_index = 0;
    if (isdigit_string(lines[i].c_str())) {
      // Has frame infomation
      GetTokenFromString(lines[i].c_str(), &data_index, buff);
      start = atof(buff);
      GetTokenFromString(lines[i].c_str(), &data_index, buff);
      end = atof(buff);
      GetTokenFromString(lines[i].c_str(), &data_index, buff);
      label.name = string(buff);
      label.start = rate * start;
      label.end = rate * end;
    } else {
      label.start = -1.0;
      label.end = -1.0;
      label.name = lines[i];
    }
    labels_.push_back(label);
  }
  CheckTime();
}

size_t Label::Size() const { return labels_.size(); }

const char *Label::GetString(size_t index) const {
  if (index > labels_.size()) {
    return NULL;
  }
  return labels_[index].name.c_str();
}

size_t Label::GetStrLen(size_t index) const {
  if (index > labels_.size()) {
    return 0;
  }
  return labels_[index].name.size();
}

double Label::GetStartFrame(size_t index) const {
  if (index > labels_.size()) {
    return -1.0;
  }
  return labels_[index].start;
}

double Label::GetEndFrame(size_t index) const {
  if (index > labels_.size()) {
    return -1.0;
  }
  return labels_[index].end;
}
}  // namespace hts
