// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/synthesizer/engine/hmm/hts_voice_convert_util.h"
#include "tts/synthesizer/engine/hmm/proto/hts_model.pb.h"
#include "mobvoi/base/at_exit.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/string_util.h"

DEFINE_string(hts_model, "cmu_us_arctic_slt.htsvoice",
              "seperated by commas(,)");
DEFINE_string(protobuf_model, "hts.model", "");
DEFINE_bool(use_fixed_point, false,
            "To judge if use fixed point model or not.");

int main(int argc, char **argv) {
  base::AtExitManager at_exit;
  google::ParseCommandLineFlags(&argc, &argv, false);

  vector<string> files;
  SplitString(FLAGS_hts_model, ',', &files);
  CHECK(!files.empty()) << "No old hts model files";
  hts::HtsModel proto_model;
  proto_model.set_stage(1);
  proto_model.set_use_log_gain(true);
  proto_model.set_alpha(0.0);
  HtsVoiceConvert(files, FLAGS_use_fixed_point, &proto_model);
  mobvoi::File::WriteStringToFileOrDie(proto_model.SerializeAsString(),
                                       FLAGS_protobuf_model);
  return 0;
}
