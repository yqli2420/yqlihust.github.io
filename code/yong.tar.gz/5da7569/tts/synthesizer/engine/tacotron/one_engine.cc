// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: sxwang@mobvoi.com (Sixue Wang)

#include "tts/synthesizer/engine/tacotron/one_engine.h"

#include "mobvoi/base/log.h"
#include "mobvoi/base/string_util.h"

namespace {
const char kDelimiter = ',';
}

namespace engine {
namespace tacotron {

ONEEngine::ONEEngine(const tts::LanguageType& language_type,
                     const std::string& model_file, float speed,
                     int n_parallel)
    : model_file_(model_file),
      language_(language_type),
      default_speed_(speed),
      model_(new mobvoi::one::TacoModel(model_file, n_parallel)) {
  LOG(INFO) << "Load Tacotron-ONEEngine from " << model_file_;
  ReadSymbol();
}

ONEEngine::~ONEEngine() {}

string ONEEngine::GetEngineModelType() const {
  return model_->ModelType();
}

bool ONEEngine::SynthesizeFromLabel(const tts::TTSOption& tts_option,
                                    const std::vector<std::string>& labels,
                                    tts::RawData* raw_data) const {
  auto seq = symbol_table_->ParseLabel(labels, tts_option.speaker());
  std::vector<float> frame;
  model_->Inference(seq, &frame);
  InterpolateCMP(frame, model_->FrameDim(),
                 tts_option.speaker() == "lucy_wnet" ? model_->FrameDim() - 1
                                                     : model_->FrameDim(),
                 default_speed_ * tts_option.speed(), &(raw_data->feature));
  return true;
}

void ONEEngine::ReadSymbol() {
  std::vector<std::string> symbols;
  SplitString(model_->Symbol(), kDelimiter, &symbols);
  symbol_table_.reset(new SymbolTable(symbols));
}

void ONEEngine::InterpolateCMP(const std::vector<float> src, int src_dim,
                               int dst_dim, float speed,
                               std::vector<float>* dst) const {
  int dst_frame = src.size() / src_dim / speed;
  dst->resize(dst_frame * dst_dim);
  for (int i = 0; i < dst_frame; ++i) {
    int index = static_cast<int>(floor(i * speed));
    std::memcpy(dst->data() + i * dst_dim, src.data() + index * src_dim,
                dst_dim * sizeof(float));
  }
}

}  // namespace tacotron
}  // namespace engine
