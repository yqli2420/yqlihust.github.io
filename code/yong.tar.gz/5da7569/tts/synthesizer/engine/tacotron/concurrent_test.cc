// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: sxwang@mobvoi.com (Sixue Wang)

#include <thread> // NOLINT

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/flags.h"
#include "tts/synthesizer/engine/tacotron/one_engine.h"

const int kSeq[] = {3,   10, 30, 103, 112, 8,  35, 104, 112, 14, 60, 103,
                    111, 17, 49, 101, 112, 20, 48, 101, 111, 6,  49, 104,
                    112, 11, 45, 104, 112, 24, 37, 103, 111, 14, 29, 102,
                    112, 12, 36, 101, 111, 15, 52, 104, 114, 1};

DEFINE_string(one, "/path/to/tensorrt.engine", "TensorRT serialized engine");
DEFINE_int32(queries, 100, "The number of queries.");
DEFINE_int32(reduction_factor, 5, "reduction factor");
DEFINE_double(default_speed, 0.87, "default speed");

using engine::tacotron::ONEEngine;

void Cpu() {
  tts::LanguageType language_type = tts::LanguageType::kMandarin;
  ONEEngine engine(language_type, FLAGS_one, FLAGS_default_speed);
  auto start = std::chrono::steady_clock::now();
  std::vector<std::thread> workers;
  for (int i = 0; i < FLAGS_queries; ++i) {
    workers.emplace_back([&engine]() {
      std::vector<float> frame;
      engine.model()->Inference(
          std::vector<int>(kSeq, kSeq + arraysize(kSeq)), &frame);
    });
  }
  for (auto&& worker : workers) {
    worker.join();
  }
  auto elapsed =
      std::chrono::duration<double>(std::chrono::steady_clock::now() - start)
          .count();
  LOG(INFO) << FLAGS_queries << " queries used " << elapsed << "s, qps "
            << FLAGS_queries / elapsed << ".";
}

int main(int argc, char* argv[]) {
  ::google::ParseCommandLineFlags(&argc, &argv, true);
  Cpu();
  return 0;
}
