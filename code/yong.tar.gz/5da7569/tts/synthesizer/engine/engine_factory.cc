// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: sxwang@mobvoi.com (Sixue Wang)

#include "tts/synthesizer/engine/engine_factory.h"

#include "mobvoi/base/flags.h"
#include "mobvoi/base/file/proto_util.h"
#include "mobvoi/base/platforms.h"
#include "tts/synthesizer/engine/hmm/hmm_engine.h"

#ifndef FOR_PORTABLE
#include "tts/synthesizer/engine/tacotron/one_engine.h"
#endif

#if PLATFORM(GNU_LINUX_X86) || PLATFORM(NEON)
#include "tts/synthesizer/engine/spss/spss_engine.h"
#endif  // PLATFORM(GNU_LINUX_X86) || PLATFORM(NEON)

namespace engine {

DEFINE_int32(taco_thread_num, 8, "the number of taco's thread");

EngineFactory& EngineFactory::Instance() {
  static EngineFactory instance;
  return instance;
}

Engine* EngineFactory::Create(const tts::SpeakerInfo& speaker_info) {
  tts::LanguageType language_type =
      tts::GetLanguageType(speaker_info.language());
  Engine* engine = nullptr;
  if (speaker_info.engine_type() == kEngineTypeHts) {
    // kodai must use static_cast
    engine = static_cast<Engine*>(
        new HMMEngine(language_type, speaker_info.engine_path(),
                      speaker_info.speed(), speaker_info.is_fixed_point()));
  } else if (speaker_info.engine_type() == kEngineTypeTacotronOne) {
#ifndef FOR_PORTABLE
    engine = static_cast<Engine*>(new tacotron::ONEEngine(
        language_type, speaker_info.engine_path(), speaker_info.speed(),
        FLAGS_taco_thread_num));
#endif
  } else if (speaker_info.engine_type() == kEngineTypeSpss) {
#if PLATFORM(GNU_LINUX_X86) || PLATFORM(NEON)
    engine = static_cast<Engine*>(new spss::SPSSEngine(
        language_type, speaker_info.engine_path(), speaker_info.speed()));
#endif  // PLATFORM(GNU_LINUX_X86) || PLATFORM(NEON)
  } else {
    LOG(FATAL) << "Unsupported model type: " << speaker_info.engine_type();
  }
  return engine;
}

}  // namespace engine
