// Copyright 2017 Mobvoi Inc. All Rights Reserved.
// Author: jbxiao@mobvoi.com (Jinba Xiao)

#include "tts/synthesizer/engine/spss/label_parser.h"

#include <map>

#include "mobvoi/base/log.h"
#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/string_util.h"

namespace engine {
namespace spss {
static const char* kToneList[] = {"1", "2", "3", "4", "5", "6", "7", "8", "9"};

LabelParser::LabelParser(const string& phones) {
  vector<string> phone_list;
  SplitString(phones, '\n', &phone_list);
  for (size_t i = 0; i < phone_list.size(); ++i) {
    phone_map_[phone_list[i]] = i;
  }
  for (size_t i = 0; i < arraysize(kToneList); ++i) {
    tone_map_[kToneList[i]] = i;
  }

  elements_.push_back(
      LabelElement("p3", "-", "+", ElementType::ONEHOT, &phone_map_));
  elements_.push_back(LabelElement("p6", "@", "_", ElementType::NUMERIC));
  elements_.push_back(LabelElement("p7", "_", "/A:", ElementType::NUMERIC));
  // A  7-10
  elements_.push_back(LabelElement("a3", "_", "+", ElementType::NUMERIC));
  // B  11-21
  elements_.push_back(
      LabelElement("b1", "/B:", "-", ElementType::ONEHOT, &tone_map_));
  elements_.push_back(LabelElement("b3", "=", "-", ElementType::NUMERIC));
  elements_.push_back(LabelElement("b5", "@", "-", ElementType::NUMERIC));
  elements_.push_back(LabelElement("b6", "-", "&", ElementType::NUMERIC));
  elements_.push_back(LabelElement("b7", "&", "-", ElementType::NUMERIC));
  elements_.push_back(LabelElement("b8", "-", "#", ElementType::NUMERIC));
  elements_.push_back(LabelElement("b9", "#", "-", ElementType::NUMERIC));
  elements_.push_back(LabelElement("b10", "-", "|", ElementType::NUMERIC));
  // C  22-25
  elements_.push_back(LabelElement("c3", "+", "_", ElementType::NUMERIC));
  // D  26-27
  elements_.push_back(LabelElement("d2", "/D:", "-", ElementType::NUMERIC));
  elements_.push_back(LabelElement("d3", "-", "/E:", ElementType::NUMERIC));
  // E  28-35
  elements_.push_back(LabelElement("e2", "/E:", "_", ElementType::NUMERIC));
  elements_.push_back(LabelElement("e3", "_", "@", ElementType::NUMERIC));
  elements_.push_back(LabelElement("e4", "@", "+", ElementType::NUMERIC));
  elements_.push_back(LabelElement("e5", "+", "&", ElementType::NUMERIC));
  // F  36-37
  elements_.push_back(LabelElement("f2", "/F:", "=", ElementType::NUMERIC));
  elements_.push_back(LabelElement("f3", "=", "/G:", ElementType::NUMERIC));
  // G  38-39
  elements_.push_back(LabelElement("g1", "/G:", "_", ElementType::NUMERIC));
  elements_.push_back(LabelElement("g2", "_", "/H:", ElementType::NUMERIC));
  // H  40-44
  elements_.push_back(LabelElement("h1", "/H:", "=", ElementType::NUMERIC));
  elements_.push_back(LabelElement("h2", "=", "^", ElementType::NUMERIC));
  elements_.push_back(LabelElement("h3", "^", "=", ElementType::NUMERIC));
  elements_.push_back(LabelElement("h4", "=", "|", ElementType::NUMERIC));
  // I  45-46
  elements_.push_back(LabelElement("i1", "/I:", "=", ElementType::NUMERIC));
  elements_.push_back(LabelElement("i2", "=", "/J:", ElementType::NUMERIC));
}

void LabelParser::GetBinaryVector(int value,
                                  vector<vector<float>>* input) const {
  vector<float> bin_vec;
  while (value != 0) {
    bin_vec.push_back(value % 2);
    value = value >> 1;
  }
  std::reverse(bin_vec.begin(), bin_vec.end());
  input->push_back(bin_vec);
}

void LabelParser::GetOneHotVector(const string& str,
                                  const map<string, int>* ref_list,
                                  vector<vector<float>>* input) const {
  vector<float> one_hot(ref_list->size(), 0.0);
  auto iter = ref_list->find(str);
  if (iter != ref_list->end()) {
    one_hot[iter->second] = 1.0;
  }
  input->push_back(one_hot);
}

bool LabelParser::Parse(const string& label, string* phone,
                        vector<float>* input) const {
  vector<vector<float>> one_hot_vec;
  vector<float> numeric_vec;
  string cur_pho;
  string cur_ele;
  size_t s_idx = 0;
  size_t e_idx = 0;

  for (size_t i = 0; i < elements_.size(); ++i) {
    if (!elements_[i].pre_delim_.empty() &&
        (s_idx = label.find(elements_[i].pre_delim_, s_idx)) == string::npos) {
      return false;
    }

    if (elements_[i].pos_delim_.empty()) {
      cur_ele = label.substr(s_idx + 1);
    } else if ((e_idx = label.find(elements_[i].pos_delim_, e_idx)) !=
               string::npos) {
      s_idx = s_idx + elements_[i].pre_delim_.length();
      cur_ele = label.substr(s_idx, e_idx - s_idx);
      e_idx = e_idx + elements_[i].pos_delim_.length();
      if (s_idx == 0) cur_pho = cur_ele;
    } else {
      return false;
    }

    // hard code first element is currence phone
    if (i == 0) {
      *phone = cur_ele;
    }

    switch (elements_[i].type_) {
      case ElementType::ONEHOT: {
        GetOneHotVector(cur_ele, elements_[i].ref_list_, &one_hot_vec);
        break;
      }
      case ElementType::NUMERIC: {
        numeric_vec.push_back(StringToFloat(cur_ele));
        break;
      }
    }
  }

  for (size_t i = 0; i < one_hot_vec.size(); ++i) {
    std::copy(one_hot_vec[i].begin(), one_hot_vec[i].end(),
              std::back_inserter(*input));
  }
  std::copy(numeric_vec.begin(), numeric_vec.end(), std::back_inserter(*input));
  return true;
}

}  // namespace spss
}  // namespace engine
