// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/synthesizer/speaker_manager.h"

#include "mobvoi/base/file.h"
#include "mobvoi/base/log.h"
#include "third_party/jsoncpp/json.h"

#include "tts/util/tts_util/wave_util.h"

namespace tts {

static const char kSpeakerJsonSepMark = '+';

SpeakerManager::SpeakerManager(const string& speaker_json_files) {
  vector<string> speaker_jsons;
  SplitString(speaker_json_files, kSpeakerJsonSepMark, &speaker_jsons);
  label_generator_manager_.reset(new LabelGeneratorManager());

  for (const auto& speaker_json : speaker_jsons) {
    string content;
    mobvoi::File::ReadFileToStringOrDie(speaker_json, &content);
    Json::Value root;
    Json::Reader reader;
    reader.parse(content, root);

    string dir = mobvoi::File::FindFileDir(speaker_json);
    Json::Value speaker_infos = root["Models"];
    for (auto sinfo : speaker_infos) {
      string speaker = sinfo.get("speaker", "").asString();
      string engine_type = sinfo.get("engine_type", "hts").asString();
      SpeakerInfo sinfo_tmp;
      sinfo_tmp.set_speaker(speaker);
      sinfo_tmp.set_language(sinfo.get("language", "").asString());
      sinfo_tmp.set_frontend(
          AppendPath(dir, sinfo.get("frontend", "").asString()));
      sinfo_tmp.set_speed(sinfo.get("speed", 1.0).asDouble());
      sinfo_tmp.set_volume(sinfo.get("volume", 1.0).asDouble());
      sinfo_tmp.set_support_en(sinfo.get("support_en", false).asBool());
      sinfo_tmp.set_cache(AppendPath(dir, sinfo.get("cache", "").asString()));
      sinfo_tmp.set_is_fixed_point(sinfo.get("is_fixed_point", false).asBool());
      sinfo_tmp.set_support_erhua(sinfo.get("support_erhua", true).asBool());
      sinfo_tmp.set_engine_type(engine_type);
      sinfo_tmp.set_engine_path(
          AppendPath(dir, sinfo.get("engine_path", "").asString()));
      sinfo_tmp.set_vocoder_type(sinfo.get("vocoder_type", "lpc").asString());
      sinfo_tmp.set_vocoder_path(
          AppendPath(dir, sinfo.get("vocoder_path", "").asString()));
      sinfo_tmp.set_is_loaded(false);
      VLOG(2) << "\n" + sinfo_tmp.DebugString();
      speaker_infos_.insert(std::make_pair(speaker, sinfo_tmp));

      bool is_load = sinfo.get("is_load", false).asBool();
      if (is_load) LoadSpeaker(speaker);
    }
  }
}

SpeakerManager::~SpeakerManager() {}

std::shared_ptr<LabelGenerator> SpeakerManager::GetLabelGenerator(
    const string& language) const {
  auto it_l = speaker_label_generators_.find(language);
  if (it_l == speaker_label_generators_.end() || it_l->second == nullptr) {
    LOG(ERROR) << "label generator is not found";
    return nullptr;
  }
  return it_l->second;
}

std::shared_ptr<engine::Engine> SpeakerManager::GetEngine(
    const string& speaker) const {
  auto it_e = speaker_engines_.find(speaker);
  if (it_e == speaker_engines_.end() || it_e->second == nullptr) {
    LOG(ERROR) << speaker << " engine is not found";
    return nullptr;
  }
  return it_e->second;
}

std::shared_ptr<vocoder::Vocoder> SpeakerManager::GetVocoder(
    const string& speaker) const {
  auto it_v = speaker_vocoders_.find(speaker);
  if (it_v == speaker_vocoders_.end() || it_v->second == nullptr) {
    LOG(ERROR) << speaker << " vocoder is not found";
    return nullptr;
  }
  return it_v->second;
}

void SpeakerManager::SetSpeakerCache(const string& speaker, const string& text,
                                     const vector<int16>& cache_data) {
  mobvoi::WriteLock lock(&mutex_);
  auto it_s = speaker_cache_datas_.find(speaker);
  if (it_s == speaker_cache_datas_.end()) return;

  it_s->second[text] = cache_data;
}

bool SpeakerManager::GetCacheData(const string& speaker,
                                  map<string, vector<int16>>* cache_data) {
  mobvoi::ReadLock lock(&mutex_);
  auto it_c = speaker_cache_datas_.find(speaker);
  if (it_c == speaker_cache_datas_.end()) {
    LOG(ERROR) << speaker << " cache is not found";
    return false;
  }
  *cache_data = it_c->second;
  return true;
}

bool SpeakerManager::CheckSpeaker(const string& speaker) const {
  auto it = speaker_infos_.find(speaker);
  if (it == speaker_infos_.end()) {
    LOG(ERROR) << "Speaker " << speaker << " is not found";
    return false;
  } else if (!it->second.is_loaded()) {
    LOG(ERROR) << "Speaker " << speaker << " exists but not loaded";
    return false;
  }
  return true;
}

bool SpeakerManager::LoadSpeaker(const string& speaker) {
  auto it = speaker_infos_.find(speaker);
  if (it == speaker_infos_.end()) {
    LOG(ERROR) << speaker << " is not exist, loading failed!!";
    return false;
  }
  if (it->second.is_loaded()) {
    LOG(INFO) << speaker << " has already loaded,no need to reload";
    return true;
  }
  auto it_c = speaker_cache_datas_.find(speaker);
  if (it_c == speaker_cache_datas_.end()) {
    map<string, vector<int16>> datas;
    LoadCacheData(it->second.cache(), &datas);
    speaker_cache_datas_[speaker] = datas;
  }

  string language = it->second.language();
  auto it_l = speaker_label_generators_.find(language);
  if (it_l == speaker_label_generators_.end()) {
    speaker_label_generators_[language] =
        label_generator_manager_->CreateLabelGenerator(language,
                                                       it->second.frontend());
  }
  auto it_e = speaker_engines_.find(speaker);

  string engine_vocoder_type = it->second.vocoder_type();
  if (it_e == speaker_engines_.end()) {
    auto engine = engine::EngineFactory::Instance().Create(it->second);
    speaker_engines_[speaker].reset(engine);
    if (engine->GetEngineModelType().find("straight") != string::npos) {
      engine_vocoder_type = "straight";
    }
  }

  auto it_v = speaker_vocoders_.find(speaker);
  if (it_v == speaker_vocoders_.end()) {
    speaker_vocoders_[speaker] = vocoder::VocoderFactory::Instance().Create(
        engine_vocoder_type, it->second.vocoder_path());
  }
  it->second.set_is_loaded(true);
  LOG(INFO) << speaker << " load success!! just enjoy!!";
  return true;
}

bool SpeakerManager::UnloadSpeaker(const string& speaker) {
  auto it = speaker_infos_.find(speaker);
  if (it == speaker_infos_.end()) {
    LOG(INFO) << speaker << " do not exists";
    return true;
  }
  if (!it->second.is_loaded()) {
    LOG(INFO) << speaker << " has not been loaded";
    return true;
  }
  string language = GetLanguage(speaker);
  auto it_c = speaker_cache_datas_.find(speaker);
  if (it_c != speaker_cache_datas_.end()) speaker_cache_datas_.erase(it_c);
  auto it_l = speaker_label_generators_.find(language);
  if (it_l != speaker_label_generators_.end() &&
      (IsUnloadLabel(language) <= 1)) {
    speaker_label_generators_.erase(it_l);
  }
  auto it_e = speaker_engines_.find(speaker);
  if (it_e != speaker_engines_.end()) speaker_engines_.erase(it_e);
  auto it_v = speaker_vocoders_.find(speaker);
  if (it_v != speaker_vocoders_.end()) speaker_vocoders_.erase(it_v);
  LOG(INFO) << speaker << " unload success!! just enjoy!!";
  it->second.set_is_loaded(false);
  return true;
}

vector<string> SpeakerManager::GetSupLanguages() const {
  set<string> languages;
  for (auto& speaker_info : speaker_infos_)
    languages.insert(speaker_info.second.language());
  return vector<string>(languages.begin(), languages.end());
}

bool SpeakerManager::IsSupportEn(const string& speaker) const {
  auto it = speaker_infos_.find(speaker);
  if (it != speaker_infos_.end()) {
    return it->second.support_en();
  }
  return false;
}

float SpeakerManager::GetVolume(const string& speaker) const {
  auto it = speaker_infos_.find(speaker);
  if (it != speaker_infos_.end()) {
    return it->second.volume();
  }
  return 0.0;
}

float SpeakerManager::GetSpeed(const string& speaker) const {
  auto it = speaker_infos_.find(speaker);
  if (it != speaker_infos_.end()) {
    return it->second.speed();
  }
  return 1.0;
}

bool SpeakerManager::IsSupportErhua(const string& speaker) const {
  auto it = speaker_infos_.find(speaker);
  if (it != speaker_infos_.end()) {
    return it->second.support_erhua();
  }
  return false;
}

string SpeakerManager::GetLanguage(const string& speaker) const {
  auto it = speaker_infos_.find(speaker);
  if (it != speaker_infos_.end()) {
    return it->second.language();
  }
  return kMandarinTypeString;
}

vector<std::pair<string, bool>> SpeakerManager::GetSpeakers(
    const string& language) const {
  vector<std::pair<string, bool>> speakers;
  for (auto& speaker_info : speaker_infos_) {
    if (speaker_info.second.language() == language) {
      speakers.push_back(std::make_pair(speaker_info.second.speaker(),
                                        speaker_info.second.is_loaded()));
    }
  }
  return speakers;
}

int SpeakerManager::IsUnloadLabel(const string& language) const {
  int num = 0;
  for (auto& speaker_info : speaker_infos_) {
    if (speaker_info.second.language() == language &&
        speaker_info.second.is_loaded()) {
      ++num;
    }
  }
  return num;
}

void SpeakerManager::LoadCacheData(
    const string& cache_config_file,
    map<string, vector<int16>>* cache_datas) const {
  if (cache_config_file.empty()) return;
  string content;
  mobvoi::File::ReadFileToStringOrDie(cache_config_file, &content);

  Json::Reader json_reader;
  Json::Value cache_config;
  json_reader.parse(content, cache_config);
  Json::Value texts = cache_config["text"];
  Json::Value datas = cache_config["data"];
  if (!datas.empty() && texts.size() != datas.size()) {
    LOG(ERROR) << "cache data and text mismatch: " << cache_config_file;
    return;
  }

  string dir = mobvoi::File::FindFileDir(cache_config_file);
  for (size_t i = 0; i < texts.size(); ++i) {
    vector<int16> cache_data;
    if (!datas.empty()) {
      string file_path = AppendPath(dir, datas[i].asString());
      WaveFile::ReadRawFile(file_path, &cache_data);
    }
    cache_datas->insert(std::make_pair(texts[i].asString(), cache_data));
  }
}

}  // namespace tts
