// Copyright 2017 Mobvoi Inc. All Rights Reserved.
// Author: ranzhang@mobvoi.com (Yunlin Chen)

#ifndef TTS_SYNTHESIZER_INTERFACE_SYNTHESIZER_INTERFACE_H_
#define TTS_SYNTHESIZER_INTERFACE_SYNTHESIZER_INTERFACE_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "third_party/jsoncpp/json.h"
#include "tts/synthesizer/interface/synthesizer_event_interface.h"
#include "tts/synthesizer/proto/tts.pb.h"
#include "tts/synthesizer/engine/engine.h"

namespace tts {
using engine::Engine;

class SynthesizerInterface {
 public:
  SynthesizerInterface();
  virtual ~SynthesizerInterface();

  virtual void FrontendSynthesize(const std::string& text,
                                  const TTSOption& synthesis_option,
                                  Json::Value* frontend_data) const = 0;

  virtual void Synthesize(const std::string& text,
                          const TTSOption& synthesis_option,
                          std::string* data_res,
                          shared_ptr<Engine> custom_engine = nullptr) const = 0;

  virtual void Synthesize(const std::string& text,
                          const TTSOption& synthesis_option,
                          SynthesizerEventInterface* callback,
                          shared_ptr<Engine> custom_engine = nullptr) const = 0;

  virtual void Synthesize(const std::string& text, const TTSOption& tts_option,
                          std::vector<int16>* data) const = 0;
};
}  // namespace tts
#endif  // TTS_SYNTHESIZER_INTERFACE_SYNTHESIZER_INTERFACE_H_
