// Copyright 2016 Mobvoi Inc. All Rights Reserved.
// Author: ylchen@mobvoi.com (Yunlin Chen)

#include "tts/synthesizer/interface/synthesizer_event_interface.h"

namespace tts {
SynthesizerEventInterface::SynthesizerEventInterface() {}
SynthesizerEventInterface::~SynthesizerEventInterface() {}

void SynthesizerEventInterface::set_use_cache(bool use_cache) {
  use_cache_ = use_cache;
}

#ifndef FOR_PORTABLE
// get bgm offset
int SynthesizerEventInterface::GetBgmOffset() { return bgm_offset_; }

// set bgm offset
void SynthesizerEventInterface::SetBgmOffset(const int offset) {
  bgm_offset_ += offset;
}
#endif
}  // namespace tts
