// Copyright 2016 Mobvoi Inc. All Rights Reserved.
// Author: ylchen@mobvoi.com (Yunlin Chen)

#ifndef TTS_SYNTHESIZER_INTERFACE_SYNTHESIZER_EVENT_INTERFACE_H_
#define TTS_SYNTHESIZER_INTERFACE_SYNTHESIZER_EVENT_INTERFACE_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"

namespace tts {
class SynthesizerEventInterface {
 public:
  SynthesizerEventInterface();
  virtual ~SynthesizerEventInterface();

  // callback when synthesize start
  virtual void OnStart() = 0;
  // true for success, false for cancel synthesizing
  virtual bool OnSynthesizeData(const std::string& data) = 0;
  // callback when synthesize finish
  virtual void OnFinish() = 0;
  // if use cache
  bool use_cache() const { return use_cache_; }
  // set if use cache
  void set_use_cache(bool use_cache);
#ifndef FOR_PORTABLE
  virtual string GetResult() = 0;
  virtual bool GetChunkDuration(const std::string& duration) = 0;
  // gen bgm offset
  int GetBgmOffset();
  // set bgm offset
  void SetBgmOffset(const int offset);
#endif

 private:
  bool use_cache_ = false;
#ifndef FOR_PORTABLE
  int bgm_offset_ = 0;
#endif
};
}  // namespace tts

#endif  // TTS_SYNTHESIZER_INTERFACE_SYNTHESIZER_EVENT_INTERFACE_H_
