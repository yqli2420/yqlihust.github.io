// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng Yang)

#include "tts/synthesizer/vocoder/world_vocoder/world/featuretrans.h"

#include <iostream>

namespace world_vocoder {

int mgc2sp(double *mgc, int mgc_order, double alpha, int fft_size, double gamma,
           double *sp) {
  int m = mgc_order, l = fft_size, no, i;
  double *c, *x, *y, logk;

  x = dgetmem(l + l + m + 1);
  y = x + l;
  c = y + l;

  no = l / 2 + 1;
  logk = 20.0 / log(10.0);
  for (i = 0; i <= mgc_order; i++) {
    c[i] = mgc[i];
  }
  mgc2sp(c, m, alpha, gamma, x, y, l);
  for (i = no; i--;) {
    x[i] = exp(x[i]);
  }
  for (i = 0; i < no; i++) {
    sp[i] = iSopr(x[i]);
  }
  if (x != NULL) free(x);
  return (0);
}

int sp2mcep(double *sp, double alpha, const int mcsize, double nFFTHalf,
            double *mgc) {
  int itype = 3;
  int ilng = FLENG;
  int flng = nFFTHalf;
  int m = mcsize;
  double a = alpha;
  int itr1 = MINITR;
  int itr2 = 0;
  int etype = ETYPE;
  double end = END, e = 1.0E-8, f = 0.0;
  if (itype == 0)
    ilng = flng;
  else
    ilng = flng / 2 + 1;
  double *x = dgetmem(flng + m + 1);
  double *mc = x + flng;
  for (int i = 0; i < ilng; i++) {
    x[i] = Sopr(sp[i]);
  }
  mcep(x, flng, mc, m, a, itr1, itr2, end, etype, e, f, itype);

  for (int i = 0; i < mcsize + 1; i++) {
    mgc[i] = mc[i];
  }
  if (x != NULL) free(x);
}

int PostFilter(double *mc, int m, double beta, double a) {
  int irleng = IRLENG, m1, k;
  double *x;
  double e1, e2;

  m1 = m + 1;
  x = dgetmem(m1);
  for (int i = 0; i < m1; i++) {
    x[i] = mc[i];
  }
  mc2b(x, x, m, a);
  e1 = b2en(x, m, a, irleng);
  x[1] -= beta * a * x[2];
  for (k = 2; k <= m; k++) x[k] *= (1.0 + beta);
  e2 = b2en(x, m, a, irleng);
  x[0] += log(e1 / e2) / 2;
  b2mc(x, x, m, a);
  for (int i = 0; i < m1; i++) {
    mc[i] = x[i];
  }
  if (x != NULL) free(x);
  return 0;
}
}  // namespace world_vocoder
