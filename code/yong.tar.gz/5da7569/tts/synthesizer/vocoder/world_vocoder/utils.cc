// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng Yang)

#include "tts/synthesizer/vocoder/world_vocoder/world/utils.h"

#include "mobvoi/base/basictypes.h"

namespace world_vocoder {

char *getmem(const size_t leng, const size_t size) {
  char *p = NULL;

  if ((p = reinterpret_cast<char *>(calloc(leng, size))) == NULL) {
    fprintf(stderr, "Cannot allocate memory!\n");
    exit(3);
  }
  return (p);
}
double *dgetmem(const int leng) {
  return (reinterpret_cast<double *>(getmem((size_t)leng, sizeof(double))));
}
void movem(void *a, void *b, const size_t size, const int nitem) {
  int64 i;
  char *c = reinterpret_cast<char *>(a);
  char *d = reinterpret_cast<char *>(b);

  i = size * nitem;
  if (c > d) {
    while (i--) *d++ = *c++;
  } else {
    c += i;
    d += i;
    while (i--) *--d = *--c;
  }
}
static int checkm(const int m) {
  int k;

  for (k = 4; k <= m; k <<= 1) {
    if (k == m) return (0);
  }
  fprintf(stderr, "fft : m must be a integer of power of 2!\n");

  return (-1);
}

int fft(double *x, double *y, const int m) {
  int j, lmx, li;
  double *xp, *yp;
  double *sinp, *cosp;
  int lf, lix, tblsize;
  int mv2, mm1;
  double t1, t2;
  double arg;
  int checkm(const int);
  double *_sintbl = 0;
  int maxfftsize = 0;

  /**************
 * RADIX-2 FFT *
 **************/

  if (checkm(m)) return (-1);

  /***********************
 * SIN table generation *
 ***********************/

  if ((_sintbl == 0) || (maxfftsize < m)) {
    tblsize = m - m / 4 + 1;
    arg = PI / m * 2;
    if (_sintbl != 0) free(_sintbl);
    sinp = dgetmem(tblsize);
    _sintbl = sinp;
    *sinp++ = 0;
    for (j = 1; j < tblsize; j++) *sinp++ = sin(arg * static_cast<double>(j));
    _sintbl[m / 2] = 0;
    maxfftsize = m;
  }

  lf = maxfftsize / m;
  lmx = m;

  for (;;) {
    lix = lmx;
    lmx /= 2;
    if (lmx <= 1) break;
    sinp = _sintbl;
    cosp = _sintbl + maxfftsize / 4;
    for (j = 0; j < lmx; j++) {
      xp = &x[j];
      yp = &y[j];
      for (li = lix; li <= m; li += lix) {
        t1 = *(xp) - *(xp + lmx);
        t2 = *(yp) - *(yp + lmx);
        *(xp) += *(xp + lmx);
        *(yp) += *(yp + lmx);
        *(xp + lmx) = *cosp * t1 + *sinp * t2;
        *(yp + lmx) = *cosp * t2 - *sinp * t1;
        xp += lix;
        yp += lix;
      }
      sinp += lf;
      cosp += lf;
    }
    lf += lf;
  }

  xp = x;
  yp = y;
  for (li = m / 2; li--; xp += 2, yp += 2) {
    t1 = *(xp) - *(xp + 1);
    t2 = *(yp) - *(yp + 1);
    *(xp) += *(xp + 1);
    *(yp) += *(yp + 1);
    *(xp + 1) = t1;
    *(yp + 1) = t2;
  }

  /***************
 * bit reversal *
 ***************/
  j = 0;
  xp = x;
  yp = y;
  mv2 = m / 2;
  mm1 = m - 1;
  for (lmx = 0; lmx < mm1; lmx++) {
    if ((li = lmx - j) < 0) {
      t1 = *(xp);
      t2 = *(yp);
      *(xp) = *(xp + li);
      *(yp) = *(yp + li);
      *(xp + li) = t1;
      *(yp + li) = t2;
    }
    li = mv2;
    while (li <= j) {
      j -= li;
      li /= 2;
    }
    j += li;
    xp = x + j;
    yp = y + j;
  }
  if (_sintbl != 0) free(_sintbl);
  return (0);
}

int fftr(double *x, double *y, const int m) {
  int i, j;
  double *xp, *yp, *xq;
  double *yq;
  int mv2, n, tblsize;
  double xt, yt, *sinp, *cosp;
  double arg;
  double *_sintbl = 0;
  int maxfftsize = 0;
  mv2 = m / 2;
  /* separate even and odd  */
  xq = xp = x;
  yp = y;
  for (i = mv2; --i >= 0;) {
    *xp++ = *xq++;
    *yp++ = *xq++;
  }

  if (fft(x, y, mv2) == -1) /* m / 2 point fft */
    return (-1);

  /***********************
 * SIN table generation *
 ***********************/

  if ((_sintbl == 0) || (maxfftsize < m)) {
    tblsize = m - m / 4 + 1;
    arg = PI / m * 2;
    if (_sintbl != 0) free(_sintbl);
    sinp = dgetmem(tblsize);
    _sintbl = sinp;
    *sinp++ = 0;
    for (j = 1; j < tblsize; j++) *sinp++ = sin(arg * static_cast<double>(j));
    _sintbl[m / 2] = 0;
    maxfftsize = m;
  }

  n = maxfftsize / m;
  sinp = _sintbl;
  cosp = _sintbl + maxfftsize / 4;

  xp = x;
  yp = y;
  xq = xp + m;
  yq = yp + m;
  *(xp + mv2) = *xp - *yp;
  *xp = *xp + *yp;
  *(yp + mv2) = *yp = 0;

  for (i = mv2, j = mv2 - 2; --i; j -= 2) {
    ++xp;
    ++yp;
    sinp += n;
    cosp += n;
    yt = *yp + *(yp + j);
    xt = *xp - *(xp + j);
    *(--xq) = (*xp + *(xp + j) + *cosp * yt - *sinp * xt) * 0.5;
    *(--yq) = (*(yp + j) - *yp + *sinp * yt + *cosp * xt) * 0.5;
  }

  xp = x + 1;
  yp = y + 1;
  xq = x + m;
  yq = y + m;

  for (i = mv2; --i;) {
    *xp++ = *(--xq);
    *yp++ = -(*(--yq));
  }
  if (_sintbl != 0) free(_sintbl);
  return (0);
}

int ifftr(double *x, double *y, const int l) {
  int i;
  double *xp, *yp;

  fftr(x, y, l);

  xp = x;
  yp = y;
  i = l;
  while (i--) {
    *xp++ /= l;
    *yp++ /= -l;
  }

  return (0);
}
void fillz(void *ptr, const size_t size, const int nitem) {
  int64 n;
  char *p = reinterpret_cast<char *>(ptr);

  n = size * nitem;
  while (n--) *p++ = '\0';
}
void freqt(double *c1, const int m1, double *c2, const int m2, const double a) {
  int i, j;
  double b;
  double *d = NULL, *g;

  if (d == NULL) {
    d = dgetmem(m2 + m2 + 2);
    g = d + m2 + 1;
  }

  b = 1 - a * a;
  fillz(g, sizeof(*g), m2 + 1);

  for (i = -m1; i <= 0; i++) {
    if (0 <= m2) g[0] = c1[-i] + a * (d[0] = g[0]);
    if (1 <= m2) g[1] = b * d[0] + a * (d[1] = g[1]);
    for (j = 2; j <= m2; j++) g[j] = d[j - 1] + a * ((d[j] = g[j]) - g[j - 1]);
  }

  movem(g, c2, sizeof(*g), m2 + 1);
  if (d != NULL) {
    free(d);
  }
  return;
}

void frqtr(double *c1, int m1, double *c2, int m2, const double a) {
  int i, j;
  double *d = NULL, *g;
  int size;

  if (d == NULL) {
    d = dgetmem(m2 + m2 + 2);
    g = d + m2 + 1;
  }
  fillz(g, sizeof(*g), m2 + 1);

  for (i = -m1; i <= 0; i++) {
    if (0 <= m2) {
      d[0] = g[0];
      g[0] = c1[-i];
    }
    for (j = 1; j <= m2; j++) g[j] = d[j - 1] + a * ((d[j] = g[j]) - g[j - 1]);
  }

  movem(g, c2, sizeof(*g), m2 + 1);
  if (d != NULL) {
    free(d);
  }
  return;
}

static void mv_mul(double *t, double *x, double *y) {
  t[0] = x[0] * y[0] + x[1] * y[1];
  t[1] = x[2] * y[0] + x[3] * y[1];

  return;
}

static void mm_mul(double *t, double *x, double *y) {
  t[0] = x[0] * y[0] + x[1] * y[2];
  t[1] = x[0] * y[1] + x[1] * y[3];
  t[2] = x[2] * y[0] + x[3] * y[2];
  t[3] = x[2] * y[1] + x[3] * y[3];

  return;
}

static int inverse(double *x, double *y, const double eps) {
  double det;

  det = y[0] * y[3] - y[1] * y[2];

#ifdef WIN32
  if ((fabs(det) < eps) || _isnan(det)) {
#else
  if ((fabs(det) < eps) || isnan(det)) {
#endif
    fprintf(stderr,
            "theq() : determinant of the normal matrix is too small!\n");
    return (-1);
  }

  x[0] = y[3] / det;
  x[1] = -y[1] / det;
  x[2] = -y[2] / det;
  x[3] = y[0] / det;

  return (0);
}

static void crstrns(double *x, double *y) {
  x[0] = y[3];
  x[1] = y[2];
  x[2] = y[1];
  x[3] = y[0];

  return;
}

static double **mtrx2(const int a, const int b) {
  int i;
  double **x;

  if (!(x = reinterpret_cast<double **>(calloc((size_t)a, sizeof(*x))))) {
    fprintf(stderr, "mtrx2() in theq() : Cannot allocate memory!\n");
    exit(3);
  }
  for (i = 0; i < a; i++)
    if (!(x[i] = reinterpret_cast<double *>(calloc((size_t)b, sizeof(**x))))) {
      fprintf(stderr, "mtrx2() in theq() : Cannot allocate memory!\n");
      exit(3);
    }

  return (x);
}

static int cal_p0(double **p, double **r, double *b, const int n,
                  const double eps) {
  double t[4], s[2];

  if (inverse(t, r[0], eps) == -1) return (-1);
  s[0] = b[0];
  s[1] = b[n - 1];
  mv_mul(p[0], t, s);

  return (0);
}

static void cal_ex(double *ex, double **r, double **x, const int i) {
  int j;
  double t[4], s[4];

  s[0] = s[1] = s[2] = s[3] = 0.;

  for (j = 0; j < i; j++) {
    mm_mul(t, r[i - j], x[j]);
    s[0] += t[0];
    s[1] += t[1];
    s[2] += t[2];
    s[3] += t[3];
  }

  ex[0] = s[0];
  ex[1] = s[1];
  ex[2] = s[2];
  ex[3] = s[3];

  return;
}

static void cal_ep(double *ep, double **r, double **p, const int i) {
  int j;
  double t[2], s[2];

  s[0] = s[1] = 0.;

  for (j = 0; j < i; j++) {
    mv_mul(t, r[i - j], p[j]);
    s[0] += t[0];
    s[1] += t[1];
  }
  ep[0] = s[0];
  ep[1] = s[1];

  return;
}

static int cal_bx(double *bx, double *vx, double *ex, const double eps) {
  double t[4], s[4];

  crstrns(t, vx);
  if (inverse(s, t, eps) == -1) return (-1);
  mm_mul(bx, s, ex);

  return (0);
}

static void cal_x(double **x, double **xx, double *bx, const int i) {
  int j;
  double t[4], s[4];

  for (j = 1; j < i; j++) {
    crstrns(t, xx[i - j]);
    mm_mul(s, t, bx);
    x[j][0] -= s[0];
    x[j][1] -= s[1];
    x[j][2] -= s[2];
    x[j][3] -= s[3];
  }

  for (j = 1; j < i; j++) {
    xx[j][0] = x[j][0];
    xx[j][1] = x[j][1];
    xx[j][2] = x[j][2];
    xx[j][3] = x[j][3];
  }

  x[i][0] = xx[i][0] = -bx[0];
  x[i][1] = xx[i][1] = -bx[1];
  x[i][2] = xx[i][2] = -bx[2];
  x[i][3] = xx[i][3] = -bx[3];

  return;
}

static void cal_vx(double *vx, double *ex, double *bx) {
  double t[4], s[4];

  crstrns(t, ex);
  mm_mul(s, t, bx);
  vx[0] -= s[0];
  vx[1] -= s[1];
  vx[2] -= s[2];
  vx[3] -= s[3];

  return;
}

static int cal_g(double *g, double *vx, double *b, double *ep, const int i,
                 const int n, const double eps) {
  double t[2], s[4], u[4];

  t[0] = b[i] - ep[0];
  t[1] = b[n - 1 - i] - ep[1];
  crstrns(s, vx);

  if (inverse(u, s, eps) == -1) return (-1);
  mv_mul(g, u, t);

  return (0);
}

static void cal_p(double **p, double **x, double *g, const int i) {
  double t[4], s[2];
  int j;

  for (j = 0; j < i; j++) {
    crstrns(t, x[i - j]);
    mv_mul(s, t, g);
    p[j][0] += s[0];
    p[j][1] += s[1];
  }

  p[i][0] = g[0];
  p[i][1] = g[1];

  return;
}

int theq(double *t, double *h, double *a, double *b, const int n, double eps) {
  double **r = NULL, **x, **xx, **p;
  int size;
  double ex[4], ep[2], vx[4], bx[4], g[2];
  int i;

  if (r == NULL) {
    r = mtrx2(n, 4);
    x = mtrx2(n, 4);
    xx = mtrx2(n, 4);
    p = mtrx2(n, 2);
    size = n;
  }

  if (eps < 0.0) eps = 1.0e-6;

  /* make r */
  for (i = 0; i < n; i++) {
    r[i][0] = r[i][3] = t[i];
    r[i][1] = h[n - 1 + i];
    r[i][2] = h[n - 1 - i];
  }

  /* step 1 */
  x[0][0] = x[0][3] = 1.0;
  if (cal_p0(p, r, b, n, eps) == -1) return (-1);

  vx[0] = r[0][0];
  vx[1] = r[0][1];
  vx[2] = r[0][2];
  vx[3] = r[0][3];

  /* step 2 */
  for (i = 1; i < n; i++) {
    cal_ex(ex, r, x, i);
    cal_ep(ep, r, p, i);
    if (cal_bx(bx, vx, ex, eps) == -1) return (-1);
    cal_x(x, xx, bx, i);
    cal_vx(vx, ex, bx);
    if (cal_g(g, vx, b, ep, i, n, eps) == -1) return (-1);
    cal_p(p, x, g, i);
  }

  /* step 3 */
  for (i = 0; i < n; i++) a[i] = p[i][0];

  /* free */
  for (i = 0; i < size; i++) {
    free(reinterpret_cast<char *>(r[i]));
    free(reinterpret_cast<char *>(x[i]));
    free(reinterpret_cast<char *>(xx[i]));
    free(reinterpret_cast<char *>(p[i]));
  }
  free(reinterpret_cast<char *>(r));
  free(reinterpret_cast<char *>(x));
  free(reinterpret_cast<char *>(xx));
  free(reinterpret_cast<char *>(p));
  return (0);
}

double Sopr(double in) { return sqrt(in) * 32768; }
double iSopr(double in) { return in * in / 32768 / 32768; }
int mcep(double *xw, const int flng, double *mc, const int m, const double a,
         const int itr1, const int itr2, const double dd, const int etype,
         const double e, const double f, const int itype) {
  int i, j;
  int flag = 0, f2, m2;
  double t, s, eps = 0.0, min, max;
  double *x = NULL, *y, *c, *d, *al, *b;
  int size_x, size_d;

  if (etype == 1 && e < 0.0) {
    fprintf(stderr, "mcep : value of e must be e>=0!\n");
    exit(1);
  }

  if (etype == 2 && e >= 0.0) {
    fprintf(stderr, "mcep : value of E must be E<0!\n");
    exit(1);
  }

  if (etype == 1) {
    eps = e;
  }

  if (x == NULL) {
    x = dgetmem(3 * flng);
    y = x + flng;
    c = y + flng;
    size_x = flng;

    d = dgetmem(3 * m + 3);
    al = d + (m + 1);
    b = al + (m + 1);
    size_d = m;
  }

  f2 = flng / 2;
  m2 = m + m;

  movem(xw, x, sizeof(*x), flng);

  switch (itype) {
    case 0: /* windowed data sequence */
      fftr(x, y, flng);
      for (i = 0; i < flng; i++) {
        x[i] = x[i] * x[i] + y[i] * y[i] + eps; /*  periodogram  */
      }
      break;
    case 1: /* dB */
      for (i = 0; i <= flng / 2; i++) {
        x[i] = exp((x[i] / 20.0) * log(10.0)); /* dB -> amplitude spectrum */
        x[i] = x[i] * x[i] + eps;              /* amplitude -> periodogram */
      }
      break;
    case 2: /* log */
      for (i = 0; i <= flng / 2; i++) {
        x[i] = exp(x[i]);         /* log -> amplitude spectrum */
        x[i] = x[i] * x[i] + eps; /* amplitude -> periodogram */
      }
      break;
    case 3: /* amplitude */
      for (i = 0; i <= flng / 2; i++) {
        x[i] = x[i] * x[i] + eps; /* amplitude -> periodogram */
      }
      break;
    case 4: /* periodogram */
      for (i = 0; i <= flng / 2; i++) {
        x[i] = x[i] + eps;
      }
      break;
    default:
      fprintf(stderr, "mcep : input type %d is not supported!\n", itype);
      exit(1);
  }
  if (itype > 0) {
    for (i = 1; i < flng / 2; i++) x[flng - i] = x[i];
  }

  if (etype == 2 && e < 0.0) {
    max = x[0];
    for (i = 1; i < flng; i++) {
      if (max < x[i]) max = x[i];
    }
    max = sqrt(max);
    min = max * pow(10.0, e / 20.0); /* floor is 20*log10(min/max) */
    min = min * min;
    for (i = 0; i < flng; i++) {
      if (x[i] < min) x[i] = min;
    }
  }

  for (i = 0; i < flng; i++) {
    if (x[i] <= 0.0) {
      fprintf(stderr,
              "mcep : periodogram has '0', use '-e' option to floor it!\n");
      exit(1);
    }
    c[i] = log(x[i]);
  }

  /*  1, (-a), (-a)^2, ..., (-a)^M  */
  al[0] = 1.0;
  for (i = 1; i <= m; i++) al[i] = -a * al[i - 1];

  /*  initial value of cepstrum  */
  ifftr(c, y, flng); /*  c : IFFT[x]  */

  c[0] /= 2.0;
  c[f2] /= 2.0;
  freqt(c, f2, mc, m, a); /*  mc : mel cep.  */
  s = c[0];

  /*  Newton Raphson method  */
  for (j = 1; j <= itr2; j++) {
    fillz(c, sizeof(*c), flng);
    freqt(mc, m, c, f2, -a); /*  mc : mel cep.  */
    fftr(c, y, flng);        /*  c, y : FFT[mc]  */
    for (i = 0; i < flng; i++) c[i] = x[i] / exp(c[i] + c[i]);
    ifftr(c, y, flng);
    frqtr(c, f2, c, m2, a); /*  c : r(k)  */

    t = c[0];
    if (j >= itr1) {
      if (fabs((t - s) / t) < dd) {
        flag = 1;
        break;
      }
      s = t;
    }

    for (i = 0; i <= m; i++) b[i] = c[i] - al[i];
    for (i = 0; i <= m2; i++) y[i] = c[i];
    for (i = 0; i <= m2; i += 2) y[i] -= c[0];
    for (i = 2; i <= m; i += 2) c[i] += c[0];
    c[0] += c[0];

    if (theq(c, y, d, b, m + 1, f)) {
      fprintf(stderr, "mcep : Error in theq() at %dth iteration !\n", j);
      exit(1);
    }

    for (i = 0; i <= m; i++) mc[i] += d[i];
  }
  if (x != NULL) {
    free(x);
    x = NULL;
  }
  if (d != NULL) {
    free(d);
    d = NULL;
  }
  if (x != NULL) {
    free(x);
  }
  if (d != NULL) {
    free(d);
  }
  if (flag)
    return (0);
  else
    return (-1);
}

void gnorm(double *c1, double *c2, int m, const double g) {
  double k;

  if (g != 0.0) {
    k = 1.0 + g * c1[0];
    for (; m >= 1; m--) c2[m] = c1[m] / k;
    c2[0] = pow(k, 1.0 / g);
  } else {
    movem(&c1[1], &c2[1], sizeof(*c1), m);
    c2[0] = exp(c1[0]);
  }

  return;
}
void ignorm(double *c1, double *c2, int m, const double g) {
  double k;

  k = pow(c1[0], g);
  if (g != 0.0) {
    for (; m >= 1; m--) c2[m] = k * c1[m];
    c2[0] = (k - 1.0) / g;
  } else {
    movem(&c1[1], &c2[1], sizeof(*c1), m);
    c2[0] = log(c1[0]);
  }

  return;
}

void gc2gc(double *c1, const int m1, const double g1, double *c2, const int m2,
           const double g2) {
  int i, min, k, mk;
  double ss1, ss2, cc;

  c2[0] = c1[0];
  for (i = 1; i <= m2; i++) {
    ss1 = ss2 = 0.0;
    min = (m1 < i) ? m1 : i - 1;
    for (k = 1; k <= min; k++) {
      mk = i - k;
      cc = c1[k] * c2[mk];
      ss2 += k * cc;
      ss1 += mk * cc;
    }

    if (i <= m1)
      c2[i] = c1[i] + (g2 * ss2 - g1 * ss1) / i;
    else
      c2[i] = (g2 * ss2 - g1 * ss1) / i;
  }
  return;
}
void c2sp(double *c, const int m, double *x, double *y, const int l) {
  int m1;

  m1 = m + 1;

  movem(c, x, sizeof(*c), m1);
  fillz(x + m1, sizeof(*x), l - m1);

  fftr(x, y, l);
}

void mgc2mgc(double *c1, const int m1, const double a1, const double g1,
             double *c2, const int m2, const double a2, const double g2) {
  double a;

  a = (a2 - a1) / (1 - a1 * a2);

  if (a == 0) {
    gnorm(c1, c1, m1, g1);
    gc2gc(c1, m1, g1, c2, m2, g2);
    ignorm(c2, c2, m2, g2);
  } else {
    freqt(c1, m1, c2, m2, a);
    gnorm(c2, c2, m2, g1);
    gc2gc(c2, m2, g1, c2, m2, g2);
    ignorm(c2, c2, m2, g2);
  }
  return;
}

void mgc2sp(double *mgc, const int m, const double a, const double g, double *x,
            double *y, const int flng) {
  double *c = NULL;
  int size;

  if (c == NULL) {
    c = dgetmem(flng / 2 + 1);
    size = flng;
  }

  mgc2mgc(mgc, m, a, g, c, flng / 2, 0.0, 0.0);
  c2sp(c, flng / 2, x, y, flng);
  if (c != NULL) free(c);
  return;
}

void b2mc(double *b, double *mc, int m, const double a) {
  double d, o;

  d = mc[m] = b[m];
  for (m--; m >= 0; m--) {
    o = b[m] + a * d;
    d = b[m];
    mc[m] = o;
  }

  return;
}

void c2ir(double *c, const int nc, double *h, const int leng) {
  int n, k, upl;
  double d;

  h[0] = exp(c[0]);
  for (n = 1; n < leng; n++) {
    d = 0;
    upl = (n >= nc) ? nc - 1 : n;
    for (k = 1; k <= upl; k++) d += k * c[k] * h[n - k];
    h[n] = d / n;
  }

  return;
}

void ic2ir(double *h, const int leng, double *c, const int nc) {
  int n, k, upl;
  double d;

  c[0] = log(h[0]);
  for (n = 1; n < nc; n++) {
    d = (n >= leng) ? 0 : n * h[n];
    upl = (n > leng) ? n - leng + 1 : 1;
    for (k = upl; k < n; k++) d -= k * c[k] * h[n - k];
    c[n] = d / (n * h[0]);
  }

  return;
}

void mc2b(double *mc, double *b, int m, const double a) {
  b[m] = mc[m];
  for (m--; m >= 0; m--) b[m] = mc[m] - a * b[m + 1];
  return;
}

double b2en(double *b, int m, double a, int irleng) {
  double en;
  int k;
  double *mc = NULL, *cep, *ir;

  if ((mc = reinterpret_cast<double *>(
           calloc((m + 1) + 2 * irleng, sizeof(double)))) == NULL) {
    fprintf(stderr, "Memory allocation error !\n");
    exit(1);
  }
  cep = mc + m + 1;
  ir = cep + irleng;

  b2mc(b, mc, m, a);
  freqt(mc, m, cep, irleng - 1, -a);
  c2ir(cep, irleng, ir, irleng);
  en = 0.0;
  for (k = 0; k < irleng; k++) en += ir[k] * ir[k];
  if (mc != NULL) {
    free(mc);
  }
  return (en);
}
}  // namespace world_vocoder
