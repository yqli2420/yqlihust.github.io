// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng Yang)

#ifndef TTS_SYNTHESIZER_VOCODER_WORLD_VOCODER_WORLD_STONEMASK_H_
#define TTS_SYNTHESIZER_VOCODER_WORLD_VOCODER_WORLD_STONEMASK_H_

#include "tts/synthesizer/vocoder/world_vocoder/world/macrodefinitions.h"

namespace world_vocoder {

WORLD_BEGIN_C_DECLS

//-----------------------------------------------------------------------------
// StoneMask() refines the estimated F0 by Dio()
// Input:
//   x                      : Input signal
//   x_length               : Length of the input signal
//   fs                     : Sampling frequency
//   time_axis              : Temporal information
//   f0                     : f0 contour
//   f0_length              : Length of f0
// Output:
//   refined_f0             : Refined F0
//-----------------------------------------------------------------------------
void StoneMask(const double *x, int x_length, int fs, const double *time_axis,
               const double *f0, int f0_length, double *refined_f0);
}  // namespace world_vocoder
WORLD_END_C_DECLS
#endif  // TTS_SYNTHESIZER_VOCODER_WORLD_VOCODER_WORLD_STONEMASK_H_
