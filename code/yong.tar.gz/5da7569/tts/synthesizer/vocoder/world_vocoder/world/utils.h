// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng Yang)

#ifndef TTS_SYNTHESIZER_VOCODER_WORLD_VOCODER_WORLD_UTILS_H_
#define TTS_SYNTHESIZER_VOCODER_WORLD_VOCODER_WORLD_UTILS_H_

#include <math.h>
#include <stdio.h>
#include <stdlib.h>

namespace world_vocoder {

#ifndef PI
#define PI 3.14159265358979323846
#endif /* PI */

#ifndef PI2
#define PI2 6.28318530717958647692
#endif /* PI2 */

#ifndef M_PI
#define M_PI 3.1415926535897932384626433832795
#endif /* M_PI */

#ifndef M_2PI
#define M_2PI 6.2831853071795864769252867665590
#endif /* M_2PI */

#define LN_TO_LOG 4.3429448190325182765

#define LZERO (-1.0e+10)
#define LSMALL (-0.5e+10)

/* #ifndef ABS(x) */
#define ABS(x) ((x < 0.0) ? -x : x)
/* #endif */

#ifdef __BIG_ENDIAN
#if __BYTE_ORDER == __BIG_ENDIAN
#define WORDS_BIGENDIAN
#endif
#endif
#define FLENG 256
#define ITYPE 0
#define ETYPE 0
#define MINITR 2
#define MAXITR 30
#define END 0.001
#define ALPHA 0.58
#define ORDER 59
#define BETA 0.3
#define IRLENG 64

char *getmem(const size_t leng, const size_t size);
double *dgetmem(const int leng);
void movem(void *a, void *b, const size_t size, const int nitem);
int fft(double *x, double *y, const int m);
int fftr(double *x, double *y, const int m);
int ifftr(double *x, double *y, const int l);
void fillz(void *ptr, const size_t size, const int nitem);
void freqt(double *c1, const int m1, double *c2, const int m2, const double a);
void frqtr(double *c1, int m1, double *c2, int m2, const double a);

int theq(double *t, double *h, double *a, double *b, const int n, double eps);
int mcep(double *xw, const int flng, double *mc, const int m, const double a,
         const int itr1, const int itr2, const double dd, const int etype,
         const double e, const double f, const int itype);

void b2mc(double *b, double *mc, int m, const double a);
void c2ir(double *c, const int nc, double *h, const int leng);
void ic2ir(double *h, const int leng, double *c, const int nc);
void mc2b(double *mc, double *b, int m, const double a);
double b2en(double *b, int m, double a, int irleng);

void ignorm(double *c1, double *c2, int m, const double g);
void mgc2sp(double *mgc, const int m, const double a, const double g, double *x,
            double *y, const int flng);

double Sopr(double in);
double iSopr(double in);
}  // namespace world_vocoder

#endif  // TTS_SYNTHESIZER_VOCODER_WORLD_VOCODER_WORLD_UTILS_H_
