// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng Yang)

#ifndef TTS_SYNTHESIZER_VOCODER_WORLD_VOCODER_WORLD_WORLD_VOCODER_H_
#define TTS_SYNTHESIZER_VOCODER_WORLD_VOCODER_WORLD_WORLD_VOCODER_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"

#include "tts/synthesizer/vocoder/world_vocoder/world/audioio.h"
#include "tts/synthesizer/vocoder/world_vocoder/world/cheaptrick.h"
#include "tts/synthesizer/vocoder/world_vocoder/world/constantnumbers.h"
#include "tts/synthesizer/vocoder/world_vocoder/world/d4c.h"
#include "tts/synthesizer/vocoder/world_vocoder/world/dio.h"
#include "tts/synthesizer/vocoder/world_vocoder/world/featuretrans.h"
#include "tts/synthesizer/vocoder/world_vocoder/world/matlabfunctions.h"
#include "tts/synthesizer/vocoder/world_vocoder/world/stonemask.h"
#include "tts/synthesizer/vocoder/world_vocoder/world/synthesis.h"
#include "tts/synthesizer/vocoder/world_vocoder/world/utils.h"

namespace world_vocoder {

struct WorldParameters {
  double frame_period;
  int fs;
  double *f0;
  double *time_axis;
  int f0_length;
  double **spectrogram;
  double **aperiodicity;
  int fft_size;
  int number_of_aperiodicities;
};

class WorldVocoder {
 public:
  WorldVocoder(int fs, double frame_period);
  ~WorldVocoder();
  bool Analysis(int fs, int nbit, double *pcms, int pcm_len,
                WorldParameters *world_parameters) const;
  bool AnalysisFromFile(const char *wave_file, vector<double> *pitch,
                        vector<vector<double> > *sp,
                        vector<vector<double> > *ap) const;

  bool AnalysisFromPCM(int fs, int nbit, double *pcms, int pcm_length,
                       vector<double> *f0, vector<vector<double> > *sp,
                       vector<vector<double> > *ap) const;

  bool SynthesizeFeaFromFile(const std::string &f0_file,
                             const std::string &mgc_file,
                             const std::string &ap_file,
                             const std::string &wav_file) const;
  void SynthesizeFeaFromFea(const vector<double> &lf0,
                            const vector<vector<double> > &sp,
                            const vector<vector<double> > &ap,
                            vector<double> *data) const;
  void ParseFeature(const vector<double> &fea, bool use_robot,
                    vector<double> *lf0, vector<vector<double> > *sp,
                    vector<vector<double> > *ap) const;
  bool ReadspFile(const char *fea_file, vector<vector<double> > *data) const;
  bool ReadApLf0File(const char *fea_file, vector<double> *data) const;
  bool ReadApFile(const char *fea_file, vector<double> *data) const;
  bool Synthesize(const vector<double> &fea, vector<double> *data) const;
  bool MergeFeature(const vector<double> &lf0,
                    const vector<vector<double> > &sp,
                    const vector<vector<double> > &ap,
                    vector<double> *fea) const;
  bool DoubleArrayToFile(const string file, const vector<vector<double> > &data,
                         const int col, const int row);
  bool DoubleArrayToFile(const string file, const vector<double> &data,
                         const int len);
  bool Vector2Wav(const vector<double> &data, const string &wav_file) const;
  void SetF0AndFormant();
  void set_mgc_order(int mgc_order);

 private:
  float f0_scale_;
  float formant_shift_;
  int sp_order_;
  int ap_order_;
  double frame_period_;
  int fs_;
  int mgc_order_;
  int fft_size_;
  double alpha_;
  double gamma_;

  void DisplayInformation(int fs, int nbit, int x_length) const;
  void F0Estimation(double *x, int x_length,
                    WorldParameters *world_parameters) const;
  void SpectralEnvelopeEstimation(double *x, int x_length,
                                  WorldParameters *world_parameters) const;
  void AperiodicityEstimation(double *x, int x_length,
                              WorldParameters *world_parameters) const;
  void ParameterModification(float Ff0_scale, float formant_shift, int fs,
                             int f0_length, int fft_size, double *f0,
                             double **spectrogram) const;
  void WaveformSynthesis(WorldParameters *world_parameters, int fs,
                         int y_length, double *y) const;
  void DestroyMemory(WorldParameters *world_parameters) const;
  void AperiodicityInterp(WorldParameters *world_parameters) const;
};
}  // namespace world_vocoder

#endif  // TTS_SYNTHESIZER_VOCODER_WORLD_VOCODER_WORLD_WORLD_VOCODER_H_
