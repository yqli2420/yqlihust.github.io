// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng Yang)

#ifndef TTS_SYNTHESIZER_VOCODER_WORLD_VOCODER_WORLD_MACRODEFINITIONS_H_
#define TTS_SYNTHESIZER_VOCODER_WORLD_VOCODER_WORLD_MACRODEFINITIONS_H_

namespace world_vocoder {

#undef WORLD_BEGIN_C_DECLS
#undef WORLD_END_C_DECLS
#ifdef __cplusplus
#define WORLD_BEGIN_C_DECLS extern "C" {
#define WORLD_END_C_DECLS }
#else  // !__cplusplus
#define WORLD_BEGIN_C_DECLS
#define WORLD_END_C_DECLS
#endif  // __cplusplus

//
// @def WORLD_API
// @hideinitializer
// Declares a symbol to be exported for shared library usage.
//

//
// @def WORLD_LOCAL
// @hideinitializer
// Declares a symbol hidden from other libraries.
//

//
// @def WORLD_PLUGIN_API
// @hideinitializer
// Declares a symbol to be exported for plug-in usage.
//

// Generic helper definitions for shared library support
#if defined _WIN32 || defined __CYGWIN__
#define WORLD_HELPER_DLL_IMPORT __declspec(dllimport)
#define WORLD_HELPER_DLL_EXPORT __declspec(dllexport)
#define WORLD_HELPER_DLL_LOCAL
#else  // ! defined _WIN32 || defined __CYGWIN__ || defined WORLD_WIN32
#if __GNUC__ >= 4
#define WORLD_HELPER_DLL_IMPORT __attribute__((visibility("default")))
#define WORLD_HELPER_DLL_EXPORT __attribute__((visibility("default")))
#define WORLD_HELPER_DLL_LOCAL __attribute__((visibility("hidden")))
#else  // ! __GNUC__ >= 4
#define WORLD_HELPER_DLL_IMPORT
#define WORLD_HELPER_DLL_EXPORT
#define WORLD_HELPER_DLL_LOCAL
#endif  // __GNUC__ >= 4
#endif  // defined _WIN32 || defined __CYGWIN__ || defined WORLD_WIN32

//
// WORLD_LIBRARIES_EXPORTS
// ----------------------
// WORLD_LIBRARIES_EXPORTS should be defined when compiling a
// shared/dynamic library.
//
// Now we use the generic helper definitions above to define
// WORLD_API and WORLD_LOCAL. WORLD_API is used for the public API symbols.
// It's either DLL imports or DLL exports (or does nothing for static build)
// WORLD_LOCAL is used for non-api symbols.
//
// WORLD_SRC
// ------------------
// WORLD_SRC should be defined when building World (instead of just using it).
//

#ifdef WORLD_LIBRARIES_EXPORTS
#ifdef WORLD_SRC
#define WORLD_API WORLD_HELPER_DLL_EXPORT
#else  // !WORLD_SRC
#define WORLD_API WORLD_HELPER_DLL_IMPORT
#endif  // WORLD_SRC
#define WORLD_LOCAL WORLD_HELPER_DLL_LOCAL
#else  // !WORLD_LIBRARIES_EXPORTS (static library)
#define WORLD_API
#define WORLD_LOCAL
#endif  // WORLD_LIBRARIES_EXPORTS

}  // namespace world_vocoder
#endif  // TTS_SYNTHESIZER_VOCODER_WORLD_VOCODER_WORLD_MACRODEFINITIONS_H_
