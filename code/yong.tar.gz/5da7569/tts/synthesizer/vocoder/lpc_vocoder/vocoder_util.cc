// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: ranzhang@mobvoi.com (Dylan)

#include "tts/synthesizer/vocoder/lpc_vocoder/vocoder_util.h"

#include <math.h>
#include <stdio.h>

#include "mobvoi/base/file.h"
#include "mobvoi/base/log.h"

DEFINE_int32(lsp_adjust_order, 20, "");
DEFINE_double(lsp_adjust_ratio, 0.12, "");

namespace vocoder {

void CosineLsp(vector<vector<float>>* lsp) {
  CHECK(!lsp->empty()) << "lsp is empty or wrong dim";
  int order = lsp->at(0).size() - 1;
  for (auto it = lsp->begin(); it != lsp->end(); ++it) {
    for (int i = 0; i < order; ++i) {
      (*it)[i] = cos((*it)[i] * k2PI);
    }
  }
}

void AdjustLsp(vector<vector<float>>* lsp_pointer) {
  vector<vector<float>>& lsp = *lsp_pointer;
  float df, df1, df2;

  int frame_number = lsp_pointer->size();
  int order = lsp_pointer->at(0).size() - 1;
  vector<vector<float>> lsp_l2h(frame_number);
  vector<vector<float>> lsp_h2l(frame_number);

  for (int k = 0; k < 10; k++) {
    for (int j = 0; j < order; ++j) {
      lsp[k][j] = lsp[10][j];
    }
  }

  for (int k = frame_number - 10; k < frame_number; k++) {
    for (int j = 0; j < order; ++j) {
      lsp[k][j] = lsp[frame_number - 11][j];
    }
  }

  for (int iter = 1; iter <= 2; iter++) {
    for (int k = 0; k < frame_number; k++) {
      // low to high
      lsp_l2h[k].resize(FLAGS_lsp_adjust_order + 1);
      lsp_h2l[k].resize(FLAGS_lsp_adjust_order + 1);
      for (int j = 0; j < FLAGS_lsp_adjust_order; ++j) {
        if (j == 0) {
          df1 = lsp[k][j];
        } else {
          df1 = lsp[k][j] - lsp_l2h[k][j - 1];
        }
        df2 = lsp[k][j + 1] - lsp[k][j];
        df = df1 + df2;
        if (df1 > df2) {
          df1 = ((df1 / df2) * (1 + FLAGS_lsp_adjust_ratio)) /
                ((df1 / df2) * (1 + FLAGS_lsp_adjust_ratio) + 1) * df;
          df2 = df - df1;
        } else {
          df2 = ((df2 / df1) * (1 + FLAGS_lsp_adjust_ratio)) /
                ((df2 / df1) * (1 + FLAGS_lsp_adjust_ratio) + 1) * df;
          df1 = df - df2;
        }

        if (j == 0)
          lsp_l2h[k][j] = df1;
        else
          lsp_l2h[k][j] = lsp_l2h[k][j - 1] + df1;
      }

      // high to low
      for (int j = FLAGS_lsp_adjust_order - 1; j >= 0; j--) {
        if (j == 0) {
          df1 = lsp[k][j];
        } else {
          df1 = lsp[k][j] - lsp[k][j - 1];
        }

        if (j == FLAGS_lsp_adjust_order - 1) {
          df2 = lsp[k][j + 1] - lsp[k][j];
        } else {
          df2 = lsp_h2l[k][j + 1] - lsp[k][j];
        }

        df = df1 + df2;
        if (df1 > df2) {
          df1 = ((df1 / df2) * (1 + FLAGS_lsp_adjust_ratio)) /
                ((df1 / df2) * (1 + FLAGS_lsp_adjust_ratio) + 1) * df;
          df2 = df - df1;
        } else {
          df2 = ((df2 / df1) * (1 + FLAGS_lsp_adjust_ratio)) /
                ((df2 / df1) * (1 + FLAGS_lsp_adjust_ratio) + 1) * df;
          df1 = df - df2;
        }
        if (j == FLAGS_lsp_adjust_order - 1) {
          lsp_h2l[k][j] = lsp[k][j + 1] - df2;
        } else {
          lsp_h2l[k][j] = lsp_h2l[k][j + 1] - df2;
        }
      }

      for (int j = 0; j < FLAGS_lsp_adjust_order; ++j) {
        lsp[k][j] = (lsp_l2h[k][j] + lsp_h2l[k][j]) / 2;
      }
    }
  }
}

bool LoadLspFile(const string& filename, int frame_num,
                 vector<vector<float>>* lsp) {
  // Load lsp data
  size_t file_size = 0;
  mobvoi::File::FileSize(filename, &file_size);

  FILE* fp = fopen(filename.c_str(), "rb");
  if (fp == NULL) {
    LOG(ERROR) << "Failed to open file:" << filename;
    return false;
  }

  CHECK_EQ(file_size % frame_num, 0U) << "Bad file size:" << file_size;

  int lsp_order = file_size / ((sizeof(float) * frame_num)) - 1;
  VLOG(1) << "lsp file_size:" << file_size;
  int frame_number =
      static_cast<int>(file_size / ((lsp_order + 1) * sizeof(float)));
  VLOG(1) << "Frame number:" << frame_number;

  for (int i = 0; i < frame_number; ++i) {
    vector<float> lsp_item(lsp_order + 1);
    fread(lsp_item.data(), sizeof(float), lsp_order + 1, fp);
    lsp->push_back(lsp_item);
  }
  fclose(fp);
  return true;
}

bool LoadPitchFile(const string& filename, vector<float>* pitch) {
  FILE* fp = fopen(filename.c_str(), "rb");
  if (fp == NULL) {
    LOG(ERROR) << "Fail to open file:" << filename;
    return false;
  }

  size_t file_size = 0;
  mobvoi::File::FileSize(filename, &file_size);
  size_t frame_num = file_size / sizeof(float);

  pitch->resize(frame_num);
  frame_num = fread(pitch->data(), sizeof(float), frame_num, fp);
  for (size_t j = 0; j < frame_num; ++j) {
    (*pitch)[j] = exp((*pitch)[j]);
    VLOG(2) << (*pitch)[j];
  }

  fclose(fp);

  return true;
}
}  // namespace vocoder
