// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_SYNTHESIZER_VOCODER_LPC_VOCODER_VECTOR_UTIL_H_
#define TTS_SYNTHESIZER_VOCODER_LPC_VOCODER_VECTOR_UTIL_H_

#include <string>
#include <vector>

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/compat.h"

namespace vocoder {

bool Write2DVector(const string& filename, const vector<vector<float>>& data);
bool Read2DVector(const string& filename, vector<vector<float>>* data);

bool WriteVector(const string& filename, const vector<float>& data);
bool ReadVector(const string& filename, vector<float>* data);

template <class T>
bool EqualVector(const vector<T>& v1, const vector<T>& v2, T delta = T()) {
  if (v1.size() != v2.size()) {
    LOG(WARNING) << "v1 size : " << v1.size() << ", v2 size : " << v2.size();
    return false;
  }

  bool equal = true;
  int different_count = 0;
  for (size_t i = 0; i < v1.size(); ++i) {
    if (abs(v1[i] - v2[i]) > delta) {
      LOG(WARNING) << "different : " << v1[i] << " : " << v2[i];
      // continue to print all different values.
      equal = false;
      ++different_count;
    }
  }
  if (different_count != 0) {
    LOG(INFO) << "different_count : " << different_count;
  }
  return equal;
}
}  // namespace vocoder
#endif  // TTS_SYNTHESIZER_VOCODER_LPC_VOCODER_VECTOR_UTIL_H_
