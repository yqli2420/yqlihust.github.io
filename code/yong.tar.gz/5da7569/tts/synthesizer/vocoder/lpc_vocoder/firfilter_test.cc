// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include <math.h>

#include <fstream>
#include <string>

#include "mobvoi/base/file.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/matrix/kaldi-matrix.h"
#include "mobvoi/matrix/matrix_test_utils.h"
#include "third_party/gtest/gtest.h"
#include "tts/synthesizer/vocoder/lpc_vocoder/fir_coefficients.h"
#include "tts/synthesizer/vocoder/lpc_vocoder/firfilter.h"

DEFINE_bool(save_fir_result, false, "");

namespace vocoder {

void LoadVectorFromFile(const string& filename, kaldi::Vector<float>* output) {
  std::ifstream ifs(filename.c_str());
  output->Read(ifs, false);
}

void KaldiVectorToStdVector(const kaldi::Vector<float>& input,
                            vector<float>* output) {
  for (kaldi::MatrixIndexT i = 0; i < input.Dim(); ++i) {
    output->push_back(input(i));
  }
}

void LoadStdVectorFromFile(const string& filename, vector<float>* output) {
  kaldi::Vector<float> kaldi_vec;
  std::ifstream ifs(filename.c_str());
  kaldi_vec.Read(ifs, false);
  KaldiVectorToStdVector(kaldi_vec, output);
}

string PrintVector(const vector<float>& vec) {
  string str;
  str.append("=======================\n");
  for (size_t i = 0; i < vec.size(); ++i) {
    str.append(StringPrintf("%f ", vec[i]));
    if (i % 10 == 9) {
      str.append("\n");
    }
  }
  str.append("\n");
  str.append("=======================\n");
  return str;
}

TEST(VocoderTest, FastFilter) {
  kaldi::Vector<float> input;
  LoadVectorFromFile("tts/synthesizer/vocoder/lpc_vocoder/testdata/noise.txt",
                     &input);
  static const int overlap_size = 2;

  FirFilter fir(overlap_size);
  vector<float> std_input;
  KaldiVectorToStdVector(input, &std_input);

  for (size_t i = 0; i < 5; ++i) {
    vector<float> fast_output(input.Dim());
    LOG(INFO) << input.Dim();
    fir.OverlapSaveConvolution(std_input, fir.Hs_[i], &fast_output[0]);
    fast_output.resize(input.Dim());

    const float kTolerance = 0.0001;

    vector<float> expected_result;
    string filename = StringPrintf(
        "tts/synthesizer/vocoder/lpc_vocoder/testdata/expect.%d", i);
    LoadStdVectorFromFile(filename, &expected_result);

    EXPECT_TRUE(
        mobvoi::ExpectStdVectorEqual(fast_output, expected_result, kTolerance));

    if (FLAGS_save_fir_result) {
      mobvoi::File::WriteStringToFile(PrintVector(fast_output),
                                      string("fast.txt") + IntToString(i));
    }
  }
}

}  // namespace vocoder
