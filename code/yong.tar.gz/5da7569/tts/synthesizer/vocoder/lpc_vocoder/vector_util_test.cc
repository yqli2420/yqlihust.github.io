// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include <pmmintrin.h>
#include <smmintrin.h>

#include "tts/synthesizer/vocoder/lpc_vocoder/vector_util.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/log.h"
#include "third_party/gtest/gtest.h"

namespace vocoder {

TEST(VectorTest, WriteVector) {
  string filename = "test.vec";
  vector<float> vec{1, 2, 3, 4};
  WriteVector(filename, vec);
  vector<float> vec2;
  ReadVector(filename, &vec2);
  EXPECT_TRUE(EqualVector(vec, vec2));
}

TEST(VectorTest, Write2DVector) {
  string filename = "test.vec2d";
  vector<vector<float>> vec = {{1, 2, 3, 4}, {1, 2, 3, 4}};
  Write2DVector(filename, vec);
  vector<vector<float>> vec2;
  Read2DVector(filename, &vec2);
  for (size_t i = 0; i < vec.size(); ++i) {
    EXPECT_TRUE(EqualVector(vec[i], vec2[i]));
  }
}

TEST(VectorTest, RevertVector) {
  float vec[] = {1.0, 2.0, 3.0, 4.0};
  __m128 a1 = _mm_loadu_ps(&vec[0]);

  __m128 a3 = _mm_shuffle_ps(a1, a1, _MM_SHUFFLE(0, 1, 2, 3));
  float ret[4];
  _mm_storeu_ps(ret, a1);
  LOG(INFO) << ret[0];
  LOG(INFO) << ret[3];

  float ret2[4];
  _mm_storeu_ps(ret2, a3);
  LOG(INFO) << ret2[0];
  LOG(INFO) << ret2[3];
  EXPECT_EQ(ret2[0], 4.0);
  EXPECT_EQ(ret2[3], 1.0);
}
}  // namespace vocoder
