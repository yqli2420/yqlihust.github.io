// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

// See http://www.fftw.org/fftw3_doc/Multi_002dthreaded-FFTW.html to read
// documents for Multi-threaded FFTW

#include "tts/synthesizer/vocoder/lpc_vocoder/firfilter.h"

#include <fstream>
#ifdef TTS_USE_SSE4
#include <pmmintrin.h>
#endif // TTS_USE_SSE4

#include "tts/synthesizer/vocoder/lpc_vocoder/fir_coefficients.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/mutex.h"
#include "mobvoi/fft/fftw3.h"

namespace vocoder {

FirFilter::FirFilter(int overlap_times)
    : band_number_(5),
      filter_length_(41),
      overlap_(filter_length_ - 1),
      process_block_size_(overlap_ * overlap_times),
      hx_size_((process_block_size_ / 2) + 1) {
  VLOG(2) << "process_block_size_ : " << process_block_size_;
  // or set a nearby power-of-2 for process_block_size_
  step_size_ = process_block_size_ - overlap_;
  x_block_.resize(process_block_size_, 0);

  yt_.resize(process_block_size_);

  H_X_ = static_cast<fftwf_complex*>(
      fftwf_malloc(sizeof(fftwf_complex) * hx_size_));
  X_ = static_cast<fftwf_complex*>(
      fftwf_malloc(sizeof(fftwf_complex) * process_block_size_));
  // The planner routines share data (e.g. wisdom and trigonometric tables)
  // between calls and plans.
  // You should create/destroy plans only from a single thread,
  // but can safely execute multiple plans in parallel.
  plan_backward_ = fftwf_plan_dft_c2r_1d(process_block_size_, H_X_, yt_.data(),
                                         FFTW_ESTIMATE);
  plan_forward_ = fftwf_plan_dft_r2c_1d(process_block_size_, x_block_.data(),
                                        X_, FFTW_ESTIMATE);
  Hs_.resize(band_number_);
  for (int i = 0; i < band_number_; ++i) {
    Hs_[i] = ComputeFFTForH(kFirCoefficients[i], filter_length_);
  }
}

FirFilter::~FirFilter() {
  fftwf_free(H_X_);
  fftwf_free(X_);
  fftwf_destroy_plan(plan_backward_);
  fftwf_destroy_plan(plan_forward_);
  for (size_t i = 0; i < Hs_.size(); ++i) {
    fftwf_free(Hs_[i]);
  }
}

void FirFilter::DoConvolution(const vector<float>& input, int col_size,
                              float* output) const {
  for (int i = 0; i < band_number_; ++i) {
    OverlapSaveConvolution(input, Hs_[i], output + i * col_size);
  }
}

#ifdef TTS_USE_SSE4
void FirFilter::FastDoConvolution(const vector<float>& input, int col_size,
                                  float* output) const {
  for (int i = 0; i < band_number_; ++i) {
    FastOverlapSaveConvolution(input, Hs_[i], output + i * col_size);
  }
}
#endif // TTS_USE_SSE4

void FirFilter::DFT(float* x, int process_block_size_, fftwf_complex* X) {
  fftwf_plan plan_forward;
  plan_forward =
      fftwf_plan_dft_r2c_1d(process_block_size_, x, X, FFTW_ESTIMATE);
  fftwf_execute(plan_forward);
  fftwf_destroy_plan(plan_forward);
}

// TODO(spye) : Try to improve performance of this function?
inline void ComplexMultiply(fftwf_complex* H, fftwf_complex* X, int nc,
                            fftwf_complex* result) {
  // Set up frequency-multiplied complex array
  // original version:
  //  for (int i = 0; i < nc; ++i) {
  //    // Calculate real and imaginary components for the multiplied array
  //    result[i][0] = X[i][0] * H[i][0] - X[i][1] * H[i][1];  // real component
  //    result[i][1] = X[i][0] * H[i][1] + X[i][1] * H[i][0];  // imaginary
  //                                                           // component
  //  }

  // Unroll loop
  for (int i = 0; i < nc; i += 2) {
    // Calculate real and imaginary components for the multiplied array
    result[i][0] = X[i][0] * H[i][0] - X[i][1] * H[i][1];  // real component
    result[i][1] = X[i][0] * H[i][1] + X[i][1] * H[i][0];  // imaginary
                                                           // component
    result[i + 1][0] = X[i + 1][0] * H[i + 1][0] - X[i + 1][1] * H[i + 1][1];
    result[i + 1][1] = X[i + 1][0] * H[i + 1][1] + X[i + 1][1] * H[i + 1][0];
  }
  if (nc % 2 != 0) {
    result[nc - 1][0] =
        X[nc - 1][0] * H[nc - 1][0] - X[nc - 1][1] * H[nc - 1][1];
    result[nc - 1][1] =
        X[nc - 1][0] * H[nc - 1][1] + X[nc - 1][1] * H[nc - 1][0];
  }
}

fftwf_complex* FirFilter::ComputeFFTForH(const float* h, int h_size) {
  fftwf_complex* H = static_cast<fftwf_complex*>(
      fftwf_malloc(sizeof(fftwf_complex) * process_block_size_));

  // Padding with zero
  float* h_padded =
      static_cast<float*>(fftwf_malloc(sizeof(float) * process_block_size_));
  for (int i = 0; i < filter_length_; ++i) {
    h_padded[i] = h[i];
  }
  for (int i = filter_length_; i < process_block_size_; ++i) {
    h_padded[i] = 0.0f;
  }
  DFT(h_padded, process_block_size_, H);
  fftwf_free(h_padded);
  return H;
}

void FirFilter::OverlapSaveConvolution(const vector<float>& x, fftwf_complex* H,
                                       float* y) const {
  // See https://en.wikipedia.org/wiki/Overlap%E2%80%93save_method
  // (Overlap–save algorithm for linear convolution)

  // Since process_block_size_ is const var, malloc memory in stack.
  float x_block[process_block_size_];  // NOLINT
  fftwf_complex X[process_block_size_];
  fftwf_complex H_X[hx_size_];

  int position = 0;
  while (position + process_block_size_ <= static_cast<int>(x.size())) {
    memcpy(x_block, x.data() + position, sizeof(float) * process_block_size_);
    fftwf_execute_dft_r2c(plan_forward_, x_block, X);
    ComplexMultiply(H, X, hx_size_, H_X);
    fftwf_execute_dft_c2r(plan_backward_, H_X, x_block);
    // FIXME(spye): Try to unroll this loop.
    for (int i = filter_length_ - 1; i < process_block_size_; ++i) {
      int index = position + i;
      *(y + index) = x_block[i] / process_block_size_;
    }
    position += step_size_;
  }
}

#ifdef TTS_USE_SSE4
inline void FastMultipleSSE(const float* v1, const float* v2, const size_t size,
                            float* v3) {
  const float* v1_data = v1;
  float* v3_data = v3;
  const float* v1_data_end = v1 + size;

  // b2 is const var.
  const __m128 b2 = _mm_load_ps(v2);
  for (; v1_data + 4 <= v1_data_end; v1_data += 4, v3_data += 4) {
    const __m128 b1 = _mm_load_ps(v1_data);
    __m128 mul = _mm_mul_ps(b1, b2);
    _mm_store_ps(v3_data, mul);
  }
}

void FirFilter::FastOverlapSaveConvolution(const vector<float>& x,
                                           fftwf_complex* H, float* y) const {
  // See https://en.wikipedia.org/wiki/Overlap%E2%80%93save_method
  // (Overlap–save algorithm for linear convolution)

  // Since process_block_size_ is const var, malloc memory in stack.
  float x_block[process_block_size_];  // NOLINT
  fftwf_complex X[process_block_size_];
  fftwf_complex H_X[hx_size_];

  const float factor = 1.0f / process_block_size_;
  static const float B[4] = {factor, factor, factor, factor};
  int position = 0;
  while (position + process_block_size_ <= static_cast<int>(x.size())) {
    memcpy(x_block, x.data() + position, sizeof(float) * process_block_size_);
    // TODO(spye): Check fftw using neon & sse or even avx2.
    fftwf_execute_dft_r2c(plan_forward_, x_block, X);
    ComplexMultiply(H, X, hx_size_, H_X);
    fftwf_execute_dft_c2r(plan_backward_, H_X, x_block);

    DCHECK_EQ((process_block_size_ - filter_length_ + 1) % 4, 0);
    float* out = y + position + filter_length_ - 1;
    float* A = &x_block[filter_length_ - 1];
    FastMultipleSSE(A, B, process_block_size_ - filter_length_ + 1, out);
    position += step_size_;
  }
}
#endif // TTS_USE_SSE4
// TODO(spye): Implement neon version.
}  // namespace vocoder
