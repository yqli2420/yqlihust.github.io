// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_SYNTHESIZER_VOCODER_LPC_VOCODER_FIRFILTER_H_
#define TTS_SYNTHESIZER_VOCODER_LPC_VOCODER_FIRFILTER_H_

#include <vector>

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/fft/fftw3.h"
#include "third_party/gtest/gtest_prod.h"

DECLARE_int32(fir_process_block_overlap_times);

namespace vocoder {
// See project https://github.com/seansowr/Code-Sample
// for reference.

// http://www.fftw.org/fftw3_doc/Usage-of-Multi_002dthreaded-FFTW.html#Usage-of-Multi_002dthreaded-FFTW
// NOTE: Fir filter use fftw, since fftw is not thread-safe, in order to use
// FirFilter in multi-threads env, Follow below steps:
// First, programs using the parallel complex transforms should be linked with
// -lfftw3_threads -lfftw3 -lm on Unix, or -lfftw3_omp -lfftw3 -lm if you
// compiled with OpenMP. You will also need to link with whatever library is
// responsible for threads on your system (e.g. -lpthread on GNU/Linux) or
// include whatever compiler flag enables OpenMP (e.g. -fopenmp with gcc).
// Second, before calling any FFTW routines, you should call the function:
// int fftw_init_threads(void);
// Third, before creating a plan that you want to parallelize, you should call:
// void fftw_plan_with_nthreads(int nthreads);

class FirFilter {
 public:
  explicit FirFilter(int overlap_times);
  ~FirFilter();

  void DoConvolution(const vector<float>& input, int col_size,
                     float* output) const;

#ifdef TTS_USE_SSE4
  void FastDoConvolution(const vector<float>& input, int col_size,
                         float* output) const;
#endif // TTS_USE_SSE4

  int band_number() const { return band_number_; }
  int overlap() const { return overlap_; }
  int length() const { return filter_length_; }

 private:
  void SlowConvolution(const vector<float>& input, const float* filter,
                       int filter_size, vector<float>* output);
  void OverlapSaveConvolution(const vector<float>& x, fftwf_complex* H,
                              float* y) const;
#ifdef TTS_USE_SSE4
  void FastOverlapSaveConvolution(const vector<float>& x, fftwf_complex* H,
                                  float* y) const;
#endif // TTS_USE_SSE4

  void DFT(float* x, int N, fftwf_complex* X);
  fftwf_complex* ComputeFFTForH(const float* h, int h_size);

  // Use const, tell compiler it can be unrolled.
  const int band_number_;
  int filter_length_;  // M

  // fft results for all fir coefficients
  vector<fftwf_complex*> Hs_;

  vector<float> x_block_;
  fftwf_complex* X_;
  fftwf_plan plan_forward_;

  const int overlap_;
  const int process_block_size_;  // N
  int step_size_;
  const int hx_size_;

  fftwf_complex* H_X_;
  vector<float> yt_;
  fftwf_plan plan_backward_;

  FRIEND_TEST(VocoderTest, FastFilter);
  DISALLOW_COPY_AND_ASSIGN(FirFilter);
};
}  // namespace vocoder
#endif  // TTS_SYNTHESIZER_VOCODER_LPC_VOCODER_FIRFILTER_H_
