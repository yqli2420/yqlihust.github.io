// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: yunlinchen@mobvoi.com (Yunlin Chen)

#include "mobvoi/base/file.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/time.h"

#include "tts/synthesizer/vocoder/melgan_vocoder/melgan_vocoder.h"
#include "tts/util/encoder/encoder.h"
#include "tts/util/tts_util/util.h"

DEFINE_string(
    model, "tts/synthesizer/vocoder/melgan_vocoder/testdata/melgan.chunk.one",
    "model file");
DEFINE_string(input,
              "tts/synthesizer/vocoder/melgan_vocoder/testdata/"
              "daohang_000039.npy.bin",  // NOLINT
              "input feature");
DEFINE_string(output, "out.wav", "");
DEFINE_int32(repeat_times, 1, "repeat times");
DEFINE_int32(mel_channel, 80, "melgan mel dims");

int main(int argc, char** argv) {
  google::ParseCommandLineFlags(&argc, &argv, false);

  FILE* fin = fopen(FLAGS_input.c_str(), "rb");
  CHECK(fin) << "Failed to open file : " << FLAGS_input;

  vocoder::MelGANVocoder vocoder(FLAGS_model);
  tts::TTSOption tts_option;
  tts::SetDefaultTTSOption(&tts_option);

  // Read in features.
  vector<float> features;
  while (true) {
    float in_features[FLAGS_mel_channel];
    ignore_result(
        fread(in_features, sizeof(in_features[0]), FLAGS_mel_channel, fin));
    features.insert(features.end(), in_features,
                    in_features + FLAGS_mel_channel);
    if (feof(fin)) break;
  }
  fclose(fin);

  int64 begin = mobvoi::GetTimeInMs();
  vector<int16> pcm;
  for (int i = 0; i < FLAGS_repeat_times; ++i) {
    pcm.clear();
    vocoder.Synthesize(features, tts_option, &pcm);
  }
  int64 end = mobvoi::GetTimeInMs();
  LOG(INFO) << "repeat times : " << FLAGS_repeat_times
            << ", perf (Ms per time): " << (end - begin) / FLAGS_repeat_times;

  encoder::PostProcessOption pp_option(tts::kDefaultSamplingFrequency, 16000,
                                       tts::kNoNormalizeFactor, 1.0, "wav");

  string data_res;
  encoder::PostProcess(pcm, pp_option, &data_res);
  mobvoi::File::WriteStringToFile(data_res, FLAGS_output);

  return 0;
}
