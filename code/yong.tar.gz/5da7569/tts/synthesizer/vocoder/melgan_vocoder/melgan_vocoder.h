// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: yunlinchen@mobvoi.com (Yunlin Chen)

#ifndef TTS_SYNTHESIZER_VOCODER_MELGAN_VOCODER_MELGAN_VOCODER_H_
#define TTS_SYNTHESIZER_VOCODER_MELGAN_VOCODER_MELGAN_VOCODER_H_

#include "third_party/one/melgan_model.h"

#include "tts/synthesizer/interface/synthesizer_event_interface.h"
#include "tts/synthesizer/vocoder/vocoder.h"
#include "tts/util/encoder/encoder.h"

namespace vocoder {

class MelGANVocoder : public Vocoder {
 public:
  explicit MelGANVocoder(const std::string& model_file);
  ~MelGANVocoder();

  bool Synthesize(const vector<float>& in_features,
                  const tts::TTSOption& tts_option,
                  vector<int16>* data) const override;

#ifndef FOR_PORTABLE
  bool Synthesize(const vector<float>& in_features,
                  const tts::TTSOption& tts_option, float speaker_volume,
                  encoder::FlacEncoder* encoder,
                  tts::SynthesizerEventInterface* callback) const override;
#endif

 private:
  std::unique_ptr<mobvoi::one::MelGANModel> model_;
};

}  // namespace vocoder

#endif  // TTS_SYNTHESIZER_VOCODER_MELGAN_VOCODER_MELGAN_VOCODER_H_
