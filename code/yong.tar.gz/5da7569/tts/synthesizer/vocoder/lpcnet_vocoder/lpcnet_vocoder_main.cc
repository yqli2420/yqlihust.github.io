// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: yunlinchen@mobvoi.com (Yunlin Chen)

#include "mobvoi/base/file.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/time.h"

#include "third_party/perftools/profiler.h"

#include "tts/synthesizer/vocoder/lpcnet_vocoder/arch.h"
#include "tts/synthesizer/vocoder/lpcnet_vocoder/freq.h"
#include "tts/synthesizer/vocoder/lpcnet_vocoder/lpcnet.h"
#include "tts/synthesizer/vocoder/lpcnet_vocoder/lpcnet_vocoder.h"
#include "tts/util/encoder/encoder.h"
#include "tts/util/tts_util/util.h"

DEFINE_string(model,
              "tts/synthesizer/vocoder/lpcnet_vocoder/testdata/lpcnet.pb",
              "model file");
DEFINE_string(input,
              "tts/synthesizer/vocoder/lpcnet_vocoder/testdata/"
              "speech-mel-daohang_000039.npy.bin",  // NOLINT
              "input feature");
DEFINE_string(output, "out.wav", "");
DEFINE_int32(repeat_times, 1, "repeat times");

int main(int argc, char** argv) {
  google::ParseCommandLineFlags(&argc, &argv, false);

  FILE* fin = fopen(FLAGS_input.c_str(), "rb");
  CHECK(fin) << "Failed to open file : " << FLAGS_input;

  vocoder::LpcNetVocoder vocoder(FLAGS_model);
  tts::TTSOption tts_option;

  // Read in features.
  vector<float> features;
  while (true) {
    float in_features[20];
    ignore_result(fread(in_features, sizeof(in_features[0]), 20, fin));
    features.insert(features.end(), in_features, in_features + 20);
    if (feof(fin)) break;
  }
  fclose(fin);

  ProfilerStart("lpcnet.cpu");
  int64 begin = mobvoi::GetTimeInMs();
  vector<short> pcm;
  for (int i = 0; i < FLAGS_repeat_times; ++i) {
    pcm.clear();
    vocoder.Synthesize(features, tts_option, &pcm);
  }
  int64 end = mobvoi::GetTimeInMs();
  ProfilerStop();
  LOG(INFO) << "repeat times : " << FLAGS_repeat_times
            << ", perf (Ms per time): " << (end - begin) / FLAGS_repeat_times;

  encoder::PostProcessOption pp_option(tts::kDefaultSamplingFrequency, 16000,
                                       tts::kNoNormalizeFactor, 1.0, "wav");

  string data_res;
  encoder::PostProcess(pcm, pp_option, &data_res);
  mobvoi::File::WriteStringToFile(data_res, FLAGS_output);

  return 0;
}
