// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: sxwang@mobvoi.com (Sixue Wang)

#include <malloc.h>
#include <cmath>
#include <limits>

#include "mobvoi/base/log.h"

extern "C" {
#include <immintrin.h>

static __m512 exp8_approx(__m512 X) {
  const __m512 K0 = _mm512_set1_ps(0.99992522f);
  const __m512 K1 = _mm512_set1_ps(0.69583354f);
  const __m512 K2 = _mm512_set1_ps(0.22606716f);
  const __m512 K3 = _mm512_set1_ps(0.078024523f);
  const __m512 log2_E = _mm512_set1_ps(1.44269504);
  const __m512 max_in = _mm512_set1_ps(50.f);
  const __m512 min_in = _mm512_set1_ps(-50.f);
  const __m512i mask = _mm512_set1_epi32(0x7fffffff);
  X = _mm512_mul_ps(X, log2_E);
  X = _mm512_max_ps(min_in, _mm512_min_ps(max_in, X));
  __m512 XF = _mm512_floor_ps(X);
  __m512i I = _mm512_cvtps_epi32(XF);
  X = _mm512_sub_ps(X, XF);
  __m512 Y = _mm512_fmadd_ps(_mm512_fmadd_ps(_mm512_fmadd_ps(K3, X, K2), X, K1),
                             X, K0);
  I = _mm512_slli_epi32(I, 23);
  Y = _mm512_castsi512_ps(
      _mm512_and_si512(mask, _mm512_add_epi32(I, _mm512_castps_si512(Y))));
  return Y;
}

static float celt_exp(float x) {
  float out[16];
  __m512 X = _mm512_set1_ps(x);
  __m512 Y = exp8_approx(X);
  _mm512_storeu_ps(out, Y);
  return out[0];
}

static void softmax(float *y, const float *x, int N) {
  int i;
  for (i = 0; i < N - 31; i += 32) {
    __m512 X1 = _mm512_load_ps(x);
    x += 16;
    __m512 X2 = _mm512_load_ps(x);
    x += 16;

    __m512 Y1 = exp8_approx(X1);
    __m512 Y2 = exp8_approx(X2);

    _mm512_store_ps(y, Y1);
    y += 16;
    _mm512_store_ps(y, Y2);
    y += 16;
  }
  for (; i < N; i++) y[i] = celt_exp(x[i]);
}

static void vec_tanh(float *y, const float *x, int N) {
  const __m512 two = _mm512_set1_ps(2.f);
  const __m512 one = _mm512_set1_ps(1.f);
  int i;
  for (i = 0; i < N - 31; i += 32) {
    __m512 X1 = _mm512_load_ps(x);
    x += 16;
    __m512 X2 = _mm512_load_ps(x);
    x += 16;

    X1 = _mm512_mul_ps(X1, two);
    X2 = _mm512_mul_ps(X2, two);

    __m512 Y1 = exp8_approx(X1);
    __m512 Y2 = exp8_approx(X2);

    Y1 = _mm512_mul_ps(_mm512_sub_ps(Y1, one),
                       _mm512_rcp14_ps(_mm512_add_ps(Y1, one)));
    Y2 = _mm512_mul_ps(_mm512_sub_ps(Y2, one),
                       _mm512_rcp14_ps(_mm512_add_ps(Y2, one)));

    _mm512_store_ps(y, Y1);
    y += 16;
    _mm512_store_ps(y, Y2);
    y += 16;
  }
  for (; i < N; i++) {
    float ex2 = celt_exp(2 * x[i]);
    y[i] = (ex2 - 1) / (ex2 + 1);
  }
}

static void vec_sigmoid(float *y, const float *x, int N) {
  static const __m512 one = _mm512_set1_ps(1.f);
  int i;
  for (i = 0; i < N - 31; i += 32) {
    __m512 X1 = _mm512_load_ps(x);
    x += 16;
    __m512 X2 = _mm512_load_ps(x);
    x += 16;

    __m512 Y1 = exp8_approx(X1);
    __m512 Y2 = exp8_approx(X2);

    Y1 = _mm512_mul_ps(Y1, _mm512_rcp14_ps(_mm512_add_ps(Y1, one)));
    Y2 = _mm512_mul_ps(Y2, _mm512_rcp14_ps(_mm512_add_ps(Y2, one)));

    _mm512_store_ps(y, Y1);
    y += 16;
    _mm512_store_ps(y, Y2);
    y += 16;
  }
  for (; i < N; i++) {
    float ex = celt_exp(x[i]);
    y[i] = (ex) / (ex + 1);
  }
}

static void GetMinMax(const float *x, const int size, float *min, float *max) {
  float tmp[16] MEM_ALIGN_64;
  int size31 = size - 31;
  *min = std::numeric_limits<float>::max();
  *max = std::numeric_limits<float>::min();
  __m512 mins0 = _mm512_set1_ps(*min);
  __m512 maxs0 = _mm512_set1_ps(*max);
  __m512 mins1 = _mm512_set1_ps(*min);
  __m512 maxs1 = _mm512_set1_ps(*max);
  int i = 0;
  for (; i < size31; i += 32, x += 32) {
    __m512 x0 = _mm512_load_ps(x);
    __m512 x1 = _mm512_load_ps(x + 16);
    mins0 = _mm512_min_ps(x0, mins0);
    maxs0 = _mm512_max_ps(x0, maxs0);
    mins1 = _mm512_min_ps(x1, mins1);
    maxs1 = _mm512_max_ps(x1, maxs1);
  }
  mins0 = _mm512_min_ps(mins0, mins1);
  _mm512_store_ps(tmp, mins0);
  for (int j = 0; j < 16; ++j) {
    *min = std::min(tmp[j], *min);
  }
  maxs0 = _mm512_max_ps(maxs0, maxs1);
  _mm512_store_ps(tmp, maxs0);
  for (int j = 0; j < 16; ++j) {
    *max = std::max(tmp[j], *max);
  }
  for (; i < size; ++i, ++x) {
    *min = std::min(*x, *min);
    *max = std::max(*x, *max);
  }
}

static void QuantFloat(const float *x, const int size, int8_t *y,
                       float *scale) {
  float min, max;
  GetMinMax(x, size, &min, &max);
  const float range = std::max(std::abs(min), std::abs(max));
  *scale = range / 127;
  const float scale_inv = 1.0f / *scale;

  const __m512i scale_512 = _mm512_set1_epi32(127);
  const __m512i scale_neg_512 = _mm512_set1_epi32(-127);
  const __m512 scale_inv_512 = _mm512_set1_ps(scale_inv);
  const __m512i permute =
      _mm512_set_epi32(15, 11, 7, 3, 14, 10, 6, 2, 13, 9, 5, 1, 12, 8, 4, 0);

  int size63 = size - 63;
  int i = 0;
  for (; i < size63; i += 64, x += 64, y += 64) {
    __m512 x0 = _mm512_load_ps(x);
    __m512 x1 = _mm512_load_ps(x + 16);
    __m512 x2 = _mm512_load_ps(x + 32);
    __m512 x3 = _mm512_load_ps(x + 48);

    __m512 m0 = _mm512_mul_ps(x0, scale_inv_512);
    __m512 m1 = _mm512_mul_ps(x1, scale_inv_512);
    __m512 m2 = _mm512_mul_ps(x2, scale_inv_512);
    __m512 m3 = _mm512_mul_ps(x3, scale_inv_512);

    __m512i qv0 = _mm512_cvtps_epi32(m0);
    __m512i qv1 = _mm512_cvtps_epi32(m1);
    __m512i qv2 = _mm512_cvtps_epi32(m2);
    __m512i qv3 = _mm512_cvtps_epi32(m3);

    qv0 = _mm512_min_epi32(scale_512, _mm512_max_epi32(scale_neg_512, qv0));
    qv1 = _mm512_min_epi32(scale_512, _mm512_max_epi32(scale_neg_512, qv1));
    qv2 = _mm512_min_epi32(scale_512, _mm512_max_epi32(scale_neg_512, qv2));
    qv3 = _mm512_min_epi32(scale_512, _mm512_max_epi32(scale_neg_512, qv3));

    __m512i qv01 = _mm512_packs_epi32(qv0, qv1);
    __m512i qv23 = _mm512_packs_epi32(qv2, qv3);

    qv01 = _mm512_packs_epi16(qv01, qv23);
    qv01 = _mm512_permutexvar_epi32(permute, qv01);

    _mm512_store_si512(y, qv01);
  }
  for (; i < size; ++i) {
    int32_t qv = static_cast<int32_t>(std::round(scale_inv * (*x++)));
    *y++ = std::min(127, std::max(-127, qv));
  }
}

static void quant_gemv_accum_row(float *out, const uint8_t *weights,
                                 const float *weights_scale, int rows, int cols,
                                 const float *x) {
  int16_t tmp[32] MEM_ALIGN_64;
  int8_t *x_int8 = (int8_t *)x;
  float x_scale;
  QuantFloat(x, cols, x_int8, &x_scale);
  for (int i = 0; i < rows; ++i) {
    __m512i sum32 = _mm512_setzero_si512();

    for (int j = 0; j < cols; j += 64, weights += 64) {
      __m512i x0 = _mm512_load_si512(x_int8 + j);
      __m512i w0 = _mm512_load_si512(weights);

      __m512i m0 = _mm512_maddubs_epi16(w0, x0);

      sum32 = _mm512_add_epi16(m0, sum32);
    }

    int sum = 0;
    _mm512_store_si512(tmp, sum32);
    for (int i = 0; i < 32; ++i) {
      sum += tmp[i];
    }
    out[i] += sum * x_scale * weights_scale[i];
  }
}

static void quant_gemv_accum_col(float *out, const uint8_t *weights,
                                 const float *weights_scale, int rows, int cols,
                                 const float *x) {
  int8_t *x_int8 = (int8_t *)x;
  float x_scale;
  QuantFloat(x, cols, x_int8, &x_scale);
  const __m512 x_scale_16 = _mm512_set1_ps(x_scale);
  int rows31 = rows - 31;
  for (int i = 0; i < rows31; i += 32, out += 32, weights_scale += 32) {
    __m512i sum32 = _mm512_setzero_si512();
    for (int j = 0; j < cols; j += 8, weights += 256) {
      __m512i x0 = _mm512_set1_epi16(x_int8[j]);
      __m512i x1 = _mm512_set1_epi16(x_int8[j + 2]);
      __m512i x2 = _mm512_set1_epi16(x_int8[j + 4]);
      __m512i x3 = _mm512_set1_epi16(x_int8[j + 6]);

      __m512i w0 = _mm512_load_si512(weights);
      __m512i w1 = _mm512_load_si512(weights + 64);
      __m512i w2 = _mm512_load_si512(weights + 128);
      __m512i w3 = _mm512_load_si512(weights + 192);

      __m512i m0 = _mm512_maddubs_epi16(w0, x0);
      __m512i m1 = _mm512_maddubs_epi16(w1, x1);
      __m512i m2 = _mm512_maddubs_epi16(w2, x2);
      __m512i m3 = _mm512_maddubs_epi16(w3, x3);

      m0 = _mm512_add_epi16(m0, m1);
      m2 = _mm512_add_epi16(m2, m3);
      m0 = _mm512_add_epi16(m0, m2);
      sum32 = _mm512_add_epi16(m0, sum32);
    }
    __m512 weights_scale_16 = _mm512_load_ps(weights_scale);
    __m512 out_16 = _mm512_load_ps(out);
    __m512 sum_16 = _mm512_cvtepi32_ps(
        _mm512_cvtepi16_epi32(_mm512_extracti32x8_epi32(sum32, 0)));
    sum_16 = _mm512_mul_ps(sum_16, x_scale_16);
    out_16 = _mm512_fmadd_ps(sum_16, weights_scale_16, out_16);
    _mm512_store_ps(out, out_16);

    weights_scale_16 = _mm512_load_ps(weights_scale + 16);
    out_16 = _mm512_load_ps(out + 16);
    sum_16 = _mm512_cvtepi32_ps(
        _mm512_cvtepi16_epi32(_mm512_extracti32x8_epi32(sum32, 1)));
    sum_16 = _mm512_mul_ps(sum_16, x_scale_16);
    out_16 = _mm512_fmadd_ps(sum_16, weights_scale_16, out_16);
    _mm512_store_ps(out + 16, out_16);
  }
}

void Test() {
  float *x = (float *)memalign(64, 64 * sizeof(float));
  int8_t *y = (int8_t *)memalign(64, 64 * sizeof(int8_t));
  for (int i = 0; i < 64; ++i) {
    x[i] = i;
  }
  float scale;
  QuantFloat(x, 64, y, &scale);
  for (int i = 0; i < 64; ++i) {
    int8_t gt =
        std::min(127, std::max(-127, (int)std::round(127.0 / (64 - 1) * i)));
    CHECK_EQ((int)y[i], (int)gt) << i;
  }
  uint8_t *w = (uint8_t *)memalign(64, 64 * sizeof(uint8_t));
  for (int i = 0; i < 64; ++i) {
    w[i] = i;
  }
  float sum = 0;
  for (int i = 0; i < 64; ++i) {
    sum += (float)(y[i]) * w[i];
  }
  sum *= scale * scale;
  float out;
  quant_gemv_accum_row(&out, w, &scale, 1, 64, x);
  CHECK_EQ(out, sum) << sum << " " << out;
}

static void sgemv_accum16(float *out, const float *weights, int rows, int cols,
                          int col_stride, const float *x) {
  if (rows % 64 == 0) {
    for (int i = 0; i < rows; i += 64, out += 64) {
      __m512 vy0 = _mm512_load_ps(out);
      __m512 vy1 = _mm512_load_ps(out + 16);
      __m512 vy2 = _mm512_load_ps(out + 32);
      __m512 vy3 = _mm512_load_ps(out + 48);
      for (int j = 0, offset = i; j < cols; j++, offset += col_stride) {
        __m512 vxj = _mm512_set1_ps(x[j]);

        __m512 vw0 = _mm512_load_ps(weights + offset);
        __m512 vw1 = _mm512_load_ps(weights + offset + 16);
        __m512 vw2 = _mm512_load_ps(weights + offset + 32);
        __m512 vw3 = _mm512_load_ps(weights + offset + 48);

        vy0 = _mm512_fmadd_ps(vw0, vxj, vy0);
        vy1 = _mm512_fmadd_ps(vw1, vxj, vy1);
        vy2 = _mm512_fmadd_ps(vw2, vxj, vy2);
        vy3 = _mm512_fmadd_ps(vw3, vxj, vy3);
      }
      _mm512_store_ps(out, vy0);
      _mm512_store_ps(out + 16, vy1);
      _mm512_store_ps(out + 32, vy2);
      _mm512_store_ps(out + 48, vy3);
    }
  } else if (rows == 48) {
    __m512 vy0 = _mm512_load_ps(out);
    __m512 vy1 = _mm512_load_ps(out + 16);
    __m512 vy2 = _mm512_load_ps(out + 32);
    for (int j = 0, offset = 0; j < cols; ++j, offset += col_stride) {
      __m512 vxj = _mm512_set1_ps(x[j]);

      __m512 vw0 = _mm512_load_ps(weights + offset);
      __m512 vw1 = _mm512_load_ps(weights + offset + 16);
      __m512 vw2 = _mm512_load_ps(weights + offset + 32);

      vy0 = _mm512_fmadd_ps(vw0, vxj, vy0);
      vy1 = _mm512_fmadd_ps(vw1, vxj, vy1);
      vy2 = _mm512_fmadd_ps(vw2, vxj, vy2);
    }
    _mm512_store_ps(out, vy0);
    _mm512_store_ps(out + 16, vy1);
    _mm512_store_ps(out + 32, vy2);
  } else {
    LOG(FATAL) << "Cannot do sgemv_accum16";
  }
}

static void sparse_sgemv_accum16(float *out, const float *weights, int rows,
                                 const int *idx, const float *x) {
  int rows16 = rows / 16;
  for (int i = 0; i < rows16; i += 3) {
    float *o1 = out + *idx++;
    float *o2 = out + *idx++;
    float *o3 = out + *idx++;
    __m512 vy0 = _mm512_load_ps(o1);
    __m512 vy1 = _mm512_load_ps(o2);
    __m512 vy2 = _mm512_load_ps(o3);

    int cols = *idx++;
    for (int j = 0; j < cols; j++, weights += 48) {
      __m512 vxj0 = _mm512_set1_ps(x[*idx++]);
      __m512 vxj1 = _mm512_set1_ps(x[*idx++]);
      __m512 vxj2 = _mm512_set1_ps(x[*idx++]);

      __m512 vw0 = _mm512_load_ps(weights);
      __m512 vw1 = _mm512_load_ps(weights + 16);
      __m512 vw2 = _mm512_load_ps(weights + 32);

      vy0 = _mm512_fmadd_ps(vw0, vxj0, vy0);
      vy1 = _mm512_fmadd_ps(vw1, vxj1, vy1);
      vy2 = _mm512_fmadd_ps(vw2, vxj2, vy2);
    }

    cols = *idx++;
    for (int j = 0; j < cols; ++j, weights += 16) {
      __m512 vxj0 = _mm512_set1_ps(x[*idx++]);
      __m512 vw0 = _mm512_load_ps(weights);
      vy0 = _mm512_fmadd_ps(vw0, vxj0, vy0);
    }
    _mm512_store_ps(o1, vy0);

    cols = *idx++;
    for (int j = 0; j < cols; ++j, weights += 16) {
      __m512 vxj1 = _mm512_set1_ps(x[*idx++]);
      __m512 vw1 = _mm512_load_ps(weights);
      vy1 = _mm512_fmadd_ps(vw1, vxj1, vy1);
    }
    _mm512_store_ps(o2, vy1);

    cols = *idx++;
    for (int j = 0; j < cols; ++j, weights += 16) {
      __m512 vxj2 = _mm512_set1_ps(x[*idx++]);
      __m512 vw2 = _mm512_load_ps(weights);
      vy2 = _mm512_fmadd_ps(vw2, vxj2, vy2);
    }
    _mm512_store_ps(o3, vy2);
  }
}

}  // extern "C"
