// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: hao.yin@mobvoi.com (Hao Yin)

#ifndef TTS_SYNTHESIZER_VOCODER_LPCNET_VOCODER_LPCNET_VOCODER_H_
#define TTS_SYNTHESIZER_VOCODER_LPCNET_VOCODER_LPCNET_VOCODER_H_

#include "tts/synthesizer/interface/synthesizer_event_interface.h"
#include "tts/synthesizer/vocoder/lpcnet_vocoder/lpcnet.h"
#include "tts/synthesizer/vocoder/vocoder.h"
#include "tts/util/encoder/encoder.h"

namespace vocoder {

class LpcNetVocoder : public Vocoder {
 public:
  explicit LpcNetVocoder(const std::string& model_file);
  ~LpcNetVocoder();

  bool Synthesize(const vector<float>& in_features,
                  const tts::TTSOption& tts_option,
                  vector<int16>* data) const override;

#ifndef FOR_PORTABLE
  bool Synthesize(const vector<float>& in_features,
                  const tts::TTSOption& tts_option, float speaker_volume,
                  encoder::FlacEncoder* encoder,
                  tts::SynthesizerEventInterface* callback) const override;
#endif

 private:
  LPCNetModel* model_;
  vector<float> sil_features_;
};

}  // namespace vocoder

#endif  // TTS_SYNTHESIZER_VOCODER_LPCNET_VOCODER_LPCNET_VOCODER_H_
