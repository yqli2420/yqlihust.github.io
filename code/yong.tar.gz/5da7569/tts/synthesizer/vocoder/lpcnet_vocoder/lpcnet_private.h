#include <stdio.h>
#include "celt_lpc.h"
#include "common.h"
#include "freq.h"
#include "lpcnet.h"
#include "nnet_data.h"

#ifndef LPCNET_PRIVATE_H
#define LPCNET_PRIVATE_H

extern "C" {

#define BITS_PER_CHAR 8

#define PITCH_MIN_PERIOD 32
#define PITCH_MAX_PERIOD 256

#define PITCH_FRAME_SIZE 320
#define PITCH_BUF_SIZE (PITCH_MAX_PERIOD + PITCH_FRAME_SIZE)

#define MULTI 4
#define MULTI_MASK (MULTI - 1)

#define FORBIDDEN_INTERP 7

#define FEATURES_DELAY (FEATURE_CONV1_DELAY + FEATURE_CONV2_DELAY)

struct LPCNetState {
  NNetState nnet;
  int last_exc;
  float last_sig[LPC_ORDER];
  float old_input[FEATURES_DELAY][FEATURE_CONV2_OUT_SIZE];
  float old_lpc[FEATURES_DELAY][LPC_ORDER];
  float old_gain[FEATURES_DELAY];
  int frame_count;
  float deemph_mem;
};

struct LPCNetModel {
  EmbeddingLayer gru_a_embed_sig;
  EmbeddingLayer gru_a_embed_pred;
  EmbeddingLayer gru_a_embed_exc;
  DenseLayer gru_a_dense_feature;
  EmbeddingLayer embed_pitch;
  Conv1DLayer feature_conv1;
  Conv1DLayer feature_conv2;
  DenseLayer feature_dense1;
  EmbeddingLayer embed_sig;
  DenseLayer feature_dense2;
  GRULayer gru_a;
  GRULayer gru_b;
  MDenseLayer dual_fc;
  SparseGRULayer sparse_gru_a;
};
}

#endif
