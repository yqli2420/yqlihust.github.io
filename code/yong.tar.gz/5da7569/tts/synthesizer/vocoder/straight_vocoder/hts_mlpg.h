// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng Yang)

#ifndef TTS_SYNTHESIZER_VOCODER_STRAIGHT_VOCODER_HTS_MLPG_H_
#define TTS_SYNTHESIZER_VOCODER_STRAIGHT_VOCODER_HTS_MLPG_H_

#include "tts/synthesizer/vocoder/straight_vocoder/hts_sp_sub.h"

#define WLEFT 0
#define WRIGHT 1

/* DWin: structure for regression window */
typedef class DWin_CLASS {
 public:
  int num;       /* number of static + deltas */
  int **width;   /* width [0..num-1][0(left) 1(right)] */
  float **coef; /* coefficient [0..num-1][length[0]..length[1]] */
  int max_L;     /* max {maxw[0], maxw[1]} */

  DWin_CLASS();
  DWin_CLASS(char *);
  ~DWin_CLASS();
} * DWin;

typedef class GVPDF_CLASS {
 public:
  float *mean;
  float *var;

  GVPDF_CLASS();
  GVPDF_CLASS(char *, int);
  ~GVPDF_CLASS();
} * GVPDF;

/* SMatrices: structure for matrices to generate sequence of speech parameter
 * vectors */
typedef class SMatrices_CLASS {
 public:
  float **R; /* W' U^-1 W  */
  float *r;  /* W' U^-1 mu */
  float *g;  /* for forward substitution */
  float *b;  /* for GV gradient */

  SMatrices_CLASS(const int, const int);
  ~SMatrices_CLASS();
  void clean(const int);
} * SMatrices;

/* PStream: structure for parameter generation setting */
typedef class PStream_CLASS {
 private:
  int vSize;    // vector size of observation vector (include static and dynamic
                // features)
  int dim;      /* vector size of static features */
  int T;        /* length */
  int width;    /* width of dynamic window */
  DWin dw;      /* dynamic window */
  SMatrices sm; /* matrices for parameter generation */
  float *vm;
  float *vv;

  void calc_R_and_r(const int);
  void Cholesky();
  void Cholesky_forward();
  void Cholesky_backward(const int);
  void calc_varstats(float **, const int, float *, float *);
  void calc_varstats(const int, float *, float *);
  void varconv(float **, const int, const float);
  void calc_grad(const int);
  void calc_vargrad(const int, const float, const float);
  void calc_stepNW(const int, const float, const float);
  void mlpg();

 public:
  float **mseq;  /* sequence of mean vector */
  float **ivseq; /* sequence of invarsed variance vector */
  float **par;   /* output parameter vector */

  PStream_CLASS(const int, const int, DWin, GVPDF);
  ~PStream_CLASS();
  void mlpgGrad(const int, const float, const float, const float, const int,
                const int);
  void mlpgGradNW(const int, const float, const float, const float,
                  const int, const int);
  int get_T();
  int get_dim();
} * PStream;

#endif  // TTS_SYNTHESIZER_VOCODER_STRAIGHT_VOCODER_HTS_MLPG_H_
