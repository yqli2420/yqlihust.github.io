// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng.yang)

#ifndef TTS_SYNTHESIZER_VOCODER_STRAIGHT_VOCODER_STRAIGHT_VOCODER_H_
#define TTS_SYNTHESIZER_VOCODER_STRAIGHT_VOCODER_STRAIGHT_VOCODER_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"

#include "tts/synthesizer/interface/synthesizer_event_interface.h"
#include "tts/synthesizer/vocoder/straight_vocoder/hts_global.h"
#include "tts/synthesizer/vocoder/vocoder.h"

namespace vocoder {

class StraightVocoder : public Vocoder {
 public:
  StraightVocoder(int sampling_rate, int frame_period);
  ~StraightVocoder();

  // NOTE: pitch is not log pitch.
  bool Synthesize(const std::vector<std::vector<float>>& _v_lf0,
                  const std::vector<std::vector<float>>& _v_mgc,
                  const std::vector<std::vector<float>>& _v_bap,
                  const std::vector<float>& _v_uv,
                  std::vector<int16>* data) const;

  bool Synthesize(const vector<float>& fea, const tts::TTSOption& tts_option,
                  vector<int16>* data) const override;
#ifndef FOR_PORTABLE
  bool Synthesize(const vector<float>& in_features,
                  const tts::TTSOption& tts_option, float speaker_volume,
                  encoder::FlacEncoder* encoder,
                  tts::SynthesizerEventInterface* callback) const override;
#endif

  bool SynthesizeFromFile(const std::string& f0_file,
                          const std::string& mgc_file,
                          const std::string& ap_file,
                          const std::string& wav_file) const;
  bool SynthesizeFeaFromFile(const std::string& f0_file,
                             const std::string& mgc_file,
                             const std::string& ap_file,
                             const std::string& wav_file) const;
  void ParseFeature(const vector<float>& fea, bool use_robot,
                    vector<float>* pitch, vector<vector<float>>* mgc,
                    vector<vector<float>>* bap) const;
  bool ReadBapFile(const char* bap_file, vector<vector<float>>* data) const;
  bool ReadMgcFile(const char* mgc_file, vector<vector<float>>* data) const;
  bool ReadLf0File(const char* lf0_file, vector<vector<float>>* data) const;

 private:
  unique_ptr<globalP_CLASS> gp_;
  int mgc_order_;
};

}  // namespace vocoder
#endif  // TTS_SYNTHESIZER_VOCODER_STRAIGHT_VOCODER_STRAIGHT_VOCODER_H_
