// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng Yang)

#include "tts/synthesizer/vocoder/straight_vocoder/hts_global.h"
#include "mobvoi/base/log.h"

globalP_CLASS::globalP_CLASS(char *cfgf) {
  if (cfgf == nullptr) {
    return;
  }
  // parse paramters from cfg file
  FILE *fp = fopen(cfgf, "rt");
  if (fp == nullptr) {
    return;
  }
  LOG(ERROR) << "globalP_CLASS: read configure file [hv.cfg] !\n";
  while (!feof(fp)) {
    char buff[1024] = {0};
    char param[512] = {0};
    char value[512] = {0};
    fgets(buff, 1024, fp);
    if (-1 == sscanf(buff, "%s", param) || param[0] == '#') {
      continue;
    }
    for (int i = 0; i < static_cast<int>(strlen(buff)); i++) {
      if (buff[i] == '=') {
        buff[i] = ' ';
      }
    }
    if (-1 == sscanf(buff, "%s%s", param, value)) {
      continue;
    }
    if (strlen(param) == 0 || strlen(value) == 0) {
      continue;
    }
    // paramters
    if (strcmp(param, "RATE") == 0) {
      RATE = atoi(value);
    } else if (strcmp(param, "FPERIOD") == 0) {
      FPERIOD = atoi(value);
    } else if (strcmp(param, "FFTLEN") == 0) {
      FFTLEN = atoi(value);
    } else if (strcmp(param, "RHO") == 0) {
      RHO = atof(value);
    } else if (strcmp(param, "VOL") == 0) {
      VOL = atof(value);
    } else if (strcmp(param, "ALPHA") == 0) {
      ALPHA = atof(value);
    } else if (strcmp(param, "GAMMA") == 0) {
      GAMMA = atof(value);
    } else if (strcmp(param, "F0_MEAN") == 0) {
      F0_MEAN = atof(value);
    } else if (strcmp(param, "F0_STD") == 0) {
      F0_STD = atof(value);
    } else if (strcmp(param, "BETA") == 0) {
      BETA = atof(value);
    } else if (strcmp(param, "UV") == 0) {
      UV = atof(value);
    } else if (strcmp(param, "LENGTH") == 0) {
      LENGTH = atof(value);
    } else if (strcmp(param, "sigp") == 0) {
      sigp = atof(value);
    } else if (strcmp(param, "rnd_flag") == 0) {
      rnd_flag = static_cast<bool>(atoi(value));
    } else if (strcmp(param, "frqbnd_rate") == 0) {
      frqbnd_rate = atof(value);
    } else {
      LOG(ERROR) << "globalP_CLASS: Unkown paramter ";
    }
  }
  fclose(fp);
  fp = nullptr;
}
