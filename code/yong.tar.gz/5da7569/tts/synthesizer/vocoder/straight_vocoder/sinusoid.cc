// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng Yang)

#include "tts/synthesizer/vocoder/straight_vocoder/sinusoid.h"

#include <vector>

#include "tts/synthesizer/vocoder/straight_vocoder/hts_sp_sub.h"

#define pi 3.1416
sin_config_CLASS::sin_config_CLASS() {
  FS = 16000;
  FRAMESIZE = 0.025;
  FRAMESHIFT = 0.0050;
  FFTLEN = 1024;
  ORDER = 80;
  MVF = 7800;
  MF0 = 60;
  SPECTYPE = 2;
  LNGAIN = 1;
  WINTYPE = 2;
  DEBUG = 1;
}

sin_config_CLASS::~sin_config_CLASS() {}

sinF_CLASS::sinF_CLASS(int nframe, sin_configP cfP) {
  this->nframe = nframe;
  this->cfp = *cfP;
  A = new float *[nframe];
  F = new float *[nframe];
  // P = new float *[nframe];
  // NA = new float *[nframe];
  // NF = new float *[nframe];
  // NP = new float *[nframe];
  sinF = new float[cfp.ORDER];
}
void sinF_CLASS::get_sinF() {
  int order = cfp.ORDER;
  int mvf = cfp.MVF;
  int minf0 = cfp.MF0;
  float m0 = 0;
  float m1 = 0;
  float it = 0;
  if (order >= 2 * mvf / minf0) {
    m0 = minf0;
    m1 = mvf;
    it = (m1 - m0) / order;
    sinF[0] = m0;
    for (int i = 1; i < order; i++) {
      sinF[i] = sinF[i - 1] + it;
    }
  }
  m0 = static_cast<float>(2595.0 * log10(1 + minf0 / 700.0));
  m1 = static_cast<float>(2595.0 * log10(1 + mvf / 700.0));
  it = (m1 - m0) / order;
  sinF[0] = m0;
  for (int i = 1; i < order; i++) {
    sinF[i] = sinF[i - 1] + it;
  }
  for (int i = 0; i < order; i++) {
    sinF[i] = 700 * (pow(10, sinF[i] / 2595) - 1);
  }
}
float sinF_CLASS::lagrange(float *x0, float *y0, float x, int sum) {
  float z = x;
  float s = 0;
  float p = 1.0;
  for (int k = 0; k < sum; k++) {
    p = 1.0;
    for (int j = 0; j < sum; j++) {
      if (j != k) {
        p = p * (z - x0[j]) / (x0[k] - x0[j]);
      }
    }
    s = p * y0[k] + s;
  }
  return s;
}
void sinF_CLASS::amplitude_interp(float *A, float *sinf, float *sina,
                                  float *F, int ln0, int rn0, int na) {
  // na:the length of every A and F
  // A: returned
  float f1;
  float sa[4];
  float sf[4];
  int sum = 0;
  int order = cfp.ORDER + 2;
  for (int i = 0; i < na; i++) {
    sum = 0;
    f1 = F[i];
    int j = 0;
    while (sinf[j] <= f1 && j <= order - 1) {
      j++;
    }
    j = j - 1;
    if (sinf[j] == f1) {
      A[i] = sina[j];
      continue;
    } else {
      if (j == 0) {
        int kk = 0;
        for (int k = j; k < j + 3; j++) {
          sa[kk] = sina[k];
          sf[kk] = sinf[k];
          sum++;
        }
      } else if (j == 1) {
        int kk = 0;
        for (int k = j - 1; k < j + 3; k++) {
          sa[kk] = sina[k];
          sf[kk] = sinf[k];
          kk++;
          sum++;
        }
      } else if (j == order - 2) {
        int kk = 0;
        for (int k = j - 1; k < j + 2; k++) {
          sa[kk] = sina[k];
          sf[kk] = sinf[k];
          kk++;
          sum++;
        }
      } else if (j == order - 1) {
        if (sinf[j] == f1) {
          A[i] = sina[j];
          continue;
        } else {
          int kk = 0;
          for (int k = j - 1; k < j + 1; k++) {
            sa[kk] = sina[k];
            sf[kk] = sinf[k];
            kk++;
            sum++;
          }
        }
      } else {
        int t = 0;
        for (int k = j - 1; k < j + 3 && k < order; k++) {
          sa[t] = sina[k];
          sf[t] = sinf[k];
          sum++;
          t++;
        }
      }

      A[i] = lagrange(sf, sa, f1, sum);
    }
  }
}
void sinF_CLASS::sin_decoder_i(float *a, float *f, float *sina, float *sinf,
                               float f0, int na) {
  float m = sina[0];
  int ln = 2, rn = 2;
  std::vector<float> sin_a(cfp.ORDER + 2);
  std::vector<float> sin_f(cfp.ORDER + 2);
  sin_a[0] = 0;
  sin_a[cfp.ORDER + 1] = 0;
  sin_f[0] = 0;
  sin_f[cfp.ORDER + 1] = cfp.MVF;
  for (int i = 1; i <= cfp.ORDER; i++) {
    sin_a[i] = sina[i];
    sin_f[i] = sinf[i - 1];
  }
  amplitude_interp(a, sin_f.data(), sin_a.data(), f, ln, rn, na);
  if (cfp.SPECTYPE != 2) {
    LOG(WARNING) << "Not support other spectype!";
  }
  if (cfp.LNGAIN) m = exp(m);
  for (int i = 0; i < na; i++) {
    a[i] = a[i] * m;
  }
}
void sinF_CLASS::sin_decoder(DMATRIX sinA, DVECTOR F0) {
  get_sinF();
  for (int i = 0; i < nframe; i++) {
    if (cfp.DEBUG) {
      LOG(WARNING) << "decoding frame = " << i;
    }
    float *sina = sinA->data[i].data();
    float f0 = F0->data[i];
    if (f0 <= 0) {
      f0 = 100;
    }
    float nh = cfp.MVF / f0;
    int na = floor(nh);
    A[i] = new float[na];
    F[i] = new float[na];
    F[i][0] = f0;
    for (int j = 1; j < na; j++) {
      F[i][j] = F[i][j - 1] + f0;
    }
    sin_decoder_i(A[i], F[i], sina, sinF, f0, na);
  }
}
DVECTOR sinF_CLASS::synthesize_sinusoid(DVECTOR F0) {
  int mvf = cfp.MVF;
  int fs = cfp.FS;
  const int framesize = floor(fs * cfp.FRAMESHIFT * 3);
  const int frameshift = floor(fs * cfp.FRAMESHIFT);
  const int frameoverlap = framesize - frameshift;
  std::vector<float> han(frameoverlap);
  std::vector<float> syspeech(nframe * frameshift + framesize);
  memset(syspeech.data(), 0, (nframe * frameshift + framesize) * sizeof(float));
  float *preA = nullptr;
  float *preF = nullptr;
  float *curA = nullptr;
  float *curF = nullptr;
  float f0 = 0;
  int curna = 0;
  bool uv = 0;
  int prena = 0;
  float a = 0, p = 0, w = 0;
  std::vector<float> curframe(framesize);
  memset(curframe.data(), 0, framesize * sizeof(float));
  std::vector<float>  preframe(framesize);
  memset(preframe.data(), 0, framesize * sizeof(float));
  std::vector<float>  left(framesize);
  memset(left.data(), 0, framesize * sizeof(float));
  std::vector<float>  preP(framesize);
  memset(preP.data(), 0, framesize * sizeof(float));
  std::vector<float>  curP(framesize);
  memset(curP.data(), 0, framesize * sizeof(float));
  DVECTOR wav;
  for (int i = 0; i < frameoverlap; i++) {
    han[i] = 0.5 * (1 - cos(0 + pi / (frameoverlap - 1.0) * i));
  }
  for (int ii = 0; ii < nframe; ii++) {
    memset(curframe.data(), 0, framesize * sizeof(float));
    f0 = F0->data[ii];
    if (f0 == 0) {
      if (ii > 0 && F0->data[ii - 1] > 0) {
        uv = 1;
        f0 = 100;
      } else {
        f0 = 100;
        uv = 0;
      }
    } else {
      uv = 1;
    }
    prena = curna;
    curna = static_cast<int>(floor(mvf / f0));
    curA = A[ii];
    curF = F[ii];
    for (int jj = 0; jj < curna; jj++) {
      a = curA[jj];
      w = curF[jj];
      if (uv == 0) {
        curP[jj] = pi * (2.0 * rand() / RAND_MAX - 1);  // NOLINT
        p = curP[jj];
      } else {
        int min = 100;
        int idx = -1;
        for (int tt = 0; tt < prena; tt++) {
          if (abs(w - preF[tt]) <= min) {
            min = abs(w - preF[tt]);
            idx = tt;
          }
        }
        if (idx == -1)
          p = -pi / 2;
        else
          p = preF[idx] * 2 * pi / fs * (frameshift - 1) + preP[idx];
        while (p > pi) p = p - 2 * pi;
        while (p < -pi) p = p + 2 * pi;
        curP[jj] = p;
      }
      a = exp(a);
      // calculate current frame of voice point
      w = w * 2 * pi / fs;
      // printf("ii:%d;jj:%d----a:%f;w:%f;p:%f\n", ii, jj, a, w, p);
      for (int i = 0; i < framesize; i++) {
        curframe[i] += a * cos(w * i + p);
      }
    }
    preA = curA;
    preF = curF;
    memset(preP.data(), 0, framesize * sizeof(float));
    for (int i = 0; i < curna; i++) {
      preP[i] = curP[i];
    }
    for (int k = 0; k < frameshift; k++) {
      syspeech[k + ii * frameshift] = preframe[k];
      preframe[k] = 0;
    }
    for (int k = frameoverlap; k < framesize; k++) {
      left[k] = curframe[k];
      curframe[k] = 0;
    }
    for (int k = 0; k < frameoverlap; k++) {
      preframe[k + frameshift] =
          preframe[k + frameshift] * (1 - han[k]) + curframe[k] * han[k];
    }
    for (int k = 0; k < frameoverlap; k++) {
      preframe[k] = preframe[k + frameshift];
    }
    for (int k = frameoverlap; k < framesize; k++) {
      preframe[k] = left[k];
    }
  }
  wav = new DVECTOR_CLASS(nframe * frameshift);
  for (int k = 0; k < (nframe - 1) * frameshift; k++) {
    wav->data[k] = syspeech[k + frameshift];
    if (k == (nframe - 1) * frameshift - 1) {
      k++;
      for (int kd = 0; kd < frameshift; kd++) wav->data[k + kd] = preframe[kd];
    }
  }
  wav->length = nframe * frameshift;
  return wav;
}
sinF_CLASS::~sinF_CLASS() {
  for (int i = 0; i < nframe; i++) {
    delete[] A[i];
    delete[] F[i];
  }
  delete[] A;
  delete[] F;
  delete[] sinF;
}
