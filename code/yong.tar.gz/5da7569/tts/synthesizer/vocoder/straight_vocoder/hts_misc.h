// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng Yang)

#ifndef TTS_SYNTHESIZER_VOCODER_STRAIGHT_VOCODER_HTS_MISC_H_
#define TTS_SYNTHESIZER_VOCODER_STRAIGHT_VOCODER_HTS_MISC_H_

#include <ctype.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>

#include "mobvoi/base/basictypes.h"

#define HTS_MAXBUFLEN 1024

typedef bool HTS_Boolean;
typedef enum { DUR, LF0, MCP, BAP, LF0GV, MCPGV, BAPGV } HTS_Mtype;
#define HTS_NUMMTYPE 7

/* ----- routines for file input/output -----*/
void HTS_Error(const int, const char *, ...);
FILE *HTS_Getfp(const char *, const char *);
void HTS_GetToken(FILE *, char *);

/* ----- routines for memory allocation/free -----*/
char* HTS_Calloc(const size_t, const size_t);
void HTS_Free(void *);
char *HTS_Strdup(const char *);
float *HTS_AllocVector(const int);
float **HTS_AllocMatrix(const int, const int);
void HTS_FreeVector(float *);
void HTS_FreeMatrix(float **, const int);

/* ----- Routines for reading from binary file ----- */
int HTS_Fread(void *, const int, const int, FILE *);

#endif  // TTS_SYNTHESIZER_VOCODER_STRAIGHT_VOCODER_HTS_MISC_H_
