// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng Yang)

#include "tts/synthesizer/vocoder/straight_vocoder/hts_vocoder.h"

#include <vector>

#if defined(__AVX2__)
#include <immintrin.h>
#elif (defined(__ARM_NEON) || defined(__ARM_NEON__))  // NOLINT
#include <arm_neon.h>
#endif

#include "tts/synthesizer/vocoder/straight_vocoder/hts_global.h"
#include "tts/synthesizer/vocoder/straight_vocoder/hts_misc.h"
#include "tts/synthesizer/vocoder/straight_vocoder/hts_sp_sub.h"

VocoderClass::VocoderClass(const int m, globalP gp) {
  order_ = m;
  iprd_ = IPERIOD;
  pd_ = PADEORDER;
  alpha_ = gp->ALPHA;
  aa_ = 1 - alpha_ * alpha_;
  gamma_ = gp->GAMMA;
  beta_ = gp->BETA;

  pade_[0] = 1.0;
  pade_[1] = 1.0;
  pade_[2] = 0.0;
  pade_[3] = 1.0;
  pade_[4] = 0.0;
  pade_[5] = 0.0;
  pade_[6] = 1.0;
  pade_[7] = 0.0;
  pade_[8] = 0.0;
  pade_[9] = 0.0;
  pade_[10] = 1.0;
  pade_[11] = 0.4999273;
  pade_[12] = 0.1067005;
  pade_[13] = 0.01170221;
  pade_[14] = 0.0005656279;
  pade_[15] = 1.0;
  pade_[16] = 0.4999391;
  pade_[17] = 0.1107098;
  pade_[18] = 0.01369984;
  pade_[19] = 0.0009564853;
  pade_[20] = 0.00003041721;

  ppade_ = &(pade_[pd_ * (pd_ + 1) / 2]);

  pb_ = reinterpret_cast<float*>(HTS_Calloc(
      3 * (order_ + 1) + 3 * (pd_ + 1) + pd_ * (order_ + 2), sizeof(float)));
  cb_ = pb_ + order_ + 1;
  binc_ = cb_ + order_ + 1;
  d1_ = binc_ + order_ + 1;

  /* for postfiltering */
  if (beta_ > 0.0 && order_ > 1) {
    irleng_ = IRLENG;
    pfmc_ = reinterpret_cast<float*>(
        HTS_Calloc((order_ + 1) + 2 * irleng_, sizeof(float)));
    pfcep_ = pfmc_ + order_ + 1;
    kpfcep_ = reinterpret_cast<float *>(HTS_Calloc(irleng_, sizeof(float)));
    pfir_ = pfcep_ + irleng_;
    pfd_ =
        reinterpret_cast<float *>(HTS_Calloc(irleng_, sizeof(float)));
  } else {
    pfmc_ = nullptr;
    pfcep_ = nullptr;
    kpfcep_ = nullptr;
    pfir_ = nullptr;
    pfd_ = nullptr;
  }
}

/* ClearVocoder: clear vocoder */
VocoderClass::~VocoderClass() {
  if (pfd_ != nullptr) {
    HTS_Free(pfd_);
    pfd_ = nullptr;
  }
  if (pfmc_ != nullptr) {
    HTS_Free(pfmc_);
    pfmc_ = nullptr;
  }
  HTS_Free(pb_);
  pb_ = nullptr;

  ppade_ = nullptr;
  cb_ = nullptr;
  binc_ = nullptr;
  d1_ = nullptr;
  pfcep_ = nullptr;
  kpfcep_ = nullptr;
  pfir_ = nullptr;
}

/* Movem: move */
void VocoderClass::Movem(float *a, float *b, int nitem) {
  if (a > b) {
    while (nitem--) *b++ = *a++;
  } else {
    a += nitem;
    b += nitem;
    while (nitem--) *--b = *--a;
  }
}

/* Mc2b: transform mel-cepstrum to MLSA digital fillter coefficients */
void VocoderClass::Mc2b(float *mc) {
  const float a = alpha_;
  int m = order_;

  cb_[m] = mc[m];
  for (m--; m >= 0; m--) cb_[m] = mc[m] - a * cb_[m + 1];

  return;
}

/* b2bc: transform MLSA digital Filter coefficients to mel-cepstrum */
void VocoderClass::B2mc() {
  const float a = alpha_;
  int m = order_;
  float d, o;

  d = pfmc_[m] = cb_[m];
  for (m--; m >= 0; m--) {
    o = cb_[m] + a * d;
    d = cb_[m];
    pfmc_[m] = o;
  }

  return;
}

/* Freqt: frequency transformation */
void VocoderClass::Freqt() {
  const float b = 1 - alpha_ * alpha_;
  memset(pfcep_, 0, sizeof(float) * irleng_);
  std::vector<float> tmp(irleng_);
  for (int i = order_; i >= 0; --i) {
    pfcep_[0] = pfmc_[i] - alpha_ * (pfd_[0] = pfcep_[0]);
    pfcep_[1] = b * pfd_[0] - alpha_ * (pfd_[1] = pfcep_[1]);
    memcpy(pfd_ + 2, pfcep_ + 2, (irleng_ - 2) * sizeof(float));
#if (defined(__ARM_NEON) || defined(__ARM_NEON__))  // NOLINT
    const float32x4_t a4 = vmovq_n_f32(-alpha_);
    int n16 = ((irleng_ - 2) & (-16)) + 2;
    int offset = 2;
    for (; offset < n16; offset += 16) {
      float32x4_t pfd_shift0 = vld1q_f32(pfd_ + offset - 1);
      float32x4_t pfd_shift1 = vld1q_f32(pfd_ + offset + 4 - 1);
      float32x4_t pfd_shift2 = vld1q_f32(pfd_ + offset + 8 - 1);
      float32x4_t pfd_shift3 = vld1q_f32(pfd_ + offset + 12 - 1);

      float32x4_t pfg0 = vld1q_f32(pfcep_ + offset);
      float32x4_t pfg1 = vld1q_f32(pfcep_ + offset + 4);
      float32x4_t pfg2 = vld1q_f32(pfcep_ + offset + 8);
      float32x4_t pfg3 = vld1q_f32(pfcep_ + offset + 12);

      pfg0 = vmulq_f32(a4, pfg0);
      pfg1 = vmulq_f32(a4, pfg1);
      pfg2 = vmulq_f32(a4, pfg2);
      pfg3 = vmulq_f32(a4, pfg3);

      pfd_shift0 = vaddq_f32(pfd_shift0, pfg0);
      pfd_shift1 = vaddq_f32(pfd_shift1, pfg1);
      pfd_shift2 = vaddq_f32(pfd_shift2, pfg2);
      pfd_shift3 = vaddq_f32(pfd_shift3, pfg3);

      vst1q_f32(tmp.data() + offset, pfd_shift0);
      vst1q_f32(tmp.data() + offset + 4, pfd_shift1);
      vst1q_f32(tmp.data() + offset + 8, pfd_shift2);
      vst1q_f32(tmp.data() + offset + 12, pfd_shift3);
    }
    for (; offset < irleng_; ++offset) {
      tmp[offset] = pfd_[offset - 1] - alpha_ * pfcep_[offset];
    }
#else
    for (int j = 2; j < irleng_; ++j) {
      tmp[j] = pfd_[j - 1] - alpha_ * pfcep_[j];
    }
#endif
    int n8 = ((irleng_ - 2) & (-8)) + 2;
    int j = 2;
    for (; j < n8; j += 8) {
      pfcep_[j] = tmp[j] + alpha_ * pfcep_[j - 1];
      pfcep_[j + 1] = tmp[j + 1] + alpha_ * pfcep_[j];
      pfcep_[j + 2] = tmp[j + 2] + alpha_ * pfcep_[j + 1];
      pfcep_[j + 3] = tmp[j + 3] + alpha_ * pfcep_[j + 2];
      pfcep_[j + 4] = tmp[j + 4] + alpha_ * pfcep_[j + 3];
      pfcep_[j + 5] = tmp[j + 5] + alpha_ * pfcep_[j + 4];
      pfcep_[j + 6] = tmp[j + 6] + alpha_ * pfcep_[j + 5];
      pfcep_[j + 7] = tmp[j + 7] + alpha_ * pfcep_[j + 6];
    }
    for (; j < irleng_; ++j) {
      pfcep_[j] = tmp[j] + alpha_ * pfcep_[j - 1];
    }
  }
}

#if (defined(__ARM_NEON) || defined(__ARM_NEON__))  // NOLINT
float32x4_t Reverse(float* input_ptr) {
  float32x4_t inp = vld1q_f32(input_ptr);
  inp = vrev64q_f32(inp);
  return vcombine_f32(vget_high_f32(inp), vget_low_f32(inp));
}
#endif

/* C2ir: The minimum phase impulse response is evaluated from the minimum phase
 * cepstrum */
float VocoderClass::C2ir() {
  pfir_[0] = exp(pfcep_[0]);
  float en = pfir_[0] * pfir_[0];

  for (int k = 1; k < irleng_; ++k) {
    kpfcep_[k] = k* pfcep_[k];
  }
  for (int n = 1; n < irleng_; ++n) {
    float d = 0;
#if (defined(__ARM_NEON) || defined(__ARM_NEON__))  // NOLINT
    if (n >=16) {
      int n16 = (n & (-16)) + 1;
      int offset = 1;

      float32x4_t sum0 = vmovq_n_f32(0.0);
      float32x4_t sum1 = vmovq_n_f32(0.0);
      float32x4_t sum2 = vmovq_n_f32(0.0);
      float32x4_t sum3 = vmovq_n_f32(0.0);
      for (; offset < n16; offset += 16) {
        float32x4_t kpfcep0 = vld1q_f32(kpfcep_ + offset);
        float32x4_t kpfcep1 = vld1q_f32(kpfcep_ + offset + 4);
        float32x4_t kpfcep2 = vld1q_f32(kpfcep_ + offset + 8);
        float32x4_t kpfcep3 = vld1q_f32(kpfcep_ + offset + 12);

        float32x4_t pfir0 = Reverse(pfir_ + n - offset - 3);
        float32x4_t pfir1 = Reverse(pfir_ + n - offset - 7);
        float32x4_t pfir2 = Reverse(pfir_ + n - offset - 11);
        float32x4_t pfir3 = Reverse(pfir_ + n - offset - 15);

        sum0 = vmlaq_f32(sum0, kpfcep0, pfir0);
        sum1 = vmlaq_f32(sum1, kpfcep1, pfir1);
        sum2 = vmlaq_f32(sum2, kpfcep2, pfir2);
        sum3 = vmlaq_f32(sum3, kpfcep3, pfir3);
      }
      for (int i = 0; i < 4; ++i) {
        d += sum0[i];
        d += sum1[i];
        d += sum2[i];
        d += sum3[i];
      }
      for (; offset <=n; ++offset) {
        d += kpfcep_[offset] * pfir_[n - offset];
      }
    } else {
      for (int k = 1; k <= n; ++k) d += kpfcep_[k] * pfir_[n - k];
    }
#else
    for (int k = 1; k <= n; ++k) d += kpfcep_[k] * pfir_[n - k];
#endif
    pfir_[n] = d / n;
    en += pfir_[n] * pfir_[n];
  }
  return en;
}

float VocoderClass::B2en() {
  B2mc();   // cb_ -> pfmc_
  Freqt();  // pfmc_ -> pfcep_
  return C2ir();   // pfcep_ -> pfir_
}

// postfiltering
void VocoderClass::PostFilter(float *mc) {
  int k;
  float e1, e2;

  e1 = B2en();
  cb_[1] -= beta_ * alpha_ * mc[2];
  for (k = 2; k <= order_; k++) cb_[k] *= (1.0 + beta_);
  e2 = B2en();
  cb_[0] += log(e1 / e2) / 2;
  for (k = 0; k <= order_; k++) mc[k] = pfmc_[k];
}

float SimdfMadd(const float *a, const float *b, unsigned int length) {
  int i;
  float y = 0.0;

// TODO(xipeng) avx512 implement
/*
#if defined (__AVX512F__)
  int four_stop = length - (length - 2) % 8;
  __m512d sum = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
  for (i = 2; i < four_stop; i += 8) {
    __m512d va = _mm512_loadu_pd(&a[i]);
    __m512d vb = _mm512_loadu_pd(&b[i]);
    sum = _mm512_fmadd_pd(va, vb, sum);
  }
  for (int i = 0; i < 8; ++i) y += sum[i];
  for (i = four_stop; i <= length; i++) y += a[i] * b[i];
*/
#if defined(__AVX2__)
  int n8 = length - (length - 2) % 8;
  // std::vector to hold partial sums
  __m256 sum = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
  for (i = 2; i < n8; i += 8) {
    auto va = _mm256_loadu_ps(&a[i]);
    auto vb = _mm256_loadu_ps(&b[i]);
    sum = _mm256_fmadd_ps(va, vb, sum);
  }
  for (i = 0; i < 8; i++) y += sum[i];
  for (i = n8; i <= length; i++) y += a[i] * b[i];
#elif (defined(__ARM_NEON) || defined(__ARM_NEON__))  // NOLINT
  int offset = 0;
  int n4 = (length - 2) & (-4);
  const float *a_start = a + 2;
  const float *b_start = b + 2;
  float32x4_t result = vmovq_n_f32(0.0);
  for (; offset < n4; offset += 4) {
    float32x4_t a0 = vld1q_f32(a_start + offset);
    float32x4_t b0 = vld1q_f32(b_start + offset);
    float32x4_t mul0 = vmulq_f32(a0, b0);
    result = vaddq_f32(result, mul0);
  }
  y += result[0];
  y += result[1];
  y += result[2];
  y += result[3];
  for (; offset <= length - 2; ++offset) {
    y += a_start[offset] * b_start[offset];
  }
#else
  for (i = 2; i <= length; i++) y += a[i] * b[i];
#endif
  return y;
}

float VocoderClass::MlsaFir(const float x, float *d) {
  d[0] = x;
  d[1] = aa_ * d[0] + alpha_ * d[1];

  std::vector<float> da(order_ + 1);
#if (defined(__ARM_NEON) || defined(__ARM_NEON__))  // NOLINT
  const float32x4_t a4 = vmovq_n_f32(alpha_);
  int n16 = ((order_ + 1 - 2) & (-16)) + 2;
  int offset = 2;
  for (; offset < n16; offset += 16) {
    float32x4_t d0 = vld1q_f32(d + offset);
    float32x4_t d1 = vld1q_f32(d + offset + 4);
    float32x4_t d2 = vld1q_f32(d + offset + 8);
    float32x4_t d3 = vld1q_f32(d + offset + 12);

    float32x4_t d_shift0 = vld1q_f32(d + 1 + offset);
    float32x4_t d_shift1 = vld1q_f32(d + 1 + offset + 4);
    float32x4_t d_shift2 = vld1q_f32(d + 1 + offset + 8);
    float32x4_t d_shift3 = vld1q_f32(d + 1 + offset + 12);

    d_shift0 = vmulq_f32(a4, d_shift0);
    d_shift1 = vmulq_f32(a4, d_shift1);
    d_shift2 = vmulq_f32(a4, d_shift2);
    d_shift3 = vmulq_f32(a4, d_shift3);

    d0 = vaddq_f32(d0, d_shift0);
    d1 = vaddq_f32(d1, d_shift1);
    d2 = vaddq_f32(d2, d_shift2);
    d3 = vaddq_f32(d3, d_shift3);

    vst1q_f32(da.data() + offset, d0);
    vst1q_f32(da.data() + offset + 4, d1);
    vst1q_f32(da.data() + offset + 8, d2);
    vst1q_f32(da.data() + offset + 12, d3);
  }
  for (; offset <=order_; ++offset) {
    da[offset] = alpha_ * d[offset + 1] + d[offset];
  }
#else
  for (int i = 2; i <= order_; ++i) {
    da[i] = alpha_ * d[i+1] + d[i];
  }
#endif
  int n8 = ((order_ + 1 - 2) & (-8)) + 2;
  int i = 2;
  for (; i < n8; i += 8) {
    d[i] = da[i] - alpha_ * d[i - 1];
    d[i + 1] = da[i + 1] - alpha_ * d[i];
    d[i + 2] = da[i + 2] - alpha_ * d[i + 1];
    d[i + 3] = da[i + 3] - alpha_ * d[i + 2];
    d[i + 4] = da[i + 4] - alpha_ * d[i + 3];
    d[i + 5] = da[i + 5] - alpha_ * d[i + 4];
    d[i + 6] = da[i + 6] - alpha_ * d[i + 5];
    d[i + 7] = da[i + 7] - alpha_ * d[i + 6];
  }
  for (; i <= order_; ++i) {
    d[i] = da[i] - alpha_ * d[i - 1];
  }
  float y = 0.0;
  y = SimdfMadd(d, pb_, order_);
#if (defined(__ARM_NEON) || defined(__ARM_NEON__))  // NOLINT
  i = order_ - 7;
  for (; i > order_ % 8; i -= 8) {
    float32x4_t a0 = vld1q_f32(d + i);
    float32x4_t a1 = vld1q_f32(d + i + 4);
    vst1q_f32(d + i + 4 + 1, a1);
    vst1q_f32(d + i + 1, a0);
  }
  i += 8;
  for (; i >= 1; --i) d[i + 1] = d[i];
#else
  for (int i = order_ + 1; i > 1; --i) d[i] = d[i - 1];
#endif
  return y;
}

float VocoderClass::MlsaDf1(float x, float *d) {
  const float a = alpha_;
  const float aa = 1 - alpha_ * alpha_;
  float v, out = 0.0, *pt;
  int i;

  pt = &d[pd_ + 1];

  for (i = pd_; i >= 1; i--) {
    d[i] = aa * pt[i - 1] + a * d[i];
    pt[i] = d[i] * pb_[1];
    v = pt[i] * ppade_[i];
    x += (1 & i) ? v : -v;
    out += v;
  }

  pt[0] = x;
  out += x;

  return (out);
}

float VocoderClass::MlsaDf2(float x, float *d) {
  const int m = order_;
  float v, out = 0.0, *pt;
  int i;

  pt = &d[pd_ * (m + 2)];

  for (i = pd_; i >= 1; i--) {
    pt[i] = MlsaFir(pt[i - 1], &d[(i - 1) * (m + 2)]);
    v = pt[i] * ppade_[i];
    x += (1 & i) ? v : -v;
    out += v;
  }

  pt[0] = x;
  out += x;

  return (out);
}

float VocoderClass::MlsaDf(float x) {
  x = MlsaDf1(x, d1_);
  x = MlsaDf2(x, &d1_[2 * (pd_ + 1)]);

  return (x);
}

/* Vocoder: excitation signal and MLSA filster based waveform synthesis */
void VocoderClass::MlsaFilter(float *x, float *mc, int len, FILE *rawfp) {
  int i, j, k;
  int16 xs;

  const int m = order_;

  Mc2b(mc);

  /* postfiltering */
  if (pfmc_ != nullptr && pfd_ != nullptr) PostFilter(mc);

  for (k = 0; k <= m; k++)
    binc_[k] =
        (cb_[k] - pb_[k]) * static_cast<float>(iprd_) / static_cast<float>(len);

  for (j = 0, i = (iprd_ + 1) / 2; j < len; j++) {
    x[j] *= exp(pb_[0]);
    x[j] = MlsaDf(x[j]);

    if (rawfp != nullptr) {
      xs = static_cast<int16>(x[j]);
      fwrite(&xs, sizeof(int16), 1, rawfp);
      fflush(stdout);
    }

    if (!--i) {
      for (k = 0; k <= m; k++) pb_[k] += binc_[k];
      i = iprd_;
    }
  }

  Movem(cb_, pb_, m + 1);
}
void VocoderClass::Lsp2Lpc(float *lsp, float *lpc, const int m) {
/* 去掉m为奇数的情况，这样效率更快！ */
/* 假定m<=80，这样不用动态分配内存！ */
#define MH 40
  int i = 0;
  int k = 0;
  int mh = m >> 1;    /* m / 2 */
  float *f = lsp + 1; /* lsp[0]: loggain */
  float *a = lpc + 1;
  float p[MH] = {0}; /* m / 2 */
  float q[MH] = {0};
  float a0[MH + 1] = {0}; /* m / 2  + 1 */
  float a1[MH + 1] = {0};
  float a2[MH + 1] = {0};
  float b0[MH + 1] = {0};
  float b1[MH + 1] = {0};
  float b2[MH + 1] = {0};
  float xx, xf, xff;
#undef MH

  /* lsp Filter parameters */
  for (i = k = 0; i < mh; i++, k += 2) {
    p[i] = -2.0 * cos(f[k]);
    q[i] = -2.0 * cos(f[k + 1]);
  }

  /* impulse response of analysis Filter */
  xx = 1.0;
  xf = xff = 0.0;
  for (k = 0; k <= m; k++) {
    a0[0] = xx + xf;
    b0[0] = xx - xf;
    xf = xx;
    for (i = 0; i < mh; i++) {
      a0[i + 1] = a0[i] + p[i] * a1[i] + a2[i];
      a2[i] = a1[i];
      a1[i] = a0[i];

      b0[i + 1] = b0[i] + q[i] * b1[i] + b2[i];
      b2[i] = b1[i];
      b1[i] = b0[i];
    }
    a[k - 1] = (a0[mh] + b0[mh]) * 0.5;
    xx = 0.0;
  }
  *lpc = exp(*lsp);

  return;
}
float VocoderClass::PoleDf(float x) {
  int m = order_;
  for (m--; m > 0; m--) {
    x -= pb_[m + 1] * d1_[m];
    d1_[m] = d1_[m - 1];
  }
  x -= pb_[1] * d1_[0];
  d1_[0] = x;

  return (x);
}
void VocoderClass::PoleFilter(float *x, float *mc, int len, FILE *rawfp) {
  int i, j, k;
  const int m = order_;

  Lsp2Lpc(mc, cb_, m);

  for (k = 0; k <= m; k++)
    binc_[k] =
        (cb_[k] - pb_[k]) * static_cast<float>(iprd_) / static_cast<float>(len);

  for (j = 0, i = (iprd_ + 1) / 2; j < len; j++) {
    x[j] *= pb_[0];
    x[j] = PoleDf(x[j]);

    if (rawfp != nullptr) {
      int16 xs = static_cast<int16>(x[j]);
      fwrite(&xs, sizeof(int16), 1, rawfp);
      fflush(stdout);
    }
    if (!--i) {
      for (k = 0; k <= m; k++) pb_[k] += binc_[k];
      i = iprd_;
    }
  }

  Movem(cb_, pb_, m + 1);

  return;
}
void VocoderClass::Filter(float *x, float *mc, int len, FILE *rawfp) {
  if (alpha_ == 0.0 && gamma_ == -1) {
    PoleFilter(x, mc, len, rawfp);
  } else if (alpha_ >= 0 && gamma_ == 0) {
    MlsaFilter(x, mc, len, rawfp);
  } else {
    fprintf(
        stderr,
        "VocoderClass::Filter(): It is not support now, alpha_ = %f, gamma_ "
        "= %f\n",
        alpha_, gamma_);
    exit(1);
  }
}
/*************************************************/
/* MLSA filtering based on PSOLA-like processing */
/*************************************************/
SynthesisClass::SynthesisClass(int order, globalP gp) {
  if (gp->rnd_flag)
    rnd_flag_ = XTRUE;
  else
    rnd_flag_ = XFALSE;
  fprd_ = gp->FPERIOD;
  fs_ = static_cast<float>(gp->RATE);
  len_ = gp->FFTLEN;
  hlen_ = (len_ - 1) / 2;
  f0min_ = 70.0;
  float shiftm = static_cast<float>(fprd_ * 1000.0 / fs_);
  uvf0_ = 500.0 / shiftm;

  hann_ = new DVECTOR_CLASS(len_, 0.0);
  psres_ = new DVECTOR_CLASS(len_, 0.0);
  pulse_ = new DVECTOR_CLASS(len_, 0.0);
  noise_ = new DVECTOR_CLASS(len_, 0.0);
  vs_ = new VocoderClass(order, gp);
  if (rnd_flag_ == XTRUE)
    rphapf_ = new RphapfClass(fs_, len_);
  else
    rphapf_ = nullptr;
  volume_rate_ = gp->VOL;
  frqbnd_rate_ = gp->frqbnd_rate;
}

SynthesisClass::~SynthesisClass() {
  // memory free
  delete hann_;
  hann_ = nullptr;
  delete psres_;
  psres_ = nullptr;
  delete pulse_;
  pulse_ = nullptr;
  delete noise_;
  noise_ = nullptr;
  delete vs_;
  vs_ = nullptr;
  if (rnd_flag_ == XTRUE) {
    delete rphapf_;
    rphapf_ = nullptr;
  }
}

void SynthesisClass::HanNing(float *window, int64 length) {
  int64 k;
  float a;

  if (length <= 1) return;
  a = 2.0 * PI / static_cast<float>((length + 1));

  for (k = 1; k <= length; k++)
    window[k] = 0.5 - 0.5 * cos(a * static_cast<float>(k));
}

void SynthesisClass::HanNing(float *window, int64 length, int64 sidx,
                             int64 eidx) {
  int64 k;
  float a;

  if (length <= 1) return;
  a = 2.0 * PI / static_cast<float>((length + 1));

  for (k = sidx + 1; k <= eidx; k++)
    window[k] = 0.5 - 0.5 * cos(a * static_cast<float>(k));
}

void SynthesisClass::PShannWin(int64 t0p) {
  int64 wlen;

  memset(hann_->data, 0, len_ * sizeof(float));
  wlen = t0p * 2 + 1;
  if (wlen > len_) {
    t0p = hlen_;
    wlen = len_;
  }
  HanNing(&(hann_->data[hlen_ - t0p]), wlen);
}

void SynthesisClass::PShannWin(int64 pt0p, int64 t0p) {
  memset(hann_->data, 0, len_ * sizeof(float));
  // #if 0
  /*
    wlen = pt0p + t0p + 1;
    if (wlen > len_) {
            t0p = hlen_;
            wlen = len_;
            HanNing(&(hann_->data[hlen_ - t0p]), wlen);
    } else {
            HanNing(&(hann_->data[hlen_ - pt0p]), pt0p * 2 + 1, 0, pt0p);
            HanNing(&(hann_->data[hlen_ - t0p]), t0p * 2 + 1, t0p, t0p * 2 + 1);
    }
    */
  // #else
  if (hlen_ > pt0p) {
    HanNing(&(hann_->data[hlen_ - pt0p]), pt0p * 2 + 1, 0, pt0p);
  } else {
    HanNing(&(hann_->data[hlen_ - hlen_]), len_, 0, hlen_);
  }
  if (hlen_ > t0p) {
    HanNing(&(hann_->data[hlen_ - t0p]), t0p * 2 + 1, t0p, t0p * 2 + 1);
  } else {
    HanNing(&(hann_->data[hlen_ - hlen_]), len_, hlen_, len_);
  }
  // #endif
}

float SynthesisClass::Sigmoid(float x, float a, float b) {
  float s0, s1;
  s0 = 1.0 / (1.0 + exp(-1.0 * a * (0.0 - b)));
  s1 = 1.0 / (1.0 + exp(-1.0 * a * (1.0 - b)));

  return (1.0 / (1.0 + exp(-1.0 * a * (x - b))) - s0) / (s1 - s0);
}

// pitch-synchronous excitation
void SynthesisClass::PsresMixRndphs(DMATRIX bndap, int64 t, float sigp,
                                    int llen, int rlen, float fgain) {
  static int idx = 0;
  int64 k, kk, b, bs, be;
  float wnz, wpr;

  if (bndap != nullptr) {
    // pulse excitation in frequency domain
    pulse_->dvialloc();
    noise_->dvialloc(0.0);
    if (len_ == 1024) {
      idx = ++idx %
            (sizeof(pulse_all_real_1024) / sizeof(pulse_all_real_1024[0]));
      if (fs_ < 32000) idx = 0;
      for (k = 0; k < len_; k++) {
        pulse_->data[k] = pulse_all_real_1024[idx][k] * fgain;
        pulse_->imag[k] = pulse_all_imag_1024[idx][k] * fgain;
      }
      // #if 0
      /*			idx = random() %
         (sizeof(gnoise_real_1024)/sizeof(gnoise_real_1024[0]));
                              for(k = 0; k < len_; k ++){
                                      noise_->data[k] =
         gnoise_real_1024[idx][k];
                                      noise_->imag[k] =
         gnoise_imag_1024[idx][k];
                              }
            */
      // #endif
    } else if (len_ == 512) {
      idx =
          ++idx % (sizeof(pulse_all_real_512) / sizeof(pulse_all_real_512[0]));
      if (fs_ < 32000) idx = 0;
      for (k = 0; k < len_; k++) {
        pulse_->data[k] = pulse_all_real_512[idx][k] * fgain;
        pulse_->imag[k] = pulse_all_imag_512[idx][k] * fgain;
      }
      // #if 0
      /*		idx = random() %
         (sizeof(gnoise_real_512)/sizeof(gnoise_real_512[0]));
                      for(k = 0; k < len_; k ++){
                              noise_->data[k] = gnoise_real_512[idx][k];
                              noise_->imag[k] = gnoise_imag_512[idx][k];
                      } */
      // #endif
    } else {
      // pulse
      idx = random() % (sizeof(pulse_all) / sizeof(pulse_all[0]));
      if (fs_ < 32000) idx = 0;
      if (len_ > 1024) {
        kk = (len_ - 1024) / 2 - 1;
        for (k = 0; k < 1024; k++)
          pulse_->data[k + kk] = pulse_all[idx][k] * fgain;
      } else {
        kk = (1024 - len_) / 2 - 1;
        for (k = kk; k < kk + len_; k++)
          pulse_->data[k - kk] = pulse_all[idx][k] * fgain;
      }
      dvfft(pulse_);
      // #if 0
      // noise
      /*
kk = sizeof(gnoise) / sizeof(float);
      if(kk - rlen * 2 - 10 > 0) idx = random() % (kk - rlen * 2 - 10);
      else idx = 0;
      if(hlen_ < rlen) {
              for (k = 0; k < len_; k++)
                      noise_->data[k] = gnoise[idx + k];
      }else{
              for (k = 0; k < len_; k++)
                      noise_->data[k] = 0;
              for (k = 0; k < 2 * rlen; k++)
                      noise_->data[hlen_ - rlen + k] = gnoise[idx + k];
      }
      dvfft(noise_);
*/
      // #endif
    }
    // noise
    kk = sizeof(gnoise) / sizeof(float);
    if (kk - rlen * 2 - 10 > 0)
      idx = random() % (kk - rlen * 2 - 10);
    else
      idx = 0;
    if (hlen_ < rlen) {
      memcpy(noise_->data, gnoise + idx, len_ * sizeof(float));
    } else {
      memset(noise_->data, 0, len_ * sizeof(float));
      memcpy(noise_->data + hlen_ - rlen,
          gnoise + idx, 2 * rlen * sizeof(float));
    }
    dvfft(noise_);
    if (rnd_flag_ == XFALSE) {
      memset(pulse_->data, 0, len_ * sizeof(float));
      memset(pulse_->imag, 0, len_ * sizeof(float));
      pulse_->data[hlen_] = fgain;
      dvfft(pulse_);
    }

    // noize excitation in frequency domain
    for (b = 0; b < bndap->col && t < bndap->row; b++) {
      // frequency bands
      if (bndap->col == 5) {
        if (b == 0) {
          bs = 0;
          be = len_ / 16;
        } else if (b == 1) {
          bs = len_ / 16;
          be = len_ / 8;
        } else if (b == 2) {
          bs = len_ / 8;
          be = len_ / 4;
        } else if (b == 3) {
          bs = len_ / 4;
          be = len_ * 3 / 8;
        } else {
          bs = len_ * 3 / 8;
          be = len_ / 2 + 1;
        }
      } else if (bndap->col == 26) {
        static const float bapcfg[] = {
            0,          0.003333, 0.003333, 0.00416667, 0.00416667, 0.00520833,
            0.00520833, 0.006667, 0.006667, 0.008334,   0.008334,   0.010416,
            0.010416,   0.013125, 0.013125, 0.016667,   0.016667,   0.020833,
            0.020833,   0.02625,  0.02625,  0.033334,   0.033334,   0.041667,
            0.041667,   0.052083, 0.052083, 0.066667,   0.066667,   0.083334,
            0.083334,   0.104167, 0.104167, 0.133334,   0.133334,   0.166667,
            0.166667,   0.208333, 0.208333, 0.2625,     0.2625,     0.333333,
            0.333333,   0.416667, 0.416667, 0.520833,   0.520833,   0.666667,
            0.666667,   0.833333, 0.833333, 1};
        bs = bapcfg[b * 2] * len_ / 2;
        be = bapcfg[b * 2 + 1] * len_ / 2;
        if (b == bndap->col - 1) {
          be += 1;
        }
      } else {
        fprintf(stderr, "bapdim must be equal to 5 or 26,now bapdim is %d!\n",
                bndap->col);
        exit(-1);
      }
      // weighting for mixed excitation
      if (sigp <= 0.0) {
        wnz = MIN(1.0, pow(10.0, (bndap->data[t][b]) / 20.0));
      } else {
        wnz = Sigmoid(pow(10.0, (bndap->data[t][b]) / 20.0), sigp, 0.25);
        wnz = MIN(1.0, wnz);
      }
      wpr = sqrt(MAX(0.0, 1.0 - SQUARE(wnz)));
      for (k = bs; k < be; k++) {
        noise_->data[k] *= wnz;
        noise_->imag[k] *= wnz;
        pulse_->data[k] *= wpr;
        pulse_->imag[k] *= wpr;
        if (k != 0 && k != len_ / 2) {
          noise_->data[len_ - k] *= wnz;
          noise_->imag[len_ - k] *= wnz;
          pulse_->data[len_ - k] *= wpr;
          pulse_->imag[len_ - k] *= wpr;
        }
      }
    }
    // noise excitation in time domain
    dvifft(noise_);
    noise_->dvifree();

    // random phase
    // if (rnd_flag_ == XTRUE) rphapf_->RandomSpec(pulse);

    // pulse excitation in time domain
    dvifft(pulse_);
    pulse_->dvifree();

    for (k = 0; k < len_; k++)
      psres_->data[k] = pulse_->data[k] + noise_->data[k];
  } else if (rnd_flag_ == XTRUE) {  // pulse excitation
    idx = ++idx % (sizeof(pulse_all) / sizeof(pulse_all[0]));
    int plen = (sizeof(pulse_all[0]) / sizeof(float));
    if (plen > len_) {
      int kk = (plen - len_) / 2 - 1;
      for (k = kk; k < kk + len_; k++)
        psres_->data[k - kk] = pulse_all[idx][k] * fgain;
    } else if (plen == len_) {
      for (k = 0; k < len_; k++) pulse_->data[k] = pulse_all[idx][k] * fgain;
    } else {
      int kk = (len_ - plen) / 2 - 1;
      for (k = 0; k < plen; k++)
        pulse_->data[k + kk] = pulse_all[idx][k] * fgain;
    }
  } else {  // sigle excitation
    for (k = 0; k < len_; k++) psres_->data[k] = 0;
    psres_->data[hlen_] = fgain;
  }
}
void SynthesisClass::FrqbandEnhanced(float *ptr, const int len, float factor) {
  std::vector<float> buff(len);
  int i;
  buff[0] = ptr[0];
  for (i = 1; i < len - 1; i++) {
    buff[i] = ptr[i] + factor * (ptr[i] - (ptr[i - 1] + ptr[i + 1]) * 0.5);
  }
  buff[i] = ptr[i];

  for (i = 0; i < len; i++) {
    ptr[i] = buff[i];
  }
}

void SynthesisClass::SetVolume(float *ptr, const int len) {
  int i = 0;
  if (volume_rate_ != 1.0) {
    for (; i < len; i++) {
      ptr[i] *= volume_rate_;
    }
  }
}

void SynthesisClass::WavCompressor(float *ptr, const int len) {
  int i, k;
  float max, mmax;
  int iframe = 0;
  int nframe = fprd_;  // 16000*0.005ms
  int s = -1, e = -1;

  // 压缩器配置参数
  float thresh = 32000 / 2;  // 阈值
  float ratio = 20;          // 压限衰减倍数
  int attack = -2;           // 压限器启动时间
  int release = 3;           // 压限器结束时间

  float saturat = 32767 / 2;

  // loglv
  bool msg_debug = 0;

  s = e = -1;
  max = mmax = 0;
  for (k = 0; k < len; k++) {
    if (FABS(ptr[k]) > max) max = FABS(ptr[k]);
    if (0 != (k + 1) % nframe) continue;  // split frame
    if (max > mmax) mmax = max;
    iframe++;
    if (max > thresh) {  // 压限器启动
      if (msg_debug)
        fprintf(stderr, "iframe = %d, k = %d, max = %f, mmax = %f\n",
                iframe - 1, k, max, mmax);
      if (s < 0) s = iframe - 1;
      e = iframe - 1;
      max = 0;
    } else if (e > 0) {  // 压限器结束
      int s_ = s;
      int e_ = e;
      float mmax_ = mmax;

      s = e = -1;
      max = mmax = 0;
      if (0 && mmax_ < saturat) {  // 如果最大振幅没有达到100%，那就不压缩
        if (msg_debug)
          fprintf(stderr, "skip [%d, %d] , mmax = %f\n", s_, e_, mmax_);
        continue;
      }
      float sratio = (thresh + (mmax_ - thresh) / ratio) /
                     mmax_;  // 转成振幅的压缩比，0<sratio<1
      int attack_ = attack;
      int release_ = release;
      if (mmax_ * sratio > saturat) sratio = saturat / mmax_;
      release_ = 1 * static_cast<int>(((1 - sratio) * 10 + 0.5));
      release_ = (release_ < release ? release : release_);
      if (msg_debug)
        fprintf(stderr,
                "smooth [%d, %d] , mmax = %f, ratio = %f, attack = %d, release "
                "= %d\n",
                s_, e_, mmax_, sratio, attack_, release_);

      int s_tmp = s_, e_tmp = e_;
      s_ *= nframe, e_ *= nframe;
      attack_ *= nframe, release_ *= nframe;
      float dratio = (1.0 - sratio) / FABS(attack_);  // 线性平滑，可能会有问题
      float max_tmp = 0;
      for (k = s_ + attack_, i = 0; k < s_; k++, i++) {
        ptr[k] *= 1.0 - i * dratio;
        if (FABS(ptr[k]) > max_tmp) max_tmp = FABS(ptr[k]);
      }
      for (k = s_; k < e_; k++) {
        ptr[k] *= sratio;
        if (FABS(ptr[k]) > max_tmp) max_tmp = FABS(ptr[k]);
      }
      dratio = (1.0 - sratio) / release_;
      for (k = e_, i = 0; k < e_ + release_; k++, i++) {
        ptr[k] *= sratio + i * dratio;
        if (FABS(ptr[k]) > max_tmp) max_tmp = FABS(ptr[k]);
      }
      k = e_ + release_ - 1;
      if (msg_debug)
        fprintf(stderr, "final [%d, %d] , mmax -> %f\n", s_tmp, e_tmp, max_tmp);
    }
  }
}
void SynthesisClass::WaveAmpCheck(DVECTOR wav, XBOOL msg_flag) {
  float value;

  value = MAX(FABS(wav->dvmax(nullptr)), FABS(wav->dvmin(nullptr)));
  if (value >= 32767.0) {
    if (1 || msg_flag == XTRUE) {
      fprintf(stderr, "amplitude is too big: %f, execute normalization\n",
              value);
    }
    dvscoper(wav, "*", 32767.0 / value);
  }
}

// speech synthesis
DVECTOR SynthesisClass::SynthesisBody(DVECTOR f0v,    // F0 sequence
                                      DMATRIX mcep,   // mel-cep sequence
                                      DMATRIX bndap,  // five-band aperiodicity
                                      float sigp,     // Sigmoid parameter
                                      FILE *rawfp) {  // raw file
  int64 t, pt, t0p, pt0p, pos, tidx;
  float f0, t0, time;
  DVECTOR xd = new DVECTOR_CLASS(mcep->row * (fprd_ + 2) + len_, 0.0);
  DVECTOR ntbl = new DVECTOR_CLASS(xd->length);
  ntbl->dvrandn();
  DVECTOR syn = nullptr;

  pt = -1;
  pt0p = 0;
  for (t = 0, pos = 0, tidx = 0, time = 0.0; t < mcep->row;) {
    if (t >= f0v->length)
      f0 = 0.0;
    else
      f0 = f0v->data[t];
    tidx = static_cast<int64>(spround(time));

    if (f0 > 0.0) {
      if (f0 < f0min_) f0 = f0min_;
      t0 = fs_ / f0;
      t0p = static_cast<int64>(spround(t0));
      memset(pulse_->data, 0, len_ * sizeof(float));
      memset(noise_->data, 0, len_ * sizeof(float));
      // asymmetric pitch-synchronous hanning window
      PShannWin(pt0p, t0p);
      // normalized pulse
      pulse_->data[hlen_] = sqrt(t0);
      // normalized noise
      if (hlen_ <= t0p) {
        memcpy(noise_->data, ntbl->data + tidx, len_ * sizeof(float));
      } else {
        memcpy(noise_->data + hlen_ - t0p,
            ntbl->data + hlen_ - t0p + tidx, (t0p * 2 + 1) * sizeof(float));
      }
      // mixed excitation
      PsresMixRndphs(bndap, t, sigp, pt0p, t0p, sqrt(t0));
    } else {
      t0 = fs_ / uvf0_;
      t0p = static_cast<int64>(spround(t0));
      // asymmetric pitch-synchronous hanning window
      PShannWin(pt0p, t0p);
      // normalized noise
      if (hlen_ <= t0p) {
        memcpy(psres_->data, ntbl->data + tidx, len_ * sizeof(float));
      } else {
        memcpy(psres_->data + hlen_ - t0p,
            ntbl->data + hlen_ - t0p + tidx, (t0p * 2 + 1) * sizeof(float));
      }
    }
    pt0p = t0p;

    // multiply window
    dvoper(psres_, "*", hann_);
    // constructing excitation with OLA
    dvpaste(xd, psres_, tidx, psres_->length, 1);

    if (t > pt) {  // MLSA filtering
      for (; pt < t; pt++)
        vs_->Filter(&(xd->data[pt * fprd_ + hlen_]),
            mcep->data[pt + 1].data(), fprd_, rawfp);
    }
    if ((pos = tidx + psres_->length) > xd->length) {
      pos = xd->length;
      break;
    }

    // time
    time += t0;
    tidx = static_cast<int64>(spround(time));
    while (tidx > (t + 1) * fprd_) t++;
  }
  vs_->Filter(&xd->data[pt * fprd_ + hlen_], mcep->data[pt].data(),
              pos - (pt * fprd_ + hlen_), rawfp);
  // DVECTOR y = new DVECTOR_CLASS(pos - hlen_);
  syn = xdvcut(xd, hlen_, pos - hlen_);

  // frequence enchanced
  FrqbandEnhanced(syn->data, syn->length, frqbnd_rate_);

  // wave compressor
  WavCompressor(syn->data, syn->length);

  // set volume
  SetVolume(syn->data, syn->length);

  // normalized amplitude
  // WaveAmpCheck(syn, XFALSE);

  // memory free
  delete xd;
  xd = nullptr;
  delete ntbl;
  ntbl = nullptr;

  return syn;
}

/**************************************************************************/
/* Following functions are used for constructing pulse with random phase. */
/**************************************************************************/
// initialization
RphapfClass::RphapfClass(float samp_freq, int64 fft_len) {
  // parameters on group delay
  gdbw_ = 70.0;     // band width
  gdsd_ = 1.0;      // standard deviation
  cornf_ = 3500.0;  // lower corner frequency

  fs_ = samp_freq;
  fftl_ = fft_len;

  // smoothing phase transition window
  phstransw_ = XPhstransWin();

  // smoothing window for group delay in frequency domain
  fgdsw_ = XFgrpdlyWin();
  gdwt_ = XGdWeight(300.0);

  // group delay
  gd_ = new DVECTOR_CLASS(fftl_);

  // all-pass Filter
  apf_ = new DVECTOR_CLASS(fftl_);
  apf_->dvialloc();

  return;
}

// free
RphapfClass::~RphapfClass() {
  delete phstransw_;
  phstransw_ = nullptr;
  delete fgdsw_;
  fgdsw_ = nullptr;
  delete gdwt_;
  gdwt_ = nullptr;
  delete gd_;
  gd_ = nullptr;
  delete apf_;
  apf_ = nullptr;

  return;
}

// smoothing phase transition window
DVECTOR RphapfClass::XPhstransWin() {
  int64 k;
  int64 fftl2;
  DVECTOR x = new DVECTOR_CLASS(fftl_);

  fftl2 = fftl_ / 2;
  for (k = 0; k < x->length; k++)
    x->data[k] = 1.0 / (1.0 + exp(-40.0 * static_cast<float>((k - fftl2)) /
                                  static_cast<float>(fftl_)));

  return x;
}

// smoothing window for group delay
DVECTOR RphapfClass::XGrpdlyWin() {
  int64 k;
  int64 fftl2;
  float value, sum;
  DVECTOR x = new DVECTOR_CLASS(fftl_);

  fftl2 = fftl_ / 2;
  // gdbw is the equvalent rectangular band width
  for (k = 0, sum = 0.0; k < x->length; k++) {
    value = fs_ * static_cast<float>((k - fftl2)) /
            static_cast<float>(fftl_ / gdbw_);
    // slope difinition function
    x->data[k] = exp(-0.25 * PI * SQUARE(value));
    sum += x->data[k];
  }
  dvscoper(x, "/", sum);

  return x;
}

// gd window in frequency domain
DVECTOR RphapfClass::XFgrpdlyWin() {
  DVECTOR x = nullptr;
  DVECTOR y = nullptr;

  // the spectral smoothing window for group delay
  x = XGrpdlyWin();

  // fft
  dvfftshift(x);
  y = xdvfft(x);
  y->dvifree();

  // memory free
  delete x;
  x = nullptr;

  return y;
}

// group delay weight
DVECTOR RphapfClass::XGdWeight(float bw) {  // group delay band width
  int64 k;
  DVECTOR x = new DVECTOR_CLASS(fftl_ / 2 + 1);

  for (k = 0; k < x->length; k++)
    x->data[k] = 1.0 / (1.0 + exp(-(static_cast<float>((k + 1)) * fs_ /
                                        static_cast<float>(fftl_) -
                                    cornf_) /
                                  bw));

  return x;
}

// group delay
void RphapfClass::GetGrpdly() {
  int64 k;
  int64 hfftl = fftl_ / 2 + 1;
  float df = fs_ / static_cast<float>(fftl_) * 2.0 * PI;
  float value;
  // noise based apf
  DVECTOR ngd = new DVECTOR_CLASS(hfftl);
  ngd->dvrandn();

  // multiply gd weighting window
  if (gdwt_ != nullptr) dvoper(ngd, "*", gdwt_);
  for (k = 0; k < hfftl; k++) gd_->data[k] = ngd->data[k];

  if (fgdsw_ != nullptr) {
    // convolute gd smoothing window
    dvfftturn(gd_);
    dvfft(gd_);
    dvoper(gd_, "*", fgdsw_);
    dvifft(gd_);
    gd_->dvifree();
  }

  // adjust gd power
  value = sqrt(static_cast<float>(fftl_) * gdbw_ / fs_);
  value *= gdsd_ * df / 1000.0;
  for (k = 0; k < hfftl; k++) gd_->data[k] *= value;

  // turn data
  dvfftturn(gd_);

  // memory free
  delete ngd;
  ngd = nullptr;

  return;
}

// noise based apf
void RphapfClass::GdtoRandomApf() {
  int64 k;
  float value;
  DVECTOR phs = nullptr;  // phase

  // integrate group delay
  value = gd_->data[0];
  phs = xdvcumsum(gd_);
  dvscoper(phs, "-", value);

  // smoothing phase transition
  value = rem(phs->data[fftl_ - 1] + phs->data[1], 2.0 * PI) - 2.0 * PI;
  for (k = 0; k < fftl_; k++) {
    phs->data[k] = -(phs->data[k] - phstransw_->data[k] * value);
    // exponential of imaginary unit
    apf_->data[k] = cos(phs->data[k]);
    apf_->imag[k] = sin(phs->data[k]);
  }

  // memory free
  delete phs;
  phs = nullptr;

  return;
}

// group delay
void RphapfClass::GetRandomApf() {
  // get group delay
  GetGrpdly();

  // get noise based apf
  GdtoRandomApf();

  return;
}

// spectrum with random phase
void RphapfClass::RandomSpec(DVECTOR spc) {
  // design apf for random phase
  GetRandomApf();

  // multiply apf
  dvoper(spc, "*", apf_);

  return;
}
