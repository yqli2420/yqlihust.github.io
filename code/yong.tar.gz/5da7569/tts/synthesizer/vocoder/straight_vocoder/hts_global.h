// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng Yang)

#ifndef TTS_SYNTHESIZER_VOCODER_STRAIGHT_VOCODER_HTS_GLOBAL_H_
#define TTS_SYNTHESIZER_VOCODER_STRAIGHT_VOCODER_HTS_GLOBAL_H_

#include "tts/synthesizer/vocoder/straight_vocoder/hts_misc.h"

typedef class globalP_CLASS {
 public:
  int RATE = 16000;     /* sampring rate                              */
  int FPERIOD = 80;  /* frame period (point)                       */
  int FFTLEN = 512;   /* FFT length                                 */
  float RHO = 1.0;   /* variable for speaking rate control         */
  float VOL = 1.0;   /* variable for speaking volume control       */
  float ALPHA = 0.42; /* variable for frequency warping parameter   */
  float GAMMA = 0;  // variable for control the cepstral scale
                    // in MGC or MGC-LSP
  float F0_MEAN = 0.0;       /* variable for f0 control                    */
  float F0_STD = 1.0;        /* variable for f0 control                    */
  float BETA = 0.0;          /* variable for postfiltering                 */
  float UV = 0.5;            /* variable for U/V threshold                 */
  float LENGTH = 0.0;        /* total number of frame for generated speech */
  HTS_Boolean rnd_flag = 1; /* use pulse train with phase manipulationn   */
  float sigp = 8.0;          /* mapping parameter for mixed excitation     */
  float frqbnd_rate = 0;   /* 音色调亮: 0~1.0 */
  globalP_CLASS(char *);
  ~globalP_CLASS() = default;
} * globalP;

#endif  //  TTS_SYNTHESIZER_VOCODER_STRAIGHT_VOCODER_HTS_GLOBAL_H_
