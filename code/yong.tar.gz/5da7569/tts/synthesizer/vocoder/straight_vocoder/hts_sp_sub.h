// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: xipeng.yang@mobvoi.com (xipeng Yang)

#ifndef TTS_SYNTHESIZER_VOCODER_STRAIGHT_VOCODER_HTS_SP_SUB_H_
#define TTS_SYNTHESIZER_VOCODER_STRAIGHT_VOCODER_HTS_SP_SUB_H_

#include <vector>

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/log.h"

#ifdef NUL
#undef NUL
#endif
#define NUL '\0'

#ifdef M_PI
#define PI M_PI
#else
#define PI 3.1415926535897932385
#endif

#ifndef NULL
#define NULL 0
#endif

#define XBOOL int
#define XTRUE 1
#define XFALSE 0
#define ALITTLE_NUMBER 1.0e-10
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#define MIN(a, b) ((a) < (b) ? (a) : (b))
#define SQUARE(x) ((x) * (x))
#define CSQUARE(xr, xi) ((xr) * (xr) + (xi) * (xi))
#define POW2(p) (1 << static_cast<int>((p)))
#define ABS(x) ((x) >= 0 ? (x) : -(x))
#define FABS(x) ((x) >= 0.0 ? (x) : -(x))
#define CABS(xr, xi)                                           \
  sqrt(static_cast<float>((xr)) * static_cast<float>((xr)) + \
       static_cast<float>((xi)) * static_cast<float>((xi)))
#define dB(x) (20.0 * log10(static_cast<float>((x))))
#define dBpow(x) (10.0 * log10(static_cast<float>((x))))

#define streq(s1, s2) \
  ((s1 != NULL) && (s2 != NULL) && (strcmp((s1), (s2)) == 0) ? 1 : 0)
#define strneq(s1, s2, n) \
  ((s1 != NULL) && (s2 != NULL) && (strncmp((s1), (s2), n) == 0) ? 1 : 0)
#define strveq(s1, s2)                                                        \
  ((s1 != NULL) && (s2 != NULL) && (strncmp((s1), (s2), strlen(s2)) == 0) ? 1 \
                                                                          : 0)
// #define arraysize(array) ((unsigned int)(sizeof(array) / sizeof(array[0])))
#define samesign(a, b) ((a) * (b) >= 0)
#define eqtrue(value) (((value) == XTRUE) ? 1 : 0)
#define strnone(string) (((string) == NULL || *(string) == NUL) ? 1 : 0)
#define strnull strnone
typedef class DVECTOR_CLASS {
 public:
  int64 length;
  float *data;
  float *imag;

  DVECTOR_CLASS(int64);
  DVECTOR_CLASS(int64, float);
  DVECTOR_CLASS(int64, float *, float *);
  ~DVECTOR_CLASS();

  void dvifree();
  void dvialloc();
  void dvialloc(float);
  void dvrandn();
  float dvmax(int64 *);
  float dvmin(int64 *);
} * DVECTOR;

typedef class DMATRIX_CLASS {
 public:
  int64 row;
  int64 col;
  std::vector<std::vector<float>> data;

  DMATRIX_CLASS(int64, int64);
  ~DMATRIX_CLASS() = default;
} * DMATRIX;
float spround(float);
float rem(float, float);
void cexp(float *, float *);
void clog(float *, float *);
float simple_random();
float simple_gnoise(float);
float randn();

DVECTOR xdvclone(DVECTOR);
DVECTOR xdvcplx(DVECTOR, DVECTOR);
void dvoper(DVECTOR, const char *, DVECTOR);
DVECTOR xdvoper(DVECTOR, char *, DVECTOR);
void dvscoper(DVECTOR, const char *, float);
DVECTOR xdvscoper(DVECTOR, char *, float);
void dvcumsum(DVECTOR);
DVECTOR xdvcumsum(DVECTOR);
void dvpaste(DVECTOR, DVECTOR, int64, int64, int);
DVECTOR xdvcut(DVECTOR, int64, int64);

int nextpow2(int64 n);
int fft(float *xRe, float *xIm, int64 fftp, int inv);
void dvfft(DVECTOR x);
void dvifft(DVECTOR x);
DVECTOR xdvfft(DVECTOR x);
DVECTOR xdvifft(DVECTOR x);
DVECTOR xdvfft(DVECTOR x, int64 length);
DVECTOR xdvifft(DVECTOR x, int64 length);
void fftturn(float *xRe, float *xIm, int64 fftp);
void dvfftturn(DVECTOR x);
void fftshift(float *xRe, float *xIm, int64 fftp);
void dvfftshift(DVECTOR x);
class SMP_GAUSSIAN_RND {
 private:
  int64 x;
  int64 a;
  int64 c;
  int64 m;

 public:
  float simple_random();
  float simple_gnoise(float rms);
  SMP_GAUSSIAN_RND();
  ~SMP_GAUSSIAN_RND();
};
#endif  // TTS_SYNTHESIZER_VOCODER_STRAIGHT_VOCODER_HTS_SP_SUB_H_
