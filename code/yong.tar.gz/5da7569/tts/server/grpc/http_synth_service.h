// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com

#ifndef TTS_SERVER_GRPC_HTTP_SYNTH_SERVICE_H_
#define TTS_SERVER_GRPC_HTTP_SYNTH_SERVICE_H_

#include <string>
#include <map>

#include "mobvoi/util/net/http_server/http_server.h"
#include "tts/server/grpc/html_page_info.h"
#include "tts/server/grpc/record_audio_info.h"
#include "tts/synthesizer/synthesizer.h"

namespace mobvoi {

class HttpSynthService {
 public:
  HttpSynthService();
  virtual ~HttpSynthService();

  bool Synthesize(
      util::HttpRequest *request,
      util::HttpResponse *response);

  bool GetHomePage(
      util::HttpRequest *request,
      util::HttpResponse *response);

  bool DownloadModel(
      util::HttpRequest *request,
      util::HttpResponse *response);

  void SetHomePageFile(const std::string& file_path);
  void SetDefaultSynthServerUrl(const std::string& synth_server_url);
  void SetSynthRequestHttp(bool synth_request_http = true);
  void SetSynthSpeakerInfoFile(const std::string& file_path);
  void SetSynthesizer(tts::Synthesizer* synthesizer);
  void SetDebugFlag(bool debug_flag);

  bool LoadHtmlPageFromDir(const std::string& html_page_dir);
  bool LoadRecordAudioFromDir(const std::string& record_audio_dir);

  void ConvertWav(
      const std::string& src_str, std::string* dst_str,
      int sample_rate, const std::string& audio_type);

 private:
  std::string home_page_content_;
  // home page file, default index.html
  std::string home_page_file_;
  std::string html_page_dir_;
  std::string record_audio_dir_;
  std::string home_error_page_file_;
  std::string synth_server_url_;
  std::string synth_speaker_info_file_;
  bool debug_flag_;
  bool synth_request_http_;
  tts::Synthesizer* synthesizer_;

  std::map<std::string, HtmlPageInfo> html_page_map_;
  std::map<std::string, RecordAudioInfo> record_audio_map_;
};  // class HttpSynthService

}  // namespace mobvoi

#endif  // TTS_SERVER_GRPC_HTTP_SYNTH_SERVICE_H_
