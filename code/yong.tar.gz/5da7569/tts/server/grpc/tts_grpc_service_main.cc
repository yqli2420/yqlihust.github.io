// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "mobvoi/audio_util/audio_logger.h"
#include "mobvoi/base/at_exit.h"
#include "mobvoi/base/base64.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/file/proto_util.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/license/license_validator.h"
#include "mobvoi/util/net/http_server/http_server.h"
#include "tts/server/grpc/grpc_synth_service.h"
#include "tts/server/grpc/http_synth_service.h"
#include "tts/server/grpc/model_manager.h"
#include "tts/server/grpc/synth_config.h"
#include "tts/server/grpc/tts_resource_manager.h"

DEFINE_string(grpc_host, "0.0.0.0", "grpc service host");
DEFINE_string(grpc_port, "8080", "service port");
DEFINE_string(http_host, "0.0.0.0", "http service host");
DEFINE_int32(http_port, 8081, "");
DEFINE_string(synth_server_url, "", "synth http server url");
DEFINE_int32(thread_num, 2, "thread number");
DEFINE_string(conc_param_conf, "config/config_file/conc_param.conf",
              "param config files");
DEFINE_string(conc_option_conf, "config/config_file/conc_option.conf",
              "option config files");
DEFINE_string(home_page, "web_server/conc_server.html",
              "default home page");
DEFINE_string(record_audio_dir, "external/config/web_server/record_wav/wav",
              "record audio dir");
DEFINE_string(html_page_dir, "external/config/web_server/",
              "htmp page dir");
DEFINE_string(synth_config, "", "synth config file path");
DEFINE_bool(enable_http, true, "http server enable or not");
DEFINE_bool(enable_grpc, true, "grpc server enable or not");
DEFINE_bool(synth_request_http, false, "grpc server enable or not");
DEFINE_string(speaker_info_file, "external/config/config_file/speakers.json",
              "speaker info json file");
DEFINE_bool(debug, true, "debug enable or not");
DEFINE_string(license, "", "license file path");

using std::placeholders::_1;
using std::placeholders::_2;

class HttpServerThread : public mobvoi::Thread {
 public:
  virtual void Run() {
    mobvoi::HttpSynthService http_synth_service;
    http_synth_service.SetSynthRequestHttp(FLAGS_synth_request_http);
    http_synth_service.SetDefaultSynthServerUrl(FLAGS_synth_server_url);
    http_synth_service.SetSynthSpeakerInfoFile(FLAGS_speaker_info_file);
    http_synth_service.SetSynthesizer(synthesizer_);
    http_synth_service.SetDebugFlag(FLAGS_debug);
    util::HttpServer http_server(FLAGS_http_port, FLAGS_thread_num);

    auto callback_synthesis = std::bind(&mobvoi::HttpSynthService::Synthesize,
                                        &http_synth_service, _1, _2);
    util::DefaultHttpHandler synthesis_handler(callback_synthesis);
    http_server.RegisterHttpHandler("/api/streaming", &synthesis_handler);
    http_server.RegisterHttpHandler("/api/synthesis", &synthesis_handler);

    auto callback_model_download = std::bind(
        &mobvoi::HttpSynthService::DownloadModel,
        &http_synth_service, _1, _2);
    util::DefaultHttpHandler model_download_handler(callback_model_download);
    http_server.RegisterHttpHandler(
        "/api/model/download", &model_download_handler);
    http_server.RegisterHttpHandler(
        "/api/notify", &model_download_handler);

    auto callback_homepage = std::bind(&mobvoi::HttpSynthService::GetHomePage,
                                       &http_synth_service, _1, _2);
    util::DefaultHttpHandler home_handler(callback_homepage);
    http_server.RegisterHttpHandler("/index", &home_handler);
    util::StatusHttpHandler status("online-neural-tts", NULL);
    http_server.RegisterHttpHandler("/status", &status);

    LOG(INFO) << "http server listening on "
              << "127.0.0.1:" << FLAGS_http_port;
    http_server.Serv();
  }
  void SetSynthesizer(tts::Synthesizer* synthesizer) {
    synthesizer_ = synthesizer;
  }

 private:
  tts::Synthesizer* synthesizer_;
};

class GrpcServerThread : public mobvoi::Thread {
 public:
  virtual void Run() {
    mobvoi::GrpcSynthService service;
    service.SetSynthRequestHttp(FLAGS_synth_request_http);
    service.SetDefaultSynthServerUrl(FLAGS_synth_server_url);
    service.SetSynthesizer(synthesizer_);
    service.SetDebugFlag(FLAGS_debug);
    std::string server_address(FLAGS_grpc_host + ":" + FLAGS_grpc_port);
    grpc::ServerBuilder builder;
    builder.AddListeningPort(server_address, grpc::InsecureServerCredentials());
    builder.RegisterService(&service);
    builder.SetMaxMessageSize(1024 * 1024 * 1024);  // 1024 MB maximum payload
    unique_ptr<grpc::Server> server(builder.BuildAndStart());
    LOG(INFO) << "grpc server listening on " << server_address;

    server->Wait();
  }

  void SetSynthesizer(tts::Synthesizer* synthesizer) {
    synthesizer_ = synthesizer;
  }

 private:
  tts::Synthesizer* synthesizer_;
};

int main(int argc, char** argv) {
  base::AtExitManager at_exit;
  mobvoi::ParseCommandLineFlags(&argc, &argv, false, "");
  google::InitGoogleLogging(argv[0]);

  // start license validate
  mobvoi::LicenseValidator::GetInstance()->StartValidate(FLAGS_license);
  mobvoi::TtsResourceManager::GetInstance()->LoadHtmlPageFromDir(
      FLAGS_html_page_dir);
  mobvoi::TtsResourceManager::GetInstance()->LoadRecordAudioFromDir(
      FLAGS_record_audio_dir);

  mobvoi::SynthConfig::LoadConfigFromFile(FLAGS_synth_config);
  mobvoi::ModelManager::GetInstance()->StartUp();

  // start audio logger
  mobvoi::AudioLogger::GetInstance()->SetDebugFlag(FLAGS_debug);
  mobvoi::AudioLogger::GetInstance()->StartLogger();
  std::unique_ptr<tts::Synthesizer> synthesizer;
  synthesizer.reset(new tts::Synthesizer(FLAGS_speaker_info_file));

  HttpServerThread http_server_thread;
  GrpcServerThread grpc_server_thread;
  http_server_thread.SetSynthesizer(synthesizer.get());
  grpc_server_thread.SetSynthesizer(synthesizer.get());
  if (FLAGS_enable_http && FLAGS_enable_grpc) {
    http_server_thread.Start();
    grpc_server_thread.Start();
    http_server_thread.Join();
    grpc_server_thread.Join();
  } else if (FLAGS_enable_http && !FLAGS_enable_grpc) {
    http_server_thread.Start();
    http_server_thread.Join();
  } else if (!FLAGS_enable_http && FLAGS_enable_grpc) {
    grpc_server_thread.Start();
    grpc_server_thread.Join();
  }
}
