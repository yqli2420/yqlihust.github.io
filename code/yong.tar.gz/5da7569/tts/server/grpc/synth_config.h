// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com (XiaoKai Yang)

#ifndef TTS_SERVER_GRPC_SYNTH_CONFIG_H_
#define TTS_SERVER_GRPC_SYNTH_CONFIG_H_

#include <list>
#include <map>
#include <string>

#include "mobvoi/base/mutex.h"

namespace mobvoi {

class SynthConfig {
 public:
  SynthConfig();
  virtual ~SynthConfig();

 public:
  static std::string GetValueAsString(const std::string& key);
  static bool LoadConfigFromFile(const std::string& config_file);
  static void SetConfigValue(const std::string& key, const std::string& value);
  static bool SetConfigValueByEnv(const std::string& key);

 private:
  static Mutex mutex_;
  static std::map<std::string, std::string> config_map_;
  static std::map<std::string, bool> config_file_map_;
  static std::map<std::string, std::string> query_filter_word_map_;
};

}  // namespace mobvoi

#endif  // TTS_SERVER_GRPC_SYNTH_CONFIG_H_
