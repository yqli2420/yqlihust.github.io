// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com

#ifndef TTS_SERVER_GRPC_HTTP_SYNTH_CLIENT_H_
#define TTS_SERVER_GRPC_HTTP_SYNTH_CLIENT_H_

#include <string>
#include <list>

#include "mobvoi/base/mutex.h"

namespace mobvoi {

class HttpSynthClient {
 public:
  HttpSynthClient();
  virtual ~HttpSynthClient();

 public:
  bool RequestSynthesis(const std::string& text, bool async = false);
  void RequestCallback(const char* data, std::size_t length);
  void SetRequestUrl(const std::string& url);
  void SetAudioType(const std::string& audio_type = "wav");
  void SetAudioSpeed(double audio_rate_);
  void SetMandarinSpeaker(const std::string& speaker_name);
  void SetSampleRate(int sample_rate);
  // if length = -1, return all remain data
  std::string GetSynthesisResult();
  bool OutputResultFinished();

 private:
  std::list<std::string> synthesis_result_list_;
  std::string url_;
  // default value: pcm
  std::string audio_type_;
  std::string text_;
  int timeout_;
  double audio_speed_;
  int sample_rate_;
  bool request_finished_;
  Mutex mutex_;
  std::string mandarin_speaker_;
  std::list<std::string> result_list_;
};

}  // namespace mobvoi

#endif  // TTS_SERVER_GRPC_HTTP_SYNTH_CLIENT_H_
