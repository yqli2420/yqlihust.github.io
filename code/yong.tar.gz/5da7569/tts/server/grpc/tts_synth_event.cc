// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com

#include "tts/server/grpc/tts_synth_event.h"
#include "mobvoi/base/log.h"

namespace mobvoi {

TtsSynthEvent::TtsSynthEvent() : ssml_entity_(nullptr) {}

TtsSynthEvent::TtsSynthEvent(TtsSsmlEntity* ssml_entity)
    : ssml_entity_(ssml_entity) {}

TtsSynthEvent::~TtsSynthEvent() {}

void TtsSynthEvent::OnStart() {
  LOG(INFO) << "tts synth event: start: channel id: " << channel_id_;
}

bool TtsSynthEvent::OnSynthesizeData(const std::string& data) {
  if (ssml_entity_ != nullptr) {
    ssml_entity_->AppendAudioData(data);
  }
  VLOG(1) << "synth call back: length: " << data.length()
          << ", channel id: " << channel_id_;
  return true;
}

void TtsSynthEvent::OnFinish() {
  if (ssml_entity_) {
    ssml_entity_->SetAppendAudioFinished(true);
  }
  LOG(INFO) << "tts synth event: finish, channel id: " << channel_id_;
}

string TtsSynthEvent::GetResult() { return string(); }
bool TtsSynthEvent::GetChunkDuration(const std::string& duration) {
  return true;
}

void TtsSynthEvent::SetSsmlEntity(TtsSsmlEntity* ssml_entity) {
  ssml_entity_ = ssml_entity;
}

void TtsSynthEvent::SetChannelId(const std::string& channel_id) {
  channel_id_ = channel_id;
}

}  // namespace mobvoi
