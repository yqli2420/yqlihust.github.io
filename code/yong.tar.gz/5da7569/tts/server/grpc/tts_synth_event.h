// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com

#ifndef TTS_SERVER_GRPC_TTS_SYNTH_EVENT_H_
#define TTS_SERVER_GRPC_TTS_SYNTH_EVENT_H_

#include "tts/synthesizer/interface/synthesizer_event_interface.h"
#include "tts/util/ssml/tts_ssml_entity.h"

namespace mobvoi {

class TtsSynthEvent : public tts::SynthesizerEventInterface {
 public:
  TtsSynthEvent();
  explicit TtsSynthEvent(TtsSsmlEntity* ssml_entity);
  ~TtsSynthEvent();

 public:
  virtual void OnStart();
  // true for success, false for cancel synthesizing
  virtual bool OnSynthesizeData(const std::string& data);
  virtual bool GetChunkDuration(const std::string& duration);
  virtual void OnFinish();
  virtual string GetResult();
  void SetSsmlEntity(TtsSsmlEntity* ssml_entity);
  void SetChannelId(const std::string& channel_id);

 private:
  TtsSsmlEntity* ssml_entity_;
  std::string channel_id_;
};

}  // namespace mobvoi

#endif  // TTS_SERVER_GRPC_TTS_SYNTH_EVENT_H_
