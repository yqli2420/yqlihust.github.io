// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com

#include "tts/server/grpc/tts_resource_manager.h"

#include <memory>

#include "mobvoi/base/file.h"
#include "mobvoi/base/log.h"

namespace mobvoi {

std::unique_ptr<TtsResourceManager> TtsResourceManager::instance(
    new TtsResourceManager());

TtsResourceManager::TtsResourceManager() {}

TtsResourceManager::~TtsResourceManager() {}

TtsResourceManager* TtsResourceManager::GetInstance() { return instance.get(); }

HtmlPageInfo* TtsResourceManager::GetHtmlPageInfo(
    const std::string& page_path) {
  if (page_path.empty()) return nullptr;
  std::map<std::string, HtmlPageInfo>::iterator it;
  if ((it = html_page_map_.find(page_path)) == html_page_map_.end()) {
    return nullptr;
  }
  return &it->second;
}

RecordAudioInfo* TtsResourceManager::GetRecordAudioInfo(
    const std::string& record_audio_id) {
  if (record_audio_id.empty()) return nullptr;
  std::map<std::string, RecordAudioInfo>::iterator it;
  if ((it = record_audio_map_.find(record_audio_id)) ==
      record_audio_map_.end()) {
    RecordAudioInfo* audio_info = new RecordAudioInfo();
    if (audio_info->LoadAudioFromWeb(record_audio_id)) {
      return audio_info;
    } else {
      return nullptr;
    }
  }
  return &it->second;
}

bool TtsResourceManager::LoadHtmlPageFromDir(const std::string& html_page_dir) {
  if (html_page_dir.empty()) {
    this->html_page_map_.clear();
    return false;
  }
  if (!File::IsDir(html_page_dir)) {
    LOG(ERROR) << "load html page from dir error: " << html_page_dir;
    return false;
  }

  std::vector<std::string> html_file_list;
  if (!File::GetFilesInDir(html_page_dir, &html_file_list)) {
    LOG(ERROR) << "get files from dir error: " << html_page_dir;
    return false;
  }

  for (const auto& html_file : html_file_list) {
    HtmlPageInfo page_info;
    if (page_info.LoadHtmlPageFromFile(html_file)) {
      std::size_t index = html_file.find_last_of("/");
      std::string html_file_name = html_file;
      if (index != std::string::npos) {
        html_file_name = html_file.substr(index + 1);
      }
      this->html_page_map_.insert(
          std::pair<std::string, HtmlPageInfo>(html_file_name, page_info));
    } else {
      LOG(ERROR) << "load html file error: " << html_file;
    }
  }
  this->html_page_dir_ = html_page_dir;
  return true;
}

bool TtsResourceManager::LoadRecordAudioFromDir(
    const std::string& record_audio_dir) {
  if (record_audio_dir.empty()) {
    this->record_audio_map_.clear();
    return false;
  }
  if (!File::IsDir(record_audio_dir)) {
    LOG(ERROR) << "load record audio from dir error: " << record_audio_dir;
    return false;
  }

  std::vector<std::string> audio_file_list;
  if (!File::GetFilesInDir(record_audio_dir, &audio_file_list)) {
    LOG(ERROR) << "get files from dir error: " << record_audio_dir;
    return false;
  }

  for (const auto& audio_file : audio_file_list) {
    RecordAudioInfo audio_info;
    if (audio_info.LoadAudioFromFile(audio_file)) {
      std::size_t index = audio_file.find_last_of("/");
      std::string audio_file_name = audio_file;
      if (index != std::string::npos) {
        audio_file_name = audio_file.substr(index + 1);
      }
      this->record_audio_map_.insert(
          std::pair<std::string, RecordAudioInfo>(audio_file_name, audio_info));
    } else {
      LOG(ERROR) << "load record audio file error: " << audio_file;
    }
  }
  this->record_audio_dir_ = record_audio_dir;
  return true;
}

}  // namespace mobvoi
