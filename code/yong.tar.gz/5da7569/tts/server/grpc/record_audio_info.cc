// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com

#include "tts/server/grpc/record_audio_info.h"

#include "mobvoi/base/file.h"
#include "mobvoi/base/log.h"
#include "tts/server/server_util.h"

namespace mobvoi {

RecordAudioInfo::RecordAudioInfo()
    : audio_header_length_(0), sample_rate_(8000) {}

RecordAudioInfo::~RecordAudioInfo() {}

const std::string& RecordAudioInfo::GetAudioName() { return audio_name_; }

const std::string& RecordAudioInfo::GetAudioData() { return audio_data_; }

const std::string& RecordAudioInfo::GetAudioPath() { return audio_path_; }

const std::string& RecordAudioInfo::GetAudioText() { return audio_text_; }

int RecordAudioInfo::GetAudioHeaderLength() { return audio_header_length_; }

int RecordAudioInfo::GetSampleRate() { return sample_rate_; }

void RecordAudioInfo::SetAudioText(const std::string& audio_text) {
  this->audio_text_ = audio_text;
}

bool RecordAudioInfo::LoadAudioFromWeb(const std::string& audio_url) {
  string audio_tmp_dir = server::ServerUtil::GetSaveAudioTmpDir();
  if (audio_url.empty()) return false;
  vector<int16> pcm_result;
  server::ServerUtil::GetAudio(server::AudioParams(audio_url, 1.0, false),
                               &pcm_result, false);
  size_t found = audio_url.find_last_of("/");
  string audio_path = audio_tmp_dir + audio_url.substr(found + 1);
  return LoadAudioFromFile(audio_path);
}

bool RecordAudioInfo::LoadAudioFromFile(const std::string& file_path) {
  if (file_path.empty()) return false;
  if (mobvoi::File::ReadFileToString(file_path, &audio_data_)) {
    int audio_header_length = GetHeaderLength(audio_data_);
    if (audio_header_length > 0) {
      audio_data_ = audio_data_.substr(audio_header_length);
      audio_header_length_ = audio_header_length;
    }
    LOG(INFO) << "load audio file success: len: " << audio_data_.length()
              << ", header len: " << audio_header_length << ": " << file_path;
    this->audio_path_ = file_path;
  } else {
    LOG(ERROR) << "load audio file failure: " << file_path;
    return false;
  }
  return true;
}

int RecordAudioInfo::GetHeaderLength(const std::string& audio_data) {
  if (audio_data.empty()) return 0;

  // check wav format, if not, return 0
  int index = 0;
  std::string tmp = audio_data.substr(index, 4);
  if (tmp.compare("RIFF") != 0) {
    LOG(INFO) << "RIFF error";
    return 0;
  }
  index += 4;

  int32_t chunk_size = audio_data.length() - 8;
  int32_t subchunk2size = chunk_size - 36;

  int64_t len = (unsigned char)audio_data[index + 3] << 24;
  len += (unsigned char)audio_data[index + 2] << 16;
  len += (unsigned char)audio_data[index + 1] << 8;
  len += (unsigned char)audio_data[index + 0];
  if (len != chunk_size) {
    LOG(INFO) << "chunk_size error: " << chunk_size << ", len: " << len;
    return 0;
  }
  index += 4;

  tmp = audio_data.substr(index, 8);
  if (tmp.compare("WAVEfmt ") != 0) {
    LOG(INFO) << "WAVEfmt error";
    return 0;
  }
  index += 8;

  int32_t zip_format = (unsigned char)audio_data[index + 3] << 24;
  zip_format += (unsigned char)audio_data[index + 2] << 16;
  zip_format += (unsigned char)audio_data[index + 1] << 8;
  zip_format += (unsigned char)audio_data[index + 0];
  if (zip_format != 16) {
    LOG(INFO) << "zip_format error";
    return 0;
  }
  index += 4;

  int wav_format = (unsigned char)audio_data[index + 1] << 8;
  wav_format += (unsigned char)audio_data[index + 0];
  if (wav_format != 1) {
    LOG(INFO) << "wav_format error";
    return 0;
  }
  index += 2;

  int channel_number = (unsigned char)audio_data[index + 1] << 8;
  channel_number += (unsigned char)audio_data[index + 0];
  index += 2;

  int32_t sample_rate = (unsigned char)audio_data[index + 3] << 24;
  sample_rate += (unsigned char)audio_data[index + 2] << 16;
  sample_rate += (unsigned char)audio_data[index + 1] << 8;
  sample_rate += (unsigned char)audio_data[index + 0];
  sample_rate_ = sample_rate;
  index += 4;

  int32_t data_transfer_rate = (unsigned char)audio_data[index + 3] << 24;
  data_transfer_rate += (unsigned char)audio_data[index + 2] << 16;
  data_transfer_rate += (unsigned char)audio_data[index + 1] << 8;
  data_transfer_rate += (unsigned char)audio_data[index + 0];
  if (data_transfer_rate != channel_number * sample_rate * 2) {
    LOG(INFO) << "data_transfer_rate error";
    return 0;
  }
  index += 4;

  int data_chunk_align_len = (unsigned char)audio_data[index + 1] << 8;
  data_chunk_align_len += (unsigned char)audio_data[index + 0];
  if (data_chunk_align_len != 0x02) {
    LOG(INFO) << "data_chunk_align_len error";
    return 0;
  }
  index += 2;

  int sample_bit_len = (unsigned char)audio_data[index + 1] << 8;
  sample_bit_len += (unsigned char)audio_data[index + 0];
  if (sample_bit_len != 0x10) {
    LOG(INFO) << "sample_bit_len error";
    return 0;
  }
  index += 2;

  index = audio_data.find("data", index);
  if (index == std::string::npos) {
    LOG(INFO) << "data label error";
    return 0;
  }
  return index + 8;
}

}  // namespace mobvoi
