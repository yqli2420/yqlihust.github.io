// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com

#include "tts/server/grpc/http_synth_client.h"

#include "mobvoi/util/net/http_client/http_client.h"
#include "mobvoi/util/url/encode/url_encode.h"
#include "mobvoi/base/log.h"

namespace mobvoi {

HttpSynthClient::HttpSynthClient()
  : audio_type_("pcm"),
    timeout_(3000),
    audio_speed_(1.0),
    sample_rate_(8000),
    request_finished_(false),
    mandarin_speaker_("cissy_gru") {}

HttpSynthClient::~HttpSynthClient() {}

// http://tts.mobvoi.com/api/synthesis?audio_type=wav&text=正在关闭
bool HttpSynthClient::RequestSynthesis(const std::string& text, bool async) {
  LOG(INFO) << "request synth url: " << url_;
  if (text.empty() || url_.empty()) return false;
  std::stringstream url;
  url << url_
      << "?audio_type=" << audio_type_
      << "&rate=" << sample_rate_
      << "&speed=" << audio_speed_
      << "&mandarin_speaker=" << mandarin_speaker_
      << "&speaker=" << mandarin_speaker_
      << "&text=" << util::UrlEncodeString(text);
  LOG(INFO) << "request synth url: " << url.str();
  util::HttpClient http_client;
  http_client.SetHttpMethod(util::HttpMethod::kGet);
  http_client.SetConnectTimeout(3000);
  http_client.SetFetchTimeout(this->timeout_);
  if (!async) {
    if (http_client.FetchUrl(url.str()) && http_client.response_code() == 200) {
      result_list_.push_back(http_client.ResponseBody());
      return true;
    } else {
      LOG(ERROR) << "tts request failure, response code: "
                 << http_client.response_code()
                 << ", curl code: " << http_client.curl_code();
    }
  } else {
    request_finished_ = false;
    std::function<void(const char*, std::size_t)> callback;
    callback = std::bind(&HttpSynthClient::RequestCallback,
        this,
        std::placeholders::_1,
        std::placeholders::_2);
    if (http_client.FetchWithCallback(url.str(), callback)
        && http_client.response_code() == 200) {
      // result_ = http_client.ResponseBody();
      LOG(INFO) << "tts request success";
      request_finished_ = true;
      return true;
    } else {
      LOG(ERROR) << "tts request failure, response code: "
                 << http_client.response_code()
                 << ", curl code: " << http_client.curl_code();
    }
  }
  return false;
}

void HttpSynthClient::RequestCallback(const char* data, std::size_t length) {
  if (data == nullptr || length <= 0) return;
  MutexLock lock(&mutex_);
  LOG(INFO) << "request callback: length: " << length;
  result_list_.push_back(std::string(data, length));
}

std::string HttpSynthClient::GetSynthesisResult() {
  MutexLock lock(&mutex_);
  if (result_list_.empty()) return "";
  std::list<std::string>::iterator it = result_list_.begin();
  std::string result = *it;
  result_list_.erase(it);
  return result;
}

bool HttpSynthClient::OutputResultFinished() {
  MutexLock lock(&mutex_);
  return request_finished_ && result_list_.empty();
}

void HttpSynthClient::SetRequestUrl(const std::string& url) {
  if (url.empty()) return;
  if (url.back() == '/') {
    url_ = url.substr(0, url.length() - 1);
  } else {
    url_ = url;
  }
}

void HttpSynthClient::SetAudioType(const std::string& audio_type) {
  audio_type_ = audio_type;
}

void HttpSynthClient::SetAudioSpeed(double audio_speed) {
  if (audio_speed <= 0) {
    LOG(ERROR) << "audio speed set error: " << audio_speed;
    return;
  }
  audio_speed_ = audio_speed;
}

void HttpSynthClient::SetSampleRate(int sample_rate) {
  if (sample_rate <= 0) {
    LOG(ERROR) << "sample rate set error: " << sample_rate;
    return;
  }
  sample_rate_ = sample_rate;
}

void HttpSynthClient::SetMandarinSpeaker(const std::string &speaker_name) {
  if (speaker_name.empty()) {
    return;
  }
  mandarin_speaker_ = speaker_name;
}

}  // namespace mobvoi
