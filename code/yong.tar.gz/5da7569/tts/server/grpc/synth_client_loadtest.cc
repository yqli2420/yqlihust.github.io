// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "absl/time/clock.h"
#include "absl/time/time.h"
#include "mobvoi/base/at_exit.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/thread.h"
#include "tts/server/grpc/grpc_synth_client.h"

DEFINE_string(grpc_server, "127.0.0.1:8080", "grpc server host");
DEFINE_int32(http_server, 8081, "");
DEFINE_int32(thread_number, 1, "thread number");
DEFINE_int32(test_count, 5, "total test count");
DEFINE_string(speak_file, "", "speak text file path");
DEFINE_string(model_file, "", "model id list file");
DEFINE_int32(test_mode, 1, "1: list mode, 2: single mode");

class HttpTestThread : public mobvoi::Thread {
 public:
  HttpTestThread()
      : success_(false),
        finished_(false),
        number_(1),
        test_number_(0),
        ave_time_(0),
        sum_time_(0),
        thread_index_(0) {
    min_time_ = 10000000;
    max_time_ = 0;
  }
  ~HttpTestThread() {}

  bool isSuccess() { return success_; }
  bool isFinished() { return finished_; }

  void SetSuccess(bool success) { success_ = success; }
  void SetFinished(bool finished) { finished_ = finished; }
  void SetTestNumber(int number) { number_ = number; }
  int  GetTestNumber() { return test_number_; }
  void SetThreadIndex(int index) { thread_index_ = index; }
  void PrintResult() {
    LOG(INFO) << "max time: " << max_time_ / 1000.0f
              << ", min time: " << min_time_ / 1000.0f
              << ", sum time: " << sum_time_ / 1000.0f
              << ", ave time: " << sum_time_ / 1000.0f / test_number_;
  }
  std::string ReplaceString(
      const std::string& str,
      const std::string& str_src,
      const std::string& str_dst) {
    std::string::size_type pos = 0;
    std::string::size_type len_src = str_src.size();
    std::string::size_type len_dst = str_dst.size();

    std::string result = str;
    pos = result.find(str_src, pos);
    while (pos != std::string::npos) {
      result.replace(pos, len_src, str_dst);
      pos = result.find(str_src, pos + len_dst);
    }
    return result;
  }

 private:
  bool success_;
  bool finished_;
  int  number_;
  int  test_number_;
  int64_t ave_time_;
  int64_t sum_time_;
  int64_t max_time_;
  int64_t min_time_;
  int thread_index_;

 protected:
  virtual void Run() {
    for (int i = 0; i < number_; i++) {
      if (!Test()) {
        success_ = false;
        finished_ = true;
        return;
      }
      test_number_++;
    }
    success_ = true;
    finished_ = true;
  }

  bool Test() {
    std::vector<std::string> model_id_list;
    if (!FLAGS_model_file.empty()) {
      if (!mobvoi::File::ReadFileToLines(FLAGS_model_file, &model_id_list)) {
        LOG(FATAL) << "read model file error: " << FLAGS_model_file;
      }
    }

    std::string text = "";
    std::string model_id = "";
    if (!FLAGS_speak_file.empty()) {
      if (!mobvoi::File::ReadFileToString(FLAGS_speak_file, &text)) {
        LOG(FATAL) << "read speak file error: " << FLAGS_speak_file;
      }
      if (!model_id_list.empty()) {
        int index = test_number_ % model_id_list.size();
        if (FLAGS_test_mode == 2) {
          index = thread_index_ % model_id_list.size();
        }
        model_id = model_id_list[index];
        text = ReplaceString(text, "$voice_name", model_id);
      }
    } else {
      text = "<speak>\n"
          "  <audio src=\"1.wav\" />\n"
          "  <audio src=\"2.wav\" />\n"
          "  <voice name=\"male\">1234</voice>\n"
          "</speak>";
    }
    LOG(INFO) << "request text: " << text;

    int session_id = thread_index_ * number_ + test_number_;
    std::stringstream ss;
    ss << session_id;
    mobvoi::GrpcSynthClient client(FLAGS_grpc_server);
    client.SetSpeaker(model_id);
    client.SetChannelId(ss.str());
    client.StreamingSynthsize(text);
    return client.IsSuccess() && client.GetTotalAudioReceivedTime() > 0;
  }
};

int main(int argc, char** argv) {
  base::AtExitManager at_exit;
  mobvoi::ParseCommandLineFlags(&argc, &argv, false, "");

  LOG(INFO) << "set thread number: " << FLAGS_thread_number
            << ", test count: " << FLAGS_test_count;

  HttpTestThread* threads = new HttpTestThread[FLAGS_thread_number];

  absl::Time start_time = absl::Now();

  // 启动线程
  for (int i = 0; i < FLAGS_thread_number; ++i) {
    threads[i].SetTestNumber(FLAGS_test_count / FLAGS_thread_number);
    threads[i].SetThreadIndex(i);
    threads[i].Start();
    if (!threads[i].running()) {
      LOG(ERROR) << "thread start failure!";
      return 0;
    }
  }

  int test_number = 0;
  while (test_number < FLAGS_test_count) {
    int test_number_tmp = 0;
    for (int i = 0; i < FLAGS_thread_number; i++) {
      test_number_tmp += threads[i].GetTestNumber();
      if (!threads[i].isFinished()) continue;
      if (!threads[i].isSuccess()) {
        LOG(ERROR) << "test failure!";
        return 0;
      }
    }
    if (test_number_tmp != test_number) {
      test_number = test_number_tmp;
      LOG(INFO) << "tested " << test_number << "/" << FLAGS_test_count;
    }
    absl::SleepFor(absl::Milliseconds(1));
  }

  absl::Time end_time = absl::Now();
  absl::Duration t = end_time - start_time;
  LOG(INFO) << "test success! total time: "
            << absl::ToInt64Milliseconds(t) / 1000.0 << "s";
  for (int i = 0 ; i < FLAGS_thread_number; ++i) {
    threads[i].PrintResult();
  }
  delete[] threads;
}

