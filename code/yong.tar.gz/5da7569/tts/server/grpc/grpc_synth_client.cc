// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com

#include "tts/server/grpc/grpc_synth_client.h"

#include "absl/time/clock.h"
#include "absl/time/time.h"
#include "mobvoi/base/log.h"

namespace mobvoi {

GrpcSynthClient::GrpcSynthClient(const std::string& server)
  : audio_frame_size_(160)
  , audio_result_length_(0)
  , first_audio_received_time_(0)
  , total_audio_received_time_(0)
  , success_(true) {
  this->stub_ = Synthesizer::NewStub(grpc::CreateChannel(
      server, grpc::InsecureChannelCredentials()));
  LOG(INFO) << "set server : " << server;
}

GrpcSynthClient::~GrpcSynthClient() {}

void GrpcSynthClient::StreamingSynthsize(const std::string& text) {
  if (text.empty()) return;
  absl::Time start_time = absl::Now();
  LOG(INFO) << "synthsize start: channel id: " << channel_id_;

  ClientContext context;
  SynthesizeRequest request;
  request.set_channel_id(channel_id_);
  request.set_text(text);
  request.set_frame_size(audio_frame_size_);

  std::unique_ptr<ClientReader<SynthesizeResponse> >
      reader(stub_->synthesize(&context, request));
  std::stringstream response_audio_data;
  SynthesizeResponse response;
  bool first_audio_received = false;
  LOG(INFO) << "request start: channel id: " << channel_id_;
  absl::Time request_time = absl::Now();
  while (reader->Read(&response)) {
    std::string audio_data = response.content();
    if (audio_data.empty()) {
      LOG(INFO) << "Streaming synth response audio empty";
      continue;
    } else {
      if (!first_audio_received) {
        first_audio_received_time_ =
            absl::ToInt64Milliseconds(absl::Now() - start_time);
        int64_t first_audio_request_time =
            absl::ToInt64Milliseconds(absl::Now() - request_time);
        LOG(INFO) << "first response audio, len: " << audio_data.length()
                  << ", time: " << first_audio_received_time_
                  << ", reponse time: " << first_audio_request_time
                  << ", speaker: " << speaker_
                  << ", channel id: " << channel_id_;
        first_audio_received = true;
      }
      VLOG(2) << "receive response audio, len: " << audio_data.length();
    }
    response_audio_data << audio_data;
  }

  total_audio_received_time_ =
      absl::ToInt64Milliseconds(absl::Now() - start_time);
  int64_t total_audio_reponse_time =
            absl::ToInt64Milliseconds(absl::Now() - request_time);
  LOG(INFO) << "receive response audio finish, len: "
            << response_audio_data.str().length()
            << ", time: " << total_audio_received_time_
            << ", reponse time: " << total_audio_reponse_time
            << ", channel id: " << channel_id_;
  audio_result_length_ = response_audio_data.str().length();

  Status status = reader->Finish();
  if (!status.ok()) {
    LOG(ERROR) << "Streaming synth failed "
               << status.error_code() << " "
               << status.error_message();
    success_ = false;
  }
}

void GrpcSynthClient::SetAudioFrameSize(int frame_size) {
  if (frame_size <= 0) {
    LOG(ERROR) << "frame size set error: " << frame_size;
    return;
  }
  audio_frame_size_ = frame_size;
}

int64_t GrpcSynthClient::GetAudioResultLength() {
  return audio_result_length_;
}

int64_t GrpcSynthClient::GetFirstAudioReceivedTime() {
  return first_audio_received_time_;
}

int64_t GrpcSynthClient::GetTotalAudioReceivedTime() {
  return total_audio_received_time_;
}

bool GrpcSynthClient::IsSuccess() {
  return success_;
}

void GrpcSynthClient::SetSpeaker(const std::string& speaker) {
  speaker_ = speaker;
}

void GrpcSynthClient::SetChannelId(const std::string& channel_id) {
  channel_id_ = channel_id;
}

}  // namespace mobvoi
