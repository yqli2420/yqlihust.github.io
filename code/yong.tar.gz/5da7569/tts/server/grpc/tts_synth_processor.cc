// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com

#include "tts/server/grpc/tts_synth_processor.h"

#include "mobvoi/base/log.h"
#include "mobvoi/base/singleton.h"
#include "mobvoi/matrix/kaldi-matrix.h"
#include "mobvoi/util/wave_reader.h"
#include "third_party/xml2/libxml/parser.h"
#include "tts/server/cache_handler.h"
#include "tts/server/grpc/html_page_info.h"
#include "tts/server/grpc/http_synth_client.h"
#include "tts/server/grpc/model_manager.h"
#include "tts/server/grpc/record_audio_info.h"
#include "tts/server/grpc/synth_config.h"
#include "tts/server/grpc/tts_resource_manager.h"
#include "tts/util/encoder/encoder.h"
#include "tts/util/encoder/sampling_rate_converter.h"
#include "tts/util/tts_util/util.h"

DEFINE_bool(enable_adjust_speed, false, "enable adjust speed or not");
DEFINE_bool(enable_silence_filter, true, "enable filter silence or not");
DEFINE_int32(callback_frames, 50, "callback frames in lpcnet streming");
DEFINE_string(default_synth_file_format, "", "default synth file format");
DEFINE_string(default_adap_post_speaker, "cissy",
              "default adaption post speaker");
DECLARE_string(save_adaptation_model_dir);

namespace mobvoi {

using kaldi::WaveData;
using kaldi::BaseFloat;
using kaldi::Vector;
using kaldi::VectorBase;
using kaldi::Matrix;
using kaldi::SubMatrix;

TtsSynthProcessor::TtsSynthProcessor()
    : synthesis_server_url_("http://tts.mobvoi.com/api/synthesis"),
      tts_ssml_entity_list_(nullptr),
      sample_rate_(8000),
      synth_request_http_(true),
      synthesis_interface_(nullptr),
      synthesizer_(nullptr) {}

TtsSynthProcessor::~TtsSynthProcessor() {}

bool TtsSynthProcessor::Synthesize(
    std::list<TtsSsmlEntity>* tts_ssml_entity_list, bool async) {
  if (tts_ssml_entity_list == nullptr) return false;
  for (auto it = tts_ssml_entity_list->begin();
       it != tts_ssml_entity_list->end(); ++it) {
    if (it->GetSsmlLabel().compare("audio") == 0) {
      RecordAudioInfo* record_audio_info =
          TtsResourceManager::GetInstance()->GetRecordAudioInfo(
              it->GetAudioSrc());
      if (record_audio_info == nullptr) {
        LOG(ERROR) << "get record audio info error: " + it->GetAudioSrc();
        if (this->synthesis_interface_ != nullptr) {
          synthesis_interface_->OnSynthesisPartial(&(*it), false);
        }
        continue;
      } else {
        const std::string& audio_data = record_audio_info->GetAudioData();
        if (audio_data.empty()) {
          LOG(ERROR) << "audio content empty error: " << it->GetSsmlText();
          if (this->synthesis_interface_ != nullptr) {
            synthesis_interface_->OnSynthesisPartial(&(*it), false);
          }
          continue;
        } else {
          double volume = ::atof(it->GetProsodyVolume().c_str());
          double speed = 1.0;
          // 如果没有开启调速，则取本地设置值
          if (FLAGS_enable_adjust_speed) {
            speed = ::atof(it->GetProsodyRate().c_str());
          } else {
            speed = ::atof(it->GetDefaultSynthRate().c_str());
          }
          // resample local audio
          int sample_rate = record_audio_info->GetSampleRate();
          if (sample_rate != sample_rate_) {
            speed *= static_cast<double>(sample_rate) / sample_rate_;
          }
          LOG(INFO) << "resample audio sample rate: " << sample_rate << "->"
                    << sample_rate_;
          std::string data = AdjustWavVolume(audio_data, volume, 1);
          if (speed != 1.0) {
            data = AdjustWavSpeed(data, speed, 1);
          }
          it->AppendAudioData(data);
          it->SetAppendAudioFinished(true);
          if (this->synthesis_interface_ != nullptr) {
            synthesis_interface_->OnSynthesisPartial(&(*it), true);
          }
        }
      }
    } else if (synth_request_http_ && !it->GetSsmlText().empty() &&
               !synthesis_server_url_.empty()) {
      HttpSynthClient client;
      client.SetAudioType("pcm");
      client.SetRequestUrl(synthesis_server_url_);
      client.SetMandarinSpeaker(it->GetVoiceName());
      client.SetSampleRate(sample_rate_);
      client.SetAudioSpeed(::atof(it->GetProsodyRate().c_str()));
      // if (client.RequestSynthesis(it->GetSsmlText(), true)) {
      std::string ssml_text = "<speak>" + it->GetValueAsSsml() + "</speak>";
      if (client.RequestSynthesis(ssml_text, async)) {
        while (!client.OutputResultFinished()) {
          const std::string& audio_data = client.GetSynthesisResult();
          double volume = ::atof(it->GetProsodyVolume().c_str());
          std::string data = AdjustWavVolume(audio_data, volume, 1);
          it->AppendAudioData(data);
          it->SetErrorFlag(false);
          it->SetAppendAudioFinished(true);
          VLOG(1) << "request http synth success: len: " << data.length();
        }
      } else {
        LOG(ERROR) << "request http synth client error";
        it->SetErrorFlag(true);
      }
    } else if (!synth_request_http_ && !it->GetSsmlText().empty()) {
      this->Synthesize(&(*it));
    } else if (it->GetSsmlLabel().compare("break") == 0) {
      std::string break_time = it->GetBreakTime();
      if (break_time.empty()) continue;
      int break_time_ms = atoi(break_time.c_str());
      if (break_time_ms <= 0) continue;
      int len = sample_rate_ * 2 * break_time_ms / 1000.0f;
      if (len % 2 != 0) len += 1;
      it->AppendAudioData(std::string(len, 0));
      it->SetAppendAudioFinished(true);
    }
  }
}

bool TtsSynthProcessor::Synthesize(TtsSsmlEntity* ssml_entity) {
  if (ssml_entity == nullptr || synthesizer_ == nullptr) return false;
  double volume = ::atof(ssml_entity->GetProsodyVolume().c_str());
  double speed = ::atof(ssml_entity->GetProsodyRate().c_str());
  tts::TTSOption tts_option;
  tts::SetDefaultTTSOption(&tts_option);
  std::string data_res = "";
  std::string speaker = ssml_entity->GetVoiceName();
  std::shared_ptr<engine::Engine> engine = nullptr;
  std::string model_id = "";
  if (!synthesizer_->CheckSpeaker(speaker)) {
    engine = ModelManager::GetInstance()->GetEngine(speaker);
    if (engine == nullptr) {
      LOG(INFO) << "model not exist: " << speaker;
      std::string default_speaker = ssml_entity->GetDefaultVoiceName();
      LOG(WARNING) << "speaker [" << speaker << "] not found, "
                   << "reset to default speaker: " << default_speaker;
      speaker = default_speaker;
    } else {
      LOG(INFO) << "engine create success: " << speaker;
      model_id = speaker;
      speaker = FLAGS_default_adap_post_speaker;
    }
  }
  std::string file_format = "pcm";
  if (!FLAGS_default_synth_file_format.empty()) {
    file_format = FLAGS_default_synth_file_format;
  } else if (speaker.find("lpcnet") != std::string::npos && engine == nullptr) {
    file_format = "pcm_streaming";
  }
  server::ServerUtil::SetAllParams(request_parameter_, "block", &tts_option,
                                   nullptr);
  tts_option.set_sampling_frequency(sample_rate_);
  tts_option.set_file_format(file_format);
  tts_option.set_speed(speed);
  tts_option.set_volume(volume);
  tts_option.set_callback_frames(FLAGS_callback_frames);
  if (engine != nullptr) {
    tts_option.set_model_id(model_id);
  }
  tts_option.set_speaker(speaker);
  std::string ssml_text =
      "<speak>" + ssml_entity->GetValueAsSsml() + "</speak>";
  // generate cache key
  string cache_key = server::GenCacheKey(tts_option, ssml_text);
  auto cache = Singleton<server::TtsCache>::get();
  if (cache->UseTtsCache() && cache->CanFetch(cache_key) &&
      (engine == nullptr ||
       (engine != nullptr &&
        !ModelManager::GetInstance()->IsModelUpdate(model_id)))) {
    cache->GetData(cache_key, &data_res);
    LOG(INFO) << "use cache instead: length: " << data_res.length();
  } else {
    // synthesizer_->Synthesize(ssml_text, tts_option, &data_res);
    synth_event_.SetSsmlEntity(ssml_entity);
    synth_event_.SetChannelId(channel_id_);
    if (engine == nullptr) {
      synthesizer_->Synthesize(ssml_text, tts_option, &synth_event_);
    } else {
      synthesizer_->Synthesize(ssml_text, tts_option, &synth_event_, engine);
    }
    const std::string& audio_data = ssml_entity->GetAudioData();
    if (cache->UseTtsCache() && !audio_data.empty()) {
      cache->PutInCache(cache_key, ssml_entity->GetAudioData());
      ModelManager::GetInstance()->ClearModelUpdate(model_id);
    }
    return true;
  }

  // for lpcnet, do not remove silence
  if ((speaker.find("lpcnet") != std::string::npos ||
       !FLAGS_enable_silence_filter) &&
      engine == nullptr) {
    if (!data_res.empty()) {
      ssml_entity->AppendAudioData(data_res);
      ssml_entity->SetAppendAudioFinished(true);
    }
    return true;
  }

  // remove silence in audio
  std::size_t start_index = 0;
  std::size_t end_index = data_res.length() - 1;
  for (int i = 0; i < data_res.length(); i += 2) {
    if (i + 1 >= data_res.length()) break;
    if (data_res[i] != 0 || data_res[i + 1] != 0) {
      break;
    } else {
      start_index = i;
    }
  }
  for (int i = data_res.length() - 2; i >= 0; i -= 2) {
    if (i < 0) break;
    if (data_res[i] != 0 || data_res[i + 1] != 0) {
      break;
    } else {
      end_index = i;
    }
  }
  if (!data_res.empty() && start_index <= end_index) {
    ssml_entity->AppendAudioData(
        data_res.substr(start_index, end_index - start_index));
    ssml_entity->SetAppendAudioFinished(true);
  }
  return true;
}

bool TtsSynthProcessor::ProcessSynthesize(
    std::list<TtsSsmlEntity>* tts_ssml_entity_list, bool async) {
  if (tts_ssml_entity_list == nullptr) return false;
  if (async) {
    this->tts_ssml_entity_list_ = tts_ssml_entity_list;
    this->Start();
  } else {
    this->Synthesize(tts_ssml_entity_list, async);
  }
}

void TtsSynthProcessor::Run() {
  if (this->tts_ssml_entity_list_ == nullptr || tts_ssml_entity_list_->empty())
    return;
  this->Synthesize(tts_ssml_entity_list_);
}

std::string TtsSynthProcessor::AdjustWavSpeed(const std::string& audio_content,
                                              double speed,
                                              int channel_number) {
  if (audio_content.length() <= 2 || speed <= 0 || speed == 1 ||
      channel_number <= 0) {
    return audio_content;
  }
  int resample_rate = static_cast<int>(sample_rate_ / speed);

  int num_samp = audio_content.length() / 2;
  const char* buffer = audio_content.c_str();
  std::vector<int16> sample_points(num_samp);
  for (int i = 0; i < num_samp; i++) {
    const int16* s = reinterpret_cast<const int16*>(buffer + i * 2);
    sample_points[i] = *s;
  }
  std::vector<int16> resample_points;

  SamplingRateConverter converter;
  converter.ConvertSamplingRate(sample_points, sample_rate_, resample_rate,
                                &resample_points);
  int num_resamp = resample_points.size();
  std::string result(num_resamp * 2, '\0');

  for (int i = 0; i < num_resamp; ++i) {
    int16 s = resample_points[i];
    const char* ch = reinterpret_cast<const char*>(&s);
    result[i * 2] = *ch;
    result[i * 2 + 1] = *(ch + 1);
  }
  return result;
}

std::string TtsSynthProcessor::AdjustWavVolume(const std::string& audio_content,
                                               double volume,
                                               int channel_number) {
  if (audio_content.length() <= 2 || volume <= 0 || volume == 1 ||
      channel_number <= 0) {
    return audio_content;
  }

  int32_t min_data = -0x8000;
  int32_t max_data = 0x7FFF;

  int sample_number = audio_content.length() / channel_number / 2;
  sample_number -= sample_number % (channel_number * 2);

  const char* audio_data = audio_content.c_str();
  Vector<BaseFloat> resample_points(sample_number);
  for (int i = 0; i < sample_number; ++i) {
    const int16* s = reinterpret_cast<const int16*>(audio_data + i * 2);
    int32_t value = (*s) * volume;
    if (value < min_data)
      value = min_data;
    else if (value > max_data)
      value = max_data;
    resample_points(i) = value;
  }

  std::string result(sample_number * 2, '\0');
  for (int i = 0; i < sample_number; ++i) {
    int16 s = resample_points(i);
    const char* ch = reinterpret_cast<const char*>(&s);
    result[i * 2] = *ch;
    result[i * 2 + 1] = *(ch + 1);
  }
  return result;
}

std::string TtsSynthProcessor::CreateWavHeader(const std::string& src,
                                               int channel_number,
                                               int sample_rate) {
  if (src.empty()) return "";
  int num_samp = src.length() / 2 / channel_number;
  int subchunk2size = channel_number * num_samp * 2;

  char header[44] = {0};
  int header_index = 0;
  memcpy(header, "RIFF", 4);
  header_index += 4;

  int32_t chunk_size = subchunk2size + 36;
  header[header_index + 3] = (chunk_size >> 24);
  header[header_index + 2] = (chunk_size >> 16) & 0xFF;
  header[header_index + 1] = (chunk_size >> 8) & 0xFF;
  header[header_index + 0] = (chunk_size & 0xFF);
  header_index += 4;

  memcpy(header + header_index, "WAVEfmt ", 8);
  header_index += 8;

  int32_t wave_format = 16;  // pcm without zip
  header[header_index + 3] = wave_format >> 24;
  header[header_index + 2] = (wave_format >> 16) & 0xFF;
  header[header_index + 1] = (wave_format >> 8) & 0xFF;
  header[header_index + 0] = wave_format & 0xFF;
  header_index += 4;

  header[header_index + 1] = 0x00;
  header[header_index + 0] = 0x01;  // WAVE_FORMAT_PCM
  header_index += 2;

  header[header_index + 1] = 0x00;
  header[header_index + 0] = channel_number;  //
  header_index += 2;

  header[header_index + 3] = sample_rate >> 24;
  header[header_index + 2] = (sample_rate >> 16) & 0xFF;
  header[header_index + 1] = (sample_rate >> 8) & 0xFF;
  header[header_index + 0] = sample_rate & 0xFF;
  header_index += 4;

  int32_t data_transfer_rate = channel_number * sample_rate * 2;
  header[header_index + 3] = data_transfer_rate >> 24;
  header[header_index + 2] = (data_transfer_rate >> 16) & 0xFF;
  header[header_index + 1] = (data_transfer_rate >> 8) & 0xFF;
  header[header_index + 0] = data_transfer_rate & 0xFF;
  header_index += 4;

  header[header_index + 1] = 0x00;
  header[header_index + 0] = 0x02;  // data chunk content
  header_index += 2;

  header[header_index + 1] = 0x00;
  header[header_index + 0] = 0x10;  // 16bit
  header_index += 2;

  memcpy(header + header_index, "data", 4);
  header_index += 4;

  header[header_index + 3] = subchunk2size >> 24;
  header[header_index + 2] = (subchunk2size >> 16) & 0xFF;
  header[header_index + 1] = (subchunk2size >> 8) & 0xFF;
  header[header_index + 0] = subchunk2size & 0xFF;
  header_index += 4;

  return std::string(header, 44);
}

void TtsSynthProcessor::SetSynthesisServerUrl(const std::string& url) {
  synthesis_server_url_ = url;
}

void TtsSynthProcessor::SetSynthesisInterface(
    TtsSynthInterface* synthesis_interface) {
  synthesis_interface_ = synthesis_interface;
}

void TtsSynthProcessor::SetSynthesisSpeakerInfoFile(
    const std::string& file_path) {
  this->synthesis_speaker_info_file_ = file_path;
}

void TtsSynthProcessor::SetSynthesisRequestHttp(bool synth_request_http) {
  this->synth_request_http_ = synth_request_http;
}

void TtsSynthProcessor::SetSynthesizer(tts::Synthesizer* synthesizer) {
  this->synthesizer_ = synthesizer;
}

void TtsSynthProcessor::SetSynthesisSampleRate(int sample_rate) {
  if (sample_rate <= 0) {
    LOG(ERROR) << "sample rate set error: " << sample_rate;
    return;
  }
  sample_rate_ = sample_rate;
}

void TtsSynthProcessor::SetChannelId(const std::string& channel_id) {
  channel_id_ = channel_id;
}

void TtsSynthProcessor::SetSynthesisRequestParameter(
    const std::map<std::string, std::string>& param) {
  this->request_parameter_ = param;
}

}  // namespace mobvoi
