// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com

#include "tts/server/grpc/html_page_info.h"

#include "mobvoi/base/file.h"
#include "mobvoi/base/log.h"

namespace mobvoi {

HtmlPageInfo::HtmlPageInfo() {}

HtmlPageInfo::~HtmlPageInfo() {}

const std::string& HtmlPageInfo::GetPageName() { return page_name_; }

const std::string& HtmlPageInfo::GetPageContent() { return page_content_; }

const std::string& HtmlPageInfo::GetPagePath() { return page_path_; }

bool HtmlPageInfo::LoadHtmlPageFromFile(const std::string& file_path) {
  if (file_path.empty()) return false;
  if (mobvoi::File::ReadFileToStringWithMmap(file_path, &page_content_)) {
    LOG(INFO) << "load html file success: " << file_path;
    this->page_path_ = file_path;
  } else {
    LOG(ERROR) << "load html file failure: " << file_path;
    return false;
  }
  return true;
}

}  // namespace mobvoi
