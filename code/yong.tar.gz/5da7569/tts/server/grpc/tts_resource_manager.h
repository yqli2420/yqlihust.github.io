// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaokai.yang@mobvoi.com

#ifndef TTS_SERVER_GRPC_TTS_RESOURCE_MANAGER_H_
#define TTS_SERVER_GRPC_TTS_RESOURCE_MANAGER_H_

#include <map>
#include <string>
#include <memory>

#include "tts/server/grpc/html_page_info.h"
#include "tts/server/grpc/record_audio_info.h"

namespace mobvoi {

class TtsResourceManager {
 private:
  TtsResourceManager();

 public:
  virtual ~TtsResourceManager();

  static TtsResourceManager* GetInstance();
  bool LoadHtmlPageFromDir(const std::string& html_page_dir);
  bool LoadRecordAudioFromDir(const std::string& record_audio_dir);

  HtmlPageInfo* GetHtmlPageInfo(const std::string& page_path);
  RecordAudioInfo* GetRecordAudioInfo(const std::string& record_audio_id);

 private:
  static std::unique_ptr<TtsResourceManager> instance;
  std::map<std::string, HtmlPageInfo> html_page_map_;
  std::map<std::string, RecordAudioInfo> record_audio_map_;

  std::string html_page_dir_;
  std::string record_audio_dir_;
};

}  // namespace mobvoi

#endif  // TTS_SERVER_GRPC_TTS_RESOURCE_MANAGER_H_
