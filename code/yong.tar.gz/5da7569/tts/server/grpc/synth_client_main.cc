// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "mobvoi/base/at_exit.h"
#include "mobvoi/base/base64.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/file/proto_util.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/util/net/http_server/http_server.h"
#include "tts/server/grpc/grpc_synth_service.h"
#include "tts/server/grpc/http_synth_service.h"
#include "tts/server/grpc/tts_resource_manager.h"
#include "tts/server/grpc/grpc_synth_client.h"

DEFINE_string(grpc_server, "127.0.0.1:8080", "grpc server host");
DEFINE_int32(http_server, 8081, "");
DEFINE_string(speak_file, "", "speak text file path");

int main(int argc, char** argv) {
  base::AtExitManager at_exit;
  mobvoi::ParseCommandLineFlags(&argc, &argv, false, "");

  std::string text = "";
  if (!FLAGS_speak_file.empty()) {
    if (!mobvoi::File::ReadFileToString(FLAGS_speak_file, &text)) {
      LOG(FATAL) << "read speak file error: " << FLAGS_speak_file;
    }
  } else {
    text = "<speak>\n"
        "  <audio src=\"1.wav\" />\n"
        "  <audio src=\"2.wav\" />\n"
        "  <voice name=\"male\">1234</voice>\n"
        "</speak>";
  }

  mobvoi::GrpcSynthClient client(FLAGS_grpc_server);
  client.StreamingSynthsize(text);
}
