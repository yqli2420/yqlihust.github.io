// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: jwang@mobvoi.com (Jian Wang)

#ifndef TTS_SERVER_ASYNC_LOGGER_H_
#define TTS_SERVER_ASYNC_LOGGER_H_

#include <string>
#include <vector>

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/concurrent_queue.h"
#include "mobvoi/base/thread.h"
#include "mobvoi/base/singleton.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/flags.h"
#include "third_party/gtest/gtest_prod.h"

namespace server {
class LoggerStream {
 public:
  LoggerStream() {}
  virtual ~LoggerStream() {}

  virtual bool WriteToStream(const string& message) = 0;

 private:
  DISALLOW_COPY_AND_ASSIGN(LoggerStream);
};

class AsyncLoggerThread : public mobvoi::Thread {
 public:
  explicit AsyncLoggerThread(mobvoi::ConcurrentQueue<string>* in_queue);

  virtual ~AsyncLoggerThread();

  void Terminate();

 protected:
  unique_ptr<LoggerStream> logger_stream_;
  mobvoi::ConcurrentQueue<string>* in_queue_;
  bool terminate_;

 private:
  DISALLOW_COPY_AND_ASSIGN(AsyncLoggerThread);
};

class AsyncLogger {
 public:
  ~AsyncLogger();

  // It's thread-safe now.
  void Log(const string& msg);

 private:
  AsyncLogger();
  void Close();

  mobvoi::ConcurrentQueue<string> concurr_queue_;
  unique_ptr<AsyncLoggerThread> logger_thread_;
  bool started_;

  FRIEND_TEST(AsyncLoggerTest, AsyncLogger);
  friend struct DefaultSingletonTraits<AsyncLogger>;
  DISALLOW_COPY_AND_ASSIGN(AsyncLogger);
};
}  // namespace server

#endif  // TTS_SERVER_ASYNC_LOGGER_H_
