// Copyright 2014 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include <signal.h>
#include <cstdio>

#include "mobvoi/base/at_exit.h"
#include "mobvoi/base/base64.h"
#include "mobvoi/base/callback.h"
#include "mobvoi/base/concurrent_queue.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/file/proto_util.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/base/time.h"
#include "mobvoi/util/net/http_server/http_server.h"
#include "tts/nlp/g2p/g2p.h"
#include "tts/server/server_util.h"
#include "tts/server/streaming_service_handler.h"
#include "tts/synthesizer/interface/synthesizer_event_handler.h"
#include "tts/synthesizer/label_generator/label_util.h"
#include "tts/synthesizer/label_generator/mandarin/mandarin_label_generator.h"
#include "tts/synthesizer/synthesizer.h"
#include "tts/util/tts_util/util.h"

DEFINE_int32(listen_port, 10012, "");
DEFINE_int32(thread_num, 10, "");
DEFINE_string(homepage_html, "external/config/web_server/www/tts-mobvoi.html",
              "");
DEFINE_string(test_cases_html, "external/config/web_server/www/test_cases.html",
              "");
DEFINE_int32(sampling_frequency, 16000, "");
DEFINE_string(wave_type, "wav", "wav | mp3 | speex-wb-10");
DEFINE_string(g2p_model_path,
              "external/config/g2p/model/g2p_pinyin_with_tone_char_1009.fst",
              "g2p model path");
DEFINE_string(speaker_info_file, "external/config/config_file/speakers.json",
              "speaker info json file");
DEFINE_string(language_type, "mandarin", "mandarin | english");
DECLARE_string(phone_map_file);
DECLARE_string(mandarin_hts_model);
DECLARE_string(english_hts_model);
DECLARE_double(additional_gain);
DECLARE_string(rnn_model);
DECLARE_string(synthesis_type);

namespace server {
class TTSDemoServer {
 public:
  TTSDemoServer();
  ~TTSDemoServer() {}

  bool GetHomePage(util::HttpRequest* request, util::HttpResponse* response);
  bool GetTestCasesPage(util::HttpRequest* request,
                        util::HttpResponse* response);
  bool GetSpeakers(util::HttpRequest* request, util::HttpResponse* response);
  bool Synthesize(util::HttpRequest* request, util::HttpResponse* response);
  bool Debug(util::HttpRequest* request, util::HttpResponse* response);

 public:
  shared_ptr<tts::Synthesizer> tts_;

 private:
  string GetLabel(const tts::SentInfo& sentence);
  void GetPhrase(const tts::SentInfo sentence, vector<string>* phrases);
  string GetPreProcessingResult(const string& norm, vector<string>* phone_seq,
                                tts::SentInfo* sentence);

  string home_page_;
  string test_cases_page_;

  DISALLOW_COPY_AND_ASSIGN(TTSDemoServer);
};

TTSDemoServer::TTSDemoServer() {
  mobvoi::File::ReadFileToStringWithMmap(FLAGS_homepage_html, &home_page_);
  mobvoi::File::ReadFileToStringWithMmap(FLAGS_test_cases_html,
                                         &test_cases_page_);

  tts_.reset(new tts::Synthesizer(FLAGS_speaker_info_file));
}

bool TTSDemoServer::GetSpeakers(util::HttpRequest* request,
                                util::HttpResponse* response) {
  response->AppendHeader("Content-Type", "text/html; charset=utf-8");
  LOG(INFO) << "Get All Speakers";

  auto mand_speakers = tts_->GetSpeakers(tts::kMandarinTypeString);
  auto eng_speakers = tts_->GetSpeakers(tts::kEnglishTypeString);
  auto can_speakers = tts_->GetSpeakers(tts::kCantoneseTypeString);
  auto sichuan_speakers = tts_->GetSpeakers(tts::kSichuaneseTypeString);

  std::string speakers;

  for (size_t i = 0; i < mand_speakers.size(); ++i) {
    if (mand_speakers[i].second) {
      speakers += mand_speakers[i].first + ",";
    }
  }
  speakers = speakers.substr(0, speakers.size() - 1);
  speakers += ";";
  for (size_t i = 0; i < eng_speakers.size(); ++i) {
    if (eng_speakers[i].second) {
      speakers += eng_speakers[i].first + ",";
    }
  }
  speakers = speakers.substr(0, speakers.size() - 1);
  speakers += ";";
  for (size_t i = 0; i < can_speakers.size(); ++i) {
    if (can_speakers[i].second) {
      speakers += can_speakers[i].first + ",";
    }
  }
  speakers = speakers.substr(0, speakers.size() - 1);
  speakers += ";";
  for (size_t i = 0; i < sichuan_speakers.size(); ++i) {
    if (sichuan_speakers[i].second) {
      speakers += sichuan_speakers[i].first + ",";
    }
  }
  speakers = speakers.substr(0, speakers.size() - 1);
  response->AppendBuffer(speakers);
  return true;
}

bool TTSDemoServer::GetHomePage(util::HttpRequest* request,
                                util::HttpResponse* response) {
  response->AppendHeader("Content-Type", "text/html; charset=utf-8");
  LOG(INFO) << "Receive request for homepage";
  response->AppendBuffer(home_page_);
  return true;
}

bool TTSDemoServer::GetTestCasesPage(util::HttpRequest* request,
                                     util::HttpResponse* response) {
  response->AppendHeader("Content-Type", "text/html; charset=utf-8");
  LOG(INFO) << "Receive request for homepage";
  response->AppendBuffer(test_cases_page_);
  return true;
}

bool TTSDemoServer::Synthesize(util::HttpRequest* request,
                               util::HttpResponse* response) {
  // Get text
  map<string, string> params;
  if (request->HttpMethod() == util::HttpMethodType_kGet) {
    request->GetQueryParams(&params);
  } else if (request->HttpMethod() == util::HttpMethodType_kPost) {
    request->GetPostParams(&params);
  } else {
    LOG(ERROR) << "Don't support this method : " << request->HttpMethod();
    // Go through here, return error message since text is empty.
  }

  vector<string> segs;
  mobvoi::SplitStringToVector(params["speaker"], " ", true, &segs);
  params["speaker"] = segs[0];
  for (auto iter : params) {
    LOG(INFO) << iter.first << " : " << iter.second;
  }

  tts::TTSOption tts_option;
  tts::SetDefaultTTSOption(&tts_option);
  ServerUtil::SetTTSOption(params, &tts_option);

  std::string text = params["text"];

  // response->AppendHeader("Access-Control-Allow-Origin", "*");
  // response->AppendHeader("Access-Control-Allow-Headers", "X-Requested-With");
  // response->AppendHeader("Access-Control-Allow-Methods",
  //                        "PUT,POST,GET,DELETE,OPTIONS");
  if (tts_option.file_format() == "wav") {
    response->AppendHeader("Content-Type", "audio/wav");
  } else if (tts_option.file_format() == "mp3") {
    response->AppendHeader("Content-Type", "audio/mpeg");
  }

  int begin = mobvoi::GetTimeInMs();
  std::string ret_str;
  tts_->Synthesize(text, tts_option, &ret_str);

  if (!tts_option.detail_output()) {
    std::string audio_data;
    base::Base64Encode(ret_str, &audio_data);
    response->AppendBuffer(audio_data);
  } else {
    response->AppendBuffer(ret_str);
  }

  int end = mobvoi::GetTimeInMs();
  LOG(INFO) << "used time (Ms):" << end - begin;
  return true;
}

}  // namespace server

using std::placeholders::_1;
using std::placeholders::_2;

int main(int argc, char** argv) {
  base::AtExitManager at_exit;
  google::ParseCommandLineFlags(&argc, &argv, false);
  google::InitGoogleLogging(argv[0]);

  util::HttpServer http_server(FLAGS_listen_port, FLAGS_thread_num);

  server::TTSDemoServer tts_server;

  auto callback =
      std::bind(&server::TTSDemoServer::Synthesize, &tts_server, _1, _2);
  util::DefaultHttpHandler dump_handler(callback);
  http_server.RegisterHttpHandler("/synthesis", &dump_handler);

  server::StreamingHttpHandler streaming_tts_handler(
      nullptr, false, tts_server.tts_, nullptr, nullptr);
  http_server.RegisterChunkedHttpHandler("/streaming", &streaming_tts_handler);

  auto callbacks =
      std::bind(&server::TTSDemoServer::GetHomePage, &tts_server, _1, _2);
  util::DefaultHttpHandler home_handler(callbacks);
  http_server.RegisterHttpHandler("/tts", &home_handler);

  auto callbacks_test_cases =
      std::bind(&server::TTSDemoServer::GetTestCasesPage, &tts_server, _1, _2);
  util::DefaultHttpHandler test_cases_handler(callbacks_test_cases);
  http_server.RegisterHttpHandler("/test_cases", &test_cases_handler);

  auto callbacks_speaker =
      std::bind(&server::TTSDemoServer::GetSpeakers, &tts_server, _1, _2);
  util::DefaultHttpHandler speaker_handler(callbacks_speaker);
  http_server.RegisterHttpHandler("/speakers", &speaker_handler);

  http_server.Serv();

  return 0;
}
