// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_SERVER_ALIGN_SERVICE_HANDLER_H_
#define TTS_SERVER_ALIGN_SERVICE_HANDLER_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "tts/server/cache_handler.h"
#include "tts/server/server_util.h"
#include "tts/synthesizer/interface/synthesizer_interface.h"

namespace util {
class HttpRequest;
class HttpResponse;
}  // namespace util

namespace server {
class AsyncLogger;

class AlignServerHandler {
 public:
  AlignServerHandler(std::shared_ptr<tts::SynthesizerInterface> _synthesizer,
                     bool use_license,
                     mobvoi::ConcurrentQueue<KibanaData>* _data_queue,
                     mobvoi::ConcurrentQueue<KibanaData>* _log_queue);
  ~AlignServerHandler();

  bool Synthesize(util::HttpRequest* request,
                  util::HttpResponse* response) const;

 private:
  bool use_license_;
  std::shared_ptr<tts::SynthesizerInterface> tts_;
  AsyncLogger* logger_;
  mobvoi::ConcurrentQueue<KibanaData>* data_queue_;
  mobvoi::ConcurrentQueue<KibanaData>* log_queue_;
  DISALLOW_COPY_AND_ASSIGN(AlignServerHandler);
};
}  // namespace server

#endif  // TTS_SERVER_ALIGN_SERVICE_HANDLER_H_
