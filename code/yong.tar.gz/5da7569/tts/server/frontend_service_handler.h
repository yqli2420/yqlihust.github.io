// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaoqin.feng@mobvoi.com

#ifndef TTS_SERVER_FRONTEND_SERVICE_HANDLER_H_
#define TTS_SERVER_FRONTEND_SERVICE_HANDLER_H_

#include <map>
#include <string>

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/mutex.h"
#include "third_party/jsoncpp/json.h"
#include "tts/server/server_util.h"
#include "tts/synthesizer/interface/synthesizer_interface.h"

namespace server {

class FrontendServerHandler {
 public:
  FrontendServerHandler(tts::SynthesizerInterface* synthesizer,
                        bool use_license);
  ~FrontendServerHandler();

  bool Synthesize(util::HttpRequest* request, util::HttpResponse* response);

  void ProcessInput(
      const vector<vector<string>>& parse_texts, int* word_num,
      vector<int>* paragraph_sizes,
      mobvoi::ConcurrentQueue<pair<int, string>>* input_queue) const;
  void BatchSynthesize(
      const tts::TTSOption& tts_option,
      mobvoi::ConcurrentQueue<std::pair<int, string>>* input_queue,
      mobvoi::ConcurrentQueue<std::pair<int, Json::Value>>* output_queue) const;
  void PostProcess(
      vector<int> paragraph_sizes,
      mobvoi::ConcurrentQueue<std::pair<int, Json::Value>>* output_queue,
      Json::Value* frontend_data) const;
  bool ConcurrentSynthesize(util::HttpRequest* request,
                            util::HttpResponse* response);
  bool GetFrontendDictSource(util::HttpRequest* request,
                             util::HttpResponse* response);

 private:
  Json::FastWriter writer_;
  bool use_license_;
  mutable mobvoi::Mutex mutex_;
  tts::SynthesizerInterface* tts_;
  AsyncLogger* logger_;
  DISALLOW_COPY_AND_ASSIGN(FrontendServerHandler);
};
}  // namespace server
#endif  // TTS_SERVER_FRONTEND_SERVICE_HANDLER_H_
