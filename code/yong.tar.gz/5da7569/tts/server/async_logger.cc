// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: jwang@mobvoi.com (Jian Wang)

#include "tts/server/async_logger.h"

#include <time.h>
#include <stdio.h>

#include <queue>

#include "mobvoi/base/concurrent_queue.h"
#include "mobvoi/base/time.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/flags.h"

DEFINE_string(tts_log_dir, "log/tts_log/", "");
DEFINE_int32(dump_disk_interval, 86400, "");
DEFINE_int32(max_log_file_size_threshold, 64 * 1025 * 1024, "");

namespace {
static const char kLogFileName[] = "tts.log";
}

namespace server {
class FileLoggerStream : public LoggerStream {
 public:
  FileLoggerStream(const string& log_dir, const string& log_file_name,
                   size_t max_log_file_size_threshold)
      : log_dir_(log_dir),
        log_file_name_(log_file_name),
        log_file_size_(0),
        max_log_file_size_threshold_(max_log_file_size_threshold),
        last_rotate_time_(time(NULL)),
        log_file_handle_(NULL) {
    CHECK(mobvoi::File::Exists(log_dir_));
    CreateLogFile();
  }

  ~FileLoggerStream() {
    if (log_file_handle_) {
      fclose(log_file_handle_);
      log_file_handle_ = NULL;
    }
  }

  bool WriteToStream(const string& message) {
    int64_t size = fwrite(message.data(), 1, message.size(), log_file_handle_);
    if (static_cast<size_t>(size) < message.size()) {
      LOG(WARNING) << "Fail to write message";
      return false;
    }
    log_file_size_ += message.size();
    time_t now = time(NULL);
    if (log_file_size_ > max_log_file_size_threshold_ ||
        ((now - last_rotate_time_) > FLAGS_dump_disk_interval)) {
      Rotate();
      log_file_size_ = 0;
      last_rotate_time_ = now;
    }
    return true;
  }

 private:
  void CreateLogFile() {
    string log_file_path = mobvoi::File::JoinPath(log_dir_, log_file_name_);
    const char* open_mode = mobvoi::File::Exists(log_file_path) ? "a" : "w";
    if (log_file_handle_) {
      fclose(log_file_handle_);
      log_file_handle_ = NULL;
    }
    log_file_handle_ = fopen(log_file_path.c_str(), open_mode);

    CHECK(log_file_handle_) << "Failed to open file:" << log_file_path;
  }

  string CreateRotateLogFileName(const string& log_file_name) {
    string time = mobvoi::GetTimeOfDay(mobvoi::Time::Now());
    string filename = StringPrintf("%s.%s.%ld", log_file_name.c_str(),
                                   time.c_str(), mobvoi::GetTimeInMs());
    return mobvoi::File::JoinPath(log_dir_, filename);
  }

  void Rotate() {
    if (log_file_handle_) {
      fclose(log_file_handle_);
      log_file_handle_ = NULL;
    }
    string log_file_path = mobvoi::File::JoinPath(log_dir_, log_file_name_);
    string rotated_log_file_path = CreateRotateLogFileName(log_file_name_);
    if (!mobvoi::File::Rename(log_file_path, rotated_log_file_path)) {
      LOG(ERROR) << "Fail to rename file:" << log_file_path
                 << " with new name:" << rotated_log_file_path;
    }
    LOG(INFO) << "Move file " << log_file_path << " --> "
              << rotated_log_file_path;
    CreateLogFile();
  }

  string log_dir_;
  string log_file_name_;
  size_t log_file_size_;
  size_t max_log_file_size_threshold_;
  time_t last_rotate_time_;
  FILE* log_file_handle_;

 private:
  DISALLOW_COPY_AND_ASSIGN(FileLoggerStream);
};

class AsyncFileLoggerThread : public AsyncLoggerThread {
 public:
  AsyncFileLoggerThread(const string& log_dir, int dump_to_disk_interval,
                        size_t max_log_file_size_threshold,
                        mobvoi::ConcurrentQueue<string>* in_queue)
      : AsyncLoggerThread(in_queue) {
    logger_stream_.reset(new FileLoggerStream(log_dir, kLogFileName,
                                              max_log_file_size_threshold));
    CHECK(logger_stream_.get());
  }

  void Run() {
    std::queue<string> log_msg_queue;
    while (!terminate_) {
      // Avoid busy loop.
      while (true) {
        if (in_queue_->Empty()) {
          sleep(2);
        } else {
          break;
        }
      }

      in_queue_->Swap(&log_msg_queue);
      while (!log_msg_queue.empty()) {
        const string& msg = log_msg_queue.front();
        string line_msg = msg;
        if (line_msg[line_msg.size() - 1] != '\n') {
          line_msg += "\n";
        }
        if (!logger_stream_->WriteToStream(line_msg)) {
          LOG(ERROR) << "Write log message " << msg << " error";
        }
        log_msg_queue.pop();
      }
    }
  }

 private:
};

AsyncLogger::AsyncLogger() : started_(false) {
  if (!mobvoi::File::Exists(FLAGS_tts_log_dir)) {
    mobvoi::File::CreateDir(FLAGS_tts_log_dir, mobvoi::DEFAULT_FILE_MODE);
  }
  logger_thread_.reset(new AsyncFileLoggerThread(
      FLAGS_tts_log_dir, FLAGS_dump_disk_interval,
      FLAGS_max_log_file_size_threshold, &concurr_queue_));
  CHECK(logger_thread_.get());
  // logger_thread_->SetJoinable(true);
  logger_thread_->Start();
  started_ = true;
}

AsyncLogger::~AsyncLogger() { Close(); }

void AsyncLogger::Log(const string& msg) {
  CHECK(started_);
  if (!msg.empty()) {
    // TODO(shunping) : Control writing speed here,
    // avoid too much data pending.
    concurr_queue_.Push(msg);
  }
}

void AsyncLogger::Close() {
  if (logger_thread_->running()) {
    logger_thread_->Terminate();
    logger_thread_->Join();
  }
}

AsyncLoggerThread::AsyncLoggerThread(mobvoi::ConcurrentQueue<string>* in_queue)
    : in_queue_(in_queue), terminate_(false) {
  CHECK(in_queue_);
}

AsyncLoggerThread::~AsyncLoggerThread() {}

void AsyncLoggerThread::Terminate() { terminate_ = true; }

}  // namespace server
