// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: fllin@mobvoi.com (Fenglv Lin)

#ifndef TTS_SERVER_ADAPTATION_SERVICE_HANDLER_H_
#define TTS_SERVER_ADAPTATION_SERVICE_HANDLER_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/mutex.h"
#include "mobvoi/util/net/http_server/http_request.h"
#include "mobvoi/util/net/http_server/http_response.h"
#include "tts/synthesizer/interface/synthesizer_interface.h"
#include "third_party/jsoncpp/json.h"

namespace server {

class AdaptationServerHandler {
 public:
  explicit AdaptationServerHandler(
    shared_ptr<tts::SynthesizerInterface> synthesizer);
  ~AdaptationServerHandler() {}

  bool Synthesize(util::HttpRequest* request,
                  util::HttpResponse* response);

  bool NotifyDownload(util::HttpRequest* request,
                      util::HttpResponse* response);
 private:
  bool SendModelWarningEmail(const string& model_id);
 private:
  Json::FastWriter writer_;
  std::shared_ptr<tts::SynthesizerInterface> tts_;
  DISALLOW_COPY_AND_ASSIGN(AdaptationServerHandler);
};
}  // namespace server

#endif  // TTS_SERVER_ADAPTATION_SERVICE_HANDLER_H_
