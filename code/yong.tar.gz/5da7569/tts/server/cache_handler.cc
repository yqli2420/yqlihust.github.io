// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: yongqiangli@mobvoi.com (Yongqiang Li)

#include "tts/server/cache_handler.h"

#include "mobvoi/base/file.h"
#include "mobvoi/base/file/proto_util.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/util/net/util.h"
#include "tts/util/tts_util/wave_util.h"

DEFINE_int32(adaptation_cache_size, 30, "cache number for tts audio file.");
DEFINE_bool(use_tts_cache, false, "If true, save the audio file");
DEFINE_int32(tts_cache_num, 5000, "cache number for tts audio file.");
DEFINE_bool(enable_redis, false, "read audio file from redis");
DEFINE_string(redis_config, "external/config/web_server/server/redis.conf",
              "redis config");
DEFINE_int32(bgm_num, 100, "cache number for bgm audio file.");
DEFINE_int32(audio_num, 100, "cache number for tmp audio file.");
DEFINE_bool(use_adaptation, false, "To judge use adaptation or not.");

namespace server {

string GenCacheKey(const tts::TTSOption& tts_option,
                   const string& processed_text) {
  Json::Value key;
  key["speaker"] = tts_option.speaker();
  key["domain"] = tts_option.domain();
  key["speed"] = tts_option.speed();
  key["sampling"] = tts_option.sampling_frequency();
  key["use_robot"] = tts_option.use_robot();
  key["volume"] = tts_option.volume();
  key["append_sil"] = tts_option.append_sil();
  key["audio_type"] = tts_option.file_format();
  key["alignment"] = tts_option.alignment();
  key["text"] = processed_text;
  key["bgm"] = tts_option.bgm();
  key["model_id"] = tts_option.model_id();
  key["pitch"] = tts_option.pitch();
  return MD5String(key.toStyledString());
}

TtsCache::TtsCache()
    : use_tts_cache_(FLAGS_use_tts_cache),
      use_redis_(FLAGS_enable_redis),
      use_adaptation_(FLAGS_use_adaptation) {
  if (use_tts_cache_)
    cache_.reset(new util::LruCache<string, string>(FLAGS_tts_cache_num));
  if (use_adaptation_)
    engine_cache_.reset(
        new LruCache<string, shared_ptr<Engine>>(FLAGS_adaptation_cache_size));
}

TtsCache::~TtsCache() {}

void TtsCache::PutInCache(const string& key, const string& data) {
  cache_->Put(key, data);
}

bool TtsCache::GetData(const string& key, string* data) {
  return cache_->Get(key, data);
}

bool TtsCache::GetDataFromRedis(const string& key, string* data) {
  util::RedisUtil redis_util(FLAGS_redis_config);
  return redis_util.Get(key, data);
}

bool TtsCache::RedisSet(const string& key, const string& data) {
  util::RedisUtil redis_util(FLAGS_redis_config);
  return redis_util.Set(key, data, 0);
}

bool TtsCache::GetEngine(const string& key,
                         shared_ptr<engine::Engine>* engine) {
  return engine_cache_->Get(key, engine);
}

bool TtsCache::HasEngine(const string& key) {
  return engine_cache_->HasKey(key);
}

void TtsCache::PutInEngine(const string& key,
                           shared_ptr<engine::Engine> engine) {
  engine_cache_->Put(key, engine);
}

bool TtsCache::RedisDel(const string& key) {
  util::RedisUtil redis_util(FLAGS_redis_config);
  return redis_util.Del(key);
}

bool TtsCache::UseTtsCache() { return use_tts_cache_; }

bool TtsCache::UseRedis() { return use_redis_; }

bool TtsCache::CanFetch(const string& key) {
  mobvoi::MutexLock lock(&mutex_);
  return cache_->HasKey(key) ? true : false;
}

size_t TtsCache::Size() { return cache_->Size(); }

Bgm::Bgm() {
  bgm_cache_.reset(new util::LruCache<string, vector<int16>>(FLAGS_bgm_num));
  audio_volume_.reset(
      new util::LruCache<string, AudioVolume>(FLAGS_bgm_num + FLAGS_audio_num));
  bgm_cache_tmp_.reset(
      new util::LruCache<string, vector<int16>>(FLAGS_audio_num));
}

Bgm::~Bgm() {}

bool Bgm::GetBgmData(const string& key, vector<int16>* data) {
  return (bgm_cache_->Get(key, data) || bgm_cache_tmp_->Get(key, data));
}

bool Bgm::GetAudioVolume(const string& key, AudioVolume* data) {
  return audio_volume_->Get(key, data);
}

void Bgm::SetAudioVolume(const string& key, const AudioVolume& data) {
  audio_volume_->Put(key, data);
}

void Bgm::SetBgmData(const string& key, const vector<int16>& data) {
  bgm_cache_->Put(key, data);
}

void Bgm::SetBgmTmpData(const string& key, const vector<int16>& data) {
  bgm_cache_tmp_->Put(key, data);
}
}  // namespace server
