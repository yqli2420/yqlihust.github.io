// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_SERVER_BLOCK_SERVICE_HANDLER_H_
#define TTS_SERVER_BLOCK_SERVICE_HANDLER_H_

#include <map>
#include <string>

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/mutex.h"
#include "tts/server/cache_handler.h"
#include "tts/server/record_wav/record_wav.h"
#include "tts/server/server_util.h"
#include "tts/synthesizer/interface/synthesizer_interface.h"
#include "tts/util/tts_util/util.h"

namespace server {
class AsyncLogger;

class BlockServerHandler {
 public:
  BlockServerHandler(std::shared_ptr<tts::SynthesizerInterface> synthesizer,
                     bool use_license,
                     mobvoi::ConcurrentQueue<KibanaData>* data_queue,
                     mobvoi::ConcurrentQueue<KibanaData>* log_queue);
  ~BlockServerHandler();
#ifndef USE_GRPC
  bool ConcurrentSynthesize(util::HttpRequest* request,
                            util::HttpResponse* response) const;
  void Postprocess(
      const tts::TTSOption& tts_option,
      const vector<std::pair<int, std::pair<string, AudioParams>>>&
          insert_audio,
      mobvoi::ConcurrentQueue<std::pair<int, vector<int16>>>* output_queue,
      std::string* data_res) const;
  void BatchSynthesize(
      const tts::TTSOption& tts_option,
      mobvoi::ConcurrentQueue<ConcurrentSent>* input_queue,
      mobvoi::ConcurrentQueue<std::pair<int, std::vector<int16>>>* output_queue)
      const;

  void SplitSpeakerTexts(
      const std::string& text, const std::string& speaker, double speed,
      vector<std::pair<int, std::pair<string, AudioParams>>>* insert_audio,
      mobvoi::ConcurrentQueue<ConcurrentSent>* input_queue) const;
  void SplitTexts(const std::string& text, const string& speaker, double speed,
                  int* id,
                  mobvoi::ConcurrentQueue<ConcurrentSent>* input_queue) const;
#endif
  bool Synthesize(util::HttpRequest* request,
                  util::HttpResponse* response) const;

 private:
  void SynthesisContext(const string& text, const tts::TTSOption& tts_option,
                        string* data_res) const;

  bool use_license_;
  mutable mobvoi::Mutex mutex_;
  std::shared_ptr<tts::SynthesizerInterface> tts_;
  unique_ptr<RecordWav> record_wav_;
  AsyncLogger* logger_;
  mobvoi::ConcurrentQueue<KibanaData>* data_queue_;
  mobvoi::ConcurrentQueue<KibanaData>* log_queue_;
  DISALLOW_COPY_AND_ASSIGN(BlockServerHandler);
};
}  // namespace server
#endif  // TTS_SERVER_BLOCK_SERVICE_HANDLER_H_
