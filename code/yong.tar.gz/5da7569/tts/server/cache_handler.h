// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: yongqiangli@mobvoi.com (Yongqiang Li)

#ifndef TTS_SERVER_CACHE_HANDLER_H_
#define TTS_SERVER_CACHE_HANDLER_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/hash_tables.h"
#include "mobvoi/base/md5.h"
#include "mobvoi/base/mutex.h"
#include "mobvoi/base/singleton.h"
#include "mobvoi/base/thread.h"
#include "mobvoi/util/cache/lru_cache.h"
#include "mobvoi/util/redis/redis_util.h"
#include "third_party/jsoncpp/json.h"
#include "tts/synthesizer/engine/engine.h"
#include "tts/synthesizer/proto/tts.pb.h"

namespace server {
using util::LruCache;
using engine::Engine;

struct AudioVolume {
  AudioVolume(const float& _avg_vol, const float& _p95_vol)
      : avg_vol(_avg_vol), p95_vol(_p95_vol) {}
  AudioVolume() {}
  bool operator==(const AudioVolume& rhs) const {
    return (rhs.avg_vol == avg_vol) && (rhs.p95_vol == p95_vol);
  }
  float avg_vol;
  float p95_vol;
};

string GenCacheKey(const tts::TTSOption& tts_option,
                   const string& processed_text);

class TtsCache {
 public:
  virtual ~TtsCache();

  void PutInCache(const string& key, const string& data);
  bool RedisSet(const string& key, const string& data);
  bool RedisDel(const string& key);
  bool GetData(const string& key, string* data);
  bool GetDataFromRedis(const string& key, string* data);
  bool GetEngine(const string& key, shared_ptr<engine::Engine>* engine);
  bool HasEngine(const string& key);
  void PutInEngine(const string& key, shared_ptr<engine::Engine> engine);
  bool CanFetch(const string& key);
  bool UseTtsCache();
  bool UseRedis();
  size_t Size();

 private:
  mobvoi::Mutex mutex_;
  bool use_adaptation_;
  bool use_tts_cache_;
  bool use_redis_;
  std::shared_ptr<util::LruCache<string, string>> cache_;
  shared_ptr<LruCache<string, shared_ptr<engine::Engine>>> engine_cache_;
  TtsCache();
  friend struct DefaultSingletonTraits<TtsCache>;
  DISALLOW_COPY_AND_ASSIGN(TtsCache);
};

class Bgm {
 public:
  virtual ~Bgm();
  bool GetBgmData(const string& key, vector<int16>* data);
  bool GetAudioVolume(const string& key, AudioVolume* audio_vol);
  void SetBgmData(const string& key, const vector<int16>& data);
  void SetAudioVolume(const string& key, const AudioVolume& data);
  void SetBgmTmpData(const string& key, const vector<int16>& data);

 private:
  std::shared_ptr<util::LruCache<string, vector<int16>>> bgm_cache_;
  std::shared_ptr<util::LruCache<string, AudioVolume>> audio_volume_;
  std::shared_ptr<util::LruCache<string, vector<int16>>> bgm_cache_tmp_;
  Bgm();
  friend struct DefaultSingletonTraits<Bgm>;
  DISALLOW_COPY_AND_ASSIGN(Bgm);
};

}  // namespace server

#endif  // TTS_SERVER_CACHE_HANDLER_H_
