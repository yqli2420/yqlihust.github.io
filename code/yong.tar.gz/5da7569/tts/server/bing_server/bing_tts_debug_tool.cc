// Copyright 2016 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "mobvoi/base/at_exit.h"
#include "mobvoi/base/log.h"
#include "mobvoi/util/net/http_client/http_client.h"
#include "mobvoi/util/net/http_server/http_server.h"
#include "third_party/gflags/gflags.h"
#include "tts/server/bing_server/bing_tts_service.h"

int main(int argc, char **argv) {
  base::AtExitManager at_exit;
  google::ParseCommandLineFlags(&argc, &argv, false);

  // Get language list supported.
  server::AccessToken token;
  server::UpdateTokenThread thread(&token);
  thread.Start();
  sleep(2);
  string t = token.GetToken();
  LOG(INFO) << "token : " << t;

  string url_prefix =
      "http://api.microsofttranslator.com/V2/Http.svc/GetLanguagesForSpeak";
  map<string, string> params;
  params["appId"] = "";
  string url = util::CreateUrl(url_prefix, params);
  LOG(INFO) << "url : " << url;
  util::HttpClient client;
  client.AddHeader("Authorization", t);
  client.FetchUrl(url);

  LOG(INFO) << client.ResponseBody();
  return 0;
}
