// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/server/streaming_data_provider.h"

#include <thread>  // NOLINT

#include "mobvoi/base/log.h"
#include "mobvoi/base/singleton.h"
#include "mobvoi/base/time.h"
#include "tts/synthesizer/engine/engine.h"
#include "tts/synthesizer/engine/tacotron/one_engine.h"
#include "tts/synthesizer/synthesizer.h"
#include "tts/util/tts_util/util.h"

DECLARE_int32(adaptation_cache_size);
DECLARE_string(save_adaptation_model_dir);

namespace server {

static void SynthesisContext(const string& request,
                             const tts::TTSOption& tts_option,
                             tts::SynthesizerInterface* tts,
                             std::shared_ptr<engine::Engine> engine,
                             std::shared_ptr<SynthesizerEvent> event) {
  vector<tts::SsmlText> ssml_texts;
  tts::SsmlParser::Instance().ParseText(request, tts::kSsmlAudio, &ssml_texts);
  for (size_t len = 0; len < ssml_texts.size(); ++len) {
    if (ssml_texts[len].text.empty()) {
      tts::TTSOption option_tmp = tts_option;
      bool is_id = true;
      auto attr_it = ssml_texts[len].tag.attrs.find(tts::kSsmlAudioName);
      if (attr_it == ssml_texts[len].tag.attrs.end()) {
        attr_it = ssml_texts[len].tag.attrs.find(tts::kSsmlAudioSrc);
        is_id = false;
      }
      option_tmp.set_audio_is_id(is_id);
      if (attr_it != ssml_texts[len].tag.attrs.end()) {
        option_tmp.set_insert_audio(true);
        auto attr_volume =
            ssml_texts[len].tag.attrs.find(tts::kSsmlAudioVolume);
        float volume = attr_volume != ssml_texts[len].tag.attrs.end()
                           ? atof(attr_volume->second.c_str())
                           : 1.0;
        option_tmp.set_audio_volume(volume);
      } else {
        continue;
      }
      if (len != ssml_texts.size() - 1) option_tmp.set_last_sentence(false);
      tts->Synthesize(attr_it->second, option_tmp, event.get(), nullptr);
    } else {
      string context = "<speak>" + ssml_texts[len].text + "</speak>";
      vector<OptionSent> option_sents;
      ServerUtil::SplitOptionSent(context, &option_sents);
      for (size_t i = 0; i < option_sents.size(); ++i) {
        tts::TTSOption option_tmp = tts_option;
        OptionSent option_sent = option_sents[i];
        LOG(INFO) << option_sent.context << " speaker: " << option_sent.speaker;
        if ((len != ssml_texts.size() - 1) || (i != option_sents.size() - 1))
          option_tmp.set_last_sentence(false);
        if (option_sent.is_set) {
          if (!option_sent.speaker.empty())
            option_tmp.set_speaker(option_sent.speaker);
          if (option_sent.speed != 0.0) {
            option_tmp.set_speed(option_sent.speed);
          }
          tts->Synthesize(option_sent.context, option_tmp, event.get(),
                          nullptr);
        } else {
          tts->Synthesize(option_sent.context, option_tmp, event.get(), engine);
        }
      }
    }
  }
}

static void SynthesisThread(const string& request, const string& redis_cmd,
                            bool use_license, int word_num,
                            tts::SynthesizerInterface* tts,
                            tts::TTSOption tts_option,
                            std::shared_ptr<SynthesizerEvent> event,
                            bool use_adaptation, const string& engine_name,
                            bool force_update, bool* cache_total_sentence) {
  ServerUtil::AcquireLicense(use_license);
  auto cache = Singleton<server::TtsCache>::get();
  // Generate cache key
  string cache_key = GenCacheKey(tts_option, request);
  string redis_key = tts_option.speaker() + cache_key;
  string audio_data;
  if (cache->UseRedis() && cache->GetDataFromRedis(redis_key, &audio_data)) {
    if (redis_cmd == "del") {
      if (cache->RedisDel(redis_key)) {
        LOG(INFO) << "Delete the key in redis: " << redis_key;
      }
    }
    event->OnSynthesizeData(audio_data);
    event->OnFinish();
    *cache_total_sentence = true;
  } else if (cache->UseTtsCache() && word_num <= kMaxCacheLen &&
             cache->CanFetch(cache_key)) {
    cache->GetData(cache_key, &audio_data);
    event->OnSynthesizeData(audio_data);
    event->OnFinish();
    *cache_total_sentence = true;
  } else {
    if (!use_adaptation) {
      SynthesisContext(request, tts_option, tts, nullptr, event);
    } else {
      string engine_path =
          FLAGS_save_adaptation_model_dir + engine_name + ".quant.one";
      std::shared_ptr<engine::Engine> engine = nullptr;
      if (!force_update && cache->HasEngine(engine_name)) {
        cache->GetEngine(engine_name, &engine);
      } else {
        if (force_update || !mobvoi::File::Exists(engine_path)) {
          if (!ServerUtil::Download(engine_name)) {
            LOG(ERROR) << "Downlad engine: " << engine_name << "failed!";
          }
        }
        // load engine
        try {
          std::shared_ptr<engine::Engine> new_engine(
              static_cast<engine::Engine*>(new engine::tacotron::ONEEngine(
                  tts::LanguageType::kMandarin, engine_path,
                  tts_option.speed())));
          cache->PutInEngine(engine_name, new_engine);
          engine = new_engine;
        } catch (const std::exception& e) {
          LOG(ERROR) << "model is incorrect. " << e.what();
        }
      }
      SynthesisContext(request, tts_option, tts, engine, event);
    }
    if (cache->UseRedis() && redis_cmd == "set") {
      cache->RedisSet(redis_key, event->GetResult());
    } else if (cache->UseTtsCache() && word_num <= kMaxCacheLen) {
      cache->PutInCache(cache_key, event->GetResult());
    }
  }
  LOG(INFO) << "Synthesis done.";
  ServerUtil::ReleaseLicense(use_license);
}

TTSDataProvider::TTSDataProvider(
    std::shared_ptr<tts::SynthesizerInterface> synthesizer, bool use_license,
    mobvoi::ConcurrentQueue<KibanaData>* kibana_queue,
    mobvoi::ConcurrentQueue<KibanaData>* log_queue, bool use_adaptation)
    : kibana_queue_(kibana_queue),
      log_queue_(log_queue),
      use_adaptation_(use_adaptation),
      use_license_(use_license),
      word_num_(0),
      first_chunk_time_(0),
      is_navigation_(false) {
  data_queue_ = std::make_shared<mobvoi::ConcurrentQueue<string>>();
  duration_ = std::make_shared<std::vector<string>>();
  event_ = std::make_shared<SynthesizerEvent>(data_queue_, duration_);
  synthesizer_ = synthesizer;
  engine_name_ = "";
  all_chunk_time_ = "0";
}

void TTSDataProvider::Start(util::HttpRequest* request,
                            util::HttpResponse* response) {
  map<string, string> params;
  ServerUtil::ParseRequestParams(request, &params);
  string text = params["text"];
  if (ServerUtil::IsRejectOfflineRequest(params)) {
    Json::Value node;
    node["status"] = "404";
    event_->OnSynthesizeData(node.toStyledString());
    event_->OnFinish();
    text = "";
  }

  request_params_ = params;
  bool force_update = false;
  if (params.find("force_update") != params.end() &&
      params["force_update"] == "true") {
    force_update = true;
  }
  tts::TTSOption tts_option;
  if (!ServerUtil::SetAllParams(params, kTypeStreaming, &tts_option,
                                response)) {
    ServerUtil::ReleaseLicense(use_license_);
    return;
  }

  // for sop 1.0
  if (ServerUtil::IsRejectOfflineRequestSop1(params, tts_option.domain())) {
    response->SetResponseCode(404);
    text = "";
    event_->OnSynthesizeData("");
    event_->OnFinish();
  }
  // for adaptation
  if (use_adaptation_) {
    engine_name_ = params["engine"];
  }
  ServerUtil::GetBgmParam(text, &tts_option);
  ServerUtil::GetPitch(text, &tts_option);
  LOG(INFO) << "Request synthesis request params:"
            << ServerUtil::GetRequestParams(params);

  std::cout << "Request synthesis request params:";
  // Input pre-processing
  ServerUtil::DoInputPreprocess(params, &text, &word_num_);
  ServerUtil::AppendHeadSilence(params, &text);
  // Parse domain
  is_navigation_ = tts_option.domain() == tts::kDomainNavigation ? true : false;
  auto it = params.find("redis_cmd");
  string redis_cmd;
  if (it != params.end() && !it->second.empty()) {
    redis_cmd = it->second;
  }
  // Create another thread to generate data.
  thread_.reset(new std::thread(SynthesisThread, text, redis_cmd, use_license_,
                                word_num_, synthesizer_.get(), tts_option,
                                event_, use_adaptation_, engine_name_,
                                force_update, &cache_total_sentence_));
  start_time_ = mobvoi::GetTimeInMs();
  speaker_ = tts_option.speaker();
  product_ = ServerUtil::GetProductParam(params);
}

bool TTSDataProvider::Next(string* data) {
  string str;
  // may stop the thread
  data_queue_->Pop(str);
  VLOG(1) << "next data segment : " << str.size();
  data->assign(str);
  if (first_chunk_) {
    first_chunk_time_ = mobvoi::GetTimeInMs() - start_time_;
    all_chunk_time_ = std::to_string(first_chunk_time_);
    // default, cache none
    int use_cache = -1;
    // set sentence prefix cache
    if (cache_total_sentence_) {
      use_cache = 1;
    } else if (event_->use_cache()) {
      use_cache = 0;
    }

    if (is_navigation_) {
      if (cache_total_sentence_) {
        use_cache = 4;
      } else if (event_->use_cache()) {
        use_cache = 3;
      } else {
        use_cache = 2;
      }
    }
    // Summary
    VLOG(1) << "cache mode: " << use_cache;

    ServerUtil::WriteToKibana(use_cache, first_chunk_time_, word_num_,
                              kTypeStreaming, speaker_, product_,
                              kibana_queue_);

    VLOG(1) << "first chunk time" << first_chunk_time_;
    first_chunk_ = false;
  } else {
    if (!str.empty())
      all_chunk_time_ = all_chunk_time_ + "," +
                        std::to_string(mobvoi::GetTimeInMs() - start_time_);
  }
  if (str.empty()) {
    string all_time = JoinVector(*duration_.get(), ',') + "|" + all_chunk_time_;
    ServerUtil::SaveLog(request_params_, first_chunk_time_, all_time,
                        kTypeStreaming, NULL, log_queue_);
  }
  return !str.empty();
}

TTSDataProvider::~TTSDataProvider() { thread_->join(); }

}  // namespace server
