// Copyright 2016 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_SERVER_RECORD_WAV_RECORD_WAV_H_
#define TTS_SERVER_RECORD_WAV_RECORD_WAV_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/hash_tables.h"
#include "tts/synthesizer/proto/tts.pb.h"

#include "third_party/jsoncpp/json.h"

namespace server {
static const string kPush = "public.push";  // NOLINT
static const string kFaq = "faq";    // NOLINT

class RecordWav {
 public:
  explicit RecordWav(const string& record_file);
  ~RecordWav();
  bool GetRecordWav(const string& xml_text, const tts::TTSOption& tts_option,
                    string* data_res) const;
  bool FindRecordWav(const string& text, const string& domain,
                     const string& speaker, vector<int16>* data) const;

 private:
  void LoadRecordWavBySource(const string& domain, const string& speaker,
                             const string& record_file);
  void ParseAndLoad(const string& model_dir, const Json::Value& models,
                    const string& domain);

  void LoadRecordWav(const string& record_file);
  void ReadWavFile(const string& wave_file_name, vector<int16>* data);

  base::hash_map<string, vector<int16>> record_wav_maps_;
  DISALLOW_COPY_AND_ASSIGN(RecordWav);
};
}  // namespace server

#endif  // TTS_SERVER_RECORD_WAV_RECORD_WAV_H_
