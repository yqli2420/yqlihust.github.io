// Copyright 2016 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/server/record_wav/record_wav.h"

#include "mobvoi/base/file.h"
#include "mobvoi/base/file/proto_util.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "third_party/gtest/gtest.h"
#include "tts/util/tts_util/util.h"

namespace server {
TEST(RecordWavTest, FindRecordWavTest) {
  const string record_file = "tts/server/record_wav/testdata/test_record.json";
  unique_ptr<RecordWav> record_wav;
  record_wav.reset(new RecordWav(record_file));
  vector<int16> raw_data;

  string domain = kPush;
  string speaker = "mio";
  EXPECT_TRUE(record_wav->FindRecordWav("test", domain, speaker, &raw_data));
  EXPECT_EQ(60624UL, raw_data.size());
}

TEST(RecordWavTest, GetRecordWavTest) {
  const string record_file = "tts/server/record_wav/testdata/test_record.json";
  unique_ptr<RecordWav> record_wav;
  record_wav.reset(new RecordWav(record_file));
  vector<int16> raw_data;

  static const string xml_text =
      "<speak version=\"1.0\" xml:lang=\"zh-cn\" "
      "xmlns=\"http://www.w3.org/2001/10/synthesis\"><tts::prompt "
      "domain=\"public.push\"/"
      ">test</speak>";

  tts::TTSOption tts_option;
  tts::SetDefaultTTSOption(&tts_option);

  string domain = tts::GetDomainFromXml(xml_text);
  EXPECT_EQ(kPush, domain);
  tts_option.set_domain(domain);
  tts_option.set_speaker("mio");
  string data_res;
  EXPECT_TRUE(record_wav->GetRecordWav(xml_text, tts_option, &data_res));
}

}  //  namespace server
