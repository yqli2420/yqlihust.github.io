// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: chhyu@mobvoi.com (Changhe Yu)

#ifndef TTS_SERVER_STREAMING_SERVICE_HANDLER_H_
#define TTS_SERVER_STREAMING_SERVICE_HANDLER_H_

#include <signal.h>
#include <stdio.h>

#include "mobvoi/util/net/http_server/event_loop.h"
#include "mobvoi/util/net/http_server/http_server.h"
#include "third_party/event/include/event2/buffer.h"
#include "third_party/event/include/event2/http.h"
#include "third_party/gflags/gflags.h"
#include "tts/server/cache_handler.h"
#include "tts/server/streaming_data_provider.h"

namespace server {

class StreamingHttpHandler : public util::HttpHandler {
 public:
  StreamingHttpHandler(util::Callback callback, bool use_license,
                       std::shared_ptr<tts::SynthesizerInterface> synthesizer,
                       mobvoi::ConcurrentQueue<KibanaData>* data_queue,
                       mobvoi::ConcurrentQueue<KibanaData>* log_queue,
                       bool use_adaptation = false);

  virtual ~StreamingHttpHandler();

  virtual bool Handler(util::HttpRequest* request,
                       util::HttpResponse* response);

  virtual util::DataProvider* CreateProvider(struct evhttp_request* req) const;

 private:
  bool use_license_;
  bool use_adaptation_;
  std::shared_ptr<tts::SynthesizerInterface> synthesizer_;
  mobvoi::ConcurrentQueue<KibanaData>* data_queue_;
  mobvoi::ConcurrentQueue<KibanaData>* log_queue_;
  DISALLOW_COPY_AND_ASSIGN(StreamingHttpHandler);
};

}  // namespace server

#endif  // TTS_SERVER_STREAMING_SERVICE_HANDLER_H_
