// Copyright 2016 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/server/kibana/kibana_write_thread.h"

#include <string>
#include <vector>

#include "mobvoi/base/log.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/util/net/http_client/http_client.h"
#include "third_party/jsoncpp/json.h"

DEFINE_string(kibana_host, "exp-hadoop-0000", "kibana host");
DEFINE_int32(kibana_port, 19200, "kibana port");
DEFINE_string(kibana_index, "tts_time", "kibana index");
DEFINE_string(kibana_type, "synthesis_time", "kibana type");
DEFINE_int32(kibana_buffer_size, 100, "Buffer size for es bulk api.");
DEFINE_int32(http_time_out, 3000, "HTTP connect or fetch timeout.");

namespace server {

KinabaWriteThread::KinabaWriteThread(
    mobvoi::ConcurrentQueue<KibanaData>* data_queue)
    : data_queue_(data_queue) {
  Json::Value node;
  Json::Value index;
  index["_index"] = FLAGS_kibana_index;
  index["_type"] = FLAGS_kibana_type;
  node["index"] = index;
  Json::FastWriter writer;
  create_json_str_ = writer.write(node);
}

KinabaWriteThread::~KinabaWriteThread() {}

void KinabaWriteThread::Run() {
  util::HttpClient http_client;
  Json::FastWriter writer;
  string url = StringPrintf("http://%s:%d/_bulk", FLAGS_kibana_host.c_str(),
                            FLAGS_kibana_port);
  while (true) {
    int cnt = 0;
    http_client.Reset();
    http_client.SetConnectTimeout(FLAGS_http_time_out);
    http_client.SetFetchTimeout(FLAGS_http_time_out);
    http_client.SetHttpMethod(util::HttpMethod::kPost);
    vector<string> v(FLAGS_kibana_buffer_size);
    while (cnt < FLAGS_kibana_buffer_size) {
      KibanaData data;
      data_queue_->Pop(data);
      if (data.isNull()) {
        LOG(WARNING) << "post data is null.";
        continue;
      }
      string post_data = StringPrintf("%s%s", create_json_str_.c_str(),
                                      writer.write(data).c_str());
      v[cnt] = post_data;
      ++cnt;
    }

    string bulk_data = mobvoi::JoinVectorToString(v, "\r\n");
    http_client.SetPostData(bulk_data);
    if (!http_client.FetchUrl(url) || http_client.response_code() != 200) {
      LOG(WARNING) << "Failed to post data to url :" << url;
    }
  }
}
}  // namespace server
