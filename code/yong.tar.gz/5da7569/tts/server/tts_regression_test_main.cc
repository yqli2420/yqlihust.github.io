// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: fllin@mobvoi.com (Fenglv Lin)

#include <thread> // NOLINT
#include <vector>

#include "mobvoi/base/at_exit.h"
#include "mobvoi/base/concurrent_queue.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/base/time.h"
#include "third_party/jsoncpp/json.h"
#include "tts/nlp/t2s/t2s_regression_test_util.h"
#include "tts/server/kibana/kibana_write_thread.h"


DEFINE_string(g2p_test_cases,
              "external/config/regression_test/g2p_test_cases.txt",
              "Grapheme to Phoneme test case file");
DEFINE_string(pause_level_test_cases,
              "external/config/regression_test/pause_level_test_cases.txt",
              "Prosody prediction test case file");
DEFINE_string(polyphone_test_cases,
              "external/config/regression_test/polyphone_test_cases.txt",
              "Polyphone test case file");
DEFINE_string(segmenter_test_cases,
              "external/config/regression_test/segmenter_test_cases.txt",
              "Segmenter test case file");
DEFINE_string(tn_test_cases,
              "external/config/regression_test/tn_test_cases.txt",
              "Text normalizer case file");
DEFINE_string(t2s_test_cases,
              "external/config/regression_test/t2s_test_cases.txt",
              "Traditional chinese to simplified chinese test case file");

DECLARE_string(kibana_index);
DECLARE_string(kibana_type);
DECLARE_int32(kibana_buffer_size);

typedef Json::Value KibanaData;
using std::string;
using std::vector;
using std::thread;

void RunG2PTestCases(const string& test_file,
    mobvoi::ConcurrentQueue<KibanaData>* data_queue) {
  LOG(INFO) << "Begin to processing RunG2PTestCases";
  Json::Value node;
  data_queue->Push(node);
  LOG(INFO) << "End of processing RunG2PTestCases";
}

void RunPausePredictorTestCases(const string& test_file,
    mobvoi::ConcurrentQueue<KibanaData>* data_queue) {
  LOG(INFO) << "Begin to processing RunPausePredictorTestCases";
  Json::Value node;
  data_queue->Push(node);
  LOG(INFO) << "End of processing RunPausePredictorTestCases";
}

void RunPolyphoneTestCases(const string& test_file,
    mobvoi::ConcurrentQueue<KibanaData>* data_queue) {
  LOG(INFO) << "Begin to processing RunPolyphoneTestCases";
  Json::Value node;
  data_queue->Push(node);
  LOG(INFO) << "End of processing RunPolyphoneTestCases";
}

void RunTextNormalizerTestCases(const string& test_file,
    mobvoi::ConcurrentQueue<KibanaData>* data_queue) {
  LOG(INFO) << "Begin to processing RunTextNormalizerTestCases";
  Json::Value node;
  data_queue->Push(node);
  LOG(INFO) << "End of processing RunTextNormalizerTestCases";
}

void RunTextSegmenterTestCases(const string& test_file,
    mobvoi::ConcurrentQueue<KibanaData>* data_queue) {
  LOG(INFO) << "Begin to processing RunTextSegmenterTestCases";
  Json::Value node;
  data_queue->Push(node);
  LOG(INFO) << "End of processing RunTextSegmenterTestCases";
}

void RunTrad2SimpTestCases(const string& test_file,
    mobvoi::ConcurrentQueue<KibanaData>* data_queue) {
  LOG(INFO) << "Begin to processing RunTrad2SimpTestCases";
  nlp::t2s::T2SRegressionTestUtil t2s_util;
  Json::Value node;
  t2s_util.RunTestCases(test_file, &node);
  data_queue->Push(node);
  LOG(INFO) << "End of processing RunTrad2SimpTestCases";
}

int main(int argc, char **argv) {
  base::AtExitManager at_exit;
  google::ParseCommandLineFlags(&argc, &argv, false);
  google::InitGoogleLogging(argv[0]);

  mobvoi::ConcurrentQueue<KibanaData> kibana_queue;
  server::KinabaWriteThread write_thread(&kibana_queue);
  write_thread.Start();

  thread g2p_thread(&RunG2PTestCases, FLAGS_g2p_test_cases, &kibana_queue);
  thread pause_predict_thread(&RunPausePredictorTestCases,
                              FLAGS_pause_level_test_cases, &kibana_queue);
  thread polyphone_thread(&RunPolyphoneTestCases,
                          FLAGS_polyphone_test_cases,
                          &kibana_queue);
  thread tn_thread(&RunTextNormalizerTestCases,
                   FLAGS_segmenter_test_cases, &kibana_queue);
  thread segmenter_thread(&RunTextSegmenterTestCases,
                          FLAGS_segmenter_test_cases, &kibana_queue);
  thread t2s_thread(&RunTrad2SimpTestCases,
                    FLAGS_t2s_test_cases, &kibana_queue);

  write_thread.Join();
  g2p_thread.join();
  pause_predict_thread.join();
  polyphone_thread.join();
  tn_thread.join();
  segmenter_thread.join();
  t2s_thread.join();
  return 0;
}
