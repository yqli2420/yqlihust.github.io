// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: mobvoi@mobvoi.com (mobvoi)

#ifndef TTS_SERVER_MODEL_UPDATE_SERVICE_HANDLER_H_
#define TTS_SERVER_MODEL_UPDATE_SERVICE_HANDLER_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/mutex.h"
#include "mobvoi/util/net/http_server/http_request.h"
#include "mobvoi/util/net/http_server/http_response.h"

namespace server {

class ModelUpdateServerHandler {
 public:
  ModelUpdateServerHandler() {}
  ~ModelUpdateServerHandler() {}
  bool UpdateFrontendModel(util::HttpRequest* request,
                           util::HttpResponse* response);

 private:
  bool Download(const string& oss_url, const string& save_dir,
                string* model_path);
  bool ReloadFrontendModel(const string& language, const string& frontend_type);
  string GetTimeOfDay();
  DISALLOW_COPY_AND_ASSIGN(ModelUpdateServerHandler);
};
}  // namespace server

#endif  // TTS_SERVER_MODEL_UPDATE_SERVICE_HANDLER_H_
