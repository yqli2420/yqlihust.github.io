// Copyright 2020 Mobvoi Inc. All Rights Reserved.
// Author: yongqiangli@mobvoi.com (yongqiang li)

#ifndef TTS_SERVER_BGM_SERVER_H_
#define TTS_SERVER_BGM_SERVER_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "tts/server/cache_handler.h"
#include "tts/server/server_util.h"

namespace util {
class HttpRequest;
class HttpResponse;
}  // namespace util

namespace server {
class AsyncLogger;

class BgmServerHandler {
 public:
  BgmServerHandler(mobvoi::ConcurrentQueue<KibanaData>* _data_queue,
                   mobvoi::ConcurrentQueue<KibanaData>* _log_queue);
  ~BgmServerHandler();

  bool FetchAudio(util::HttpRequest* request,
                  util::HttpResponse* response) const;

 private:
  AsyncLogger* logger_;
  mobvoi::ConcurrentQueue<KibanaData>* data_queue_;
  mobvoi::ConcurrentQueue<KibanaData>* log_queue_;
  DISALLOW_COPY_AND_ASSIGN(BgmServerHandler);
};
}  // namespace server

#endif  // TTS_SERVER_BGM_SERVER_H_
