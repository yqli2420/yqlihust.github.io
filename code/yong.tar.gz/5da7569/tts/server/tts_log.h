// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: fllin@mobvoi.com (Fenglv Lin)

#ifndef TTS_SERVER_TTS_LOG_H_
#define TTS_SERVER_TTS_LOG_H_

#include <map>
#include <string>

#include "mobvoi/base/concurrent_queue.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/base/time.h"
#include "mobvoi/util/mysql/mysql_util.h"
#include "tts/server/server_util.h"

DEFINE_string(mysql_server_conf,
              "external/config/web_server/server/log_db.conf", "mysql config");
DEFINE_bool(enable_mysql, false, "To judge if import to mysql.");

static void SaveLogToMysql(mobvoi::ConcurrentQueue<KibanaData>* log_queue) {
  while (true) {
    if (log_queue->Empty()) {
      mobvoi::USleep(10);
      continue;
    }
    KibanaData data;
    log_queue->Pop(data);
    if (data.isNull()) {
      LOG(WARNING) << "post data is null.";
      continue;
    }

    if (FLAGS_enable_mysql) {
      uint32 time = data["create_time"].asUInt();
      string text = data["text"].asString();
      mobvoi::ReplaceAllAfterOffset(&text, 0, "\"", "'");
      string uri = data["uri"].asString();
      mobvoi::ReplaceAllAfterOffset(&uri, 0, "\"", "'");
      string all_time = data["all_chunk_time"].asString();
      string command = StringPrintf(
          "INSERT INTO tts_log_new"
          " (create_time, product, query, "  // NOLINT
          " synthesize_mode, speaker, uri, "
          "latency,appkey,msg_id,source,all_chunk_time) VALUES"  // NOLINT
          " (\"%s\", \"%s\", \"%s\", \"%s\", \"%s\" , \"%s\", "
          "%d,\"%s\",\"%s\",\"%s\",\"%s\")",  // NOLINT
          mobvoi::GetDetailTime(mobvoi::Time::FromTimeT(time)).c_str(),
          data["product"].asCString(), text.c_str(),
          data["synthesize_mode"].asCString(), data["speaker"].asCString(),
          uri.c_str(), data["latency"].asInt(), data["appkey"].asCString(),
          data["msg_id"].asCString(), data["source"].asCString(),
          all_time.c_str());
      util::RunMysqlCommand(FLAGS_mysql_server_conf, command);
    }
  }
}

#endif  // TTS_SERVER_TTS_LOG_H_
