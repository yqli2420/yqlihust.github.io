// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/server/speaker_mapping.h"
#include "mobvoi/base/log.h"
#include "tts/util/tts_util/util.h"

DEFINE_string(speaker_mapping, "", "map config center file");

namespace server {

SpeakerMapping::SpeakerMapping() { LoadSpeakerMapping(FLAGS_speaker_mapping); }

SpeakerMapping::~SpeakerMapping() {}

void SpeakerMapping::LoadSpeakerMapping(const string& map_config) {
  Json::Value projects;
  tts::GetConfigCenterAsJson(map_config, &projects);
  VLOG(2) << projects;
  for (const auto& project : projects) {
    string app_key = project.get("app_key", "").asString();
    Json::Value speakers = project["mapping"];
    for (const auto& speaker : speakers.getMemberNames()) {
      string ori_speaker = app_key + "_" + speaker;
      string map_speaker = speakers.get(speaker, "").asString();
      VLOG(2) << "add speaker mapping: " << ori_speaker << " " << map_speaker;
      speaker_mapping_.insert(std::make_pair(ori_speaker, map_speaker));
    }
  }
}

bool SpeakerMapping::MapSpeaker(const string& app_key, const string& speaker,
                                string* map_speaker) const {
  string ori_speaker = app_key + "_" + speaker;
  auto it = speaker_mapping_.find(ori_speaker);
  if (it != speaker_mapping_.end()) {
    VLOG(2) << "map speaker: " << ori_speaker << " --> " << it->second;
    *map_speaker = it->second;
    return true;
  }
  VLOG(2) << "no map speaker: " << ori_speaker;
  return false;
}

}  // namespace server
