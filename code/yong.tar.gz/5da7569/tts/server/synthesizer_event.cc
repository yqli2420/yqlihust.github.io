// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: fllin@mobvoi.com (Fenglv Lin)

#include "tts/server/synthesizer_event.h"

#include "mobvoi/base/log.h"

namespace server {

SynthesizerEvent::SynthesizerEvent(
    std::shared_ptr<mobvoi::ConcurrentQueue<string>> data_queue,
    std::shared_ptr<std::vector<string>> duration)
    : data_queue_(data_queue), duration_(duration), data_res_("") {}

SynthesizerEvent::~SynthesizerEvent() {}

void SynthesizerEvent::OnStart() { LOG(INFO) << "start to synthesis data."; }

bool SynthesizerEvent::OnSynthesizeData(const std::string& data) {
  data_res_ += data;
  if (!data.empty()) {
    data_queue_->Push(data);
  }
  VLOG(1) << "got data, size : " << data.size();
  return true;
}

bool SynthesizerEvent::GetChunkDuration(const std::string& duration) {
  if (!duration.empty()) {
    duration_->emplace_back(duration);
  }
  return true;
}

void SynthesizerEvent::OnFinish() { data_queue_->Push(string()); }

string SynthesizerEvent::GetResult() { return data_res_; }

}  // namespace server
