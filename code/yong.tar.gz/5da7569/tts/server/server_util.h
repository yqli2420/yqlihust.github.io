// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: chhyu@mobvoi.com (Changhe Yu)

#ifndef TTS_SERVER_SERVER_UTIL_H_
#define TTS_SERVER_SERVER_UTIL_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/singleton.h"
#include "mobvoi/license/license_validator.h"
#include "mobvoi/util/net/http_server/http_request.h"
#include "mobvoi/util/net/http_server/http_response.h"
#include "mobvoi/util/net/http_server/http_server.h"
#include "third_party/jsoncpp/json.h"
#include "tts/server/async_logger.h"
#include "tts/server/cache_handler.h"
#include "tts/synthesizer/proto/tts.pb.h"
#include "tts/util/ssml/ssml_parser.h"

typedef Json::Value KibanaData;
namespace util {
class HttpRequest;
class HttpResponse;
}  // namespace util

namespace server {

static const int kMaxCacheLen = 400;
static const char kTypeStreaming[] = "streaming";
static const char kTypeBlock[] = "block";
static const char kReqTypeAlign[] = "alignment";
static const char kReqTypeFrontend[] = "frontend";
static const char kReqTypeFrontendTn[] = "frontend_tn";
static const char kReqTypeSynthesis[] = "synthesis";
static const char kInputTypeJson[] = "json";
static const char kInputTypeText[] = "text";

static const char kSsmlOptionKey[] = "option";
static const char kSsmlSpeakerKey[] = "speaker";
static const char kSsmlSpeedKey[] = "speed";

struct SynText {
  string text;
  string href;

  void Clear() {
    text.clear();
    href.clear();
  }
};

struct KibanaInfo {
  int use_cache;
  int used_time_ms;
  int text_length;
  string type;
  string speaker;
  string product;
};

struct AudioParams {
  AudioParams(const string& _name, float _volume, bool _is_id)
      : name(_name), volume(_volume), is_id(_is_id) {}
  string name;
  float volume;
  bool is_id = true;
};

struct OptionSent {
  OptionSent(const string& _context, const string& _speaker, double _speed,
             bool _is_set)
      : context(_context), speaker(_speaker), speed(_speed), is_set(_is_set) {}
  string context;
  string speaker;
  double speed;
  bool is_set;
};

struct ConcurrentSent {
  ConcurrentSent() {}
  ConcurrentSent(int _id, const string& _context, const string& _speaker,
                 double _speed)
      : id(_id), context(_context), speaker(_speaker), speed(_speed) {}
  int id;
  string context;
  string speaker;
  double speed;
};

class ServerUtil {
 public:
  ServerUtil() = delete;
  ~ServerUtil() = delete;

  static void AcquireLicense(bool use_license);
  static void AppendHeadSilence(const map<string, string>& params,
                                string* text);
  static bool Download(const string& engine_name);
  static string FetchUrl(const string& url);
  static void ReleaseLicense(bool use_license);
  static void RequestInputParser(const string& request_string,
                                 const string& text_type,
                                 vector<vector<string>>* prase_text);
  static void RestrictTextLen(string* text, int* word_num);
  static void GetTextLen(const string& text, int* word_num);
  static string GetRequestParams(const map<string, string>& params);
  static string GetProductParam(const map<string, string>& params);
  static string GetRequestTypeParam(const map<string, string>& params);
  static string GetRequestTextTypeParam(const map<string, string>& params);
  static string GetSaveAudioTmpDir();
  static void ParseRequestParams(util::HttpRequest* request,
                                 map<string, string>* params);
  static void SetTTSOption(const map<string, string>& params,
                           tts::TTSOption* tts_option);
  static void SetJsonContentType(const string& request_type,
                                 const string& audio_type,
                                 util::HttpResponse* response);
  static bool SetAllParams(const map<string, string>& params,
                           const string& type, tts::TTSOption* tts_option,
                           util::HttpResponse* response);
  static void DoInputPreprocess(const map<string, string>& params, string* text,
                                int* word_num);

  static void SplitOptionSent(const string& request,
                              vector<OptionSent>* option_sents);
  static void SaveLogToQueue(const std::map<std::string, std::string>& params,
                             const std::string& synthesize_mode,
                             int32 used_time,
                             const std::string& all_time,
                             mobvoi::ConcurrentQueue<KibanaData>* log_queue);
  static void SaveSyncLog(const map<string, string>& params, int32 used_time,
                          AsyncLogger* logger);
  static void SaveLog(const map<string, string>& params, const int& used_time,
                      const string& all_time,
                      const string& type, server::AsyncLogger* logger,
                      mobvoi::ConcurrentQueue<KibanaData>* log_queue);
  // use_cache->-1:cache none, 0:cache sentence prefix, 1:cache all setence
  static void WriteToKibana(int use_cache, int used_time_ms, int text_length,
                            const string& type, const string& speaker,
                            const string& product,
                            mobvoi::ConcurrentQueue<KibanaData>* data_queue);
  static bool FetchWavByUrl(const string& url, const string& name,
                            vector<int16>* wav_data, bool del_tmp_file = true);
  static void GetBgmParam(const string& text, tts::TTSOption* tts_option);
  static bool GetUrl(const string& id, string* url, string* name);
  static void GetSpecialAudio(const AudioParams& audio_param, int* beg,
                              int* end, map<int, int>* bgm_section,
                              vector<int16>* pcm_result);
  static bool GetAudio(const AudioParams& audio_param,
                       vector<int16>* pcm_result, bool del_tmp_file = true);
  static void GenAudioVolume(const vector<int16>& pcm_result,
                             AudioVolume* audio_volume);
  static bool GetAudioVolume(const string& id, AudioVolume* audio_volume);
  static bool GetBgm(const string& bgm_id, vector<int16>* pcm_tmp);
  static void InitBgm();
  static void FrontendDictJsonWrapper(Json::Value* frontend_dict_data);
  static bool IsRejectOfflineRequest(
      const std::map<std::string, std::string>& params);
  static bool IsRejectOfflineRequestSop1(
      const std::map<std::string, std::string>& params,
      const std::string& domain);
  static void GetPitch(const string& text, tts::TTSOption* tts_option);

 private:
  DISALLOW_COPY_AND_ASSIGN(ServerUtil);
};

}  // namespace server

#endif  // TTS_SERVER_SERVER_UTIL_H_
