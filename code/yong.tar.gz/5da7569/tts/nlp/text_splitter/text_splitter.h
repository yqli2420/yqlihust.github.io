// Copyright 2017 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (zheng zhang)

#ifndef TTS_NLP_TEXT_SPLITTER_TEXT_SPLITTER_H_
#define TTS_NLP_TEXT_SPLITTER_TEXT_SPLITTER_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "tts/util/ssml/ssml_parser.h"
#include "tts/util/tts_util/util.h"

namespace nlp {
namespace splitter {

// split level from high to low
enum SplitLevel {
  kPunc = 0,
  kWeakPunc,
  kTag,
  kText,
  kNon,
  kSplitAllNum,
};

// Split long text to several text part based on
// text length threshold
// preference split in punctuation
class TextSplitter {
 public:
  TextSplitter();
  ~TextSplitter();

  void TextSplit(const vector<tts::SsmlText>& ssml_texts, int len_threshold,
                 vector<vector<tts::SsmlText>>* text_pieces) const;
  void TextSplit(const vector<tts::SsmlText>& ssml_texts, int len_threshold,
                 int break_time,
                 vector<vector<tts::SsmlText>>* text_pieces) const;

 private:
  // repalce break tag to punctuation for target attrs in ssml
  void ProcessBreakTag(const vector<tts::SsmlText>& ssml_texts,
                       vector<tts::SsmlText>* break_processed_texts) const;
  // split text by punc then by length
  void DeepSplit(const vector<tts::SsmlText>& ssml_texts, int len_threshold,
                 int break_time, vector<tts::SsmlText>* split_pieces,
                 vector<SplitLevel>* split_levels) const;
  void MergeDeepSplit(const vector<tts::SsmlText>& split_pieces,
                      const vector<SplitLevel>& split_levels, int len_threshold,
                      vector<vector<tts::SsmlText>>* text_pieces) const;
  // split pure text by punc
  void TextSplitByPunc(const string& text,
                       vector<std::pair<string, SplitLevel>>* text_segs) const;
  // split pure text by length
  void TextSplitByLen(const std::pair<string, SplitLevel>& text,
                      int len_threshold, vector<tts::SsmlText>* split_pieces,
                      vector<SplitLevel>* split_levels) const;

  DISALLOW_COPY_AND_ASSIGN(TextSplitter);
};

bool IsPunctuationForSplit(const string& text, SplitLevel* level);
// decide if it is a ambiguity punctuation
// return true, it is not a punc for split, otherwise return false
bool AmbiguityPunc(const string& cur_word, const string& next_word);
bool IsBreakPunctuation(const string& cur_word);

}  // namespace splitter
}  // namespace nlp
#endif  // TTS_NLP_TEXT_SPLITTER_TEXT_SPLITTER_H_
