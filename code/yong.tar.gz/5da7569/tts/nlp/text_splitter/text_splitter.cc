// Copyright 2017 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (zheng zhang)

#include "tts/nlp/text_splitter/text_splitter.h"

#include "mobvoi/base/log.h"
#include "mobvoi/util/utf8/utf8_util.h"
#include "tts/synthesizer/label_generator/label_def.h"

namespace nlp {
namespace splitter {

static const char* kPunctuationForSplit[] = {
    "。", "；", "？", "！",  // double byte
    ".",  ";",  "?",  "!",   // single byte
};
static const char* kBreakPunctuation[] = {
    "\r", "\n",
};
static const char* kWeakPunctuationForSplit[] = {
    "，", ",",
};

TextSplitter::TextSplitter() {}

TextSplitter::~TextSplitter() {}

void TextSplitter::TextSplit(const vector<tts::SsmlText>& ssml_texts,
                             int len_threshold,
                             vector<vector<tts::SsmlText>>* text_pieces) const {
  TextSplit(ssml_texts, len_threshold, tts::kPuncBreakTime, text_pieces);
}

void TextSplitter::TextSplit(const vector<tts::SsmlText>& ssml_texts,
                             int len_threshold, int break_time,
                             vector<vector<tts::SsmlText>>* text_pieces) const {
  VLOG(2) << "begin to split text";
  vector<tts::SsmlText> punc_pieces;
  vector<SplitLevel> split_levels;
  vector<tts::SsmlText> break_processed_texts;
  ProcessBreakTag(ssml_texts, &break_processed_texts);
  DeepSplit(break_processed_texts, len_threshold, break_time, &punc_pieces,
            &split_levels);
  MergeDeepSplit(punc_pieces, split_levels, len_threshold, text_pieces);

  if (VLOG_IS_ON(2)) {
    for (const auto& text_piece : *text_pieces) {
      tts::SsmlParser::Instance().LogSsml(text_piece);
    }
  }
  VLOG(2) << "text split finished";
}

void TextSplitter::ProcessBreakTag(
    const vector<tts::SsmlText>& ssml_texts,
    vector<tts::SsmlText>* break_processed_texts) const {
  for (const auto& ssml_text : ssml_texts) {
    if (ssml_text.tag.name != tts::kSsmlBreakKey) {
      break_processed_texts->emplace_back(ssml_text);
      continue;
    }
    auto it = ssml_text.tag.attrs.find(tts::kSsmlBreakStrength);
    if (it == ssml_text.tag.attrs.end()) {
      break_processed_texts->emplace_back(ssml_text);
      continue;
    }
    if (it->second == tts::kSsmlBreakWeak) {
      break_processed_texts->emplace_back(tts::kSepMarkWord);
    } else if (it->second == tts::kSsmlBreakMedium) {
      break_processed_texts->emplace_back(tts::kSepMarkPhrase);
    } else if (it->second == tts::kSsmlBreakStrong) {
      break_processed_texts->emplace_back(tts::kSepMarkLP);
    } else {  // tts::kSsmlBreakXStrong or others, treat as "<break>"
      tts::SsmlText ssml_text_tmp(ssml_text);
      ssml_text_tmp.tag.attrs.clear();
      break_processed_texts->emplace_back(ssml_text_tmp);
    }
  }
}

void TextSplitter::DeepSplit(const vector<tts::SsmlText>& ssml_texts,
                             int len_threshold, int break_time,
                             vector<tts::SsmlText>* split_pieces,
                             vector<SplitLevel>* split_levels) const {
  VLOG(2) << "begin to deep split text";
  for (const auto& ssml_text : ssml_texts) {
    if (!ssml_text.tag.name.empty()) {
      split_pieces->emplace_back(ssml_text);
      split_levels->emplace_back(SplitLevel::kTag);
    } else {
      vector<std::pair<string, SplitLevel>> text_segs;
      TextSplitByPunc(ssml_text.text, &text_segs);
      for (const auto& text_seg : text_segs) {
        if (text_seg.second == SplitLevel::kTag) {
          split_pieces->emplace_back(
              tts::SsmlParser::Instance().GenBreakSsmlText(break_time));
          split_levels->emplace_back(SplitLevel::kTag);
          continue;
        }
        TextSplitByLen(text_seg, len_threshold, split_pieces, split_levels);
      }
    }
  }
  VLOG(2) << "deep split text finished ...";
}

void TextSplitter::MergeDeepSplit(
    const vector<tts::SsmlText>& split_pieces,
    const vector<SplitLevel>& split_levels, int len_threshold,
    vector<vector<tts::SsmlText>>* text_pieces) const {
  vector<tts::SsmlText> text_piece_tmp;
  int cur_len = 0;
  // each level vector offset
  tts::SplitPoint level_offset(SplitLevel::kSplitAllNum);
  // each level text length
  tts::SplitPoint level_len(SplitLevel::kSplitAllNum);
  for (size_t i = 0; i < split_pieces.size(); ++i) {
    if (split_pieces[i].tag.name == tts::kSsmlBreakKey) {
      if (!text_piece_tmp.empty()) {
        text_pieces->emplace_back(std::move(text_piece_tmp));
        level_offset.SetLevelValue(SplitLevel::kPunc, 0);
        level_len.SetLevelValue(SplitLevel::kPunc, 0);
      }
      text_pieces->emplace_back(1, split_pieces[i]);
      cur_len = 0;
      continue;
    }
    text_piece_tmp.emplace_back(split_pieces[i]);
    cur_len += util::utflen(split_pieces[i].text.c_str());
    if (cur_len > len_threshold) {
      int split_level;
      if (level_offset.GetSplitLevel(&split_level)) {
        int split_offset = level_offset.GetLevelValue(split_level);
        int split_len = level_len.GetLevelValue(split_level);
        vector<tts::SsmlText> text_tmp;
        text_tmp.insert(text_tmp.end(), text_piece_tmp.begin(),
                        text_piece_tmp.begin() + split_offset);
        text_pieces->emplace_back(text_tmp);
        text_piece_tmp.erase(text_piece_tmp.begin(),
                             text_piece_tmp.begin() + split_offset);
        cur_len -= split_len;
        level_offset.RemoveLevelAndRefresh(split_level);
        level_len.RemoveLevelAndRefresh(split_level);
      }
    }
    level_offset.SetLevelValue(split_levels[i], text_piece_tmp.size());
    level_len.SetLevelValue(split_levels[i], cur_len);
  }
  if (!text_piece_tmp.empty()) {
    text_pieces->emplace_back(text_piece_tmp);
  }
}

void TextSplitter::TextSplitByPunc(
    const string& text,
    vector<std::pair<string, SplitLevel>>* text_segs) const {
  VLOG(2) << "begin to split text part by punc: " << text;
  vector<util::Rune> unicodes;
  util::Utf8ToUnicode(text, &unicodes);
  string text_tmp;
  string cur_word;
  for (size_t i = 0; i < unicodes.size(); ++i) {
    cur_word = util::RuneToWord(unicodes[i]);
    if (IsBreakPunctuation(cur_word)) {
      if (!text_tmp.empty()) {
        text_segs->emplace_back(
            std::make_pair(std::move(text_tmp), SplitLevel::kNon));
      }
      // remove duplicated \r and \n
      if (text_segs->empty() || text_segs->back().second != SplitLevel::kTag) {
        text_segs->emplace_back(std::make_pair(cur_word, SplitLevel::kTag));
      }
      continue;
    }
    text_tmp.append(cur_word);
    SplitLevel level_tmp = SplitLevel::kNon;
    if (IsPunctuationForSplit(cur_word, &level_tmp)) {
      if (i == unicodes.size() - 1 ||
          !AmbiguityPunc(cur_word, util::RuneToWord(unicodes[i + 1]))) {
        text_segs->emplace_back(std::make_pair(std::move(text_tmp), level_tmp));
      }
    }
  }
  // Last piece
  if (!text_tmp.empty()) {
    text_segs->emplace_back(std::make_pair(text_tmp, SplitLevel::kText));
  }
  if (VLOG_IS_ON(2)) {
    for (const auto& text_seg : *text_segs) {
      LOG(INFO) << "  text seg: " << text_seg.first;
    }
  }
  VLOG(2) << "split text part finished ...";
}

void TextSplitter::TextSplitByLen(const std::pair<string, SplitLevel>& text,
                                  int len_threshold,
                                  vector<tts::SsmlText>* split_pieces,
                                  vector<SplitLevel>* split_levels) const {
  VLOG(2) << "begin to split text by length: " << text.first;
  string text_str = text.first;
  vector<util::Rune> unicodes;
  util::Utf8ToUnicode(text_str, &unicodes);
  size_t start = 0, end = start + len_threshold;
  string text_tmp;
  while (end < unicodes.size()) {
    while (std::isalpha(static_cast<unsigned char>(unicodes[end - 1])) &&
           end < unicodes.size())
      ++end;
    util::UnicodeToUtf8(unicodes.begin() + start, unicodes.begin() + end,
                        &text_tmp);
    split_pieces->emplace_back(tts::SsmlText(text_tmp));
    split_levels->emplace_back(SplitLevel::kText);
    start = end;
    end = start + len_threshold;
  }
  if (start != unicodes.size()) {
    util::UnicodeToUtf8(unicodes.begin() + start, unicodes.end(), &text_tmp);
    split_pieces->emplace_back(tts::SsmlText(text_tmp));
    split_levels->emplace_back(text.second);
  }
  VLOG(2) << "split text by length finished ...";
}

bool IsPunctuationForSplit(const string& text, SplitLevel* level) {
  for (const auto& punc : kPunctuationForSplit) {
    if (text == punc) {
      *level = SplitLevel::kPunc;
      return true;
    }
  }
  for (const auto& punc : kWeakPunctuationForSplit) {
    if (text == punc) {
      *level = SplitLevel::kWeakPunc;
      return true;
    }
  }
  return false;
}

bool AmbiguityPunc(const string& cur_word, const string& next_word) {
  if (cur_word == ".") {
    if (next_word != " ") {
      // abbreviation
      return true;
    } else if (next_word.size() == 1 && std::isdigit(next_word[0])) {
      // decimal
      return true;
    }
  } else if (cur_word == ",") {
    if (next_word.size() == 1 && std::isdigit(next_word[0])) {
      // thousands
      return true;
    }
  }
  return false;
}

bool IsBreakPunctuation(const string& cur_word) {
  for (const auto& punc : kBreakPunctuation) {
    if (cur_word == punc) {
      return true;
    }
  }
  return false;
}

}  // namespace splitter
}  // namespace nlp
