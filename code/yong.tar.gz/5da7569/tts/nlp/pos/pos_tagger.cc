// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/nlp/pos/pos_tagger.h"

#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/hash_tables.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/util/utf8/utf8_util.h"
#include "third_party/crf/crfpp.h"
#include "third_party/crf/tagger.h"

DEFINE_double(pos_crf_cost_factor, 1.0, "");

namespace nlp {
namespace segmenter {

class PosCrfModel {
 public:
  PosCrfModel(const string& pos_crf_model,
              const string& pos_word_id_conf);
  ~PosCrfModel();

  CRFPP::DecoderFeatureIndex* decoder_feature_index() {
    return decoder_feature_index_;
  }
  int GetWordId(const string& word) const;


 private:
  CRFPP::DecoderFeatureIndex* decoder_feature_index_;
  base::hash_map<string, int> word_to_id_;

  DISALLOW_COPY_AND_ASSIGN(PosCrfModel);
};

PosCrfModel::PosCrfModel(const string& pos_crf_model,
                         const string& pos_word_id_conf) {
  decoder_feature_index_ = new CRFPP::DecoderFeatureIndex;
  if (!decoder_feature_index_->open(pos_crf_model.c_str())) {
    LOG(FATAL) << decoder_feature_index_->what();
  }
  // Load word id mapping config.
  file::SimpleLineReader reader(pos_word_id_conf);
  vector<string> lines;
  reader.ReadLines(&lines);
  for (auto line : lines) {
    vector<string> segs;
    SplitString(line,  '\t', &segs);
    if (segs.size() != 2U) {
      continue;
    }
    word_to_id_[segs[0]] = StringToInt(segs[1]);
  }
}

PosCrfModel::~PosCrfModel() {
  delete decoder_feature_index_;
}

int PosCrfModel::GetWordId(const string& word) const {
  auto it = word_to_id_.find(word);
  if (it != word_to_id_.end()) {
    return it->second;
  } else {
    // Return 0 for all OOV words.
    return 0;
  }
}

PosTagger::PosTagger(const string& pos_crf_model,
                     const string& word_id_conf) {
  VLOG(2) << "pos_crf_model : " << pos_crf_model
          << ", word_id_conf : " << word_id_conf;
  model_.reset(new PosCrfModel(pos_crf_model, word_id_conf));
  tagger_.reset(new CRFPP::TaggerImpl);
  const int kNbest = 1;
  const int kVerboseLevel = 0;
  if (!tagger_->open(model_->decoder_feature_index(),
                     kNbest, kVerboseLevel)) {
    LOG(FATAL) << tagger_->what();
    return;
  }
  tagger_->set_cost_factor(FLAGS_pos_crf_cost_factor);
}

PosTagger::~PosTagger() {}

bool PosTagger::Tag(const vector<string>& tokens,
                    vector<string>* result) const {
  mobvoi::MutexLock lock(&mutex_);
  tagger_->clear();

  for (size_t i = 0; i < tokens.size(); ++i) {
    string line = StringPrintf("%d\t%s",
                               model_->GetWordId(tokens[i]),
                               tokens[i].c_str());
    VLOG(2) << "add token : " << line;
    tagger_->add(line.c_str());
  }
  if (!tagger_->parse()) {
    VLOG(1) << "Fail to parse";
    return false;
  }
  if (tagger_->empty()) {
    VLOG(1) << "tagger is empty.";
    return false;
  }
  VLOG(2) << tagger_->toString();

  for (size_t i = 0; i < tokens.size(); ++i) {
    result->push_back(tagger_->y2(i));
  }
  return true;
}

}  // namespace segmenter
}  // namespace nlp
