// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/nlp/t2s/trad_simp_converter.h"

#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/util/utf8/utf8_util.h"

namespace nlp {
namespace t2s {

static const char kMapSepSign = '\t';
enum T2sMapFormat {
  kT2sTrad = 0,
  kT2sSimp,
  kT2sAllNum,
};

Trad2SimpConverter::Trad2SimpConverter(const string& conf_file) {
  if (!LoadTradSimpMap(conf_file)) {
    LOG(FATAL) << "load traditional file error" << conf_file;
  }
}

Trad2SimpConverter::~Trad2SimpConverter() {}

bool Trad2SimpConverter::Convert(const string& trad, string* simp) const {
  vector<util::Rune> unicodes;
  util::Utf8ToUnicode(trad, &unicodes);
  for (auto& unicode : unicodes) {
    auto it = trad_simp_map_.find(unicode);
    if (it != trad_simp_map_.end()) {
      unicode = it->second;
    }
  }
  util::UnicodeToUtf8(unicodes.begin(), unicodes.end(), simp);
  return true;
}

bool Trad2SimpConverter::LoadTradSimpMap(const string& conf_file) {
  vector<string> lines;
  file::SimpleLineReader reader(conf_file, true, "#");
  reader.ReadLines(&lines);

  trad_simp_map_.reserve(lines.size());
  for (const string& line : lines) {
    vector<string> segs;
    SplitString(line, kMapSepSign, &segs);
    CHECK(T2sMapFormat::kT2sAllNum == segs.size())
        << "line format error: " << line;

    vector<string> simp;
    SplitString(segs[T2sMapFormat::kT2sSimp], ' ', &simp);
    string trad = segs[T2sMapFormat::kT2sTrad];

    util::Rune trad_rune;
    util::chartorune(&trad_rune, trad.c_str());
    util::Rune simp_rune;
    util::chartorune(&simp_rune, simp[0].c_str());
    trad_simp_map_[trad_rune] = simp_rune;
  }
  if (trad_simp_map_.empty()) return false;
  VLOG(1) << "trad_simp_map_  size : " << trad_simp_map_.size();
  return true;
}

}  // namespace t2s
}  // namespace nlp
