// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: fllin@mobvoi.com (Fenglv Lin)

#ifndef TTS_NLP_T2S_T2S_REGRESSION_TEST_UTIL_H_
#define TTS_NLP_T2S_T2S_REGRESSION_TEST_UTIL_H_

#include <string>

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "third_party/jsoncpp/json.h"
#include "tts/nlp/t2s/trad_simp_converter.h"

namespace nlp {
namespace t2s {

class T2SRegressionTestUtil {
 public:
  T2SRegressionTestUtil();
  ~T2SRegressionTestUtil() {}
  void RunTestCases(const std::string& test_file, Json::Value* result) const;

 private:
  unique_ptr<nlp::t2s::Trad2SimpConverter> t2s;
  DISALLOW_COPY_AND_ASSIGN(T2SRegressionTestUtil);
};

}  // namespace t2s
}  // namespace nlp
#endif  // TTS_NLP_T2S_T2S_REGRESSION_TEST_UTIL_H_
