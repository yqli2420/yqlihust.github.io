// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/nlp/t2s/trad_simp_converter.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/time.h"
#include "mobvoi/util/utf8/utf8_util.h"

DEFINE_string(input, "沒有找到相關音樂", "");
DEFINE_string(input_file, "", "");
DEFINE_string(output_file, "", "");
DEFINE_string(trad_to_simp, "external/config/front_end/dict/trad_to_simp.txt",
              "");

int main(int argc, char** argv) {
  google::ParseCommandLineFlags(&argc, &argv, false);

  vector<string> input_texts;
  if (!FLAGS_input.empty()) {
    input_texts.push_back(FLAGS_input);
  } else if (!FLAGS_input_file.empty()) {
    file::SimpleLineReader file_reader(FLAGS_input_file, true, "#");
    file_reader.ReadLines(&input_texts);
  } else {
    LOG(FATAL) << "no input texts";
  }

  unique_ptr<nlp::t2s::Trad2SimpConverter> t2s;
  t2s.reset(new nlp::t2s::Trad2SimpConverter(FLAGS_trad_to_simp));

  vector<string> result;
  result.reserve(input_texts.size());
  int64 begin_time = mobvoi::GetTimeInMs();
  int total_length = 0;
  for (const string& text : input_texts) {
    total_length += util::utflen(text.c_str());
    string simp;
    t2s->Convert(text, &simp);
    result.emplace_back(std::move(simp));
  }
  int64 end_time = mobvoi::GetTimeInMs();

  if (FLAGS_output_file.empty()) {
    for (const string& simp : result) LOG(INFO) << simp;
  } else {
    string result_string = JoinVector(result, '\n');
    mobvoi::File::WriteStringToFileOrDie(result_string, FLAGS_output_file);
  }

  int64 used_time = end_time - begin_time;
  LOG(INFO) << "t2s text length: " << total_length;
  LOG(INFO) << "used time: " << used_time;
  if (used_time) {
    LOG(INFO) << "performance(character/second): "
              << total_length * 1000.0 / used_time;
  }
  return 0;
}
