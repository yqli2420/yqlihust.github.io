// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/nlp/tn/text_normalizer.h"
#include "tts/nlp/tn/text_normalizer_impl.h"

#include "mobvoi/base/log.h"
#include "tts/util/tts_util/util.h"

#include "tts/nlp/tn/cantonese_text_normalizer.h"
#include "tts/nlp/tn/english_text_normalizer.h"
#include "tts/nlp/tn/mandarin_text_normalizer.h"
#include "tts/nlp/tn/taiwanese_text_normalizer.h"

namespace nlp {
namespace tn {

TextNormalizer::TextNormalizer(const string& language,
                               const string& resource_file) {
  p_impl.reset(CreateImpl(language, resource_file));
}

TextNormalizer::~TextNormalizer() {}

bool TextNormalizer::Normalize(const vector<tts::SsmlText>& ssml_inputs,
                               const string& option,
                               vector<tts::SsmlText>* ssml_outputs) const {
  return p_impl->Normalize(ssml_inputs, option, ssml_outputs);
}

bool TextNormalizer::Normalize(const vector<tts::SsmlText>& ssml_inputs,
                               const string& option,
                               vector<tts::SsmlText>* ssml_outputs,
                               tts::TnDetail* detail) const {
  return p_impl->Normalize(ssml_inputs, option, ssml_outputs, detail);
}

bool TextNormalizer::Normalize(const string& input, const string& option,
                               string* output) const {
  return p_impl->Normalize(input, option, output);
}

bool TextNormalizer::Normalize(const string& input, const string& option,
                               string* output, tts::TnDetail* detail) const {
  return p_impl->Normalize(input, option, output, detail);
}

void TextNormalizer::PostProcess(string* text) const {
  return p_impl->PostProcess(text);
}

TextNormalizerImpl* TextNormalizer::CreateImpl(const string& language,
                                               const string& resource_file) {
  LOG(INFO) << "init tn: " << language;
  if (tts::kMandarinTypeString == language ||
      tts::kSichuaneseTypeString == language) {
    return new TextNormalizerImpl(mandarin::kMandarinPatternHandlers,
                                  arraysize(mandarin::kMandarinPatternHandlers),
                                  mandarin::kMandarinFundHandlers,
                                  arraysize(mandarin::kMandarinFundHandlers),
                                  resource_file);
  } else if (tts::kTaiwaneseTypeString == language) {
    return new TextNormalizerImpl(
        mandarin::kTaiwanesePatternHandlers,
        arraysize(mandarin::kTaiwanesePatternHandlers),
        mandarin::kMandarinFundHandlers,
        arraysize(mandarin::kMandarinFundHandlers), resource_file);
  } else if (tts::kCantoneseTypeString == language) {
    return new TextNormalizerImpl(
        mandarin::kCantonesePatternHandlers,
        arraysize(mandarin::kCantonesePatternHandlers),
        mandarin::kCantoneseFundHandlers,
        arraysize(mandarin::kCantoneseFundHandlers), resource_file);
  } else if (tts::kEnglishTypeString == language) {
    return new TextNormalizerImpl(english::kEnglishPatternHandlers,
                                  arraysize(english::kEnglishPatternHandlers),
                                  english::kEnglishFundHandlers,
                                  arraysize(english::kEnglishFundHandlers),
                                  resource_file);
  } else {
    LOG(FATAL) << "not support this language: " << language;
    return nullptr;
  }
}

}  // namespace tn
}  // namespace nlp
