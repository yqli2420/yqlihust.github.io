// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_NLP_TN_CANTONESE_TEXT_NORMALIZER_H_
#define TTS_NLP_TN_CANTONESE_TEXT_NORMALIZER_H_

#include "tts/nlp/tn/common_pattern_handler.h"

namespace nlp {
namespace tn {
namespace mandarin {

static const PatternHandler kCantonesePatternHandlers[] = {
    // special regex pattern
    // customized pattern for 长
    {kCustomizedPattern, CustomizedHandler},
    {kSpecialSymbolPattern, SpecialSymbolHandler},
    {kSpecialEnglishPattern, SpecialEnglishHandler},  // TFBoys
    {kSpecialPointPattern, YiSpecialPointHandler},    // 7·11
    {kSubWayPattern, SubwayHandler},                  // 14号线
    {kSubWayPattern2, SubwayHandler},                 // B1层
    {kBuildingPattern, LowerBuildingHandler},         // a座 a口
    {k360Pattern1, SpecialNameHandler},               // 360浏览器 e.g.
    {k360Pattern2, SpecialNameHandler},               // 安装360 e.g.
    {kAgesPattern, YiSpecialCaseHandler},             // 80、90后
    {kAgePattern, YiSpecialNameHandler},              // 80后 90后
    {kColleagePattern, YiSpecialNameHandler},         // 985学校
    {kSpecialNamePattern, YiSpecialNameHandler},      // 911事件　311事变
    {kSpecialPlacePattern, YiSpecialNameHandler},     // 导航去798
    {kSpecialPlacePattern2, YiSpecialNameHandler},    // 798店
    {kSpecialPlacePattern3, YiSpecialNameHandler},    // 动感101
    {kRadioPattern, YiRadioHandler},                  // FM 103.6MHz

    {kWebsitePattern, YiWebsiteHandler},  // zz@163.com  www.baidu.com
    {kAtPattern, AtHandler},              // @you
    // {kNumberEnglishPattern1, YiNumberEnglishHandler},  // 2D 3D 4D
    // {kNumberEnglishPattern2, YiNumberEnglishHandler},  // T台
    // {kQQEnglishPattern, QQEnglishHandler},             // QQ

    {kMathPattern2, MathHandler, kDomainCalc, kAllBody},  // 2002-2-3等于1997
    {kMathStringPattern1, MathHandler, kDomainCalc,
     kAllBody},  // 100加203等于303
    {kMathStringPattern2, MathHandler, kDomainCalc, kAllBody},  // 等于303
    {kMathPattern1, MathHandler, kDomainCalc, kAllBody},        // 1+2-3=14

    // number pattern
    {kPMPattern, PMHandler},                    // PM2.5
    {kYearMonthDayStringPattern, DateHandler},  // 2015年03月12日
    {kYearMonthStringPattern, DateHandler},     // 2015年03月
    {kMonthDayStringPattern, DateHandler},      // 07月03日
    {kSingleYearPattern, YearHandler},          // 2015年
    // {kCommaNumberPattern, CommaNumberHandler},  // 13,000,000
    // percent
    {kSignedPercentPattern, PercentHandler},  // -13.72% +100%
    {kPercentPattern, PercentHandler},        // 13.72% 100%

    // score
    {kScoreKWPreToPattern, ScoreHandler},      // 比分为8-12
    {kScoreKWPostToPattern, ScoreHandler},     // 比分为103-86-72
    {kScoreKWPreRatioPattern, ScoreHandler},   // 比分为8:12
    {kScoreKWPostRatioPattern, ScoreHandler},  // 比分为103:86:72
    // // time
    {kTimeFullAppendPattern, TimeHandler},  // 12:00:23AM, 3:10:23PM
    {kTimePartAppendPattern, TimeHandler},  // 12:00AM, 3:10PM

    {kTimeFullPattern, TimeHandler},        // 08:23:20 12:00:23AM, 3:10:23PM
    {kTimePartPattern, TimeHandler},        // 18:30 12:00AM, 3:10PM
    {kTimeStringFullPattern, TimeHandler},  // 17点8分12秒
    {kTimeStringPartPattern, TimeHandler},  // 17点8分

    // order
    {kOrdinalPattern, OrdinalHandler},
    // number for currency
    {kCurrencyPattern, CurrencyHandler},        // ￥1.4
    {kCurrencyStringPattern, CurrencyHandler},  // RMB28
    {kPreAbbvUnitsPattern, CurrencyHandler},    // No.48

    {kTwoYearStrictPattern, DateHandler},  // 98年
    // number for coordinate and race time
    {kCoordinatePattern, CoordinateHandler},   // 18°09′34″
    {kCoordinatePattern2, CoordinateHandler},  // 18°09′
    {kRaceTimePattern, CoordinateHandler},     // 09′34″
    // number for temperature
    {kTemperaturePattern2, TemperatureHandler2},  // -2到5℃
    {kTemperaturePattern, TemperatureHandler},    // 34.32℃
    // numbers for measure abbv word
    {kMeasureCombAbbvPattern, MeasureAbbvHandler},
    {kMeasureAbbvPattern, MeasureAbbvHandler},
    // serial number
    {kStockPattern1, YiStockHandler},  // stock  (sz000001)
    {kStockPattern2, YiStockHandler},  // stock  sz000001  SZ:000001
    // keyword mobile
    {kStrongMobilePattern1, YiTelHandler},  // 拨打 +86 010 8231 2343
    {kStrongMobilePattern2, YiTelHandler},  // +86 010 8231 2343 电话
    // serial
    {kSerialNumPattern, YiSerialHandler},         // MU7089 G65 730Li
    {kSerialNumKeyWordPattern, YiSerialHandler},  // 1024次列车
    {kBuildingPattern2, BuildingHandler, kDomainNavigation,
     kAllBody},  // 和馨园2栋
    // numbers for measure word
    {kNumberToMeasurePattern, MeasureTrieHandler,
     kMeasureTriePatternBody},                          // 1.5-1.79亿元
    {kSignedNumberMeasurePattern, MeasureTrieHandler},  // -1.79亿元
    {kNumberMeasurePattern, MeasureTrieHandler},        // 2079法郎
    {kMeasureTagPattern, MeasureTagHandler},
    {kNumberKWPrePattern, MeasureWordHandler},

    // date
    {kYearMonthDayPattern, DateHandler},  // 2015-03-12
    {kYearMonthPattern, DateHandler},     // 2015-03
    {kMonthDayPattern, DateHandler},      // 07-03

    // Telephone
    {kTelPattern1, YiTelHandler},    // +86 010 8231 2343
    {kTelPattern2, YiTelHandler},    // +86 0721 831 2343
    {kMobilePattern, YiTelHandler},  // +86 010 8231 2343

    {kStrongSpecialTelPattern1, YiTelHandler},  // 400-811-9090
    {kStrongSpecialTelPattern2, YiTelHandler},  // 4008-811-090
    {kStrongSpecialTelPattern3, YiTelHandler},  // 95592
    {kWeakSpecialTelPattern1, YiTelHandler},
    {kWeakSpecialTelPattern2, YiTelHandler},

    {kCommaNumberPattern, CommaNumberHandler},  // 13,000,000

    {kDiscountPattern, DiscountHandler},  // 9.0折, 9折, 7.5折 95折
    {kFractionPattern, FractionHandler},  // 1/2 3/5
    {kPerMeasurePattern, PerHandler},     // per 元/人

    {kScoreDefaultPattern, ScoreHandler},  // 103:86:72
    // symbol -
    {kKeyYearPattern, KeyYearHandler},  // 2018新年 喜迎2018
    {kBarPattern1, BarHandler},         // 小区黄城根1号楼-1-302
    {kBarPattern2, BarHandler},         // 207-3室
    {kDefaultTelPattern, YiTelHandler},
    {kNumberToPattern, BarHandler},  // 37.2-43.4℃  37.2~43.4℃
    {kToPattern, ToHandler},         // 北京 - 上海

    {kGreekPattern, GreekHandler},  // αβγΓΔδεζηθλμξπ∏ρ∑στφΨΩω

    // default patterns
    {kSignedNumberPattern, DefaultNumericalHandler, kNumericalDomain, kAllBody},
    {kSignedNumberPattern, YiDefaultDigitalHandler, kDomainCall, kAllBody},
    {kUnsignedIntegerPattern, DefaultDigitalHandler, kDomainCall, kAllBody},
    {kSignedNumberPattern, DefaultNumberHandler},
    {kUnsignedDecimalPattern, DefaultNumberHandler},
    {kUnsignedIntegerPattern, DefaultNumberHandler},
    {kSymbolPattern, SymbolsHandler},
};

static const FundHandler kCantoneseFundHandlers[] = {
    {tts::kSsmlTnAsDigits, ReadAsDigit},
    {tts::kSsmlTnAsValue, ReadAsValue},
    {tts::kSsmlTnAsContact, ReadAsName},
    {tts::kSsmlTnAsBookName, ReadAsBook},
    {tts::kSsmlTnAsBuilding, ReadAsBuilding},
    {tts::kSsmlTnAsFestival, ReadAsFestival},
    {tts::kSsmlTnAsTelephone, YiReadAsTelephone},
};

}  // namespace mandarin
}  // namespace tn
}  // namespace nlp

#endif  // TTS_NLP_TN_CANTONESE_TEXT_NORMALIZER_H_
