// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/nlp/tn/tn_handler.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/util/utf8/utf8_util.h"

namespace nlp {
namespace tn {

static const int kMaxArgs = 17;  // defined in re2
static const char kBodySepMark = ',';
enum BodyFormat {
  kBodyBegin = 0,
  kBodyEnd,
  kBodyAllNum,
};

BaseHandler::BaseHandler() {}

BaseHandler::~BaseHandler() {}

// empty leaf handler: remain
LeafHandler::LeafHandler() : const_replace_(false) {}

// map leaf handler: do mapping
LeafHandler::LeafHandler(const std::unordered_map<string, string>& handler_map)
    : handler_map_(handler_map), const_replace_(false) {}

// const leaf handler: replace to const string
LeafHandler::LeafHandler(const string& _replace)
    : const_replace_(true), replace_(_replace) {}

LeafHandler::~LeafHandler() {}

string LeafHandler::FullMatchProcess(const string& input) const {
  // const leaf handler
  if (const_replace_) return replace_;
  // empty leaf handler
  if (handler_map_.empty()) return input;
  // else map leaf handler
  auto it = handler_map_.find(input);
  if (it != handler_map_.end()) return it->second;
  return "";
}

string LeafHandler::Process(const string& input, int offset,
                            tts::TnDetail* tn_detail) const {
  return "";
}

BranchHandler::BranchHandler() {}

BranchHandler::BranchHandler(
    const string& pattern,
    const vector<std::shared_ptr<BaseHandler>>& _handlers, const string& _body)
    : handlers_(_handlers) {
  pattern_.reset(new re2::RE2(pattern));
  int param_num = pattern_->NumberOfCapturingGroups();
  if (static_cast<size_t>(param_num) != handlers_.size()) {
    LOG(FATAL) << "pattern mismatch: " << pattern_->pattern() << " "
               << handlers_.size();
  }
  if (_body.empty()) {
    body_ = std::make_pair(0, handlers_.size());
  } else {
    vector<string> bodys;
    SplitString(_body, kBodySepMark, &bodys);
    if (bodys.size() != BodyFormat::kBodyAllNum) {
      LOG(FATAL) << "body mismatch: " << _body << " " << handlers_.size();
    }
    int begin = std::max(0, StringToInt(bodys[BodyFormat::kBodyBegin]));
    int end = std::min(static_cast<int>(handlers_.size()),
                       StringToInt(bodys[BodyFormat::kBodyEnd]));
    body_ = std::make_pair(begin, end);
  }
}

BranchHandler::~BranchHandler() {}

string BranchHandler::FullMatchProcess(const string& input) const { return ""; }

string BranchHandler::Process(const string& input, int offset,
                              tts::TnDetail* detail) const {
  string norm = input;
  int param_num = pattern_->NumberOfCapturingGroups();
  VLOG(2) << "process pattern: " << pattern_->pattern();

  const re2::RE2::Arg* args[kMaxArgs];
  re2::StringPiece strs[kMaxArgs];
  re2::RE2::Arg args_value[kMaxArgs];

  for (int i = 0; i < kMaxArgs; ++i) {
    args_value[i] = re2::RE2::Arg(&strs[i]);
    args[i] = &args_value[i];
  }

  re2::StringPiece norm_piece(norm);
  string norm_pre;
  size_t offset_tmp = 0;
  while (norm_piece.length() > offset_tmp &&
         re2::RE2::PartialMatchN(norm_piece.data() + offset_tmp,
                                 *pattern_.get(), args, param_num)) {
    VLOG(2) << "MATCHED: " << pattern_->pattern();
    VLOG(2) << "origin string: " << norm_piece.data() + offset_tmp;
    string replace_string;
    string body_origin_string;
    string body_replace_string;
    int start = strs[0].data() - norm_piece.data();
    int body_start = strs[body_.first].data() - norm_piece.data();
    int body_offset = util::utflen(norm_piece.data()) -
                      util::utflen(strs[body_.first].data());
    int len = strs[param_num - 1].data() - strs[0].data() +
              strs[param_num - 1].length();
    int body_len = strs[body_.second - 1].data() - strs[body_.first].data() +
                   strs[body_.second - 1].length();
    for (int i = 0; i < param_num; ++i) {
      string part_string = handlers_[i]->FullMatchProcess(strs[i].as_string());
      replace_string += part_string;
      if (i >= body_.first && i < body_.second) {
        body_replace_string += part_string;
      }
    }
    norm_pre = norm;
    VLOG(3) << norm.substr(start, len) << " -> " << replace_string;
    body_origin_string = norm.substr(body_start, body_len);
    norm.replace(start, len, replace_string);
    if (norm_pre == norm) {
      // LOG(WARNING) << "tn no change in text: " << norm;
      offset_tmp = start + len;
    } else {
      detail->tn_mappings.emplace_back(offset + body_offset, body_origin_string,
                                       body_replace_string, "");
    }
    norm_piece = norm;
  }
  return norm;
}

}  // namespace tn
}  // namespace nlp
