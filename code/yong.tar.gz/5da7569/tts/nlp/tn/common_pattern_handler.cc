// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

// See below page for ref
// http://www.zhihu.com/question/22629654
// http://zh.wikipedia.org/wiki/%E4%B8%AD%E6%96%87%E6%95%B0%E5%AD%97
#include "tts/nlp/tn/common_pattern_handler.h"
#include "tts/util/tts_util/util.h"

#include "mobvoi/base/log.h"

namespace nlp {
namespace tn {
namespace mandarin {

static const char* kNonePron = "";
static const char* kPointPron = "点";
static const char* kZhiToPron = "至";
static const char* kPlusPron = "加";
static const char* kXingPron = "星号";    // *
static const char* kDixianPron = "底线";  // _
static const char* kPositivePron = "正";
static const char* kNegativePron = "负";
static const char* kLiangPron = "两";
static const char* kIllegalSignedLiangPron = "负两";
static const char* kDigitsPron[] = {"零", "一", "二", "三", "四",
                                    "五", "六", "七", "八", "九"};
static const char* kDigitsYaoPron[] = {"零", "幺", "二", "三", "四",
                                       "五", "六", "七", "八", "九"};
static const char* kDigitsLiangPron[] = {"零", "一", "两", "三", "四",
                                         "五", "六", "七", "八", "九"};
static const char* kUnitsPron[] = {"", "十", "百", "千"};
static const char* kGroupsPron[] = {"", "万", "亿", "万亿"};
static const Symbol2Pron kEnglish2Pron[] = {
    {"a", "诶"}, {"b", "逼"}, {"d", "弟"}, {"e", "易"}, {"g", "即"},
    {"i", "爱"}, {"n", "恩"}, {"o", "欧"}, {"p", "屁"}, {"q", "秋"},
    {"r", "阿"}, {"t", "踢"}, {"u", "优"}, {"v", "喂"},
};
static const char* kQPron = "鹙鹙";

// telephone length > 6 will be devided to groups by 4 from the end
// e.g. devide: 8323432 -> 832 3432
//  not devide: 10086, 955655
static const int kTelGroupLen = 4;
static const int kTelMinLen = 6;

static const char* kZhangPron = "掌";
static const Symbol2Pron kSpecial2Pron[] = {
    {"|", kSepMarkLP}, {"丨", kSepMarkLP},     {"->", "到"},
    {"→", "转"},       {"<::>", kSilenceMark}, {"∧", "与"}};
static const Symbol2Pron kSerialSymbol2Pron[] = {
    {"Ⅰ", "一^"},   {"Ⅱ", "二^"},   {"Ⅲ", "三^"},   {"Ⅳ", "四^"},
    {"Ⅴ", "五^"},   {"Ⅵ", "六^"},   {"Ⅶ", "七^"},   {"Ⅷ", "八^"},
    {"Ⅸ", "九^"},   {"Ⅹ", "十^"},   {"Ⅺ", "十一^"}, {"Ⅻ", "十二^"},
    {"ⅰ", "一^"},   {"ⅱ", "二^"},   {"ⅲ", "三^"},   {"ⅳ", "四^"},
    {"ⅴ", "五^"},   {"ⅵ", "六^"},   {"ⅶ", "七^"},   {"ⅷ", "八^"},
    {"ⅸ", "九^"},   {"ⅹ", "十^"},   {"①", "一^"},   {"②", "二^"},
    {"③", "三^"},   {"④", "四^"},   {"⑤", "五^"},   {"⑥", "六^"},
    {"⑦", "七^"},   {"⑧", "八^"},   {"⑨", "九^"},   {"⑩", "十^"},
    {"⑪", "十一^"}, {"⑫", "十二^"}, {"⑬", "十三^"}, {"⑭", "十四^"},
    {"⑮", "十五^"}, {"⑯", "十六^"}, {"⑰", "十七^"}, {"⑱", "十八^"},
    {"⑲", "十九^"}, {"⑳", "二十^"}, {"⓪", "零^"},   {"❶", "一^"},
    {"❷", "二^"},   {"❸", "三^"},   {"❹", "四^"},   {"❺", "五^"},
    {"❻", "六^"},   {"❼", "七^"},   {"❽", "八^"},   {"❾", "九^"},
    {"❿", "十^"},   {"⓫", "十一^"}, {"⓬", "十二^"}, {"⓭", "十三^"},
    {"⓮", "十四^"}, {"⓯", "十五^"}, {"⓰", "十六^"}, {"⓱", "十七^"},
    {"⓲", "十八^"}, {"⓳", "十九^"}, {"⓴", "二十^"}, {"㊀", "一^"},
    {"㊁", "二^"},  {"㊂", "三^"},  {"㊃", "四^"},  {"㊄", "五^"},
    {"㊅", "六^"},  {"㊆", "七^"},  {"㊇", "八^"},  {"㊈", "九^"},
    {"㊉", "十^"},  {"⑴", "一^"},   {"⑵", "二^"},   {"⑶", "三^"},
    {"⑷", "四^"},   {"⑸", "五^"},   {"⑹", "六^"},   {"⑺", "七^"},
    {"⑻", "八^"},   {"⑼", "九^"},   {"⑽", "十^"},   {"⑾", "十一^"},
    {"⑿", "十二^"}, {"⒀", "十三^"}, {"⒁", "十四^"}, {"⒂", "十五^"},
    {"⒃", "十六^"}, {"⒄", "十七^"}, {"⒅", "十八^"}, {"⒆", "十九^"},
    {"⒇", "二十^"}, {"⒈", "一^"},   {"⒉", "二^"},   {"⒊", "三^"},
    {"⒋", "四^"},   {"⒌", "五^"},   {"⒍", "六^"},   {"⒎", "七^"},
    {"⒏", "八^"},   {"⒐", "九^"},   {"⒑", "十^"},   {"⒒", "十一^"},
    {"⒓", "十二^"}, {"⒔", "十三^"}, {"⒕", "十四^"}, {"⒖", "十五^"},
    {"⒗", "十六^"}, {"⒘", "十七^"}, {"⒙", "十八^"}, {"⒚", "十九^"},
    {"⒛", "二十^"}, {"Ⓐ", "A^"},    {"Ⓑ", "B^"},    {"Ⓒ", "C^"},
    {"Ⓓ", "D^"},    {"Ⓔ", "E^"},    {"Ⓕ", "F^"},    {"Ⓖ", "G^"},
    {"Ⓗ", "H^"},    {"Ⓘ", "I^"},    {"Ⓙ", "J^"},    {"Ⓚ", "K^"},
    {"Ⓛ", "L^"},    {"Ⓜ", "M^"},    {"Ⓝ", "N^"},    {"Ⓞ", "O^"},
    {"Ⓟ", "P^"},    {"Ⓠ", "Q^"},    {"Ⓡ", "R^"},    {"Ⓢ", "S^"},
    {"Ⓣ", "T^"},    {"Ⓤ", "U^"},    {"Ⓥ", "V^"},    {"Ⓦ", "W^"},
    {"Ⓧ", "X^"},    {"Ⓨ", "Y^"},    {"Ⓩ", "Z^"},    {"ⓐ", "A^"},
    {"ⓑ", "B^"},    {"ⓒ", "C^"},    {"ⓓ", "D^"},    {"ⓔ", "E^"},
    {"ⓕ", "F^"},    {"ⓖ", "G^"},    {"ⓗ", "H^"},    {"ⓘ", "I^"},
    {"ⓙ", "J^"},    {"ⓚ", "K^"},    {"ⓛ", "L^"},    {"ⓜ", "M^"},
    {"ⓝ", "N^"},    {"ⓞ", "O^"},    {"ⓟ", "P^"},    {"ⓠ", "Q^"},
    {"ⓡ", "R^"},    {"ⓢ", "S^"},    {"ⓣ", "T^"},    {"ⓤ", "U^"},
    {"ⓥ", "V^"},    {"ⓦ", "W^"},    {"ⓧ", "X^"},    {"ⓨ", "Y^"},
    {"ⓩ", "Z^"},    {"⒜", "A^"},    {"⒝", "B^"},    {"⒞", "C^"},
    {"⒟", "D^"},    {"⒠", "E^"},    {"⒡", "F^"},    {"⒢", "G^"},
    {"⒣", "H^"},    {"⒤", "I^"},    {"⒥", "J^"},    {"⒦", "K^"},
    {"⒧", "L^"},    {"⒨", "M^"},    {"⒩", "N^"},    {"⒪", "O^"},
    {"⒫", "P^"},    {"⒬", "Q^"},    {"⒭", "R^"},    {"⒮", "S^"},
    {"⒯", "T^"},    {"⒰", "U^"},    {"⒱", "V^"},    {"⒲", "W^"},
    {"⒳", "X^"},    {"⒴", "Y^"},    {"⒵", "Z^"}};

static const Symbol2Pron kSpecialEnglish2Pron[] = {
    {"tfboys", "TF boys"}, {"soho", "搜吼"}, {"mall", "茂"}, {"ipod", "哎破锝"},
};

static const char* kFreqPron = "兆赫";

static const Symbol2Pron kCurrency2Pron[] = {
    {"＄", "美元"},  {"$", "美元"},  {"USD", "美元"}, {"HKD", "港币"},
    {"￥", "元"},    {"¥", "元"},    {"CNY", "元"},   {"RMB", "元"},
    {"€", "欧元"},   {"￡", "英镑"}, {"£", "英镑"},   {"₩", "韩元"},
    {"JPY", "日元"}, {"No.", "号"},  {"NO.", "号"},
};

static const Symbol2Pron kMeasure2Pron[] = {
    {"km", "公里"},    {"dm", "分米"}, {"cm", "厘米"}, {"mm", "毫米"},
    {"nm", "纳米"},    {"m", "米"},    {"gb", "GB"},   {"kbps", "KBPS"},
    {"mbps", "mbps"},  {"G", "G"},     {"mb", "兆"},   {"M", "M"},
    {"kb", "KB"},      {"K", "K"},     {"b", "B"},     {"B", "B"},
    {"kg", "千克"},    {"g", "克"},    {"h", "小时"},  {"H", "小时"},
    {"s", "秒"},       {"S", "S"},     {"w", "瓦"},    {"W", "瓦"},
    {"mah", "毫安时"}, {"ml", "毫升"}, {"T", "T"},     {"L", "升"},
};

static const Symbol2Pron kSymbolNormalize[] = {
    {"∶", ":"}, {"﹪", "%"}, {"：", ":"}, {"︰", ":"},
};

static const char* kYearPron = "年";
static const char* kMonthPron = "月";
static const char* kDayPron = "日";

static const Symbol2Pron kTime2Pron[] = {
    {"am", "上午"}, {"a.m", "上午"}, {"pm", "下午"}, {"p.m", "下午"},
};

static const char* kScorePron = "比";

static const Symbol2Pron kPercent2Pron[] = {
    {"%", "百分之"}, {"‰", "千分之"},
};
static const char* kFractionPron = "分之";
static const char* kPerPron = "每";

static const Symbol2Pron kStock2Pron[] = {
    {"sh", "上证"}, {"sz", "深证"},
};

static const Pattern2Sub kNamePattern[] = {
    {"^单", "善"}, {"^解", "谢"}, {"^朴", "瓢"},       {"^盖", "葛"},
    {"^洗", "显"}, {"^仇", "球"}, {"^查", "渣"},       {"^翟", "宅"},
    {"^曾", "增"}, {"^薄", "伯"}, {"^(.)乐", "\\1越"}, {"^\\s", ","},
    {" ", ""},     {"了", "钌"}};

static const Pattern2Sub kBookPattern[] = {
    {"^([^<]*?)-(\\d+)", "\\1之\\2"},
};

static const char* kBarPron = "杠";
static const char* kMultiPron = "乘";

static const Symbol2Pron kMath2Pron[] = {
    {"+", "加"},   {"-", "减"},   {"*", "乘"}, {"/", "除"}, {">", "大于"},
    {"<", "小于"}, {"=", "等于"}, {"(", ""},   {")", ""},   {"[", ""},
    {"]", ""},     {"{", ""},     {"}", ""}};
static const char* kMinusPron = "减";

static const Symbol2Pron kLessGreaterSymbol2Pron[] = {
    {">", "大于"}, {"<", "小于"},
};

static const Symbol2Pron kSymbol2Pron[] = {
    {"#", " "},       {"¥", "金额"},    {"%", "百分之"}, {"&", "和"},
    {"+", "加"},      {"-", "^"},       {"*", "^"},      {"$", "美元"},
    {"_", "^"},       {"≈", "约等于"},  {">", " "},      {"<", " "},
    {"=", "等于"},    {"㎡", "平方米"}, {"/", "^"},      {"~", " "},
    {"°C", "摄氏度"}, {"℃", "摄氏度"},  {"℉", "华氏度"}, {"°F", "华氏度"},
    {"ø", ""},        {"•", "^"},       {"∽", "到"},     {"・", "^"}};

static const Symbol2Pron kGreek2Pron[] = {
    {"α", "阿尔法"},   {"β", "贝塔"},   {"γ", "伽马"},     {"Γ", "伽马"},
    {"Δ", "得尔塔"},   {"δ", "得尔塔"}, {"ε", "埃普西龙"}, {"ζ", "泽塔"},
    {"η", "伊塔"},     {"θ", "西塔"},   {"λ", "兰姆达"},   {"μ", "谬"},
    {"ξ", "可赛"},     {"π", "派"},     {"∏", "派"},       {"ρ", "柔"},
    {"∑", "西格玛"},   {"σ", "西格玛"}, {"τ", "套"},       {"φ", "弗爱"},
    {"Ψ", "弗爱"},     {"Ω", "欧米伽"}, {"ω", "欧米伽"},   {"ψ", "普西"},
    {"υ", "宇普西龙"}, {"ν", "纽"},     {"χ", "西"}};

static const Symbol2Pron kManTone2Pron[] = {
    {"ā", "a"}, {"á", "a"}, {"ǎ", "a"}, {"à", "a"}, {"ō", "o"}, {"ó", "o"},
    {"ǒ", "o"}, {"ò", "o"}, {"ē", "e"}, {"é", "e"}, {"ě", "e"}, {"è", "e"},
    {"ī", "i"}, {"í", "i"}, {"ǐ", "i"}, {"ì", "i"}, {"ū", "u"}, {"ú", "u"},
    {"ǔ", "u"}, {"ù", "u"}, {"ǖ", "u"}, {"ǘ", "u"}, {"ǚ", "u"}, {"ǜ", "u"},
    {"ä", "a"}, {"ë", "e"}, {"ö", "o"}, {"ü", "u"}, {"Ü", "U"}, {"å", "a"},
    {"ç", "c"}, {"Å", "A"}, {"Á", "A"}, {"À", "A"}, {"Ă", "A"}, {"Ắ", "A"},
    {"ă", "a"}, {"ắ", "a"}, {"Ằ", "A"}, {"ằ", "a"}, {"Ẵ", "A"}, {"ẵ", "a"},
    {"Ẳ", "A"}, {"ẳ", "a"}, {"Â", "A"}, {"â", "a"}, {"Ấ", "A"}, {"ấ", "a"},
    {"Ầ", "A"}, {"ầ", "a"}, {"Ẫ", "A"}, {"ẫ", "a"}, {"Ẩ", "A"}, {"ẩ", "a"},
    {"Ầ", "A"}, {"ầ", "a"}, {"Ẫ", "A"}, {"ẫ", "a"}, {"Ẩ", "A"}, {"ẩ", "a"},
    {"Ǎ", "A"}, {"Ǻ", "A"}, {"ǻ", "a"}, {"Ä", "A"}, {"Ǟ", "A"}, {"ǟ", "a"},
    {"Ã", "A"}, {"ã", "a"}, {"Ȧ", "A"}, {"ȧ", "a"}, {"Ǡ", "A"}, {"ǡ", "a"},
    {"Ą", "A"}, {"ą", "a"}, {"Ā", "A"}, {"Ả", "A"}, {"ả", "a"}, {"Ȁ", "A"},
    {"ȁ", "a"}, {"Ȃ", "A"}, {"ȃ", "a"}, {"Ạ", "A"}, {"ạ", "a"}, {"Ặ", "A"},
    {"ặ", "a"}, {"Ậ", "A"}, {"ậ", "a"}, {"Ḁ", "A"}, {"ḁ", "a"}, {"Ⱥ", "A"},
    {"ⱥ̱", "a"}, {"ø", "o"}, {"ô", "o"}};

static const Symbol2Pron kMonthDay2Pron[] = {
    {"11.11", "双十一"}, {"12.12", "双十二"}, {"5.1", "五一"}, {"7.1", "七一"},
    {"8.1", "八一"},     {"9.9", "九九"},     {"3.8", "三八"}, {"10.1", "十一"},
};

bool PlaceSearch(const string& place_str, const SearchDirection& direction,
                 const map<string, std::unique_ptr<trie::MarisaTrie>>& trie) {
  auto it = trie.find(kPlaceTrie);
  if (it == trie.end()) return false;
  vector<util::Rune> unicode;
  util::Utf8ToUnicode(place_str, &unicode);
  vector<trie::DagNode> dag;
  for (size_t i = 2; i <= unicode.size(); ++i) {
    if (direction == SearchDirection::kForward) {
      if (it->second->FindPrefix(unicode.begin(), unicode.begin() + i, &dag)) {
        return true;
      }
    } else {
      if (it->second->FindPrefix(unicode.end() - i, unicode.end(), &dag)) {
        return true;
      }
    }
  }
  return false;
}

bool IsAllDigit(const string& input) {
  static re2::RE2 all_digit_pattern_obj(kAllDigitPattern);
  return re2::RE2::FullMatch(input, all_digit_pattern_obj);
}

// Common methods
// read a number string contain 0~9 support a-z
// rule: digits as one by one, if empty input, return empty
// a-z as A-Z
// + as 加, * as 星
string ReadAsDigit(const string& input) { return ReadAsDigit(input, false); }
string ReadAsDigitYao(const string& input) { return ReadAsDigit(input, true); }
string ReadAsDigitYi(const string& input) { return ReadAsDigit(input, false); }
string ReadAsDigit(const string& input, bool is_yao) {
  string pron;
  if (input.empty()) return kNonePron;
  vector<string> upper_input;
  util::SplitUtf8String(tts::ToUpper(input), &upper_input);
  for (size_t i = 0; i < upper_input.size(); ++i) {
    if (upper_input[i] == "+") {  // +
      pron += kPlusPron;
      continue;
    }
    if (upper_input[i] == "*") {  // *
      pron += kXingPron;
      continue;
    }
    if (upper_input[i] == ".") {  // .
      pron += kPointPron;
      continue;
    }
    // a-z
    if (tts::AllUpper(upper_input[i])) {
      pron += upper_input[i];
      pron += " ";
      continue;
    }
    if (tts::IsChineseWord(upper_input[i])) {
      pron += upper_input[i];
      continue;
    }
    if (tts::AllDigit(upper_input[i])) {
      int value = upper_input[i][0] - '0';
      if (is_yao) {
        pron += kDigitsYaoPron[value];
      } else {
        pron += kDigitsPron[value];
      }
    }
  }
  return pron;
}

// tw email
string ReadAsTwEmail(const string& input) {
  string pron;
  if (input.empty()) return kNonePron;
  vector<string> upper_input;
  util::SplitUtf8String(tts::ToUpper(input), &upper_input);
  for (size_t i = 0; i < upper_input.size(); ++i) {
    if (upper_input[i] == "+") {  // +
      pron += kPlusPron;
      continue;
    }
    if (upper_input[i] == "*") {  // *
      pron += kXingPron;
      continue;
    }
    if (upper_input[i] == ".") {  // .
      pron += kPointPron;
      continue;
    }
    if (upper_input[i] == "@") {
      pron += kAtPron;
      continue;
    }
    if (upper_input[i] == "_") {
      pron += kDixianPron;
      continue;
    }
    // a-z
    if (tts::AllUpper(upper_input[i])) {
      pron += upper_input[i];
      pron += " ";
      continue;
    }
    if (tts::IsChineseWord(upper_input[i])) {
      pron += upper_input[i];
      continue;
    }
    if (tts::AllDigit(upper_input[i])) {
      int value = upper_input[i][0] - '0';
      pron += kDigitsPron[value];
    }
  }
  return pron;
}

// read a number string contain 0~9
// rule: numerical pronounciation
// TODO(zhengzhang) add negative pron -
string ReadAsValue(const string& input) {
  return ReadAsValue(input, false, true);
}
string ReadAsValueLiang(const string& input) {
  return ReadAsValue(input, true, true);
}
string ReadAsValueEr(const string& input) {
  return ReadAsValue(input, false, true);
}

string ReadAsDecimalValueLiang(const string& input) {
  if (input.empty()) return input;
  static re2::RE2 decimal_pattern(kDecimalPattern);
  if (!re2::RE2::FullMatch(input, decimal_pattern)) return input;
  vector<string> numbers;
  SplitString(input, '.', &numbers);
  string pron = ReadAsValue(numbers[0], true, true);
  for (size_t i = 1; i < numbers.size(); ++i) {
    pron += kPointPron + ReadAsDigit(numbers[i], false);
  }
  return pron;
}

string ReadAsDecimalValueLiangSigned(const string& input) {
  if (input.empty()) return input;
  static re2::RE2 decimal_pattern(kDecimalPattern);
  if (!re2::RE2::FullMatch(input, decimal_pattern)) return input;
  vector<string> numbers;
  SplitString(input, '.', &numbers);
  string pron = ReadAsValue(numbers[0], true, false);
  for (size_t i = 1; i < numbers.size(); ++i) {
    pron += kPointPron + ReadAsDigit(numbers[i], false);
  }
  if (pron == kIllegalSignedLiangPron) return input;
  return pron;
}

string ReadAsDecimalValueErSigned(const string& input) {
  if (input.empty()) return input;
  static re2::RE2 decimal_pattern(kDecimalPattern);
  if (!re2::RE2::FullMatch(input, decimal_pattern)) return input;
  vector<string> numbers;
  SplitString(input, '.', &numbers);
  string pron = ReadAsValue(numbers[0], false, false);
  for (size_t i = 1; i < numbers.size(); ++i) {
    pron += kPointPron + ReadAsDigit(numbers[i], false);
  }
  return pron;
}

string ReadAsDecimalValueEr(const string& input) {
  if (input.empty()) return input;
  static re2::RE2 decimal_pattern(kDecimalPattern);
  if (!re2::RE2::FullMatch(input, decimal_pattern)) return input;
  vector<string> numbers;
  SplitString(input, '.', &numbers);
  string pron = ReadAsValue(numbers[0], false, true);
  for (size_t i = 1; i < numbers.size(); ++i) {
    pron += kPointPron + ReadAsDigit(numbers[i], false);
  }
  return pron;
}
string ReadAsValue(const string& input, bool is_liang, bool is_unsigned) {
  string pron;
  // trim front 0s
  string upper_input = tts::ToUpper(input);
  size_t nonzero_offset = upper_input.find_first_not_of("0");
  if (nonzero_offset == string::npos) return kZeroPron;
  string trim_zero = upper_input.substr(nonzero_offset);
  if (trim_zero.empty()) return kZeroPron;

  size_t length = trim_zero.size();
  if (length > kNumberMaxLength) {
    return ReadAsDigit(trim_zero, false);
  }

  // Variable 'group_is_zero' handles whether 万,亿,兆 is needed,
  // that is whether group contains all 0s
  bool group_is_zero = true;
  // Variable 'need_zero' handles whether 零 is needed,
  // to handle special zeros, 500：五百 not 五百零..,
  // 3006：三千零六 not 三千零零6,
  //   1020：一千零二十 not 一千零二十零,
  bool need_zero = false;
  // Begin core loop
  size_t j = 0;
  for (j = 0; j < length; ++j) {
    if (trim_zero[j] == '-' && !is_unsigned) {
      pron.append(kNegativePron);
      continue;
    }
    if ((trim_zero[j] >= 'a' && trim_zero[j] <= 'z') ||
        (trim_zero[j] >= 'A' && trim_zero[j] <= 'Z')) {
      pron += trim_zero[j];
      pron += " ";
      continue;
    }
    if (trim_zero[j] >= '0' && trim_zero[j] <= '9') {
      break;
    }
  }
  size_t num_length = length - j;
  for (size_t i = 0; i < num_length && i + j < length; ++i) {
    if (trim_zero[i + j] < '0' || trim_zero[i + j] > '9') {
      continue;
    }
    int digit = trim_zero[i + j] - '0';
    int position = num_length - i - 1;
    int unit = position % kNumberOfUnits;
    int group = position / kNumberOfUnits;

    if (digit != 0) {
      if (need_zero) pron.append(kZeroPron);
      // 以下为数字发音的条件，除去１有可能不读音
      // １不发音的条件为:1在十位且百位和千位为０ e.g. 10012:一万零一十二
      if (digit != 1 || unit != 1 || !group_is_zero || need_zero) {
        // 千位读两，个位在没有更高位时读两
        // e.g. 2012:两千零一十二 200022000元:两亿两万两千元
        if (is_liang && (unit == 3 || (unit == 0 && group_is_zero &&
                                       (group != 0 || num_length == 1)))) {
          pron.append(kDigitsLiangPron[digit]);
        } else {
          pron.append(kDigitsPron[digit]);
        }
      }
      pron.append(kUnitsPron[unit]);
    }
    group_is_zero = group_is_zero && digit == 0;
    if (unit == 0 && !group_is_zero) {
      // Handle 100000000：一亿 not 一亿万
      pron.append(kGroupsPron[group]);
    }

    need_zero = (digit == 0 && (unit != 0 || group_is_zero));
    if (unit == 0) {
      group_is_zero = true;
    }
  }  // End core loop
  return pron;
}

string ReadAsBuilding(const string& input) {
  vector<string> segs;
  vector<bool> is_digit;
  SplitStringByNumber(input, &segs, &is_digit);

  string result;
  for (size_t i = 0; i < segs.size(); ++i) {
    if (!is_digit[i]) {
      if (segs[i] == "-") {
        result += kBarPron;
      } else {
        result += segs[i];
      }
      continue;
    }
    result += ReadAsSerial(segs[i]);
  }
  return result;
}

void SplitStringByNumber(const string& input, vector<string>* output,
                         vector<bool>* is_digit) {
  vector<string> utf8;
  util::SplitUtf8String(input, &utf8);
  string cur_str;
  bool cur_is_digit = false;
  for (const string& character : utf8) {
    if (character.empty()) continue;
    if (character[0] >= '0' && character[0] <= '9') {
      if (!cur_is_digit && !cur_str.empty()) {
        output->emplace_back(cur_str);
        is_digit->push_back(false);
        cur_str.clear();
      }
      cur_is_digit = true;
      cur_str += character;
    } else {
      // non number character, first process cur_str, then cur character
      if (cur_is_digit && !cur_str.empty()) {
        output->emplace_back(cur_str);
        is_digit->push_back(true);
        cur_str.clear();
      }
      cur_is_digit = false;
      cur_str += character;
    }
  }
  if (!cur_str.empty()) {
    output->emplace_back(cur_str);
    is_digit->push_back(cur_is_digit);
  }
}

// read number as digit and remain mandarin character
// e.g. 51劳动节 -> 五一劳动节
string ReadAsFestival(const string& input) {
  vector<string> segs;
  vector<bool> is_digit;
  SplitStringByNumber(input, &segs, &is_digit);

  string result;
  for (size_t i = 0; i < segs.size(); ++i) {
    if (!is_digit[i]) {
      result += segs[i];
      continue;
    }
    result += ReadAsDigit(segs[i]);
  }
  return result;
}

string TelephoneReading(const string& input, bool is_yao) {
  string result;
  string text = input;
  while (text.size() > kTelMinLen) {
    result = kSepMarkLP +
             ReadAsDigit(text.substr(text.size() - kTelGroupLen), is_yao) +
             result;
    text = text.substr(0, text.size() - kTelGroupLen);
  }
  result = ReadAsDigit(text, is_yao) + result;
  return result;
}

string ReadAsTelephone(const string& input) {
  vector<string> segs;
  vector<bool> is_digit;
  SplitStringByNumber(input, &segs, &is_digit);
  string result;
  for (size_t i = 0; i < segs.size(); ++i) {
    if (!is_digit[i]) {
      if (segs[i] == " " || segs[i] == "-") {
        result += kSepMarkLP;
      } else {
        result += segs[i];
      }
      continue;
    }
    result += TelephoneReading(segs[i], true);
  }
  return kSepMarkPhrase + result + kSepMarkPhrase;
}

string TwDigitStringReading(const string& input, bool is_yao) {
  string result;
  string text = input;
  if (text.size() == 9) {
    if (text[0] == '0') {
      result = ReadAsDigit(text.substr(0, 2), is_yao) + kSepMarkLP +
               ReadAsDigit(text.substr(2, 3), is_yao) + kSepMarkLP +
               ReadAsDigit(text.substr(5, 4), is_yao) + kSepMarkLP;
    } else {
      result = ReadAsDigit(text.substr(0, 3), is_yao) + kSepMarkLP +
               ReadAsDigit(text.substr(3, 3), is_yao) + kSepMarkLP +
               ReadAsDigit(text.substr(6, 3), is_yao) + kSepMarkLP;
    }
  } else if (text.size() == 10) {
    if (text.substr(0, 2) == "09") {
      result = ReadAsDigit(text.substr(0, 4), is_yao) + kSepMarkLP +
               ReadAsDigit(text.substr(4, 3), is_yao) + kSepMarkLP +
               ReadAsDigit(text.substr(7, 3), is_yao) + kSepMarkLP;
    } else {
      result = ReadAsDigit(text.substr(0, 2), is_yao) + kSepMarkLP +
               ReadAsDigit(text.substr(2, 4), is_yao) + kSepMarkLP +
               ReadAsDigit(text.substr(6, 4), is_yao) + kSepMarkLP;
    }
  } else {
    int i = 0;
    while (text.size() >= kTelGroupLen) {
      result = result + kSepMarkLP +
               ReadAsDigit(text.substr(i * kTelGroupLen, kTelGroupLen), is_yao);
      ++i;
      text = text.substr(i * kTelGroupLen);
    }
    result = result + kSepMarkLP + ReadAsDigit(text, is_yao);
  }
  return result;
}

string ReadAsTwDigitString(const string& input) {
  vector<string> segs;
  vector<bool> is_digit;
  SplitStringByNumber(input, &segs, &is_digit);
  string result;
  for (size_t i = 0; i < segs.size(); ++i) {
    if (!is_digit[i]) {
      if (segs[i] == " " || segs[i] == "-") {
        result += kSepMarkLP;
      } else {
        result += segs[i];
      }
      continue;
    }
    result += TwDigitStringReading(segs[i], true);
  }
  return kSepMarkPhrase + result + kSepMarkPhrase;
}

string YiReadAsTelephone(const string& input) {
  vector<string> segs;
  vector<bool> is_digit;
  SplitStringByNumber(input, &segs, &is_digit);
  string result;
  for (size_t i = 0; i < segs.size(); ++i) {
    if (!is_digit[i]) {
      if (segs[i] == " " || segs[i] == "-") {
        result += kSepMarkLP;
      } else {
        result += segs[i];
      }
      continue;
    }
    result += TelephoneReading(segs[i], false);
  }
  return kSepMarkPhrase + result + kSepMarkPhrase;
}

string ReadAsSerial(const string& input) {
  if (input.empty()) return string();
  if (input.size() > 2 || input[0] == '0') {
    return ReadAsDigit(input, true);
  } else {
    return ReadAsValue(input, false, true);
  }
}

// input foramt \d\d or \d or ""
// rule: read as value
// 0x or x read as 零x
// 00 read as 零
// '' return empty string
string ReadAsNumberTime(const string& input) {
  if (input.empty()) return kNonePron;
  string time;
  // insert 0 if only 1 number: 8 -> 08
  if (input.size() == 1)
    time = "0" + input;
  else
    time = input;

  if (time[0] == '0') {
    if (time[1] == '0') {
      return kZeroPron;
    } else {
      return ReadAsDigit(time, false);
    }
  } else {
    return ReadAsValue(time, false, true);
  }
}

// : joined number
string ReadAsTime(const string& input) {
  static re2::RE2 hour_minute_second_pattern(kHourMinuteSecondPattern);
  static re2::RE2 hour_minute_pattern(kHourMinutePattern);

  string hour, minute, second;
  string seperate1, seperate2;
  string output;
  if (re2::RE2::FullMatch(input, hour_minute_second_pattern, &hour, &seperate1,
                          &minute, &seperate2, &second)) {
    output += ReadAsDecimalValueEr(hour) + kHourPron;
    output += ReadAsDecimalValueEr(minute) + kMinPron;
    output += ReadAsDecimalValueEr(second) + kSecPron;
  } else if (re2::RE2::FullMatch(input, hour_minute_pattern, &hour, &seperate1,
                                 &minute)) {
    output += ReadAsDecimalValueEr(hour) + kHourPron;
    string min_pron = ReadAsDecimalValueEr(minute);
    if (min_pron == kZeroPron)
      output += kEmptyPron;
    else
      output += min_pron + kMinPron;
  } else {
    return input;
  }
  return output;
}

// / joined number
string ReadAsFraction(const string& input) {
  static re2::RE2 simple_fraction_pattern(kSimpleFractionPattern);
  string number1, number2;
  string seperate;
  string output;
  if (re2::RE2::FullMatch(input, simple_fraction_pattern, &number1, &seperate,
                          &number2)) {
    if (number2.size() == 1) {
      output += ReadAsValue(number2, false, true);
    } else {
      output += ReadAsValue(number2, true, true);
    }
    output += kFractionPron;
    if (number1.size() == 1) {
      output += ReadAsValue(number1, false, true);
    } else {
      output += ReadAsValue(number1, true, true);
    }
  } else {
    return input;
  }
  return output;
}

string ReadAsAlphabet(const string& input) {
  static re2::RE2 english_pattern(kEnglishPattern);
  if (!re2::RE2::FullMatch(input, english_pattern)) return input;
  string upper = tts::ToUpper(input);
  string pron;
  for (size_t i = 0; i < upper.size(); ++i) {
    pron += string() + upper[i] + kSepMarkWord;
  }
  pron = kSepMarkWord + pron;
  return pron;
}

string ReadAsWord(const string& input) {
  static re2::RE2 english_pattern(kEnglishPattern);
  if (!re2::RE2::FullMatch(input, english_pattern)) return input;
  string pron = kSepMarkWord + tts::ToLower(input) + kSepMarkWord;
  return pron;
}

string ReadAsName(const string& input) {
  return ParsePronFromPattern(input, kNamePattern, arraysize(kNamePattern));
}

string ReadAsBook(const string& input) {
  return ParsePronFromPattern(input, kBookPattern, arraysize(kBookPattern));
}

// year.month.day, year.month and month.day pattern
string ReadAsDate(const string& input) {
  static re2::RE2 year_month_day_pattern(kSimpleYearMonthDayPattern);
  static re2::RE2 year_month_pattern(kSimpleYearMonthPattern);
  static re2::RE2 month_day_pattern(kSimpleMonthDayPattern);
  string year, month, day;
  string seperate1, seperate2;
  string output;

  if (re2::RE2::FullMatch(input, year_month_day_pattern, &year, &seperate1,
                          &month, &seperate2, &day)) {
    output += ReadAsDigit(year, false) + kYearPron;
    output += ReadAsValue(month, false, true) + kMonthPron;
    output += ReadAsValue(day, false, true) + kDayPron;
  } else if (re2::RE2::FullMatch(input, year_month_pattern, &year, &seperate1,
                                 &month)) {
    output += ReadAsDigit(year, false) + kYearPron;
    output += ReadAsValue(month, false, true) + kMonthPron;
  } else if (re2::RE2::FullMatch(input, month_day_pattern, &month, &seperate1,
                                 &day)) {
    output += ReadAsValue(month, false, true) + kMonthPron;
    output += ReadAsValue(day, false, true) + kDayPron;
  } else {
    return input;
  }
  return output;
}

// : - / joined number
string ReadAsRatio(const string& input) {
  static re2::RE2 number_bar_pattern(kNumberBarPattern);
  static re2::RE2 number_comma_pattern(kNumberCommaPattern);
  static re2::RE2 number_slash_pattern(kNumberSlashPattern);
  vector<string> numbers;
  if (re2::RE2::FullMatch(input, number_bar_pattern)) {
    SplitString(input, '-', &numbers);
  } else if (re2::RE2::FullMatch(input, number_comma_pattern)) {
    SplitString(input, ':', &numbers);
  } else if (re2::RE2::FullMatch(input, number_slash_pattern)) {
    SplitString(input, '/', &numbers);
  } else {
    return input;
  }
  string pron = ReadAsDecimalValueEr(numbers[0]);
  for (size_t i = 1; i < numbers.size(); ++i) {
    pron += kScorePron + ReadAsDecimalValueEr(numbers[i]);
  }
  return pron;
}

// - joined number: 23-34 -> 23到34
string ReadAsScale(const string& input) {
  static re2::RE2 number_bar_pattern(kNumberBarPattern);
  vector<string> numbers;
  if (re2::RE2::FullMatch(input, number_bar_pattern)) {
    SplitString(input, '-', &numbers);
  } else {
    return input;
  }
  string pron = ReadAsDecimalValueEr(numbers[0]);
  for (size_t i = 1; i < numbers.size(); ++i) {
    pron += kToPron + ReadAsDecimalValueEr(numbers[i]);
  }
  return pron;
}

// + - * = / joined number: 23-34
string ReadAsMath(const string& input) {
  static re2::RE2 math_expression_pattern(kMathExpressionPattern);
  if (!re2::RE2::FullMatch(input, math_expression_pattern)) return input;

  string number;
  string symbol;
  string output;
  static string symbol_list = "+-*/=";
  for (size_t i = 0; i < input.size(); ++i) {
    if (symbol_list.find(input[i]) != string::npos) {
      symbol = input.substr(i, 1);
      if (!number.empty()) {
        output += ReadAsDecimalValueEr(number);
        number.clear();
      }
      output += GetPronFromSymbol(symbol, kMath2Pron, arraysize(kMath2Pron));
    } else {
      number += input.substr(i, 1);
    }
  }
  if (!number.empty()) output += ReadAsDecimalValueEr(number);
  return output;
}

string ReadAsSymbol(const string& symbol) { return "^"; }

string ReadAsWebsite(const string& input, bool is_man) {
  string pron;
  vector<string> web_segs;
  vector<string> web_prons;
  SplitString(input, '.', &web_segs);
  for (const auto& web_seg : web_segs) {
    vector<string> mail_segs;
    vector<string> mail_prons;
    SplitString(web_seg, '@', &mail_segs);
    for (const auto& mail_seg : mail_segs) {
      if (IsAllDigit(mail_seg)) {
        mail_prons.push_back(ReadAsDigit(mail_seg, true));
      } else {
        mail_prons.push_back(mail_seg);
      }
    }
    web_prons.push_back(mobvoi::JoinVectorToString(mail_prons, kAtPron));
  }
  if (is_man)
    pron = mobvoi::JoinVectorToString(web_prons, kDianPron);
  else
    pron = mobvoi::JoinVectorToString(web_prons, kDotPron);
  return pron;
}

// return www`点`baidu`点`com
string ReadAsManWebsite(const string& input) {
  return ReadAsWebsite(input, true);
}

// return www`dot`baidu`dot`com
string ReadAsWebsite(const string& input) {
  return ReadAsWebsite(input, false);
}

// Gen Pron for a english string
// skip none english words
static string GetPronForEnglish(const string& english_str) {
  string pron;
  string english = tts::ToLower(english_str);
  for (size_t i = 0; i < english.size(); ++i) {
    pron.append(GetPronFromSymbol(english.substr(i, 1), kEnglish2Pron,
                                  arraysize(kEnglish2Pron)));
  }
  return pron;
}

// Gen pron for a number string
// read sign
// normalize to contain only 0~9 '%' '‰' and '.',
// begin or end is '.' pron as 点
string GetPronForNumString(const string& number, bool is_liang) {
  string pron;
  if (number.empty()) return pron;
  if (number[0] == '+') pron.append(kPositivePron);
  if (number[0] == '-') pron.append(kNegativePron);
  string percent = number.substr(number.size() - 1);
  if (percent == "%" || percent == "‰") {
    pron.append(
        GetPronFromSymbol(percent, kPercent2Pron, arraysize(kPercent2Pron)));
  }
  string number_norm = NormalizeNumString(number);
  vector<string> segs;
  SplitString(number_norm, '.', &segs);
  if (segs.size() == 0) return pron;
  if (number_norm[0] == '.') pron.append(kPointPron);

  // more than 1 '.', read seperate as value
  if (segs.size() > 2) {
    for (size_t i = 0; i < segs.size() - 1; ++i) {
      pron.append(ReadAsDigit(segs[i], false));
      pron.append(kPointPron);
    }
    pron.append(ReadAsDigit(segs.back(), false));
  } else {
    // interger part
    pron.append(ReadAsValue(segs[0], is_liang, true));
    if (segs.size() == 2) {
      if (pron == "两") pron = "二";  // 2.3 -> 二点三
      pron.append(kPointPron);
      // fraction part
      pron.append(ReadAsDigit(segs[1], false));
    }
  }
  if (number_norm.back() == '.') pron.append(kPointPron);
  return pron;
}

// Number pattern handlers
// PM 2.5: PM number boundary
void PMHandler(const re2::StringPiece* str_args, int args_num,
               const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
               string* output) {
  VLOG(2) << "Process Air quality pattern ...";
  string pron = GetPronForNumString(str_args[1].as_string(), false);
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}

// Comma Number type: boundary number boundary
void CommaNumberHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process comma number pattern ...";
  string pron = GetPronForNumString(str_args[1].as_string(), true);
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}

// Currency type: boundary symbol number boundary
void CurrencyHandler(const re2::StringPiece* str_args, int args_num,
                     const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                     string* output) {
  VLOG(2) << "Process currency ...";
  string pron = GetPronForNumString(str_args[2].as_string(), true);
  pron.append(GetPronFromSymbol(str_args[1].as_string(), kCurrency2Pron,
                                arraysize(kCurrency2Pron)));
  *output = str_args[0].as_string() + pron + str_args[3].as_string();
}

// Phone number: boundary preword tel (sep tel)pair postword boundary
void TelHandler(const re2::StringPiece* str_args, int args_num,
                const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                string* output) {
  VLOG(2) << "Process telephone number ...";
  string pron;
  for (int i = 2; i < args_num - 2; i += 2) {
    string tmp = str_args[i].as_string();
    re2::RE2::GlobalReplace(&tmp, "\\*", "");
    string pron_tmp = ReadAsDigit(tmp, true);
    if (!pron_tmp.empty()) {
      string sep = pron.empty() ? "" : kSepMarkLP;
      pron.append(sep + pron_tmp);
    }
  }
  pron = kSepMarkPhrase + pron + kSepMarkPhrase;
  *output = str_args[0].as_string() + str_args[1].as_string() + pron +
            str_args[args_num - 2].as_string() +
            str_args[args_num - 1].as_string();
}

// Phone number: boundary preword tel (sep tel)pair postword boundary
// 一 is not pronounced as 幺 in cantonese and taiwanese
void YiTelHandler(const re2::StringPiece* str_args, int args_num,
                  const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                  string* output) {
  VLOG(2) << "Process telephone number ...";
  string pron;
  for (int i = 2; i < args_num - 2; i += 2) {
    string pron_tmp = ReadAsDigit(str_args[i].as_string(), false);
    if (!pron_tmp.empty()) {
      string sep = pron.empty() ? "" : kSepMarkLP;
      pron.append(sep + pron_tmp);
    }
  }
  pron = kSepMarkPhrase + pron + kSepMarkPhrase;
  *output = str_args[0].as_string() + str_args[1].as_string() + pron +
            str_args[args_num - 2].as_string() +
            str_args[args_num - 1].as_string();
}

// Coordinate: boundary number ° number ′ number ″
void CoordinateHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process coordinate ...";
  string pron;
  if (!str_args[1].empty()) {
    pron.append(GetPronForNumString(str_args[1].as_string(), false));
    pron.append(GetPronFromSymbol(str_args[2].as_string(), kCoordinate2Pron,
                                  arraysize(kCoordinate2Pron)));
  }
  if (!str_args[3].empty()) {
    pron.append(GetPronForNumString(str_args[3].as_string(), false));
    pron.append(GetPronFromSymbol(str_args[4].as_string(), kCoordinate2Pron,
                                  arraysize(kCoordinate2Pron)));
  }
  if (!str_args[5].empty()) {
    pron.append(GetPronForNumString(str_args[5].as_string(), false));
    pron.append(GetPronFromSymbol(str_args[6].as_string(), kCoordinate2Pron,
                                  arraysize(kCoordinate2Pron)));
  }
  *output = str_args[0].as_string() + pron;
}

// Temperature: boundary sign number unit
void TemperatureHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process temperature ...";
  string pron;
  if (str_args[1].as_string() == "-" && StringToDouble(str_args[2].as_string()))
    pron.append(kNegativeTemperature);

  pron.append(GetPronForNumString(str_args[2].as_string(), false));
  string temperature_unit = GetPronFromSymbol(
      str_args[3].as_string(), kTemperature2Pron, arraysize(kTemperature2Pron));
  if (temperature_unit.empty()) {
    pron.append(str_args[3].as_string());
  } else {
    pron.append(temperature_unit);
  }
  *output = str_args[0].as_string() + pron;
}

// Temperature: boundary sign number to sign number unit
void TemperatureHandler2(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process temperature ...";
  string pron;
  if (str_args[1].as_string() == "-" && StringToDouble(str_args[2].as_string()))
    pron.append(kNegativeTemperature);

  pron.append(GetPronForNumString(str_args[2].as_string(), false));
  string temperature_unit = GetPronFromSymbol(
      str_args[6].as_string(), kTemperature2Pron, arraysize(kTemperature2Pron));
  if (temperature_unit.empty()) {
    temperature_unit = str_args[6].as_string();
  }
  if (str_args[3].as_string() == "~" || str_args[3].as_string() == "-")
    pron.append(kToPron);
  else
    pron.append(str_args[3].as_string());
  if (str_args[4].as_string() == "-" && StringToDouble(str_args[5].as_string()))
    pron.append(kNegativeTemperature);
  pron.append(GetPronForNumString(str_args[5].as_string(), false));
  pron.append(temperature_unit);
  *output = str_args[0].as_string() + pron;
}

// Score: boundary preword score postword boundary
void ScoreHandler(const re2::StringPiece* str_args, int args_num,
                  const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                  string* output) {
  VLOG(2) << "Process score pattern ...";
  vector<string> scores;
  mobvoi::SplitStringToVector(str_args[2].as_string(), "-:", true, &scores);
  string pron;
  pron.append(GetPronForNumString(scores[0], false));
  for (size_t i = 1; i < scores.size(); ++i) {
    pron.append(kScorePron);
    pron.append(GetPronForNumString(scores[i], false));
  }
  *output = str_args[0].as_string() + str_args[1].as_string() + pron +
            str_args[args_num - 2].as_string() +
            str_args[args_num - 1].as_string();
}

// Discount: boundary number point number 折
void DiscountHandler(const re2::StringPiece* str_args, int args_num,
                     const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                     string* output) {
  VLOG(2) << "Process discount ...";
  string pron = ReadAsDigit(str_args[1].as_string(), false);
  if (str_args[3].as_string() != "0")
    pron.append(ReadAsDigit(str_args[3].as_string(), false));
  *output = str_args[0].as_string() + pron + str_args[4].as_string();
}

// Percent: boundary sign number percent
void PercentHandler(const re2::StringPiece* str_args, int args_num,
                    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                    string* output) {
  VLOG(2) << "Process percent ...";
  string pron;
  if (str_args[1].as_string() == "+") pron.append(kNonePron);
  if (str_args[1].as_string() == "-") pron.append(kNegativePron);
  pron.append(GetPronFromSymbol(str_args[3].as_string(), kPercent2Pron,
                                arraysize(kPercent2Pron)));
  pron.append(GetPronForNumString(str_args[2].as_string(), false));
  *output = str_args[0].as_string() + pron;
}

// Date: boundary year sep month sep day sep boundary
void DateHandler(const re2::StringPiece* str_args, int args_num,
                 const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                 string* output) {
  VLOG(2) << "Process date pattern ...";
  string pron;
  const string& year = str_args[1].as_string();
  const string& month = str_args[3].as_string();
  const string& day = str_args[5].as_string();
  if (!year.empty()) {
    pron.append(ReadAsDigit(year, false));
    pron.append(kYearPron);
  }
  if (!month.empty()) {
    pron.append(GetPronForNumString(month, false));
    pron.append(kMonthPron);
  }
  if (!day.empty()) {
    pron.append(GetPronForNumString(day, false));
    if (str_args[6].empty()) {
      pron.append(kDayPron);
    } else {
      pron.append(str_args[6].as_string());
    }
  }
  *output = str_args[0].as_string() + pron + str_args[7].as_string();
}

// Year: 2013年 boundary year 年|届|款
void YearHandler(const re2::StringPiece* str_args, int args_num,
                 const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                 string* output) {
  VLOG(2) << "Process year ...";
  string pron = ReadAsDigit(str_args[1].as_string(), false);
  string year = str_args[2].as_string();
  re2::RE2::GlobalReplace(&year, "\\s", "");
  pron.append(year);
  *output = str_args[0].as_string() + pron;
}

// 6.18 狂欢节
// keyword placeholder month sep day placeholder keyword
void MonthDayHandler(const re2::StringPiece* str_args, int args_num,
                     const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                     string* output) {
  VLOG(2) << "Process year ...";
  string month = str_args[2].as_string();
  string day = str_args[4].as_string();
  string date = month + str_args[3].as_string() + day;
  string pron =
      GetPronFromSymbol(date, kMonthDay2Pron, arraysize(kMonthDay2Pron));
  if (pron.empty()) {
    if (month.size() == 1 && day.size() == 2) {
      pron = ReadAsDigit(month + day, true);
    } else {
      pron = ReadAsDate(date);
    }
  }
  *output = str_args[0].as_string() + str_args[1].as_string() + pron +
            str_args[5].as_string() + str_args[6].as_string();
}

// Year: 喜迎2018   key years
void KeyYearHandler(const re2::StringPiece* str_args, int args_num,
                    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                    string* output) {
  VLOG(2) << "Process year ...";
  string pron = ReadAsDigit(str_args[1].as_string(), false);
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}

// Ip: 10.2.3.56
// boundary ip boundary
void IpHandler(const re2::StringPiece* str_args, int args_num,
               const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
               string* output) {
  VLOG(2) << "Process Ip ...";
  string pron = ReadAsDigit(str_args[1].as_string(), true);
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}
void YiIpHandler(const re2::StringPiece* str_args, int args_num,
                 const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                 string* output) {
  VLOG(2) << "Process Ip ...";
  string pron = ReadAsDigit(str_args[1].as_string(), false);
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}

// Time: boundary hour sep min sep sec sep AM boundary
void TimeHandler(const re2::StringPiece* str_args, int args_num,
                 const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                 string* output) {
  VLOG(2) << "Process time pattern ...";
  string pron;
  if (!str_args[7].empty()) {
    pron.append(GetPronFromSymbol(tts::ToLower(str_args[7].as_string()),
                                  kTime2Pron, arraysize(kTime2Pron)));
  }
  // Handle hour
  pron.append(ReadAsValue(str_args[1].as_string(), true, true));
  pron.append(kHourPron);
  // Handle minute and second
  string minute_pron = ReadAsNumberTime(str_args[3].as_string());
  string second_pron = ReadAsNumberTime(str_args[5].as_string());
  if (minute_pron == kZeroPron &&
      (second_pron.empty() || second_pron == kZeroPron)) {
    pron.append(kEmptyPron);
  } else {
    pron.append(minute_pron);
    pron.append(kMinPron);
    if (second_pron != kZeroPron && !second_pron.empty()) {
      pron.append(second_pron);
      pron.append(kSecPron);
    }
  }
  *output = str_args[0].as_string() + pron + str_args[8].as_string();
}

// Fraction: boundary number / number boundary
void FractionHandler(const re2::StringPiece* str_args, int args_num,
                     const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                     string* output) {
  VLOG(2) << "Process fraction pattern ...";
  string pron;
  string number1 = str_args[1].as_string();
  string number2 = str_args[3].as_string();
  if (number2.size() == 1) {
    pron.append(ReadAsValue(number2, false, true));
  } else {
    pron.append(ReadAsValue(number2, true, true));
  }
  pron.append(kFractionPron);
  if (number1.size() == 1) {
    pron.append(ReadAsValue(number1, false, true));
  } else {
    pron.append(ReadAsValue(number1, true, true));
  }
  *output = str_args[0].as_string() + pron + str_args[4].as_string();
}

// Per: unit / unit
void PerHandler(const re2::StringPiece* str_args, int args_num,
                const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                string* output) {
  VLOG(2) << "Process per pattern ...";
  *output = str_args[0].as_string() + kPerPron + str_args[2].as_string();
}

// Math expression: boundary math boundary
// 1+2=3
void MathHandler(const re2::StringPiece* str_args, int args_num,
                 const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                 string* output) {
  VLOG(2) << "Process math expression pattern ...";
  string pron;
  string math_expression = str_args[1].as_string();
  string number_pattern = "0123456789.,%‰";
  string number;
  for (size_t i = 0; i < math_expression.size(); ++i) {
    if (number_pattern.find_first_of(math_expression[i]) != string::npos) {
      number.append(math_expression.substr(i, 1));
    } else {
      string symbol = math_expression.substr(i, 1);
      if (!number.empty()) {
        pron.append(GetPronForNumString(number, false));
        number.clear();
        if (symbol == "-") {
          pron.append(kMinusPron);
          continue;
        }
      } else {
        if (symbol == "-") {
          pron.append(kNegativePron);
          continue;
        }
      }
      string symbol_trans =
          GetPronFromSymbol(symbol, kMath2Pron, arraysize(kMath2Pron));
      if (symbol_trans.empty()) {
        pron.append(symbol);
      } else {
        pron.append(symbol_trans);
      }
    }
  }
  pron.append(GetPronForNumString(number, false));
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}

// Serial: boundary serial boundary
void SerialHandler(const re2::StringPiece* str_args, int args_num,
                   const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                   string* output) {
  VLOG(2) << "Process serial pattern ...";
  string pron = ReadAsDigit(str_args[1].as_string(), true);
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}
void YiSerialHandler(const re2::StringPiece* str_args, int args_num,
                     const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                     string* output) {
  VLOG(2) << "Process serial pattern ...";
  string pron = ReadAsDigit(str_args[1].as_string(), false);
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}

void BuildingHandler(const re2::StringPiece* str_args, int args_num,
                     const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                     string* output) {
  VLOG(2) << "Process navigation building pattern ...";
  string pron = ReadAsBuilding(str_args[1].as_string());
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}

// bar: 2-7室 207-3室 等于-3.2
// preword number - number postword
void BarHandler(const re2::StringPiece* str_args, int args_num,
                const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                string* output) {
  VLOG(2) << "Process bar pattern ...";
  string pron;
  static string kNumberKeyword =
      "度日号点整分秒元度一二三四五六七八九零十百千万亿兆0123456789";
  if (!str_args[0].empty() || !str_args[4].empty()) {
    // 杠
    pron.append(kBarPron);
    string number2 = str_args[3].as_string();
    if (IsAllDigit(number2)) {
      pron.append(ReadAsSerial(number2));
    } else {
      pron.append(number2);
    }
    *output = str_args[0].as_string() + str_args[1].as_string() + pron +
              str_args[4].as_string();
  } else {
    // 到
    string number2 = str_args[3].as_string();
    if (kNumberKeyword.find(str_args[1].as_string()) != string::npos) {
      pron.append(kToPron);
    } else if ((number2[0] > '0' && number2[0] <= '9') ||
               (number2[0] == '0' && number2[1] == '.')) {
      pron.append(kNegativePron);
    } else {
      pron.append(" ");
    }
    *output = str_args[0].as_string() + str_args[1].as_string() + pron +
              str_args[3].as_string() + str_args[4].as_string();
  }
}

// to pattern: preword - backword
// 130-120元
// handle 1222-1300 -> 1222到1300年 and 7月24日－25日 -> 7月24日到25日
// 8-10 八到十 11:00-12:00
// 北京 - 上海 北京-上海
void ToHandler(const re2::StringPiece* str_args, int args_num,
               const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
               string* output) {
  VLOG(2) << "Process to pattern ...";
  bool forward_is_place =
      PlaceSearch(str_args[0].as_string(), SearchDirection::kBackward, trie);
  bool backward_is_place =
      PlaceSearch(str_args[2].as_string(), SearchDirection::kForward, trie);
  string pron;
  if (forward_is_place && backward_is_place) {
    pron.append(kToPron);
  } else {
    pron.append(" ");
  }
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}

// Number with measure word 36元 25~36元
// boundary number sign number 多 unit
void MeasureTrieHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process measure trie ...";
  static string kNegativeExceptWord = "月日元";
  bool is_measure = false;
  string measure;
  auto it = trie.find(kMeasureTrie);
  for (int i = 5; i < args_num; ++i) {
    if (it == trie.end()) break;
    if (!str_args[i].empty()) {
      measure.append(str_args[i].as_string());
      vector<util::Rune> unicode;
      util::Utf8ToUnicode(measure, &unicode);
      if (it->second->Find(unicode.begin(), unicode.end()) != trie::kNotFound) {
        is_measure = true;
        break;
      }
    }
  }
  string pron;
  if (is_measure) {
    if (!str_args[1].empty()) {
      pron += GetPronForNumString(str_args[1].as_string(), true);
      pron += kToPron;
    } else if (str_args[0].empty() ||
               kNegativeExceptWord.find(str_args[0].as_string()) ==
                   string::npos) {
      if (str_args[2].as_string() == "+") pron.append(kPositivePron);
      if (str_args[2].as_string() == "-") pron.append(kNegativePron);
    } else {
      pron.append(str_args[2].as_string());
    }
    string tmp = GetPronForNumString(str_args[3].as_string(), true);
    if ((pron == kNegativePron || pron == kPositivePron) && tmp == kLiangPron) {
      tmp = GetPronForNumString(str_args[3].as_string(), false);
    }
    pron += tmp;
  } else {
    pron.append(str_args[1].as_string());
    pron.append(str_args[2].as_string());
    pron.append(str_args[3].as_string());
    pron.append(kSignalTag);
  }
  *output = str_args[0].as_string() + pron + str_args[4].as_string() +
            str_args[5].as_string() + str_args[6].as_string() +
            str_args[7].as_string() + str_args[8].as_string();
}

// Stock: boundary sz 000000 boundary
void StockHandler(const re2::StringPiece* str_args, int args_num,
                  const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                  string* output) {
  VLOG(2) << "Process stock number ...";
  string pron;
  string id = str_args[1].as_string();
  if (id[0] == '(') id = id.substr(1);
  if (!id.empty())
    pron.append(GetPronFromSymbol(tts::ToLower(id), kStock2Pron,
                                  arraysize(kStock2Pron)));
  pron.append(ReadAsDigit(str_args[2].as_string(), true));
  *output = str_args[0].as_string() + pron + str_args[3].as_string();
}
void YiStockHandler(const re2::StringPiece* str_args, int args_num,
                    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                    string* output) {
  VLOG(2) << "Process stock number ...";
  string pron;
  string id = str_args[1].as_string();
  if (id[0] == '(') id = id.substr(1);
  if (!id.empty())
    pron.append(GetPronFromSymbol(tts::ToLower(id), kStock2Pron,
                                  arraysize(kStock2Pron)));
  pron.append(ReadAsDigit(str_args[2].as_string(), false));
  *output = str_args[0].as_string() + pron + str_args[3].as_string();
}

// wenyan project number default read as serial
void WenyanNumberHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process wenyan number ...";
  string pron = ReadAsSerial(str_args[0].as_string());
  *output = pron;
}

// 1000*2000m
// boundary number * number * number measure_abbv boundary
void MultiSymbolHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process multi symbol ...";
  string pron;
  pron += GetPronForNumString(str_args[1].as_string(), false);
  pron += kMultiPron;
  pron += GetPronForNumString(str_args[3].as_string(), false);
  if (!str_args[4].empty()) pron += kMultiPron;
  if (!str_args[5].empty())
    pron += GetPronForNumString(str_args[5].as_string(), false);
  if (!str_args[6].empty())
    pron += GetPronFromSymbol(str_args[6].as_string(), kMeasure2Pron,
                              arraysize(kMeasure2Pron));
  *output = str_args[0].as_string() + pron + str_args[7].as_string();
}

// value number: 超过200
// keyword number keyword
void ValueNumberHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process value number ...";
  string pron = ReadAsValue(str_args[1].as_string(), true, true);
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}

// default number: boundary number boundary
// rules: float or signed number read as value
// 0x read as digit, xx or xxx read as value other read as digit
void DefaultNumberHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process default number ...";
  string pron;
  string number = str_args[1].as_string();
  if (number.find_first_of(".") != string::npos || number[0] == '-') {  // float
    pron.append(GetPronForNumString(number, false));
  } else {  // int
    if (number.size() > 4 || number[0] == '0') {
      pron.append(ReadAsDigit(number, false));
    } else {
      pron.append(ReadAsValue(number, false, true));
    }
  }
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}

// default digital: read all pure number as digital
void DefaultDigitalHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process default digital ...";
  string pron;
  string number = str_args[1].as_string();
  if (number.find_first_of(".") != string::npos || number[0] == '-') {  // float
    pron.append(GetPronForNumString(number, false));
  } else {  // int
    pron.append(ReadAsDigit(number, true));
  }
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}
void YiDefaultDigitalHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process default digital ...";
  string pron;
  string number = str_args[1].as_string();
  if (number.find_first_of(".") != string::npos || number[0] == '-') {  // float
    pron.append(GetPronForNumString(number, false));
  } else {  // int
    pron.append(ReadAsDigit(number, false));
  }
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}

// default numerical: read all pure number as numerical
void DefaultNumericalHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process default numerical ...";
  string pron;
  string number = str_args[1].as_string();
  if (number.find_first_of(".") != string::npos || number[0] == '-') {  // float
    pron.append(GetPronForNumString(number, false));
  } else {  // int
    pron.append(ReadAsValue(number, false, true));
  }
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}

// symbols: symbol
void SymbolsHandler(const re2::StringPiece* str_args, int args_num,
                    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                    string* output) {
  VLOG(2) << "Process symbols ...";
  string pron;
  pron.append(GetPronFromSymbol(str_args[0].as_string(), kSymbol2Pron,
                                arraysize(kSymbol2Pron)));
  *output = pron;
}

// english: boundary english boundary
// remain the same
void DefaultEnglishHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  *output = str_args[0].as_string() + str_args[1].as_string() +
            str_args[2].as_string();
}

void LessGreaterHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  string pron;
  pron.append(GetPronFromSymbol(str_args[1].as_string(),
                                kLessGreaterSymbol2Pron,
                                arraysize(kLessGreaterSymbol2Pron)));
  *output = str_args[0].as_string() + pron;
}

void LessGreaterHandler2(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  string pron;
  pron.append(GetPronFromSymbol(str_args[0].as_string(),
                                kLessGreaterSymbol2Pron,
                                arraysize(kLessGreaterSymbol2Pron)));
  *output = pron + str_args[1].as_string();
}

// greek symbol: greek
void GreekHandler(const re2::StringPiece* str_args, int args_num,
                  const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                  string* output) {
  VLOG(2) << "Process Greek symbols ...";
  string pron;
  pron.append(GetPronFromSymbol(str_args[0].as_string(), kGreek2Pron,
                                arraysize(kGreek2Pron)));
  *output = pron;
}

// mantone symbol: ā á
void ManToneSymbolHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process ManToneSymbol symbols ...";
  string pron;
  pron.append(GetPronFromSymbol(tts::ToLower(str_args[1].as_string()),
                                kManTone2Pron, arraysize(kManTone2Pron)));
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}

// Ordinal: preword number boundary
void OrdinalHandler(const re2::StringPiece* str_args, int args_num,
                    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                    string* output) {
  VLOG(2) << "Process order word ...";
  string pron = string();
  string order = str_args[1].as_string();
  if (IsAllDigit(order)) {
    pron = ReadAsValue(str_args[1].as_string(), false, true);
  } else {
    size_t to_index = order.find_first_of("~-～");
    if (to_index != string::npos) {
      string order_from = order.substr(0, to_index);
      string order_to = order.substr(to_index + 1, order.size());
      pron = ReadAsValue(order_from, false, true) + kZhiToPron +
             ReadAsValue(order_to, false, true);
    }
  }
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}

void MeasureTagHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  *output = "";
}

// Number with measure word 36元:
// boundary number unit
void MeasureWordHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process measure word ...";
  string pron = GetPronForNumString(str_args[1].as_string(), true);
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}

// Number with measure abbreviation: 36kg 57.72km 23.01m/s
// boundary number \s unit / unit boundary
// ambiguous units in 1 char like m/M g/G should not convert to lower case
void MeasureAbbvHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process measure word with abbreviation ...";
  string pron = GetPronForNumString(str_args[1].as_string(), true);
  string unit1 = (str_args[3].size() == 1)
                     ? str_args[3].as_string()
                     : tts::ToLower(str_args[3].as_string());
  pron.append(
      GetPronFromSymbol(unit1, kMeasure2Pron, arraysize(kMeasure2Pron)));
  if (!str_args[4].empty()) {
    pron.append(kPerPron);
  }
  if (!str_args[5].empty()) {
    string unit2 = (str_args[5].size() == 1)
                       ? str_args[5].as_string()
                       : tts::ToLower(str_args[5].as_string());
    pron.append(
        GetPronFromSymbol(unit2, kMeasure2Pron, arraysize(kMeasure2Pron)));
  }
  *output = str_args[0].as_string() + pron + str_args[6].as_string();
}

// ∶ -> : and so on
// symbol
void SymbolNormalizeHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process symbol normalize ...";
  *output = GetPronFromSymbol(str_args[0].as_string(), kSymbolNormalize,
                              arraysize(kSymbolNormalize));
}

void CustomizedHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process customized words ...";
  *output = kZhangPron + str_args[1].as_string() + str_args[2].as_string();
}

// other pattern handlers
// special symbol pattern: symbol pattern
void SpecialSymbolHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process Special symbol ...";
  *output = GetPronFromSymbol(str_args[0].as_string(), kSpecial2Pron,
                              arraysize(kSpecial2Pron));
}

// Serial symbol type
void SerialSymbolHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process serial symbol ...";
  *output = GetPronFromSymbol(str_args[0].as_string(), kSerialSymbol2Pron,
                              arraysize(kSerialSymbol2Pron));
}

// english special name: TFBoys
// boundary english boundary
void SpecialEnglishHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process Special English ...";
  string pron;
  pron.append(GetPronFromSymbol(tts::ToLower(str_args[1].as_string()),
                                kSpecialEnglish2Pron,
                                arraysize(kSpecialEnglish2Pron)));
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}

// process special name like 360浏览器
// boundary number sep boundary
void SpecialNameHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process special name ...";
  string pron = ReadAsDigit(str_args[1].as_string(), true);
  *output = str_args[0].as_string() + pron + str_args[2].as_string() +
            str_args[3].as_string();
}
void YiSpecialNameHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process special name ...";
  string pron = ReadAsDigit(str_args[1].as_string(), false);
  *output = str_args[0].as_string() + pron + str_args[2].as_string() +
            str_args[3].as_string();
}

// process special name like windows10
// boundary win backspace number boundary
void SpecialEnglishNameHandler1(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process special name ...";
  string word = tts::ToLower(str_args[1].as_string());
  string pron = word;
  vector<string> numbers;
  SplitString(str_args[3].as_string(), '.', &numbers);
  for (size_t i = 0; i < numbers.size(); ++i) {
    string number = numbers[i];
    if (number.size() > 0 && number[0] == '0') {
      pron += ReadAsDigit(number, true);
    } else if (number == "2000" || word == "top" || word == "step") {
      pron += ReadAsValue(number, true, true);  // win2000
    } else if (number.size() <= 2 && number.size() > 0 && number[0] <= '3') {
      pron += ReadAsValue(number, false, true);
    } else {
      pron += ReadAsDigit(number, true);
    }
    if (i != numbers.size() - 1) pron += kPointPron;
  }
  *output = str_args[0].as_string() + pron + str_args[4].as_string();
}
void SpecialEnglishNameHandler2(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process special name ...";
  string pron;
  string upper = tts::ToUpper(str_args[1].as_string());
  for (size_t i = 0; i < upper.size(); ++i) {
    pron += string() + upper[i] + kSepMarkWord;
  }
  vector<string> numbers;
  SplitString(str_args[3].as_string(), '.', &numbers);
  for (size_t i = 0; i < numbers.size(); ++i) {
    string number = numbers[i];
    if (number.size() > 0 && number[0] == '0') {
      pron += ReadAsDigit(number, true);
    } else if (number == "2000") {
      pron += ReadAsValue(number, true, true);  // iOS2000
    } else if (number.size() <= 2 && number.size() > 0 && number[0] <= '3') {
      pron += ReadAsValue(number, false, true);
    } else {
      pron += ReadAsDigit(number, true);
    }
    if (i != numbers.size() - 1) pron += kPointPron;
  }
  *output = str_args[0].as_string() + pron + str_args[4].as_string();
}

// strong keyword pattern 歼-12 618狂欢
// keyword - number keyword
void SpecialStrongWordHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process strong keyword number ...";
  string number = str_args[2].as_string();
  string pron;
  if (number.size() <= 2) {
    pron += ReadAsValue(number, false, true);
  } else {
    pron += ReadAsDigit(number, true);
  }
  *output = str_args[0].as_string() + pron + str_args[3].as_string();
}

// process special point: 7·11
// boundary number · number boundary
void SpecialPointHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process special point ...";
  string pron = ReadAsDigit(str_args[1].as_string(), true);
  pron += ReadAsDigit(str_args[3].as_string(), true);
  *output = str_args[0].as_string() + pron + str_args[4].as_string();
}
void YiSpecialPointHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process special point ...";
  string pron = ReadAsDigit(str_args[1].as_string(), false);
  pron += ReadAsDigit(str_args[3].as_string(), false);
  *output = str_args[0].as_string() + pron + str_args[4].as_string();
}

// process special cases: 80、90后
// boundary number 、 number boundary
void SpecialCaseHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process special case name ...";
  string pron1 = ReadAsDigit(str_args[1].as_string(), true);
  string pron2 = ReadAsDigit(str_args[3].as_string(), true);
  *output = str_args[0].as_string() + pron1 + str_args[2].as_string() + pron2 +
            str_args[4].as_string();
}
void YiSpecialCaseHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process special case name ...";
  string pron1 = ReadAsDigit(str_args[1].as_string(), false);
  string pron2 = ReadAsDigit(str_args[3].as_string(), false);
  *output = str_args[0].as_string() + pron1 + str_args[2].as_string() + pron2 +
            str_args[4].as_string();
}

// process subway number
// boundary number 号线
void SubwayHandler(const re2::StringPiece* str_args, int args_num,
                   const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                   string* output) {
  VLOG(2) << "Process subway pattern ...";
  string pron = ReadAsValue(str_args[1].as_string(), false, true);
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}

// lower building
// boundary alphabet 口|座
void LowerBuildingHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process lower building pattern ...";
  string lower_alpha = str_args[1].as_string();
  *output = str_args[0].as_string() + tts::ToUpper(lower_alpha) +
            str_args[2].as_string();
}

// bus number e.g. 286路公交车
// boundary number keyword
void BusNumberHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process bus number pattern ...";
  string pron;
  string number = str_args[1].as_string();
  if (number.size() <= 2) {
    pron = ReadAsValue(number, false, true);
  } else {
    pron = ReadAsDigit(number, true);
  }
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}

// special number handler
// preword other number other postword
void SpecialNumberHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process special number pattern ...";
  string pron = ReadAsDigit(str_args[2].as_string(), true);
  *output = str_args[0].as_string() + str_args[1].as_string() + pron +
            str_args[3].as_string() + str_args[4].as_string();
}

// process radio pattern
// boundary number mhz boundary
void RadioHandler(const re2::StringPiece* str_args, int args_num,
                  const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                  string* output) {
  VLOG(2) << "Process radio ...";
  string pron;
  string pre_number = str_args[1].as_string();
  string post_number = str_args[2].as_string();
  if (pre_number.size() == 3) {  // 101.5
    pron.append(ReadAsDigit(pre_number + post_number, true));
  } else {  // 97.6
    pron.append(GetPronForNumString(pre_number + post_number, false));
  }
  if (!str_args[3].empty()) pron.append(kFreqPron);
  *output = str_args[0].as_string() + pron + str_args[4].as_string();
}
void YiRadioHandler(const re2::StringPiece* str_args, int args_num,
                    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                    string* output) {
  VLOG(2) << "Process radio ...";
  string pron;
  string pre_number = str_args[1].as_string();
  string post_number = str_args[2].as_string();
  if (pre_number.size() == 3) {  // 101.5
    pron.append(ReadAsDigit(pre_number + post_number, false));
  } else {  // 97.6
    pron.append(GetPronForNumString(pre_number + post_number, false));
  }
  if (!str_args[3].empty()) pron.append(kFreqPron);
  *output = str_args[0].as_string() + pron + str_args[4].as_string();
}

// process website pattern
// boundary website boundary
void WebsiteHandler(const re2::StringPiece* str_args, int args_num,
                    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                    string* output) {
  VLOG(2) << "Process website ...";
  string pron;
  vector<string> web_segs;
  vector<string> web_prons;
  SplitString(str_args[1].as_string(), '.', &web_segs);
  for (const auto& web_seg : web_segs) {
    vector<string> mail_segs;
    vector<string> mail_prons;
    SplitString(web_seg, '@', &mail_segs);
    for (const auto& mail_seg : mail_segs) {
      if (IsAllDigit(mail_seg)) {
        mail_prons.push_back(ReadAsDigit(mail_seg, true));
      } else {
        mail_prons.push_back(mail_seg);
      }
    }
    web_prons.push_back(mobvoi::JoinVectorToString(mail_prons, kAtPron));
  }
  pron = mobvoi::JoinVectorToString(web_prons, kDotPron);
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}
void YiWebsiteHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process website ...";
  string pron;
  vector<string> web_segs;
  vector<string> web_prons;
  SplitString(str_args[1].as_string(), '.', &web_segs);
  for (const auto& web_seg : web_segs) {
    vector<string> mail_segs;
    vector<string> mail_prons;
    SplitString(web_seg, '@', &mail_segs);
    for (const auto& mail_seg : mail_segs) {
      if (IsAllDigit(mail_seg)) {
        mail_prons.push_back(ReadAsDigit(mail_seg, false));
      } else {
        mail_prons.push_back(mail_seg);
      }
    }
    web_prons.push_back(mobvoi::JoinVectorToString(mail_prons, kAtPron));
  }
  pron = mobvoi::JoinVectorToString(web_prons, kDotPron);
  *output = str_args[0].as_string() + pron + str_args[2].as_string();
}

// @
void AtHandler(const re2::StringPiece* str_args, int args_num,
               const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
               string* output) {
  VLOG(2) << "Process @ ...";
  *output = kAtPron;
}

// 2D 3D 4D T台 T恤
// boundary number english boundary
void NumberEnglishHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process special number/english ...";
  string pron;
  if (!str_args[1].empty())
    pron.append(GetPronForNumString(str_args[1].as_string(), false));
  pron.append(GetPronForEnglish(str_args[2].as_string()));
  *output = str_args[0].as_string() + pron + str_args[3].as_string();
}
void YiNumberEnglishHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process special number/english ...";
  string pron;
  if (!str_args[1].empty())
    pron.append(GetPronForNumString(str_args[1].as_string(), false));
  pron.append(GetPronForEnglish(str_args[2].as_string()));
  *output = str_args[0].as_string() + pron + str_args[3].as_string();
}

// QQ
// boundary english boundary
void QQEnglishHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
    string* output) {
  VLOG(2) << "Process all capital english ...";
  *output = str_args[0].as_string() + kQPron + str_args[2].as_string();
}

}  // namespace mandarin
}  // namespace tn
}  // namespace nlp
