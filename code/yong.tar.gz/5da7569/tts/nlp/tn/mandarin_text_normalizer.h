// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_NLP_TN_MANDARIN_TEXT_NORMALIZER_H_
#define TTS_NLP_TN_MANDARIN_TEXT_NORMALIZER_H_

#include "tts/nlp/tn/common_pattern_handler.h"

namespace nlp {
namespace tn {
namespace mandarin {

static const PatternHandler kMandarinPatternHandlers[] = {
    {kSymbolNormalizePattern, SymbolNormalizeHandler, kAllBody,
     TnChoiceType::kNon, kTnNameNon},
    {kWenyanNumberPattern, WenyanNumberHandler, kDomainWenyanAddress, kAllBody,
     TnChoiceType::kNon, kTnNameNon},
    // special regex pattern
    // customized pattern for 长
    {kCustomizedPattern, CustomizedHandler, kCustomizedPatternBody, kAllBody,
     TnChoiceType::kNon, kTnNameNon},
    {kSpecialSymbolPattern, SpecialSymbolHandler, kAllBody, TnChoiceType::kNon,
     kTnNameNon},
    {kSerialSymbolPattern, SerialSymbolHandler, kAllBody, TnChoiceType::kNon,
     kTnNameNon},  //Ⅰ,Ⅱ,Ⅲ,Ⅳ,ⅰ,ⅲ,ⅳ
    {kSpecialEnglishPattern, SpecialEnglishHandler, kSpecialEnglishPatternBody,
     TnChoiceType::kNon, kTnNameNon},  // TFBoys
    {kSpecialPointPattern, SpecialPointHandler, kSpecialPointPatternBody,
     TnChoiceType::kBarNumber, tts::kSsmlTnAsDigitYao},  // 7·11
    {kSubWayPattern, SubwayHandler, kSubWayPatternBody, TnChoiceType::kNumber,
     kTnNameNon},  // 14号线
    {kSubWayPattern2, SubwayHandler, kSubWayPatternBody, TnChoiceType::kNumber,
     kTnNameNon},  // B1层
    {kBusNumberPattern, BusNumberHandler, kBusNumberPatternBody,
     TnChoiceType::kNumber, kTnNameNon},  // 112路公交车
    {kBuildingPattern, LowerBuildingHandler, kBuildingPatternBody,
     TnChoiceType::kNon, kTnNameNon},  // a座 a口
    {k360Pattern1, SpecialNameHandler, kSpecialPatternBody,
     TnChoiceType::kNumber, kTnNameNon},  // 360浏览器 e.g.
    {k360Pattern2, SpecialNameHandler, kSpecialPatternBody,
     TnChoiceType::kNumber, kTnNameNon},  // 安装360 e.g.
    {kSpecialEnglishNamePattern1, SpecialEnglishNameHandler1,
     kSpecialEnglishNamePatternBody, TnChoiceType::kNumber,
     kTnNameNon},  // Win98
    {kSpecialEnglishNamePattern2, SpecialEnglishNameHandler2,
     kSpecialEnglishNamePatternBody, TnChoiceType::kNumber,
     kTnNameNon},  // ios10
    {kSpecialStrongWordPattern1, SpecialStrongWordHandler,
     kSpecialStrongWordPatternBody, TnChoiceType::kNumber,
     kTnNameNon},  // 歼-12
    {kSpecialStrongWordPattern2, SpecialStrongWordHandler,
     kSpecialStrongWordPatternBody, TnChoiceType::kNumber,
     kTnNameNon},  // 315执法
    {kAgesPattern, SpecialCaseHandler, kAgesPatternBody, TnChoiceType::kNumber,
     kTnNameNon},  // 80、90后
    {kAgePattern, SpecialNameHandler, kSpecialPatternBody,
     TnChoiceType::kNumber, kTnNameNon},  // 80后 90后
    {kColleagePattern, SpecialNameHandler, kSpecialPatternBody,
     TnChoiceType::kNumber, kTnNameNon},  // 985学校
    {kSpecialNamePattern, SpecialNameHandler, kSpecialPatternBody,
     TnChoiceType::kNumber, kTnNameNon},  // 911事件　311事变
    {kSpecialPlacePattern, SpecialNameHandler, kSpecialPatternBody,
     TnChoiceType::kNumber, kTnNameNon},  // 导航去798
    {kSpecialPlacePattern2, SpecialNameHandler, kSpecialPatternBody,
     TnChoiceType::kNumber, kTnNameNon},  // 798店
    {kSpecialPlacePattern3, SpecialNameHandler, kSpecialPatternBody,
     TnChoiceType::kNumber, kTnNameNon},  // 动感101
    {kRadioPattern, RadioHandler, kRadioPatternBody, TnChoiceType::kBarNumber,
     kTnNameNon},  // FM 103.6MHz

    {kWebsitePattern, WebsiteHandler, kWebsitePatternBody,
     TnChoiceType::kWebsite,
     tts::kSsmlTnAsWebsite},  // zz@163.com  www.baidu.com
    {kAtPattern, AtHandler, kAllBody, TnChoiceType::kNon, kTnNameNon},  // @you
    {kNumberEnglishPattern1, NumberEnglishHandler, kNumberEnglishPatternBody,
     TnChoiceType::kNon, kTnNameNon},  // 2D 3D 4D
    {kNumberEnglishPattern2, NumberEnglishHandler, kNumberEnglishPatternBody,
     TnChoiceType::kNon, kTnNameNon},  // T台
    {kQQEnglishPattern, QQEnglishHandler, kQQEnglishPatternBody,
     TnChoiceType::kNon, kTnNameNon},  // QQ

    {kMathPattern2, MathHandler, kDomainCalc, kAllBody, TnChoiceType::kNon,
     kTnNameNon},  // 2002-2-3等于1997
    {kMathStringPattern1, MathHandler, kDomainCalc, kAllBody,
     TnChoiceType::kNon, kTnNameNon},  // 100加203等于303
    {kMathStringPattern2, MathHandler, kDomainCalc, kAllBody,
     TnChoiceType::kNon, kTnNameNon},  // 等于303
    {kMathPattern1, MathHandler, kDomainCalc, kAllBody, TnChoiceType::kNon,
     tts::kSsmlTnAsMath},  // 1+2-3=14
                           //    {kMathPattern1, MathHandler,
    //    kAllBody,TnChoiceType::kNon,tts::kSsmlTnAsMath},        // 1+2-3=14

    // number pattern
    {kPMPattern, PMHandler, kPMPatternBody, TnChoiceType::kBarNumber,
     kTnNameNon},  // PM2.5
    {kYearMonthDayStringPattern, DateHandler, kDatePatternBody,
     TnChoiceType::kNon, tts::kSsmlTnAsDate},  // 2015年03月12日
    {kYearMonthStringPattern, DateHandler, kDatePatternBody, TnChoiceType::kNon,
     tts::kSsmlTnAsDate},  // 2015年03月
    {kMonthDayStringPattern, DateHandler, kDatePatternBody, TnChoiceType::kNon,
     tts::kSsmlTnAsDate},  // 07月03日
    {kSingleYearPattern, YearHandler, kSingleYearPatternBody,
     TnChoiceType::kNumber, tts::kSsmlTnAsDate},  // 2015年
    // {kCommaNumberPattern, CommaNumberHandler},  // 13,000,000
    // percent
    {kSignedPercentPattern, PercentHandler, kPercentPatternBody,
     TnChoiceType::kNon, tts::kTnNamePrecentNumber},  // -13.72% +100%
    {kPercentPattern, PercentHandler, kPercentPatternBody, TnChoiceType::kNon,
     tts::kTnNamePrecentNumber},  // 13.72% 100%

    // score
    {kScoreKWPreToPattern, ScoreHandler, kScoreKWPatternBody,
     TnChoiceType::kBarNumber, tts::kSsmlTnAsRatio},  // 比分为8-12
    {kScoreKWPostToPattern, ScoreHandler, kScoreKWPatternBody,
     TnChoiceType::kBarNumber, tts::kSsmlTnAsRatio},  // 比分为103-86-72
    {kScoreKWPreRatioPattern, ScoreHandler, kScoreKWPatternBody,
     TnChoiceType::kCommaNumber, tts::kSsmlTnAsRatio},  // 比分为8:12
    {kScoreKWPostRatioPattern, ScoreHandler, kScoreKWPatternBody,
     TnChoiceType::kCommaNumber, tts::kSsmlTnAsRatio},  // 比分为103:86:72
    // time
    {kTimeFullAppendPattern, TimeHandler, kTimePatternBody, TnChoiceType::kNon,
     tts::kSsmlTnAsTime},  // 12:00:23AM, 3:10:23PM
    {kTimePartAppendPattern, TimeHandler, kTimePatternBody, TnChoiceType::kNon,
     tts::kSsmlTnAsTime},  // 12:00AM, 3:10PM

    {kTimeFullPattern, TimeHandler, kTimePatternBody,
     TnChoiceType::kCommaNumber,
     tts::kSsmlTnAsTime},  // 08:23:20 12:00:23AM, 3:10:23PM
    {kTimePartPattern, TimeHandler, kTimePatternBody,
     TnChoiceType::kCommaNumber, tts::kSsmlTnAsTime},  // 18:30 12:00AM, 3:10PM
    {kTimeStringFullPattern, TimeHandler, kTimePatternBody, TnChoiceType::kNon,
     tts::kSsmlTnAsTime},  // 17点8分12秒
    {kTimeStringPartPattern, TimeHandler, kTimePatternBody, TnChoiceType::kNon,
     tts::kSsmlTnAsTime},  // 17点8分

    // order
    {kOrdinalPattern2, OrdinalHandler, kOrdinalPatternBody,
     TnChoiceType::kBarNumber, tts::kSsmlTnAsOrdinal},
    {kOrdinalPattern, OrdinalHandler, kOrdinalPatternBody,
     TnChoiceType::kNumber, tts::kSsmlTnAsOrdinal},

    // number for currency
    {kCurrencyPattern, CurrencyHandler, kCurrencyPatternBody,
     TnChoiceType::kNon, tts::kTnNameCurrency},  // ￥1.4
    {kCurrencyStringPattern, CurrencyHandler, kCurrencyPatternBody,
     TnChoiceType::kNon, tts::kTnNameCurrency},  // RMB28
    {kPreAbbvUnitsPattern, CurrencyHandler, kCurrencyPatternBody,
     TnChoiceType::kNon, tts::kSsmlTnAsOrdinal},  // No.48

    {kTwoYearStrictPattern, DateHandler, kTwoYearPatternBody,
     TnChoiceType::kNumber, tts::kSsmlTnAsDate},  // 98年
    // number for coordinate and race time
    {kCoordinatePattern, CoordinateHandler, kCoordinatePatternBody,
     TnChoiceType::kNon, tts::kTnNameCoordinate},  // 18°09′34″
    {kCoordinatePattern2, CoordinateHandler, kCoordinatePatternBody,
     TnChoiceType::kNon, tts::kTnNameCoordinate},  // 18°09′
    {kRaceTimePattern, CoordinateHandler, kCoordinatePatternBody,
     TnChoiceType::kNon, tts::kSsmlTnAsTime},  // 09′34″
    // number for temperature
    {kTemperaturePattern2, TemperatureHandler2, kTemperaturePattern2Body,
     TnChoiceType::kNon, tts::kTnNameTemperature},  // -2到5℃
    {kTemperaturePattern, TemperatureHandler, kTemperaturePatternBody,
     TnChoiceType::kNon, tts::kTnNameTemperature},  // 34.32℃
    // symbols: > <
    {kLessOrGreaterPattern1, LessGreaterHandler, kLessGreaterPatternBody,
     TnChoiceType::kNon, kTnNameNon},
    {kLessOrGreaterPattern2, LessGreaterHandler2, kLessGreaterPattern2Body,
     TnChoiceType::kNon, kTnNameNon},
    {kMultiSymbolPattern1, MultiSymbolHandler, kMultiSymbolPatternBody,
     TnChoiceType::kNon, kTnNameNon},  // 1000x2000x3000bps
    {kMultiSymbolPattern2, MultiSymbolHandler, kMultiSymbolPatternBody,
     TnChoiceType::kNon, kTnNameNon},  // 1000x2000bps
    {kMultiSymbolPattern3, MultiSymbolHandler, kMultiSymbolPatternBody,
     TnChoiceType::kNon, kTnNameNon},  // 1000x2000x3000
    {kMultiSymbolPattern4, MultiSymbolHandler, kMultiSymbolPatternBody,
     TnChoiceType::kNon, kTnNameNon},  // 1000x2000
    // numbers for measure abbv word
    {kMeasureCombAbbvPattern, MeasureAbbvHandler, kMeasureAbbvPatternBody,
     TnChoiceType::kNon, kTnNameNon},
    {kMeasureAbbvPattern, MeasureAbbvHandler, kMeasureAbbvPatternBody,
     TnChoiceType::kNon, kTnNameNon},
    // serial number
    {kStockPattern1, StockHandler, kStockPatternBody, TnChoiceType::kNon,
     tts::kTnNameStock},  // stock  (sz000001)
    {kStockPattern2, StockHandler, kStockPatternBody, TnChoiceType::kNon,
     tts::kTnNameStock},  // stock  sz000001  SZ:000001

    // keyword mobile
    {kStrongMobilePattern1, TelHandler, kTelPatternBody, TnChoiceType::kNon,
     tts::kSsmlTnAsTelephone},  // 拨打 +86 010 8231 2343
    {kStrongMobilePattern2, TelHandler, kTelPatternBody, TnChoiceType::kNon,
     tts::kSsmlTnAsTelephone},  // +86 010 8231 2343 电话
    // serial
    {kSerialNumPattern, SerialHandler, kSerialNumberPatternBody,
     TnChoiceType::kNumber, tts::kSsmlTnAsDigitYao},  // MU7089 G65 730Li
    {kSerialNumKeyWordPattern, SerialHandler, kSerialNumberPatternBody,
     TnChoiceType::kNumber, tts::kSsmlTnAsDigitYao},  // 1024次列车
    {kBuildingPattern2, BuildingHandler, kDomainNavigation,
     kBuildingPatternBody, TnChoiceType::kNumber, kTnNameNon},  // 和馨园2栋
    // numbers for measure word
    {kNumberToMeasurePattern, MeasureTrieHandler, kMeasureTriePatternBody,
     TnChoiceType::kBarNumber, kTnNameNon},  // 1.5-1.79亿元
    {kSignedNumberMeasurePattern, MeasureTrieHandler, kMeasureTriePatternBody,
     TnChoiceType::kBarNumber, kTnNameNon},  // -1.79亿元
    {kNumberMeasurePattern, MeasureTrieHandler, kMeasureTriePatternBody,
     TnChoiceType::kBarNumber, kTnNameNon},  // 2079法郎
    {kMeasureTagPattern, MeasureTagHandler, kAllBody, TnChoiceType::kNon,
     kTnNameNon},
    {kNumberKWPrePattern, MeasureWordHandler, kMeasureKWPatternBody,
     TnChoiceType::kPointNumber, kTnNameNon},

    // date
    {kYearMonthDayPattern, DateHandler, kDatePatternBody,
     TnChoiceType::kBarNumber, tts::kSsmlTnAsDate},  // 2015-03-12
    {kYearMonthPattern, DateHandler, kDatePatternBody, TnChoiceType::kBarNumber,
     tts::kSsmlTnAsDate},  // 2015-03
    {kMonthDayPattern, DateHandler, kDatePatternBody, TnChoiceType::kBarNumber,
     tts::kSsmlTnAsDate},  // 07-03

    // Telephone
    {kTelPattern1, TelHandler, kTelPatternBody, TnChoiceType::kNon,
     tts::kSsmlTnAsTelephone},  // +86 010 8231 2343
    {kTelPattern2, TelHandler, kTelPatternBody, TnChoiceType::kNon,
     tts::kSsmlTnAsTelephone},  // +86 0721 831 2343
    {kMobilePattern, TelHandler, kTelPatternBody, TnChoiceType::kNon,
     tts::kSsmlTnAsTelephone},  // +86 010 8231 2343

    {kStrongSpecialTelPattern1, TelHandler, kShortTelPatternBody,
     TnChoiceType::kBarNumber, tts::kSsmlTnAsTelephone},  // 400-811-9090
    {kStrongSpecialTelPattern2, TelHandler, kShortTelPatternBody,
     TnChoiceType::kBarNumber, tts::kSsmlTnAsTelephone},  // 4008-811-090
    {kStrongSpecialTelPattern3, TelHandler, kShortTelPatternBody,
     TnChoiceType::kNumber, tts::kSsmlTnAsTelephone},  // 95592
    {kWeakSpecialTelPattern1, TelHandler, kShortTelPatternBody,
     TnChoiceType::kNumber, tts::kSsmlTnAsTelephone},
    {kWeakSpecialTelPattern2, TelHandler, kShortTelPatternBody,
     TnChoiceType::kNumber, tts::kSsmlTnAsTelephone},
    {kSpecialNumberPattern1, SpecialNumberHandler, kSpecialNumberPatternBody,
     TnChoiceType::kNumber, kTnNameNon},  // 骁龙860
    {kSpecialNumberPattern2, SpecialNumberHandler, kSpecialNumberPatternBody,
     TnChoiceType::kNumber, kTnNameNon},  // 860事件

    {kCommaNumberPattern, CommaNumberHandler, kCommaNumberPatternBody,
     TnChoiceType::kNon, kTnNameNon},  // 13,000,000

    {kDiscountPattern, DiscountHandler, kDiscountPatternBody,
     TnChoiceType::kNumber, kTnNameNon},  // 9.0折, 9折, 7.5折 95折
    {kFractionPattern, FractionHandler, kFractionPatternBody,
     TnChoiceType::kSlashNumber, tts::kSsmlTnAsFraction},  // 1/2 3/5
    {kPerMeasurePattern, PerHandler, kFractionPatternBody, TnChoiceType::kNon,
     kTnNameNon},  // per 元/人

    {kScoreDefaultPattern, ScoreHandler, kScoreKWPatternBody,
     TnChoiceType::kCommaNumber, tts::kSsmlTnAsRatio},  // 103:86:72
    // symbol -
    {kKeyYearPattern, KeyYearHandler, kYearPatternBody, TnChoiceType::kNumber,
     kTnNameNon},  // 2018新年 喜迎2018
    {kBarPattern1, BarHandler, kBarBuildingPatternBody, TnChoiceType::kNumber,
     kTnNameNon},  // 小区黄城根1号楼-1-302
    {kBarPattern2, BarHandler, kBarBuildingPatternBody,
     TnChoiceType::kBarNumber, kTnNameNon},  // 207-3室
    {kDefaultTelPattern, TelHandler, kShortTelPatternBody, TnChoiceType::kNon,
     kTnNameNon},
    {kNumberToPattern, BarHandler, kBarToPatternBody, TnChoiceType::kNon,
     kTnNameNon},  // 37.2-43.4℃ 37.2~43.4℃
    {kToPattern, ToHandler, kToPatternBody, TnChoiceType::kNon,
     kTnNameNon},  // 北京 - 上海

    {kGreekPattern, GreekHandler, kAllBody, TnChoiceType::kNon,
     kTnNameNon},  // αβγΓΔδεζηθλμξπ∏ρ∑στφΨΩω
    {kManToneSymbolPattern, ManToneSymbolHandler, kAllBody, TnChoiceType::kNon,
     kTnNameNon},  // āáǎàōóǒòcēéěèīíǐìūúǔùǖǘǚ

    {kIpPattern, IpHandler, kIpPatternBody, TnChoiceType::kPointNumber,
     tts::kSsmlTnAsManWebsite},  // 10.2.3.56
    {kMonthDayKWPattern1, MonthDayHandler, kMonthDayKWPatternBody,
     TnChoiceType::kPointNumber, kTnNameNon},  // 6.18狂欢节
    {kMonthDayKWPattern2, MonthDayHandler, kMonthDayKWPatternBody,
     TnChoiceType::kPointNumber, kTnNameNon},  // 今天6.18

    // default patterns
    {kCapitalEnglishPattern, DefaultEnglishHandler, kEnglishPatternBody,
     TnChoiceType::kEnglish, kTnNameNon},
    {kSignedNumberPattern, DefaultNumericalHandler, kNumericalDomain, kAllBody,
     TnChoiceType::kNon, tts::kSsmlTnAsValue},
    {kSignedNumberPattern, DefaultDigitalHandler, kDomainCall, kAllBody,
     TnChoiceType::kNon, tts::kSsmlTnAsValue},
    {kUnsignedIntegerPattern, DefaultDigitalHandler, kDomainCall, kAllBody,
     TnChoiceType::kNon, tts::kSsmlTnAsValue},
    {kValueNumberPattern1, ValueNumberHandler, kValueNumberPatternBody,
     TnChoiceType::kNumber, tts::kSsmlTnAsValue},
    {kValueNumberPattern2, ValueNumberHandler, kValueNumberPatternBody,
     TnChoiceType::kNumber, tts::kSsmlTnAsValue},
    {kSignedNumberPattern, DefaultNumberHandler, kDefaultNumberBody,
     TnChoiceType::kNumber, tts::kSsmlTnAsValue},
    {kUnsignedDecimalPattern, DefaultNumberHandler, kDefaultNumberBody,
     TnChoiceType::kPointNumber, tts::kSsmlTnAsValue},
    {kUnsignedIntegerPattern, DefaultNumberHandler, kDefaultNumberBody,
     TnChoiceType::kNumber, tts::kSsmlTnAsValue},
    {kSymbolPattern, SymbolsHandler, kAllBody, TnChoiceType::kNon, kTnNameNon},
};

}  // namespace mandarin
}  // namespace tn
}  // namespace nlp

#endif  // TTS_NLP_TN_MANDARIN_TEXT_NORMALIZER_H_
