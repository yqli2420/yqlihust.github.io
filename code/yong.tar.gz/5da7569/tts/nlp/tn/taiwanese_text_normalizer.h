// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_NLP_TN_TAIWANESE_TEXT_NORMALIZER_H_
#define TTS_NLP_TN_TAIWANESE_TEXT_NORMALIZER_H_

#include "tts/nlp/tn/common_pattern_handler.h"

namespace nlp {
namespace tn {
namespace mandarin {

void TWTemperatureHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void TWTemperatureHandler2(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void TWTimeHandler(const re2::StringPiece* str_args, int args_num,
                   const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                   string* output);

static const PatternHandler kTaiwanesePatternHandlers[] = {
    // special regex pattern
    // customized pattern for 长
    {kCustomizedPattern, CustomizedHandler, kCustomizedPatternBody,
     TnChoiceType::kNon, kTnNameNon},
    {kSpecialSymbolPattern, SpecialSymbolHandler, kAllBody, TnChoiceType::kNon,
     kTnNameNon},
    {kSpecialEnglishPattern, SpecialEnglishHandler, kSpecialEnglishPatternBody,
     TnChoiceType::kNon, kTnNameNon},              // TFBoys
    {kSpecialPointPattern, YiSpecialPointHandler,  // 7·11
     kSpecialPointPatternBody, TnChoiceType::kNon, tts::kSsmlTnAsDigitYi},
    {kSubWayPattern, SubwayHandler, kSubWayPatternBody, TnChoiceType::kNumber,
     kTnNameNon},  // 14号线
    {kSubWayPattern2, SubwayHandler, kSubWayPatternBody, TnChoiceType::kNumber,
     kTnNameNon},  // B1层
    {kBuildingPattern, LowerBuildingHandler, kBuildingPatternBody,
     TnChoiceType::kNon, kTnNameNon},  // a座 a口
    {k360Pattern1, SpecialNameHandler, kSpecialPatternBody,
     TnChoiceType::kNumber, kTnNameNon},  // 360浏览器 e.g.
    {k360Pattern2, SpecialNameHandler, kSpecialPatternBody,
     TnChoiceType::kNumber, kTnNameNon},  // 安装360 e.g.
    {kAgesPattern, YiSpecialCaseHandler, kAgesPatternBody, TnChoiceType::kNon,
     kTnNameNon},  // 80、90后
    {kAgePattern, YiSpecialNameHandler, kSpecialPatternBody, TnChoiceType::kNon,
     kTnNameNon},  // 80后 90后
    {kColleagePattern, YiSpecialNameHandler, kSpecialPatternBody,
     TnChoiceType::kNon, kTnNameNon},  // 985学校
    {kSpecialNamePattern, YiSpecialNameHandler, kSpecialPatternBody,
     TnChoiceType::kNon, kTnNameNon},  // 911事件　311事变
    {kSpecialPlacePattern, YiSpecialNameHandler, kSpecialPatternBody,
     TnChoiceType::kNon, kTnNameNon},  // 导航去798
    {kSpecialPlacePattern2, YiSpecialNameHandler, kSpecialPatternBody,
     TnChoiceType::kNon, kTnNameNon},  // 798店
    {kRadioPattern, YiRadioHandler, kRadioPatternBody, TnChoiceType::kNon,
     kTnNameNon},  // FM 103.6MHz

    {kWebsitePattern, YiWebsiteHandler, kWebsitePatternBody, TnChoiceType::kNon,
     tts::kSsmlTnAsWebsite},  // zz@163.com
                              // www.baidu.com
    {kAtPattern, AtHandler, kAllBody, TnChoiceType::kNon, kTnNameNon},  // @you
    {kNumberEnglishPattern1, YiNumberEnglishHandler, kNumberEnglishPatternBody,
     TnChoiceType::kNon, kTnNameNon},  // 2D 3D 4D
    {kNumberEnglishPattern2, YiNumberEnglishHandler, kNumberEnglishPatternBody,
     TnChoiceType::kNon, kTnNameNon},  // T台

    {kMathPattern2, MathHandler, kDomainCalc, kAllBody, TnChoiceType::kNon,
     kTnNameNon},  // 2002-2-3等于1997
    {kMathStringPattern1, MathHandler, kDomainCalc, kAllBody,
     TnChoiceType::kNon, kTnNameNon},  // 100加203等于303
    {kMathStringPattern2, MathHandler, kDomainCalc, kAllBody,
     TnChoiceType::kNon, kTnNameNon},  // 等于303
    {kMathPattern1, MathHandler, kDomainCalc, kAllBody, TnChoiceType::kNon,
     tts::kSsmlTnAsMath},  // 1+2-3=14

    // number pattern
    {kPMPattern, PMHandler, kPMPatternBody, TnChoiceType::kNon,
     kTnNameNon},  // PM2.5
    {kYearMonthDayStringPattern, DateHandler, kDatePatternBody,
     TnChoiceType::kNon, tts::kSsmlTnAsDate},  // 2015年03月12日
    {kYearMonthStringPattern, DateHandler, kDatePatternBody, TnChoiceType::kNon,
     tts::kSsmlTnAsDate},  // 2015年03月
    {kMonthDayStringPattern, DateHandler, kDatePatternBody, TnChoiceType::kNon,
     tts::kSsmlTnAsDate},  // 07月03日
    {kSingleYearPattern, YearHandler, kSingleYearPatternBody,
     TnChoiceType::kNon, tts::kSsmlTnAsDate},  // 2015年
    // {kCommaNumberPattern, CommaNumberHandler},
    // // 13,000,000
    // percent
    {kSignedPercentPattern, PercentHandler, kPercentPatternBody,
     TnChoiceType::kNon, tts::kTnNamePrecentNumber},  // -13.72% +100%
    {kPercentPattern, PercentHandler, kPercentPatternBody, TnChoiceType::kNon,
     tts::kTnNamePrecentNumber},  // 13.72% 100%

    // score
    {kScoreKWPreToPattern, ScoreHandler, kScoreKWPatternBody,
     TnChoiceType::kBarNumber, tts::kSsmlTnAsRatio},  // 比分为8-12
    {kScoreKWPostToPattern, ScoreHandler, kScoreKWPatternBody,
     TnChoiceType::kBarNumber, tts::kSsmlTnAsRatio},  // 比分为103-86-72
    {kScoreKWPreRatioPattern, ScoreHandler, kScoreKWPatternBody,
     TnChoiceType::kCommaNumber, tts::kSsmlTnAsRatio},  // 比分为8:12
    {kScoreKWPostRatioPattern, ScoreHandler, kScoreKWPatternBody,
     TnChoiceType::kCommaNumber, tts::kSsmlTnAsRatio},  // 比分为103:86:72
    // // time
    {kTimeFullAppendPattern, TimeHandler, kTimePatternBody, TnChoiceType::kNon,
     tts::kSsmlTnAsTime},  // 12:00:23AM, 3:10:23PM
    {kTimePartAppendPattern, TimeHandler, kTimePatternBody, TnChoiceType::kNon,
     tts::kSsmlTnAsTime},  // 12:00AM, 3:10PM

    {kTimeFullPattern, TWTimeHandler, kTimePatternBody,
     TnChoiceType::kCommaNumber, tts::kSsmlTnAsTime},  // 08:23:20 12:00:23AM,
                                                       // 3:10:23PM
    {kTimePartPattern, TWTimeHandler, kTimePatternBody,
     TnChoiceType::kCommaNumber, tts::kSsmlTnAsTime},  // 18:30 12:00AM, 3:10PM
    {kTimeStringFullPattern, TimeHandler, kTimePatternBody, TnChoiceType::kNon,
     tts::kSsmlTnAsTime},  // 17点8分12秒
    {kTimeStringPartPattern, TimeHandler, kTimePatternBody, TnChoiceType::kNon,
     tts::kSsmlTnAsTime},  // 17点8分

    // order
    {kOrdinalPattern, OrdinalHandler, kOrdinalPatternBody, TnChoiceType::kNon,
     tts::kSsmlTnAsOrdinal},
    // number for currency
    {kCurrencyPattern, CurrencyHandler, kCurrencyPatternBody,
     TnChoiceType::kNon, tts::kTnNameCurrency},  // ￥1.4
    {kCurrencyStringPattern, CurrencyHandler, kCurrencyPatternBody,
     TnChoiceType::kNon, tts::kTnNameCurrency},  // RMB28
    {kPreAbbvUnitsPattern, CurrencyHandler, kCurrencyPatternBody,
     TnChoiceType::kNon, tts::kSsmlTnAsOrdinal},  // No.48

    {kTwoYearStrictPattern, DateHandler, kTwoYearPatternBody,
     TnChoiceType::kNumber, tts::kSsmlTnAsDate},  // 98年
    // number for coordinate and race time
    {kCoordinatePattern, CoordinateHandler, kCoordinatePatternBody,
     TnChoiceType::kNon, tts::kTnNameCoordinate},  // 18°09′34″
    {kCoordinatePattern2, CoordinateHandler, kCoordinatePatternBody,
     TnChoiceType::kNon, tts::kTnNameCoordinate},  // 18°09′
    {kRaceTimePattern, CoordinateHandler, kCoordinatePatternBody,
     TnChoiceType::kNon, tts::kSsmlTnAsTime},  // 09′34″
    // number for temperature
    {kTemperaturePattern2, TWTemperatureHandler2, kTemperaturePattern2Body,
     TnChoiceType::kNon, tts::kTnNameTemperature},  // -2到5℃
    {kTemperaturePattern, TWTemperatureHandler, kTemperaturePatternBody,
     TnChoiceType::kNon, tts::kTnNameTemperature},  // 34.32℃
    // symbols: > <
    {kLessOrGreaterPattern1, LessGreaterHandler, kLessGreaterPatternBody,
     TnChoiceType::kNon, kTnNameNon},
    {kLessOrGreaterPattern2, LessGreaterHandler2, kLessGreaterPattern2Body,
     TnChoiceType::kNon, kTnNameNon},
    {kBuildingPattern2, BuildingHandler, kDomainNavigation, kAllBody,
     TnChoiceType::kNon, kTnNameNon},  // 和馨园2栋
    // numbers for measure word
    {kNumberToMeasurePattern, MeasureTrieHandler, kMeasureTriePatternBody,
     TnChoiceType::kNon, kTnNameNon},  // 1.5-1.79亿元
    {kSignedNumberMeasurePattern, MeasureTrieHandler, kMeasureTriePatternBody,
     TnChoiceType::kNon, kTnNameNon},  // -1.79亿元
    {kNumberMeasurePattern, MeasureTrieHandler, kMeasureTriePatternBody,
     TnChoiceType::kNon, kTnNameNon},  // 2079法郎
    {kMeasureTagPattern, MeasureTagHandler, kAllBody, TnChoiceType::kNon,
     kTnNameNon},
    {kNumberKWPrePattern, MeasureWordHandler, kMeasureKWPatternBody,
     TnChoiceType::kPointNumber, kTnNameNon},
    // numbers for measure abbv word
    {kMeasureCombAbbvPattern, MeasureAbbvHandler, kMeasureAbbvPatternBody,
     TnChoiceType::kNon, kTnNameNon},
    {kMeasureAbbvPattern, MeasureAbbvHandler, kMeasureAbbvPatternBody,
     TnChoiceType::kNon, kTnNameNon},

    // date
    {kYearMonthDayPattern, DateHandler, kDatePatternBody,
     TnChoiceType::kBarNumber, tts::kSsmlTnAsDate},  // 2015-03-12
    {kYearMonthPattern, DateHandler, kDatePatternBody, TnChoiceType::kBarNumber,
     tts::kSsmlTnAsDate},  // 2015-03
    {kMonthDayPattern, DateHandler, kDatePatternBody, TnChoiceType::kBarNumber,
     tts::kSsmlTnAsDate},  // 07-03

    // Telephone
    {kTelPattern1, YiTelHandler, kTelPatternBody, TnChoiceType::kNon,
     tts::kSsmlTnAsTelephone},  // +86 010 8231 2343
    {kTelPattern2, YiTelHandler, kTelPatternBody, TnChoiceType::kNon,
     tts::kSsmlTnAsTelephone},  // +86 0721 831 2343
    {kMobilePattern, YiTelHandler, kTelPatternBody, TnChoiceType::kNon,
     tts::kSsmlTnAsTelephone},  // +86 010 8231 2343

    {kStrongSpecialTelPattern1, YiTelHandler, kShortTelPatternBody,
     TnChoiceType::kBarNumber, tts::kSsmlTnAsTelephone},  // 400-811-9090
    {kStrongSpecialTelPattern2, YiTelHandler, kShortTelPatternBody,
     TnChoiceType::kBarNumber, tts::kSsmlTnAsTelephone},  // 4008-811-090
    {kStrongSpecialTelPattern3, YiTelHandler, kShortTelPatternBody,
     TnChoiceType::kNumber, tts::kSsmlTnAsTelephone},  // 95592
    {kWeakSpecialTelPattern1, YiTelHandler, kShortTelPatternBody,
     TnChoiceType::kNumber, tts::kSsmlTnAsTelephone},
    {kWeakSpecialTelPattern2, YiTelHandler, kShortTelPatternBody,
     TnChoiceType::kNumber, tts::kSsmlTnAsTelephone},

    {kCommaNumberPattern, CommaNumberHandler, kCommaNumberPatternBody,
     TnChoiceType::kNon, kTnNameNon},  // 13,000,000

    {kStockPattern1, YiStockHandler, kStockPatternBody, TnChoiceType::kNon,
     tts::kTnNameStock},  // stock  (sz000001)
    {kStockPattern2, YiStockHandler, kStockPatternBody, TnChoiceType::kNon,
     tts::kTnNameStock},  // stock  sz000001
                          // SZ:000001
    {kDiscountPattern, DiscountHandler, kDiscountPatternBody,
     TnChoiceType::kNon, kTnNameNon},  // 9.0折, 9折, 7.5折 95折
    {kSerialNumPattern, YiSerialHandler, kSerialNumberPatternBody,
     TnChoiceType::kNon, tts::kSsmlTnAsDigitYi},  // MU7089 G65 730Li
    {kSerialNumKeyWordPattern, SerialHandler, kSerialNumberPatternBody,
     TnChoiceType::kNumber, tts::kSsmlTnAsDigitYi},  // 1024次列车
    {kFractionPattern, FractionHandler, kFractionPatternBody,
     TnChoiceType::kSlashNumber, tts::kSsmlTnAsFraction},  // 1/2 3/5
    {kPerMeasurePattern, PerHandler, kFractionPatternBody, TnChoiceType::kNon,
     kTnNameNon},  // per 元/人

    {kScoreDefaultPattern, ScoreHandler, kScoreKWPatternBody,
     TnChoiceType::kCommaNumber, tts::kSsmlTnAsRatio},  // 103:86:72
    // symbol -
    {kKeyYearPattern, KeyYearHandler, kYearPatternBody, TnChoiceType::kNumber,
     kTnNameNon},  // 2018新年 喜迎2018
    {kBarPattern1, BarHandler, kBarBuildingPatternBody, TnChoiceType::kNon,
     kTnNameNon},  // 小区黄城根1号楼-1-302
    {kBarPattern2, BarHandler, kBarBuildingPatternBody, TnChoiceType::kNon,
     kTnNameNon},  // 207-3室
    {kDefaultTelPattern, YiTelHandler, kShortTelPatternBody, TnChoiceType::kNon,
     kTnNameNon},
    {kNumberToPattern, BarHandler, kBarToPatternBody, TnChoiceType::kNon,
     kTnNameNon},  // 37.2-43.4℃ 37.2~43.4℃
    {kToPattern, ToHandler, kToPatternBody, TnChoiceType::kNon,
     kTnNameNon},  // 北京 - 上海

    {kGreekPattern, GreekHandler, kAllBody, TnChoiceType::kNon,
     kTnNameNon},  // αβγΓΔδεζηθλμξπ∏ρ∑στφΨΩω
    {kIpPattern, YiIpHandler, kIpPatternBody, TnChoiceType::kPointNumber,
     kTnNameNon},  // 10.2.3.56

    // default patterns
    {kSignedNumberPattern, DefaultNumericalHandler, kNumericalDomain, kAllBody,
     TnChoiceType::kNon, tts::kSsmlTnAsValue},
    {kSignedNumberPattern, YiDefaultDigitalHandler, kDomainCall, kAllBody,
     TnChoiceType::kNon, tts::kSsmlTnAsValue},
    {kUnsignedIntegerPattern, YiDefaultDigitalHandler, kDomainCall, kAllBody,
     TnChoiceType::kNon, tts::kSsmlTnAsValue},
    {kSignedNumberPattern, DefaultNumberHandler, kDefaultNumberBody,
     TnChoiceType::kNon, tts::kSsmlTnAsValue},
    {kUnsignedDecimalPattern, DefaultNumberHandler, kDefaultNumberBody,
     TnChoiceType::kPointNumber, tts::kSsmlTnAsValue},
    {kUnsignedIntegerPattern, DefaultNumberHandler, kDefaultNumberBody,
     TnChoiceType::kNumber, tts::kSsmlTnAsValue},
    {kSymbolPattern, SymbolsHandler, kAllBody, TnChoiceType::kNon, kTnNameNon},
};

}  // namespace mandarin
}  // namespace tn
}  // namespace nlp
#endif  // TTS_NLP_TN_TAIWANESE_TEXT_NORMALIZER_H_
