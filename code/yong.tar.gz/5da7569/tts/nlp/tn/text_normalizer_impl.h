// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_NLP_TN_TEXT_NORMALIZER_IMPL_H_
#define TTS_NLP_TN_TEXT_NORMALIZER_IMPL_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "tts/nlp/tn/text_normalizer_util.h"
#include "tts/nlp/tn/tn_handler.h"
#include "tts/util/ssml/ssml_parser.h"
#include "tts/util/trie/marisa_trie.h"
#include "tts/util/tts_util/tts_data.h"

namespace nlp {
namespace tn {

class TextNormalizerImpl {
 public:
  TextNormalizerImpl(const PatternHandler* pattern_handlers,
                     size_t pattern_number, const FundHandler* fund_handlers,
                     size_t base_number, const string& resource_file);
  ~TextNormalizerImpl();

  bool Normalize(const vector<tts::SsmlText>& ssml_inputs, const string& option,
                 vector<tts::SsmlText>* ssml_outputs) const;
  bool Normalize(const vector<tts::SsmlText>& ssml_inputs, const string& option,
                 vector<tts::SsmlText>* ssml_outputs,
                 tts::TnDetail* detail) const;
  bool Normalize(const string& input, const string& option,
                 string* output) const;
  bool Normalize(const string& input, const string& option, string* output,
                 tts::TnDetail* detail) const;
  void PostProcess(string* text) const;

 private:
  void LoadSpecialNormalizeWords(const string& special_normalize);
  void ParseSsmlTags(const vector<tts::SsmlText>& texts,
                     vector<tts::SsmlText>* text_without_ssml,
                     map<int, string>* offsets_phone,
                     map<int, string>* offsets_pause) const;
  void ParseSsmlRules(tts::SsmlText* ssml_text, int offset,
                      tts::TnDetail* detail) const;
  void SpecialNormalize(string* text, int offset, tts::TnDetail* detail) const;
  // void ProcessHandler(string* text, const TnHandler& tn_handler, int offset,
  //                     tts::TnDetail* detail) const;
  void ProcessPattern(const string& input, const PatternHandler& pattern,
                      string* output, int offset, tts::TnDetail* detail) const;
  bool FundHandlerProcess(const string& input, const string& method,
                          string* output) const;
  void GenerateCandidates(const string& input, const TnChoiceType& choice_type,
                          map<string, string>* candidates) const;
  void RegistPostProcess();
  void PostProcess(string* text, int offset, tts::TnDetail* detail) const;
  // remove front punctuation of first text
  void RemoveFrontPunc(vector<tts::SsmlText>* ssml_output, int offset,
                       tts::TnDetail* detail) const;
  void SsmlPostProcess(tts::TnDetail detail, map<int, string> offsets_phone,
                       map<int, string> offsets_pause,
                       vector<tts::SsmlText>* ssml_outputs) const;

  vector<std::shared_ptr<BaseHandler>> process_handlers_;
  map<string, std::shared_ptr<BaseHandler>> tn_handlers_;
  vector<std::shared_ptr<BaseHandler>> post_process_handlers_;
  std::shared_ptr<BaseHandler> remove_punc_handlers_;

  // measure and place trie
  map<string, std::unique_ptr<trie::MarisaTrie>> trie_;
  // base tn functions
  map<string, BaseFunction> fund_handlers_;
  vector<PatternHandler> pattern_handlers_;
  DISALLOW_COPY_AND_ASSIGN(TextNormalizerImpl);
};

bool ConformOption(const PatternHandler& pattern, const string& option);

}  // namespace tn
}  // namespace nlp
#endif  // TTS_NLP_TN_TEXT_NORMALIZER_IMPL_H_
