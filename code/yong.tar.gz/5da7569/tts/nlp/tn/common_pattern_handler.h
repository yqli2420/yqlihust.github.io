// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_NLP_TN_COMMON_PATTERN_HANDLER_H_
#define TTS_NLP_TN_COMMON_PATTERN_HANDLER_H_

#include "tts/nlp/tn/text_normalizer_util.h"
#include "tts/util/tts_util/util.h"

namespace nlp {
namespace tn {
namespace mandarin {

// common pron
static const char kZeroPron[] = "零";
static const char kTemperaturePron[] = "摄氏";
static const char kNegativeTemperature[] = "零下";
static const char kDuPron[] = "度";
static const Symbol2Pron kTemperature2Pron[] = {
    {"℃", "摄氏度"},  {"°C", "摄氏度"}, {"℉", "华氏度"},
    {"°F", "华氏度"}, {"°", "度"},
};
static const Symbol2Pron kTWTemperature2Pron[] = {
    {"℃", "摄氏"}, {"°C", "摄氏"}, {"℉", "华氏"}, {"°F", "华氏"}, {"°", "摄氏"},
};
static const char kToPron[] = "到";
static const char kSignalTag[] = "<MTag>";

static const char kHourPron[] = "点";
static const char kMinPron[] = "分";
static const char kSecPron[] = "秒";
static const char kEmptyPron[] = "整";

static const size_t kNumberOfUnits = 4;
static const size_t kNumberMaxLength = 16;

// common pattern
static const char kSpacePattern[] = "(\\s?)";
static const char kSignedPattern[] = "([+\\-])";
static const char kIntPattern[] = "(\\d+)";
static const char kFloatPattern[] =
    "((?:\\d{1,3}(?:,\\d{3})+|\\d+)(?:\\.\\d+)?\\s?)";
static const char kDecimalPattern[] = "(([a-zA-Z]+|\\-)?\\d+(\\.\\d+)?)";
static const char kSerialPattern[] = "(\\w*(?:\\d[a-zA-Z]|[a-zA-Z]\\d)\\w*)";
// static const char kSignedFloatPattern[] = "([+\\-]\\d+(?:\\.\\d+)?)";
static const char kNumberFrontBd[] = "(^|[^\\d.])";
static const char kNumberEndBd[] = "($|[^\\d.])";
static const char kEnglishFrontBd[] = "(^|\\W)";
static const char kEnglishEndBd[] = "($|\\W)";
static const char kEnglishNumberFrontBd[] = "(^|[^\\da-zA-Z.])";
static const char kEnglishNumberEndBd[] = "($|[^\\da-zA-Z.])";

// symbol normalize
static const string kSymbolNormalizePattern = "(∶|﹪|：|︰)";

// to symbol: - ~
static const char kToSymbol[] = "(\\s?[～~\\-]+\\s?)";
static const char kMultiToSymbol[] = "(\\s?-+\\s?)";

// to number: 2-3 2~3
static const char kNumberToSymbol[] = "(\\d+[～~\\-]\\d+)";

// customized pattern
static const string kCustomizedPattern =
    string() + "(长)(\\d+~\\d+)" + kNumberEndBd;
static const string kCustomizedPatternBody = "1,2";

// special symbol
static const char kSpecialSymbolPattern[] = "(丨|\\||->|→|<::>|∧)";
static const char kSerialSymbolPattern[] =
    "(Ⅰ|Ⅱ|Ⅲ|Ⅳ|Ⅴ|Ⅵ|Ⅶ|Ⅷ|Ⅸ|Ⅹ|Ⅺ|Ⅻ|ⅰ|ⅱ|ⅲ|ⅳ|ⅴ|ⅵ|ⅶ|ⅷ|ⅸ|ⅹ|①|②|"
    "③|④|⑤|⑥|⑦|⑧|⑨|⑩|⑪|⑫|⑬|⑭|⑮|⑯|⑰|⑱|⑲|⑳|⓪|❶|❷|❸|❹|❺|"
    "❻|❼|❽|❾|❿|⓫|⓬|⓭|⓮|⓯|⓰|⓱|⓲|⓳|⓴|㊀|㊁|㊂|㊃|㊄|㊅|㊆|㊇|㊈|㊉|⑴|"
    "⑵|⑶|⑷|⑸|⑹|⑺|⑻|⑼|⑽|⑾|⑿|⒀|⒁|⒂|⒃|⒄|⒅|⒆|⒇|⒈|⒉|⒊|⒋|⒌|⒍|⒎|⒏|"
    "⒐|⒑|⒒|⒓|⒔|⒕|⒖|⒗|⒘|⒙|⒚|⒛|Ⓐ|Ⓑ|Ⓒ|Ⓓ|Ⓔ|Ⓕ|Ⓖ|Ⓗ|Ⓘ|Ⓙ|Ⓚ|Ⓛ|Ⓜ|Ⓝ|Ⓞ|Ⓟ|"
    "Ⓠ|Ⓡ|Ⓢ|Ⓣ|Ⓤ|Ⓥ|Ⓦ|Ⓧ|Ⓨ|Ⓩ|ⓐ|ⓑ|ⓒ|ⓓ|ⓔ|ⓕ|ⓖ|ⓗ|ⓘ|ⓙ|ⓚ|ⓛ|ⓜ|ⓝ|ⓞ|ⓟ|ⓠ|ⓡ|"
    "ⓢ|ⓣ|ⓤ|ⓥ|ⓦ|ⓧ|ⓨ|ⓩ|⒜|⒝|⒞|⒟|⒠|⒡|⒢|⒣|⒤|⒥|⒦|⒧|⒨|⒩|⒪|⒫|⒬|⒭|⒮|⒯|⒰|"
    "⒱|⒲|⒳|⒴|⒵)";

static const char kSpecialEnglishWord[] =
    "(TFBoys|tfboys|TFboys|TFBOYS|SOHO|soho|Soho|SoHo|MALL|Mall|mall"
    "|IPOD|IPod|ipod|iPod)";
static const string kSpecialEnglishPattern =
    string() + kEnglishFrontBd + kSpecialEnglishWord + kEnglishEndBd;
static const string kSpecialEnglishPatternBody = "1,2";

// subway or building
static const char kSubWayPattern[] = "(^|\\D)(\\d{1,2})(座|口|号线)";
static const char kSubWayPattern2[] = "(^B|\\WB)(\\d)(层?)";
static const string kSubWayPatternBody = "1,2";

static const char kBuildingPattern[] = "(^|\\W)([a-g])(座|口)";
static const char kBuildingPattern2[] = "(^|\\D)(\\d+)(栋)";
static const string kBuildingPatternBody = "1,2";

// radio
static const char kRadioKeyWord[] = "((?:(?:^|\\W)[Ff][Mm]|调频|收听|播放) ?)";
static const char kRadioNumberPattern[] = "(1?\\d\\d)(\\.\\d)?";
static const string kRadioPattern = string() + kRadioKeyWord +
                                    kRadioNumberPattern +
                                    "((?: ?[Mm][Hh][Zz])?)" + kEnglishEndBd;
static const string kRadioPatternBody = "1,4";

// website
static const char kDotPron[] = "`dot`";
static const char kDianPron[] = "`点`";
static const char kAtPron[] = "`at`";
static const char kAllDigitPattern[] = "\\d+";
static const string kWebsitePattern =
    string() + kEnglishFrontBd +
    "((?:\\w+[@.])+(?:com|net|org|gov|edu|int|cn|us))" + kEnglishEndBd;
static const string kWebsitePatternBody = "1,2";

// process @ punctuation in case ambigious with pause level sign "`^@,"
static const string kAtPattern = "(@)";

// special key word
static const char k360WordPost[] =
    "(\\D{0,2}(?:软件|安全卫士|浏览器|安全浏览器|保险箱|隐私保护器|手机|"
    "投资控股|系统急救箱|杀毒|扣扣保镖|手机安全管家|木马防火墙|U盘|单日|"
    "儿童手表|信息安全部|董事长|解密|回归|A股|需要|浏览器|上市|借壳|公司|挑战|"
    "申报|私有化|姚彤|谈|夺|索赔|智能|大师|负责|披露|企业|兼容|门铃|宣布|助手|"
    "遇到|实验室|融合|特供机|率先|公安|独家|纠纷|隐私|多高|多远|宣布|诉|称|"
    "拦截|良医))";
static const char k360WordPre[] =
    "((?:安装|卸载|删除|致谢|加盟|赋能|奇虎|和|上任|昂坪|当|指|因此|搜狗|赋能|"
    "融|回馈|入驻)\\D{0,2})";
static const char kPositionWord[] = "(去|到|前往|来|在|开往)";
static const char kPositionWord2[] = "(动感)";
static const char kPositionPostWord[] = "(店)";
static const char kColleageWord[] =
    "(高校|工程|学校|院校|大学|研究生|博士|博士生|都不是)";
static const char kSpecialNameKW[] = "(事件|事变|国道|省道|乡道|县道|言论)";
static const string k360Pattern1 = string() + "(^|\\D)(360)()" + k360WordPost;
static const string k360Pattern2 = string() + k360WordPre + "(360)($|\\D)";
static const char kAgesPattern[] =
    "(^|\\D)(70|75|80|85|90|95|00)(、)(70|75|80|85|90|95|00)(后)";
static const string kAgesPatternBody = "1,4";
static const char kAgePattern[] = "(^|\\D)(70|75|80|85|90|95|00)()(后|前)";
static const string kColleagePattern =
    string() + "(^|\\D)(985|211)([\\s\"＂”]?\\D{0,5})" + kColleageWord;
static const string kSpecialNamePattern =
    string() + "(^|\\D)(\\d{3})()" + kSpecialNameKW;
static const string kSpecialPlacePattern =
    string() + kPositionWord + "(798)()($|\\D)";
static const string kSpecialPlacePattern3 =
    string() + kPositionWord2 + "(101)()($|\\D)";
static const string kSpecialPlacePattern2 =
    string() + "()(798)" + kPositionPostWord + "($|\\D)";
static const string kSpecialPatternBody = "1,2";

static const char kSpecialNumber[] = "(\\d{2,4})";
static const char kOtherContent[] = "(\\D{0,2})";
static const char kPlaceHolder[] = "()";
static const char kSpecialNumberKWPre[] =
    "(华硕|波音|日航|签署|在了|接到|电话|骁龙|海思|麒麟|高通|歼|鲲鹏|赶集|佳通|"
    "调频|螺纹钢|铀|废除|一颗|驾驶|易美逊|天猫|力帆|荣威|索泰|丰田|本田|神机|"
    "运通|自由豹|七彩虹|星河|酷路泽|保时捷|黑潮|荣耀|宝骏|民进党|比亚迪|"
    "摩托罗拉|宝沃)";
static const char kSpecialNumberKWPost[] =
    "(客机|鱼鹰|直升机|就是|电话|衰变|俱乐部|衰落|裂变|聚变|宪法|三极管|"
    "二极管|主力|服务|系列|敛财|天猫|医院|狂欢|端口|网站|急救|惠农|惠民|航班)";
static const string kSpecialNumberPattern1 = string() + kSpecialNumberKWPre +
                                             kOtherContent + kSpecialNumber +
                                             kPlaceHolder + kNumberEndBd;
static const string kSpecialNumberPattern2 =
    string() + kNumberFrontBd + kPlaceHolder + kSpecialNumber + kOtherContent +
    kSpecialNumberKWPost;
static const string kSpecialNumberPatternBody = "2,3";

// bus number
static const char kBusNumber[] = "(\\d{2,3})";
static const char kBusNumberKWPost[] = "(路|厂)";
static const string kBusNumberPattern =
    string() + kNumberFrontBd + kBusNumber + kBusNumberKWPost;
static const string kBusNumberPatternBody = "1,2";

// special word windows
static const char kSpecialEnglishName1[] =
    "([wW]in|WIN|[wW]indows|WINDOWS|i[pP]hone|[mM]odel|TOP|top|[oO]ffice|[nN]"
    "ote|[mM]ac|MAC|Co|[cC]hromebook|Zen[fF]one|JellyBean|STEMIN|[mM]ate|MATE|"
    "Exynos|Kirin|MEKOA|dota|DOTA|nexus|[sS]tep|[wW]hisky|FLIP|MIX|Mix|Area)("
    "\\s*)";
static const char kSpecialEnglishName2[] =
    "(iOS|ios|LOL|WWDC|FIPS|GTX|LHS|AVX|U|X|T|V|R|N|M|A|F|P|K|Q)(\\s*)";
static const string kSpecialEnglishNamePattern1 =
    string() + kEnglishFrontBd + kSpecialEnglishName1 + "(\\d+(?:\\.\\d+)*)" +
    kEnglishNumberEndBd;
static const string kSpecialEnglishNamePattern2 =
    string() + kEnglishFrontBd + kSpecialEnglishName2 + "(\\d+(?:\\.\\d+)*)" +
    kEnglishNumberEndBd;
static const string kSpecialEnglishNamePatternBody = "1,4";

// 歼-12 618狂欢
static const char kSpecialStrongWord1[] =
    "(人民日报|竞彩|双层|伊尔|安|苏|施华洛世奇|氙|涂|编号|歼|米|天猫|苏宁|魅族|"
    "薇姿|乐视|吾悦|骚扰|看尚|省道|重温|“东风”|ω|(?:\\W|^)(?:S|U|T|K|A|P|F|YF|"
    "UB|GP|M|MG|Amos|AMOS|CRS|XS|CS|SC|KT|RQ|Z|ZX))";
static const char kSpecialStrongWord2[] =
    "(儿童节|网|虐狗日|工作制|锆石|悦街|悼念|警示|协议|牌照|声讯台|联防队员|"
    "购物|机队|乐视|当天)";
static const char kSpecialStrongNumber1[] = "(\\d{1,3})";
static const char kSpecialStrongNumber2[] = "(\\d{3})";
static const string kSpecialStrongWordPattern1 =
    string() + kSpecialStrongWord1 + "((?:”|-)?)" + kSpecialStrongNumber1 +
    kEnglishNumberEndBd;
static const string kSpecialStrongWordPattern2 =
    string() + kEnglishNumberFrontBd + "()" + kSpecialStrongNumber2 +
    kSpecialStrongWord2;
static const string kSpecialStrongWordPatternBody = "1,3";

static const char kNumberEnglishPattern1[] =
    "(^|\\W)([2-9](?:\\.5)?)([dD])($|\\W)";
static const char kNumberEnglishPattern2[] = "(^|\\W)()(T|t)(恤|台)";
static const char kQQEnglishPattern[] = "(^|\\W)(QQ)($|\\W)";
static const string kNumberEnglishPatternBody = "1,3";
static const string kQQEnglishPatternBody = "1,2";

static const char kSPointPattern[] = "(·|・|•|⋅)";
static const string kSpecialPointPattern = string() + kNumberFrontBd +
                                           kIntPattern + kSPointPattern +
                                           kIntPattern + kNumberEndBd;
static const string kSpecialPointPatternBody = "1,4";

// order
static const char kOrdinalKeyWord[] = "(第)";
static const string kOrdinalPattern =
    string() + kOrdinalKeyWord + kIntPattern + kNumberEndBd;

static const string kOrdinalPattern2 =
    string() + kOrdinalKeyWord + kNumberToSymbol + kNumberEndBd;
static const string kOrdinalPatternBody = "1,2";

// temperature
static const string kTemperaturePattern =
    string() + "(^|\\D)(-?)" + kFloatPattern + "(℃|°C|℉|°F|°|摄氏度|华氏度|度)";
static const string kTemperaturePattern2 =
    string() + "(^|\\D)(-?)" + kFloatPattern + "(到|至|~|-)" + "(-?)" +
    kFloatPattern + "(℃|°C|℉|°F|°|摄氏度|华氏度|度)";
static const string kTemperaturePatternBody = "1,4";
static const string kTemperaturePattern2Body = "1,7";

// coordinate
static const Symbol2Pron kCoordinate2Pron[] = {
    {"°", "度"}, {"′", "分"}, {"″", "秒"},
};
static const string kCoordinatePattern = string() + "(^|\\D)" + kFloatPattern +
                                         "(°)" + kFloatPattern + "(′)" +
                                         kFloatPattern + "(″)";
static const string kCoordinatePattern2 = string() + "(^|\\D)" + kFloatPattern +
                                          "(°)" + kFloatPattern + "(′)" +
                                          "()()";
static const string kRaceTimePattern = string() + "(^|\\D)" + "()()" +
                                       kFloatPattern + "(′)" + kFloatPattern +
                                       "(″)";
static const string kCoordinatePatternBody = "1,7";

static const char kNumberPostWord[] = "(多?)";
static const char kMeasureTrieWord[] =
    "([^<\\s\\d])([^<\\s\\d]?)([^<\\s\\d]?)([^<\\s\\d]?)";
static const string kNumberToMeasurePattern =
    string() + kNumberFrontBd + kFloatPattern + kToSymbol + kFloatPattern +
    kNumberPostWord + kMeasureTrieWord;
static const string kSignedNumberMeasurePattern =
    string() + kNumberFrontBd + "()" + kSignedPattern + kFloatPattern +
    kNumberPostWord + kMeasureTrieWord;
static const string kNumberMeasurePattern = string() + kNumberFrontBd + "()()" +
                                            kFloatPattern + kNumberPostWord +
                                            kMeasureTrieWord;
static const char kMeasureKWPre[] = "(人均)";
static const string kNumberKWPrePattern =
    string() + kMeasureKWPre + "([\\d.]+)" + kNumberEndBd;
static const char kMeasureTagPattern[] = "(<MTag>)";
static const string kMeasureTriePatternBody = "1,4";
static const string kMeasureKWPatternBody = "1,2";

// comma number
static const string kCommaNumberPattern =
    string() + kNumberFrontBd + "(-?\\d{1,3}(?:,\\d{3}){1,}(?:\\.\\d+)?)" +
    kNumberEndBd;
static const string kCommaNumberPatternBody = "1,2";

// currency
static const char kCurrencyUnits[] = "([$＄¥￥€£￡₩])";
static const char kCurrencyUnitsString[] = "(HKD|JPY|CNY|RMB|USD)";
static const char kPreAbbvUnits[] = "(N[Oo].)";
// () used to align format with currency string pattern
static const string kCurrencyPattern =
    string() + "()" + kCurrencyUnits + kFloatPattern + "($|\\D)";
static const string kCurrencyStringPattern = string() + "(^|[^a-zA-Z])" +
                                             kCurrencyUnitsString +
                                             kFloatPattern + "($|\\D)";
static const string kPreAbbvUnitsPattern =
    string() + "(^|[^a-zA-Z])" + kPreAbbvUnits + kIntPattern + kNumberEndBd;
static const string kCurrencyPatternBody = "1,3";

// TODO(zhengzhang): 3G网络 3G硬盘 3g药材 M兆 2B
static const char kMeasureAbbv[] =
    "([kK][mM]|[dD][mM]|[cC][mM]|[mM][mM]|[nN][mM]"  // distance
    "|[gG][bB]|[mM][bB]|[kK][bB]"                    // memory
    "|[kK][gG]"                                      // weight
    "|ml|mL"                                         // volume
    "|[kK]bps|[mM]bps|mAh"
    "|g|G|m|L|M|K|T|[wW]|[sS]|[hH]|[bB])";  // single measure
static const string kMeasureAbbvPattern = string() + kEnglishNumberFrontBd +
                                          kFloatPattern + kSpacePattern +
                                          kMeasureAbbv + "()()($|[^A-Za-z0-9])";
static const string kMeasureCombAbbvPattern =
    string() + kEnglishNumberFrontBd + kFloatPattern + kSpacePattern +
    kMeasureAbbv + "(/)" + kMeasureAbbv + "($|[^A-Za-z0-9])";
static const string kMeasureAbbvPatternBody = "1,6";

// date pattern
static const char kYearSeperate[] = "(年)";
static const char kMonthSeperate[] = "(月)";
static const char kDaySeperate[] = "(日|号)";
static const char kDateSeperate[] = "([·|・|•|⋅|.|:|\\-/])";
static const char kKeyYears[] = "(19\\d\\d|20\\d\\d)";
static const char kYearFrontBd[] = "(^|[^.\\w])";
static const char kYearEndBd[] = "($|[^.\\w])";
static const char kYearPattern[] = "(1[6-9]\\d{2}|2[0-4]\\d{2})";
static const char kTwoYearPattern[] = "(9\\d|0\\d)";
static const char kMonthPattern[] = "(0?[1-9]|1[0-2])";
static const char kMonthStrictPattern[] = "(0[1-9])";
static const char kDayPattern[] = "(0?[1-9]|[12]\\d|3[01])";
static const char kDayStrictPattern[] = "(0[1-9]|[12]\\d|3[01])";
static const char kDateFrontBd[] = "(^[./\\-]?|\\D[./\\-]|[^\\d./\\-])";
static const char kDateEndBd[] = "([./\\-]?$|[./\\-][^\\d]|[^\\d./\\-])";
static const char kMonthDayKWPre[] = "(天猫|届|聚焦|定档|适逢|天隆)";
static const char kMonthDayKWPost[] =
    "(促销|护士节|庆生|”|专案组|女王节|女神节|妇女节|楼市|移动|音乐节|事变|"
    "玫瑰|媒体|宝马|活动|电商节|互联网|免费日|打击|网络|假期|晚评|专案组)";
static const string kSimpleYearMonthDayPattern = string() + kYearPattern +
                                                 kDateSeperate + kMonthPattern +
                                                 kDateSeperate + kDayPattern;
static const string kSimpleYearMonthPattern =
    string() + kYearPattern + kDateSeperate + kMonthPattern;
static const string kSimpleMonthDayPattern =
    string() + kMonthPattern + kDateSeperate + kDayPattern;
static const string kTwoYearStrictPattern =
    string() + kDateFrontBd + kTwoYearPattern + "(年)()()()()()";
static const string kYearMonthDayPattern =
    string() + kDateFrontBd + kYearPattern + kDateSeperate + kMonthPattern +
    kDateSeperate + kDayPattern + "()" + kDateEndBd;
static const string kYearMonthDayStringPattern =
    string() + kDateFrontBd + kYearPattern + kYearSeperate + kMonthPattern +
    kMonthSeperate + kDayPattern + kDaySeperate + "()";
static const string kYearMonthPattern = string() + kDateFrontBd + kYearPattern +
                                        kDateSeperate + kMonthPattern +
                                        "()()()" + kDateEndBd;
static const string kYearMonthStringPattern =
    string() + kDateFrontBd + kYearPattern + kYearSeperate + kMonthPattern +
    kMonthSeperate + "()()()";
static const string kMonthDayPattern = string() + kDateFrontBd + "()()" +
                                       kMonthStrictPattern + kDateSeperate +
                                       kDayStrictPattern + "()" + kDateEndBd;
static const string kMonthDayStringPattern = string() + kDateFrontBd + "()()" +
                                             kMonthPattern + kMonthSeperate +
                                             kDayPattern + kDaySeperate + "()";
static const string kMonthDayKWPattern1 =
    string() + kMonthDayKWPre + "([^a-zA-Z\\d]{0,2})" + kSimpleMonthDayPattern +
    "()" + kEnglishNumberEndBd;
static const string kMonthDayKWPattern2 =
    string() + kEnglishNumberFrontBd + "()" + kSimpleMonthDayPattern +
    "([^a-zA-Z\\d]{0,2})" + kMonthDayKWPost;
static const string kSingleYearPattern =
    string() + "(^|[^\\d.])" + kYearPattern + "(\\s*(?:年|届|款))";
static const string kKeyYearPattern =
    string() + kYearFrontBd + kKeyYears + kYearEndBd;
static const string kSingleYearPatternBody = "1,3";
static const string kDatePatternBody = "1,7";
static const string kTwoYearPatternBody = "1,2";
static const string kYearPatternBody = "1,2";
static const string kMonthDayKWPatternBody = "2,5";

// time pattern
static const char kTimeSeperate[] = "(:)";
static const char kHourPattern[] = "(0?\\d|1\\d|2[0-3])";
static const char kMinSecPattern[] = "([0-5]\\d)";
static const char kMinSecStringPattern[] = "([0-5]?\\d)";
static const char kTimeFrontBd[] = "(^|[^\\d.:]|^:|\\D:)";
static const char kTimeEndBd[] = "(\\.?$|\\.?[^\\d:])";
static const char kTimeAppendEndBd[] = "($|[^a-z])";
static const string kTimeFullPattern =
    string() + kTimeFrontBd + kHourPattern + kTimeSeperate + kMinSecPattern +
    kTimeSeperate + kMinSecPattern + "()()" + kTimeEndBd;
static const string kTimeFullAppendPattern =
    string() + kTimeFrontBd + kHourPattern + kTimeSeperate + kMinSecPattern +
    kTimeSeperate + kMinSecPattern + "()([aApP]\\.?[mM])" + kTimeAppendEndBd;
static const string kTimePartPattern = string() + kTimeFrontBd + kHourPattern +
                                       kTimeSeperate + kMinSecPattern +
                                       "()()()()" + kTimeEndBd;
static const string kTimePartAppendPattern =
    string() + kTimeFrontBd + kHourPattern + kTimeSeperate + kMinSecPattern +
    "()()()" + "([aApP]\\.?[mM])" + kTimeAppendEndBd;
static const string kTimeStringFullPattern =
    string() + kTimeFrontBd + kHourPattern + "(点)" + kMinSecStringPattern +
    "(分)" + kMinSecStringPattern + "(秒)()()";
static const string kTimeStringPartPattern =
    string() + kTimeFrontBd + kHourPattern + "(点)" + kMinSecStringPattern +
    "(分)" + "()()()()";
static const string kHourMinuteSecondPattern = string() + kHourPattern +
                                               kTimeSeperate + kMinSecPattern +
                                               kTimeSeperate + kMinSecPattern;
static const string kHourMinutePattern =
    string() + kHourPattern + kTimeSeperate + kMinSecPattern;
static const string kTimePatternBody = "1,8";

// telephone pattern
static const char kTelSeperate[] = "([\\- ]?)";
static const char kCountryCode[] = "((?:\\(?\\+?8\\d\\)?)?)";
static const char kAreaCode[] = "((?:\\(?(?:\\d{3}|0\\d{3})\\)?)?)";
static const char kMobileHead[] = "(1[35789]\\d)";
static const char kTelFrontBd[] = "(^|\\D\\s|[^\\d.\\-])";
static const char kTelEndBd[] = "($|\\s\\D|[^\\d.\\-])";
static const char kTelKeyWord[] = "(电话|手机|号码|来电|热线|打|拨|开头|报警)";
static const string kTelPattern1 = string() + kTelFrontBd + "()" +
                                   kCountryCode + kTelSeperate + kAreaCode +
                                   kTelSeperate + "(\\d{4})" + kTelSeperate +
                                   "(\\d{4}|\\*\\*\\*\\*)" + "()" + kTelEndBd;
static const string kTelPattern2 = string() + kTelFrontBd + "()" +
                                   kCountryCode + kTelSeperate + kAreaCode +
                                   kTelSeperate + "([1-9]\\d{2})" +
                                   kTelSeperate + "(\\d{4})" + "()" + kTelEndBd;
static const string kMobile =
    string() + kCountryCode + kTelSeperate + kMobileHead + kTelSeperate +
    "(\\d{4}|\\*\\*\\*\\*)" + kTelSeperate + "(\\d{4})";
static const string kStrongMobilePattern1 =
    string() + kTelKeyWord + "(\\D{0,3})" + kMobile + "()" + kTelEndBd;
static const string kStrongMobilePattern2 =
    string() + kTelFrontBd + "()" + kMobile + "([^\\d,.]{0,3})" + kTelKeyWord;
static const string kMobilePattern =
    string() + kTelFrontBd + "()" + kMobile + "()" + kTelEndBd;
static const string kStrongSpecialTel1 = string() + "(400\\d)" + kTelSeperate +
                                         "(\\d{3})" + kTelSeperate + "(\\d{3})";
static const string kStrongSpecialTel2 =
    string() + "(400)" + kTelSeperate + "(\\d{3})" + kTelSeperate + "(\\d{4})";
static const char kStrongSpecialTel3[] =
    "(955\\d{2}|12306|10086|10010|10001)()()()()";
static const char kWeakSpecialTel[] = "(110|119|120|114|911|\\d{3,5})()()()()";
static const char kDefaultTel[] = "(\\d+)(-)(\\d+)(-)(\\d+)";
static const string kStrongSpecialTelPattern1 =
    string() + kTelFrontBd + "()" + kStrongSpecialTel1 + "()" + kTelEndBd;
static const string kStrongSpecialTelPattern2 =
    string() + kTelFrontBd + "()" + kStrongSpecialTel2 + "()" + kTelEndBd;
static const string kStrongSpecialTelPattern3 =
    string() + kTelFrontBd + "()" + kStrongSpecialTel3 + "()" + kTelEndBd;
static const string kWeakSpecialTelPattern1 =
    string() + kTelKeyWord + "(\\D{0,3})" + kWeakSpecialTel + "()" + kTelEndBd;
static const string kWeakSpecialTelPattern2 = string() + kTelFrontBd + "()" +
                                              kWeakSpecialTel + "(\\D{0,3})" +
                                              kTelKeyWord;
static const string kDefaultTelPattern =
    string() + kTelFrontBd + "()" + kDefaultTel + "()" + kTelEndBd;
static const string kTelPatternBody = "2,9";
static const string kShortTelPatternBody = "2,7";

// score pattern
static const char kScorePreKeyWord[] =
    "(比分|力克|缺阵|结果|哑火|落后|领先|比|胜|赢|输|败|马竞|马拉加|破门|破网|"
    "一方|球|国安|中国队|上港|中国|国足|男篮|男排|女足|女篮|女排|双方|主场|"
    "客场|鲁能|血洗|总分|恒大)";
static const char kScorePostKeyWord[] =
    "(力克|缺阵|结果|哑火|落后|领先|胜|赢|输|败|马竞|马拉加|告负|国安|前锋|球|"
    "不敌|逆转|富力|晋级|战平|血洗|憾平|紧追|锁定|扳平|淘汰)";
static const char kScoreRatioPattern[] =
    "(\\d+(?:\\.\\d+)?(?::\\d+(?:\\.\\d+)?)+)";
static const char kScoreToPattern[] = "(\\d+-\\d+)";
static const string kScoreKWPreToPattern = string() + kScorePreKeyWord +
                                           "(\\D{0,7})" + kScoreToPattern +
                                           "()($|[^\\d.\\-])";
static const string kScoreKWPostToPattern = string() + "(^|[^\\d.\\-])()" +
                                            kScoreToPattern + "(\\D{0,4})" +
                                            kScorePostKeyWord;
static const string kScoreKWPreRatioPattern =
    string() + kScorePreKeyWord + "(\\D{0,7})" + kScoreRatioPattern +
    "()($|[^\\d.])";
static const string kScoreKWPostRatioPattern = string() + "(^|[^\\d.])()" +
                                               kScoreRatioPattern +
                                               "(\\D{0,4})" + kScorePostKeyWord;
static const string kScoreDefaultPattern =
    string() + "(^|[^\\d.])()" + kScoreRatioPattern + "()($|[^\\d.])";
static const string kNumberBarPattern =
    "(\\d+(?:\\.\\d+)?(?:-\\d+(?:\\.\\d+)?)+)";
static const string kNumberSlashPattern =
    "(\\d+(?:\\.\\d+)?(?:/\\d+(?:\\.\\d+)?)+)";
static const string kNumberCommaPattern = kScoreRatioPattern;
static const string kScoreKWPatternBody = "2,3";

// percent
static const char kPercentFrontBd[] = "(^|[^\\d.%‰])";
static const string kSignedPercentPattern =
    string() + kPercentFrontBd + kSignedPattern + kFloatPattern + "([%‰])";
static const string kPercentPattern =
    string() + kNumberFrontBd + "()" + kFloatPattern + "([%‰])";
static const string kPercentPatternBody = "1,4";

// discount
static const string kDiscountPattern =
    string() + kNumberFrontBd + "(\\d)(\\.?)(\\d)(折)";
static const string kDiscountPatternBody = "1,4";

// fraction
static const string kFractionPattern =
    string() + kNumberFrontBd + "(\\d+)(/)(\\d+)" + kNumberEndBd;
static const string kSimpleFractionPattern = "(\\d+)(/)(\\d+)";
static const string kFractionPatternBody = "1,4";

// per
static const char kCombMeasureWord[] =
    "(元|人|天|吨|小时|分|秒|毫秒|米|公里|千米|公里|次|克|公斤|斤|两|只)";
static const string kPerMeasurePattern =
    string() + kCombMeasureWord + "(/)" + kCombMeasureWord;

// stock
static const string kStockPattern1 = string() + kEnglishFrontBd +
                                     "(\\((?:[sS][hHzZ])?)(:?\\d{6}\\))" +
                                     kNumberEndBd;
static const string kStockPattern2 =
    string() + kEnglishFrontBd + "([sS][hHzZ])(:?\\d{6})" + kNumberEndBd;

static const string kManToneSymbolPattern =
    string() + "(^|[a-zA-Z]{0,})" +
    "(ā|á|ǎ|à|ō|ó|ǒ|ò|ē|é|ě|è|ī|í|ǐ|ì|ū|ú|ǔ|ù|ǖ|ǘ|ǚ|ǜ|ä|ë|ö|ü|Ü|å|ç|Å|Á|À|Ă|ă|"
    "Ắ|ắ|Ằ|ằ|Ẵ|ẵ|Ẳ|ẳ|Â|â|Ấ|ấ|Ầ|ầ|Ẫ|ẫ|Ẩ|ẩ|Ǎ|Ǻ|ǻ|Ä|Ǟ|ǟ|Ã|ã|Ȧ|ȧ|Ǡ|ǡ|Ą|ą|Ā|Ả|ả|Ȁ|ȁ|"
    "Ȃ|ȃ|Ạ|ạ|Ặ|ặ|Ậ|ậ|Ḁ|ḁ|Ⱥ|ⱥ̱|ø|ô)" +
    "(^|[a-zA-Z]{0,})";

static const string kStockPatternBody = "1,3";

// serial number
static const string kSerialNumPattern =
    string() + "(^|[^.\\w])" + kSerialPattern + "($|[^.\\w])";
static const string kSerialNumKeyWordPattern =
    string() + kNumberFrontBd + "(\\d{3,})" + "((?:次)?列车)";
static const string kSerialNumberPatternBody = "1,2";

// to pattern
static const char kBarPostKeyWord[] = "(室)";
static const char kBarPreKeyWord[] =
    "(楼|巷|甲|乙|丙|丁|园|杠|苑|区|堡|城|街|期|豪庭|单元|家园|北里|南里"
    "|东里|西里|公寓|广场|宿舍|号院)";
static const string kBarPattern1 = string() + kBarPreKeyWord + "(.{0,4})" +
                                   kMultiToSymbol +
                                   "([一二三四五六七八九零0-9]+)()";
static const string kBarPattern2 =
    string() + "()([一二三四五六七八九零0-9]+)" + kMultiToSymbol +
    "([一二三四五六七八九零0-9]+)" + kBarPostKeyWord;
static const string kNumberToPattern = string() + "()([^-])" + kToSymbol +
                                       "([一二三四五六七八九零十百千1-9]|0.|"
                                       "(?:晚上|凌晨|上午|中午|下午|早上|摄氏|"
                                       "华氏)[一二三四五六七八九零十百千1-9])("
                                       ")";
static const string kToPattern =
    string() + "(\\S{2,5})" + kMultiToSymbol + "(\\S{2,5})";
static const string kBarBuildingPatternBody = "2,4";
static const string kBarToPatternBody = "2,3";
static const string kToPatternBody = "1,2";

// math pattern
static const char kMathFloatPattern[] =
    "(?:-?(?:\\d{1,3}(?:,\\d{3})+|\\d+)(?:\\.\\d+)?(?:[%‰])?)";
static const char kMathSymbolPattern[] = "(?:[+*/\\-()\\[\\]=<>{}]+?)";
static const char kMathSymbolStringPattern[] =
    "(?:加上|减去|乘以|除以|等于|大于|小于|加|减|乘|除)";
static const string kMathPattern1 =
    string() + "(^|[^\\d\\-])(" + kMathFloatPattern + "(?:" +
    kMathSymbolPattern + kMathFloatPattern + "){2,})" + "($|\\D)";
static const string kMathPattern2 =
    string() + "(^|[^\\d\\-])(" + kMathFloatPattern + "(?:" +
    kMathSymbolPattern + kMathFloatPattern + "){1,}(?:" +
    kMathSymbolStringPattern + kMathFloatPattern + "){1,})" + "($|\\D)";
static const string kMathStringPattern1 =
    string() + "(^|[^\\d\\-])((?:" + kMathFloatPattern +
    kMathSymbolStringPattern + "){1,}" + kMathFloatPattern + "?)" + "($|\\D)";
static const string kMathStringPattern2 = string() + "()((?:" +
                                          kMathSymbolStringPattern +
                                          kMathFloatPattern + "){1,})($|\\D)";
static const string kMathExpressionPattern =
    "(\\d+(?:\\.\\d+)?(?:[+\\-*/=]\\d+(?:\\.\\d+)?)+)";

// ip pattern: 10.2.3.256
static const string kIpPattern =
    string() + kNumberFrontBd + "(\\d+(?:\\.\\d+){2,})" + kNumberEndBd;
static const string kIpPatternBody = "1,2";

// PM
static const string kPMPattern =
    string() + "(PM[ ]?)" + kFloatPattern + "($|[^\\d.])";
static const string kPMPatternBody = "1,2";

// wenyan private
static const char kWenyanNumberPattern[] = "(\\d+)";

// 3000x2000
static const char kMultiSymbol[] = "(\\s*(?:[*xX]|×)\\s*)";
static const string kMultiSymbolPattern1 =
    string() + kNumberFrontBd + kFloatPattern + kMultiSymbol + kFloatPattern +
    kMultiSymbol + kFloatPattern + kMeasureAbbv + kEnglishNumberEndBd;
static const string kMultiSymbolPattern2 =
    string() + kNumberFrontBd + kFloatPattern + kMultiSymbol + kFloatPattern +
    "()()" + kMeasureAbbv + kEnglishNumberEndBd;
static const string kMultiSymbolPattern3 =
    string() + kNumberFrontBd + kFloatPattern + kMultiSymbol + kFloatPattern +
    kMultiSymbol + kFloatPattern + "()" + kEnglishNumberEndBd;
static const string kMultiSymbolPattern4 =
    string() + kNumberFrontBd + kFloatPattern + kMultiSymbol + kFloatPattern +
    "()()()" + kEnglishNumberEndBd;
static const string kMultiSymbolPatternBody = "1,7";

// english
static const char kEnglishPattern[] = "([a-zA-Z]+)";

static const char kValueNumberKWPre[] = "(突破|悬赏|回踩|派遣|集|订单|豪礼)";
static const char kValueNumberKWPost[] =
    "(跌破|反复|幼师|志愿者|榜|陌生人|侄子|摘)";
static const string kValueNumberPattern1 =
    string() + kValueNumberKWPre + kIntPattern + kNumberEndBd;
static const string kValueNumberPattern2 =
    string() + kNumberFrontBd + kIntPattern + kValueNumberKWPost;
static const string kValueNumberPatternBody = "1,2";

// default
static const char kCapitalEnglishPattern[] =
    "(^|[^a-zA-Z])((?:[a-zA-Z]+[A-Z][a-zA-Z]*)|(?:[a-zA-Z]*[A-Z][a-zA-Z]+))($|"
    "[^a-zA-Z])";
static const string kEnglishPatternBody = "1,2";

static const char kSignedNumberPattern[] =
    "(^|\\D)(-[\\d]+(?:\\.\\d+)?)($|\\D)";
static const char kUnsignedDecimalPattern[] =
    "(^|\\D)([\\d]+(?:\\.\\d+))($|\\D)";
static const char kUnsignedIntegerPattern[] = "(^|\\D)([\\d]+)($|\\D)";
static const string kDefaultNumberBody = "1,2";

// symbol: > < (e.g. >5 大于五)
static const char kLessOrGreaterPattern1[] = "(-?[\\d]+(?:\\.\\d+)?)(<|>)";
static const char kLessOrGreaterPattern2[] = "(<|>)(-?[\\d]+(?:\\.\\d+)?)";
static const char kSymbolPattern[] =
    "([#%$&+\\-'‘’*_<>=㎡~/]|≈|¥|°C|℃|℉|°F|•|~|・)";
static const char kGreekPattern[] = "([αβγΓΔδεζηθλμξπ∏ρ∑στφΨΩωχνψυ])";
static const string kLessGreaterPatternBody = "1,2";
static const string kLessGreaterPattern2Body = "0,1";

// common function
enum SearchDirection {
  kForward = 0,
  kBackward,
};
bool PlaceSearch(const string& place_str, const SearchDirection& direction,
                 const map<string, std::unique_ptr<trie::MarisaTrie>>& trie);
string GetPronForNumString(const string& number, bool is_liang);
string ReadAsDigit(const string& input);
string ReadAsDigitYao(const string& input);
string ReadAsDigitYi(const string& input);
string ReadAsDigit(const string& input, bool is_yao);
string ReadAsValue(const string& input);
string ReadAsValueLiang(const string& input);
string ReadAsValueEr(const string& input);
string ReadAsDecimalValueLiang(const string& input);
string ReadAsDecimalValueEr(const string& input);
string ReadAsDecimalValueLiangSigned(const string& input);
string ReadAsDecimalValueErSigned(const string& input);
string ReadAsTwEmail(const string& input);
string ReadAsTwDigitString(const string& input);
string TwDigitStringReading(const string& input, bool is_yao);
string ReadAsValue(const string& input, bool is_liang, bool is_unsigned);
// 2号楼206 -> 2 号楼 206
void SplitStringByNumber(const string& input, vector<string>* output,
                         vector<bool>* is_digit);
string ReadAsSerial(const string& input);
// input any text, read number as serial, read - as 杠, others remain
// e.g. 2楼203-204 -> 二楼二零三杠二零四
string ReadAsBuilding(const string& input);
string ReadAsFestival(const string& input);
string TelephoneReading(const string& input, bool is_yao);
string ReadAsTelephone(const string& input);
string YiReadAsTelephone(const string& input);
string ReadAsNumberTime(const string& input);
string ReadAsTime(const string& input);
string ReadAsName(const string& input);
string ReadAsBook(const string& input);
string ReadAsDate(const string& input);
string ReadAsRatio(const string& input);
string ReadAsScale(const string& input);
string ReadAsMath(const string& input);
string ReadAsFraction(const string& input);
string ReadAsAlphabet(const string& input);    // bat -> B A T
string ReadAsWord(const string& input);        // BAT -> bat
string ReadAsSymbol(const string& input);      // return ^
string ReadAsWebsite(const string& input);     // return www`dot`baidu`dot`com
string ReadAsManWebsite(const string& input);  // return www`点`baidu`点`com
string ReadAsWebsite(const string& input, bool is_man);

// common handler
void SymbolNormalizeHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void CustomizedHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void SpecialSymbolHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void SerialSymbolHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void SpecialEnglishHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void SubwayHandler(const re2::StringPiece* str_args, int args_num,
                   const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                   string* output);
void LowerBuildingHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void BusNumberHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void SpecialNameHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void YiSpecialNameHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void SpecialEnglishNameHandler1(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void SpecialEnglishNameHandler2(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void SpecialStrongWordHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void SpecialPointHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void YiSpecialPointHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void SpecialCaseHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void YiSpecialCaseHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void SpecialNumberHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void RadioHandler(const re2::StringPiece* str_args, int args_num,
                  const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                  string* output);
void YiRadioHandler(const re2::StringPiece* str_args, int args_num,
                    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                    string* output);
void WebsiteHandler(const re2::StringPiece* str_args, int args_num,
                    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                    string* output);
void YiWebsiteHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void AtHandler(const re2::StringPiece* str_args, int args_num,
               const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
               string* output);
void NumberEnglishHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void YiNumberEnglishHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void QQEnglishHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void MathHandler(const re2::StringPiece* str_args, int args_num,
                 const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                 string* output);
void PMHandler(const re2::StringPiece* str_args, int args_num,
               const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
               string* output);
void DateHandler(const re2::StringPiece* str_args, int args_num,
                 const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                 string* output);
void YearHandler(const re2::StringPiece* str_args, int args_num,
                 const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                 string* output);
void MonthDayHandler(const re2::StringPiece* str_args, int args_num,
                     const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                     string* output);
void CommaNumberHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void PercentHandler(const re2::StringPiece* str_args, int args_num,
                    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                    string* output);
void ScoreHandler(const re2::StringPiece* str_args, int args_num,
                  const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                  string* output);
void TimeHandler(const re2::StringPiece* str_args, int args_num,
                 const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                 string* output);
void OrdinalHandler(const re2::StringPiece* str_args, int args_num,
                    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                    string* output);
void CurrencyHandler(const re2::StringPiece* str_args, int args_num,
                     const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                     string* output);
void CoordinateHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void TemperatureHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void TemperatureHandler2(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void MeasureTagHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void MeasureWordHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void MeasureAbbvHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void TelHandler(const re2::StringPiece* str_args, int args_num,
                const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                string* output);
void YiTelHandler(const re2::StringPiece* str_args, int args_num,
                  const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                  string* output);
void StockHandler(const re2::StringPiece* str_args, int args_num,
                  const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                  string* output);
void YiStockHandler(const re2::StringPiece* str_args, int args_num,
                    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                    string* output);
void DiscountHandler(const re2::StringPiece* str_args, int args_num,
                     const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                     string* output);
void SerialHandler(const re2::StringPiece* str_args, int args_num,
                   const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                   string* output);
void YiSerialHandler(const re2::StringPiece* str_args, int args_num,
                     const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                     string* output);
void BuildingHandler(const re2::StringPiece* str_args, int args_num,
                     const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                     string* output);
void FractionHandler(const re2::StringPiece* str_args, int args_num,
                     const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                     string* output);
void PerHandler(const re2::StringPiece* str_args, int args_num,
                const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                string* output);
void BarHandler(const re2::StringPiece* str_args, int args_num,
                const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                string* output);
void ToHandler(const re2::StringPiece* str_args, int args_num,
               const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
               string* output);
void MeasureTrieHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void GreekHandler(const re2::StringPiece* str_args, int args_num,
                  const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                  string* output);
void ManToneSymbolHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void KeyYearHandler(const re2::StringPiece* str_args, int args_num,
                    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                    string* output);
void IpHandler(const re2::StringPiece* str_args, int args_num,
               const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
               string* output);
void YiIpHandler(const re2::StringPiece* str_args, int args_num,
                 const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                 string* output);
void DefaultNumericalHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void DefaultDigitalHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void YiDefaultDigitalHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void WenyanNumberHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void MultiSymbolHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void ValueNumberHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void DefaultNumberHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void SymbolsHandler(const re2::StringPiece* str_args, int args_num,
                    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
                    string* output);
void DefaultEnglishHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);

void LessGreaterHandler(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
void LessGreaterHandler2(
    const re2::StringPiece* str_args, int args_num,
    const map<string, std::unique_ptr<trie::MarisaTrie>>& trie, string* output);
static const FundHandler kMandarinFundHandlers[] = {
    {tts::kSsmlTnAsTwEmail, ReadAsTwEmail},
    {tts::kSsmlTnAsTwDS, ReadAsTwDigitString},
    {tts::kSsmlTnAsDigits, ReadAsDigit},
    {tts::kSsmlTnAsValue, ReadAsValue},
    {tts::kSsmlTnAsContact, ReadAsName},
    {tts::kSsmlTnAsBookName, ReadAsBook},
    {tts::kSsmlTnAsBuilding, ReadAsBuilding},
    {tts::kSsmlTnAsFestival, ReadAsFestival},
    {tts::kSsmlTnAsTelephone, ReadAsTelephone},

    {tts::kSsmlTnAsValueLiang, ReadAsDecimalValueLiang},
    {tts::kSsmlTnAsValueEr, ReadAsDecimalValueEr},
    {tts::kSsmlTnAsValueLiangSigned, ReadAsDecimalValueLiangSigned},
    {tts::kSsmlTnAsValueErSigned, ReadAsDecimalValueErSigned},

    {tts::kSsmlTnAsDigitYao, ReadAsDigitYao},
    {tts::kSsmlTnAsDigitYi, ReadAsDigitYi},
    {tts::kSsmlTnAsDate, ReadAsDate},
    {tts::kSsmlTnAsRatio, ReadAsRatio},
    {tts::kSsmlTnAsScale, ReadAsScale},
    {tts::kSsmlTnAsMath, ReadAsMath},
    {tts::kSsmlTnAsTime, ReadAsTime},
    {tts::kSsmlTnAsFraction, ReadAsFraction},
    {tts::kSsmlTnAsTelephone, ReadAsTelephone},
    {tts::kSsmlTnAsAlphabet, ReadAsAlphabet},
    {tts::kSsmlTnAsWord, ReadAsWord},
    {tts::kSsmlTnAsSymbol, ReadAsSymbol},
    {tts::kSsmlTnAsWebsite, ReadAsWebsite},
    {tts::kSsmlTnAsManWebsite, ReadAsManWebsite},
};

}  // namespace mandarin
}  // namespace tn
}  // namespace nlp
#endif  // TTS_NLP_TN_COMMON_PATTERN_HANDLER_H_
