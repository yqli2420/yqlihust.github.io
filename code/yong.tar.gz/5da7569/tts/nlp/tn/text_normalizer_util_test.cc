// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/nlp/tn/text_normalizer_util.h"

#include "mobvoi/base/file/simple_line_reader.h"
#include "third_party/gtest/gtest.h"

namespace nlp {
namespace tn {

static const string kTestDataDir = "tts/nlp/tn/testdata/";  // NOLINT

inline void ReadFileLines(const string& filename, vector<string>* lines) {
  file::SimpleLineReader reader(filename, true, "#");
  reader.ReadLines(lines);
}

// TEST(TnUtilTest, PostProcess) {
//   string test_file = kTestDataDir + "postprocess_test.txt";
//   string expect_file = kTestDataDir + "postprocess_expect.txt";
//   vector<string> input;
//   vector<string> expect;
//   ReadFileLines(test_file, &input);
//   ReadFileLines(expect_file, &expect);
//   EXPECT_EQ(input.size(), expect.size());
//   for (size_t i = 0; i < input.size(); ++i) {
//     PostProcess(&input[i]);
//     EXPECT_EQ(expect[i], input[i]) << expect[i] << "\n" << input[i];
//   }
// }

// TEST(TnUtilTest, RemoveRepeatPunc) {
//   string raw_text =
//       "出台,中国落实2030年可持续发展议程国别方案,,.,在经济.`^^社会^,^,取得..."
//       "诸多早期收获。";
//   const string& expect_text =
//       "出台,中国落实2030年可持续发展议程国别方案.在经济.社会,取得."
//       "诸多早期收获。";
//   RemoveRepeatPunc(&raw_text);
//   EXPECT_EQ(expect_text, raw_text) << expect_text << "\n" << raw_text;
// }

}  // namespace tn
}  // namespace nlp
