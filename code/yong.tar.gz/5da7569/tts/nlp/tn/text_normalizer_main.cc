// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/nlp/tn/text_normalizer.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/time.h"
#include "mobvoi/util/utf8/utf8_util.h"
#include "third_party/perftools/heap-profiler.h"
#include "third_party/perftools/profiler.h"
#include "tts/util/ssml/ssml_parser.h"

DEFINE_string(input, "MU5130北京首都机场, 80折, 票价￥1230", "input text");
DEFINE_string(input_file, "", "");
DEFINE_string(tn_config, "external/config/front_end/tn/man_tn.conf",
              "tn resource config directory");
DEFINE_string(language, "Mandarin",
              "Mandarin | Taiwanese | Cantonese | English");
DEFINE_string(domain, "", "tn domain");
DEFINE_string(output_file, "", "");

DEFINE_bool(heap_profile, false, "If true, enable heap profile");
DEFINE_bool(cpu_profile, false, "If true, enable heap profile");
DEFINE_bool(benchmark, false, "If true, use benchmark text instead");
DEFINE_string(benchmarkfile,
              "tts/nlp/tn/testdata/text_normalizer_benchmark.txt", "");

int TextNormalize(
    const std::shared_ptr<nlp::tn::TextNormalizer> text_normalizer,
    const vector<string>& input_texts, const string& output_file) {
  int total_length = 0;
  vector<string> tn_result;
  for (size_t i = 0; i < input_texts.size(); ++i) {
    total_length += util::utflen(input_texts[i].c_str());
    string option = FLAGS_domain;
    VLOG(1) << "begin to tn text: " << input_texts[i];
    vector<tts::SsmlText> ssml_texts;
    vector<tts::SsmlText> ssml_outputs;
    tts::SsmlParser::Instance().ParseText(input_texts[i], &ssml_texts);
    text_normalizer->Normalize(ssml_texts, option, &ssml_outputs);
    tn_result.emplace_back(input_texts[i] + "\t" +
                           tts::SsmlParser::Instance().JoinText(ssml_outputs));
    if (FLAGS_heap_profile) {
      LOG(INFO) << "Dump memory profiler.";
      HeapProfilerDump(StringPrintf("sentence_%d", i).c_str());
    }
  }
  if (output_file.empty()) {
    LOG(INFO) << JoinVector(tn_result, '\n');
  } else {
    mobvoi::File::WriteStringToFile(JoinVector(tn_result, '\n'), output_file);
  }
  return total_length;
}

int main(int argc, char** argv) {
  google::ParseCommandLineFlags(&argc, &argv, false);
  if (FLAGS_heap_profile) {
    google::InitGoogleLogging(argv[0]);
  }

  vector<string> input_texts;
  if (FLAGS_benchmark) {
    file::SimpleLineReader file_reader(FLAGS_benchmarkfile, true, "#");
    file_reader.ReadLines(&input_texts);
  } else if (!FLAGS_input.empty()) {
    input_texts.push_back(FLAGS_input);
  } else if (!FLAGS_input_file.empty()) {
    file::SimpleLineReader file_reader(FLAGS_input_file, true, "#");
    file_reader.ReadLines(&input_texts);
  } else {
    LOG(WARNING) << "no input texts";
  }

  if (FLAGS_heap_profile) {
    LOG(INFO) << "enable heap profile...";
    HeapProfilerStart("t.mem");
  }

  std::shared_ptr<nlp::tn::TextNormalizer> text_normalizer;
  text_normalizer.reset(
      new nlp::tn::TextNormalizer(FLAGS_language, FLAGS_tn_config));

  if (FLAGS_heap_profile) {
    LOG(INFO) << "Dump memory profiler.";
    HeapProfilerDump("model loaded");
  }
  if (FLAGS_cpu_profile) {
    ProfilerStart("tn.cpu");
  }

  int64 begin_time = mobvoi::GetTimeInMs();
  int total_length =
      TextNormalize(text_normalizer, input_texts, FLAGS_output_file);

  if (FLAGS_heap_profile) {
    HeapProfilerStop();
  }
  if (FLAGS_cpu_profile) {
    ProfilerStop();
  }

  int64 end_time = mobvoi::GetTimeInMs();
  int64 used_time = end_time - begin_time;
  LOG(INFO) << "tn text length: " << total_length;
  LOG(INFO) << "used time: " << used_time;
  if (used_time) {
    LOG(INFO) << "performance(character/second): "
              << total_length * 1000.0 / used_time;
  }
  return 0;
}
