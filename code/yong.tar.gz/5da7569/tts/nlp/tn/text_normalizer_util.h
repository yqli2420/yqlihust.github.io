// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_NLP_TN_TEXT_NORMALIZER_UTIL_H_
#define TTS_NLP_TN_TEXT_NORMALIZER_UTIL_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "re2/re2.h"
#include "tts/nlp/tn/text_normalizer_def.h"
#include "tts/synthesizer/label_generator/label_def.h"
#include "tts/util/trie/marisa_trie.h"
#include "tts/util/tts_util/util.h"

namespace nlp {
namespace tn {

static const char kSilenceMark[] = "^,.,^";
static const char kSepMarkWord[] = "`";
static const char kSepMarkPhrase[] = "^";
static const char kSepMarkSP[] = "@";
static const char kSepMarkLP[] = ",";
static const char kAllBody[] = "";
static const char kTnNameNon[] = "";

static const char kOptionSepMark = '|';
static const string kNumericalDomain =  // NOLINT
    string() + kDomainStock + kOptionSepMark + kDomainWeather + kOptionSepMark +
    kDomainCalc + kOptionSepMark + kDomainConv;
static const char kMeasureTrie[] = "measure_trie";
static const char kPlaceTrie[] = "place_trie";

enum TnChoiceType {
  kNumber = 0,      // 3
  kPointNumber,     // 3.6
  kBarNumber,       // 3-12
  kCommaNumber,     // 3:12
  kSlashNumber,     // 3/12
  kEnglishNumber,   // ticwatch2
  kCapitalEnglish,  // IoT
  kEnglish,         // IOT
  kWebsite,
  kNon,
};

static const string kNumberChoice =  // NOLINT
    string() + tts::kSsmlTnAsValueLiang + kOptionSepMark +
    tts::kSsmlTnAsValueEr + kOptionSepMark + tts::kSsmlTnAsDigitYao +
    kOptionSepMark + tts::kSsmlTnAsDigitYi + kOptionSepMark +
    tts::kSsmlTnAsValueLiangSigned + kOptionSepMark +
    tts::kSsmlTnAsValueErSigned;

static const string kPointNumberChoice =  // NOLINT
    string() + tts::kSsmlTnAsValueLiang + kOptionSepMark +
    tts::kSsmlTnAsValueEr + kOptionSepMark + tts::kSsmlTnAsDigitYao +
    kOptionSepMark + tts::kSsmlTnAsDigitYi + kOptionSepMark +
    tts::kSsmlTnAsDate;
static const string kBarNumberChoice =  // NOLINT
    string() + tts::kSsmlTnAsRatio + kOptionSepMark + tts::kSsmlTnAsDate +
    kOptionSepMark + tts::kSsmlTnAsScale + kOptionSepMark + tts::kSsmlTnAsMath +
    kOptionSepMark + tts::kSsmlTnAsValueEr + kOptionSepMark +
    tts::kSsmlTnAsDigitYi;
static const string kCommaNumberChoice =  // NOLINT
    string() + tts::kSsmlTnAsRatio + kOptionSepMark + tts::kSsmlTnAsTime +
    kOptionSepMark + tts::kSsmlTnAsDate;
static const string kSlashNumberChoice =  // NOLINT
    string() + tts::kSsmlTnAsMath + kOptionSepMark + tts::kSsmlTnAsFraction +
    kOptionSepMark + tts::kSsmlTnAsRatio + kOptionSepMark + tts::kSsmlTnAsDate;
static const string kEnglishNumberChoice = "";   // NOLINT
static const string kCapitalEnglishChoice = "";  // NOLINT
static const string kEnglishChoice =             // NOLINT
    string() + tts::kSsmlTnAsAlphabet + kOptionSepMark + tts::kSsmlTnAsWord;
static const string kWebsiteChoice =  // NOLINT
    string() + tts::kSsmlTnAsWebsite + kOptionSepMark +
    tts::kSsmlTnAsManWebsite;
static const string kTnChoiceList[] = {
    kNumberChoice,         kPointNumberChoice, kBarNumberChoice,
    kCommaNumberChoice,    kSlashNumberChoice, kEnglishNumberChoice,
    kCapitalEnglishChoice, kEnglishChoice,     kWebsiteChoice,
};

typedef string (*BaseFunction)(const string& input);
struct FundHandler {
  FundHandler() : fn(nullptr) {}
  FundHandler(const string& _key, BaseFunction _fn) : key(_key), fn(_fn) {}
  string key;
  BaseFunction fn;
};

// pattern handler structure
// use graphic to capture all as regx string[0]
struct PatternHandler {
  typedef void (*ProcessFunction)(
      const re2::StringPiece* str_args, int args_num,
      const map<string, std::unique_ptr<trie::MarisaTrie>>& trie,
      string* output);
  PatternHandler() : fn(nullptr) {}
  PatternHandler(const string& _pattern, ProcessFunction _fn,
                 const string& _body = "",
                 TnChoiceType choice_type = TnChoiceType::kNon,
                 const string& name = "");
  PatternHandler(const string& _pattern, ProcessFunction _fn,
                 const string& _option, const string& _body,
                 TnChoiceType choice_type = TnChoiceType::kNon,
                 const string& name = "");

  ProcessFunction fn;
  string option;
  std::pair<int, int> body;
  std::shared_ptr<re2::RE2> re2_obj;
  TnChoiceType choice_type;
  string name;
};

struct Symbol2Pron {
  const string symbol;
  const string pron;
};

struct Pattern2Sub {
  Pattern2Sub(const string& _obj, const string& _sub) : obj(_obj), sub(_sub) {}
  re2::RE2 obj;
  const string sub;
};

// core function
string GetPronFromSymbol(const string& symbol,
                         const Symbol2Pron* symbol_pron_map, size_t length);
string ParsePronFromPattern(const string& input, const Pattern2Sub* pattern_sub,
                            size_t length);
string NormalizeNumString(const string& number_str);

}  // namespace tn
}  // namespace nlp
#endif  // TTS_NLP_TN_TEXT_NORMALIZER_UTIL_H_
