// Copyright 2017 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Zheng Zhang)

#include "tts/nlp/segmenter/segmenter_dict_convert_util.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"

// option
DEFINE_int32(top_n_number, 1000000, "top n words according");
DEFINE_int32(max_word_len, 10, "max segment word length");

// input
DEFINE_string(dict, "training/front_end/dict/comb.word.dict", "segmenter dict");

// output
DEFINE_string(protobuf_dict,
              "external/config/front_end/dict/segmenter_dict_new.proto", "");
DEFINE_string(text_dict,
              "external/config/front_end/dict/segmenter_dict_new.txt", "");
DEFINE_string(trie_dict_path,
              "external/config/front_end/dict/word.dict.utf8.trie_new", "");

int main(int argc, char **argv) {
  google::ParseCommandLineFlags(&argc, &argv, false);

  LOG(INFO) << "Begin to convert segmenter dict.";

  // Load word dict file
  vector<nlp::segmenter::WordDict> word_dict;
  LoadWordDict(FLAGS_dict, FLAGS_max_word_len, &word_dict);

  // Calculate word weight through frequency
  CalculateWeight(&word_dict);

  // Select top n words according to weight
  SelectTopNWords(FLAGS_top_n_number, &word_dict);

  // sort phone list
  vector<string> phone_list;
  GenPhoneList(word_dict, &phone_list);
  // sort word dict
  SortWordDict(&word_dict);

  // NOTE: word_dict will be modified.
  SaveMarisaTrie(&word_dict, FLAGS_trie_dict_path);

  // Generate protobuf word dict
  LOG(INFO) << "Begin generate proto";
  GenerateProtoDict(word_dict, FLAGS_protobuf_dict, phone_list);
  GenerateTextDict(word_dict, FLAGS_text_dict);

  LOG(INFO) << "done";
  return 0;
}
