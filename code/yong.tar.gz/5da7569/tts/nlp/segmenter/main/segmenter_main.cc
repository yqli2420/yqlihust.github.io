// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengnzhang@mobvoi.com (Allen)

#include "tts/nlp/segmenter/segmenter.h"
#include "mobvoi/base/at_exit.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/time.h"
#include "tts/nlp/tn/text_normalizer.h"
#include "tts/util/ssml/ssml_parser.h"
#include "tts/util/tts_util/util.h"

DEFINE_string(language, "Mandarin", "tn language");
DEFINE_string(tn_conf, "external/config/front_end/tn/man_tn.conf",
              "tn reosurce config");
DEFINE_string(segmenter_conf,
              "external/config/front_end/segmenter/man_segmenter.conf",
              "segmenter reosurce config directory");
DEFINE_bool(enable_tn, false, "");
DEFINE_string(input,
              "Hello, 我名字叫李那曲是一个中国人,"
              "我有时买Q币来玩, 我还听说过C#语言",
              "");
DEFINE_string(input_file, "", "");
DEFINE_string(output_file, "", "");
DEFINE_string(user_dict_ids, "", "user dict from mysql");

static const char kSegmentSepMark = ' ';
static const char kTextSegSepMark = '\t';

int WordSegmentation(const nlp::tn::TextNormalizer* text_normalizer,
                     const nlp::segmenter::Segmenter* segmenter,
                     const string& user_dict_ids,
                     const vector<string>& input_texts,
                     const string& output_file) {
  int total_length = 0;
  string segmenter_result;
  for (const auto& text : input_texts) {
    vector<nlp::segmenter::SegmentWord> segment_words;
    if (FLAGS_enable_tn) {
      string norm_text;
      text_normalizer->Normalize(text, "", &norm_text);
      total_length += norm_text.size();
      segmenter->WordSegmentation(norm_text, user_dict_ids, &segment_words);
    } else {
      total_length += util::utflen(text.c_str());
      vector<tts::SsmlText> ssml_text;
      tts::SsmlParser::Instance().ParseText(text, &ssml_text);
      segmenter->WordSegmentation(ssml_text, user_dict_ids, &segment_words);
    }
    vector<string> result_words;
    for (const auto& segment_word : segment_words) {
      string word_res =
          StringPrintf("%s(%s %s)", segment_word.word.c_str(),
                       segment_word.pron.c_str(), segment_word.pos.c_str());
      result_words.push_back(word_res);
    }
    segmenter_result +=
        StringPrintf("%s%c%s\n", text.c_str(), kTextSegSepMark,
                     JoinVector(result_words, kSegmentSepMark).c_str());
  }
  if (output_file.empty()) {
    LOG(INFO) << segmenter_result;
  } else {
    mobvoi::File::WriteStringToFile(segmenter_result, output_file);
  }
  return total_length;
}

int main(int argc, char** argv) {
  base::AtExitManager at_exit;
  google::ParseCommandLineFlags(&argc, &argv, false);

  vector<string> input_texts;
  if (!FLAGS_input.empty()) {
    input_texts.push_back(FLAGS_input);
  } else if (!FLAGS_input_file.empty()) {
    file::SimpleLineReader file_reader(FLAGS_input_file, true, "#");
    file_reader.ReadLines(&input_texts);
  } else {
    LOG(FATAL) << "no input texts";
  }

  std::unique_ptr<nlp::tn::TextNormalizer> text_normalizer;
  text_normalizer.reset(
      new nlp::tn::TextNormalizer(FLAGS_language, FLAGS_tn_conf));

  std::unique_ptr<nlp::segmenter::Segmenter> segmenter;
  segmenter.reset(new nlp::segmenter::Segmenter(FLAGS_segmenter_conf));

  int64 begin_time = mobvoi::GetTimeInMs();
  int total_length =
      WordSegmentation(text_normalizer.get(), segmenter.get(),
                       FLAGS_user_dict_ids, input_texts, FLAGS_output_file);
  int64 end_time = mobvoi::GetTimeInMs();
  int64 used_time = end_time - begin_time;
  LOG(INFO) << "g2p text length: " << total_length;
  LOG(INFO) << "used time: " << used_time;
  if (used_time) {
    LOG(INFO) << "performance(character/second): "
              << total_length * 1000.0 / used_time;
  }
  return 0;
}
