// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/nlp/segmenter/impl/comb_segmenter.h"
#include "mobvoi/base/log.h"

namespace nlp {
namespace segmenter {

CombSegmenter::CombSegmenter(const SegmenterResource& segmenter_resource,
                             const string& hmm_model) {
  mp_segmenter_.reset(new MPSegmenter(segmenter_resource));
  hmm_segmenter_.reset(new HMMSegmenter(hmm_model));
}

CombSegmenter::~CombSegmenter() {}

bool CombSegmenter::Cut(vector<util::Rune>::const_iterator begin,
                        vector<util::Rune>::const_iterator end,
                        const string& user_dict,
                        vector<SegmentWord>* result) const {
  if (begin >= end) return false;
  vector<SegmentWord> mp_result;
  // Use mp cut first
  if (!mp_segmenter_->Cut(begin, end, user_dict, &mp_result)) {
    LOG(ERROR) << "mp_segmenter cut failed";
    return false;
  }
  vector<util::Rune> unicode_tmp;
  for (const auto& mp_seg_word : mp_result) {
    // If word is too long, or continues OOV word: cut with hmm segmenter
    if (mp_seg_word.word_id != trie::kNotFound) {
      if (!unicode_tmp.empty()) {
        // use hmm segmenter cut continues oov words
        HMMCut(unicode_tmp.begin(), unicode_tmp.end(), result);
        unicode_tmp.clear();
      }
      result->push_back(mp_seg_word);
    } else {
      // OOV words
      vector<util::Rune> unicode;
      util::Utf8ToUnicode(mp_seg_word.word, &unicode);
      unicode_tmp.insert(unicode_tmp.end(), unicode.begin(), unicode.end());
    }
  }
  // cut left words
  if (!unicode_tmp.empty()) {
    HMMCut(unicode_tmp.begin(), unicode_tmp.end(), result);
  }
  return true;
}

bool CombSegmenter::HMMCut(vector<util::Rune>::const_iterator begin,
                           vector<util::Rune>::const_iterator end,
                           vector<SegmentWord>* result) const {
  vector<SegmentWord> hmm_result;
  if (!hmm_segmenter_->Cut(begin, end, "", &hmm_result)) {
    LOG(ERROR) << "hmm_segmenter cut failed";
    return false;
  }
  result->insert(result->end(), hmm_result.begin(), hmm_result.end());
  return true;
}

// // Checks if the cut words is OK
// bool CombSegmenter::IsWordCutOK(const vector<SegmentWord>& words_cut) const {
//   // If 80% of the cut words are single character, the words cut is not OK
//   size_t single_chars = 0;
//   for (const auto& c_word : words_cut) {
//     vector<util::Rune> unicode;
//     util::Utf8ToUnicode(c_word.word, &unicode);
//     if (unicode.size() < 2) {
//       ++single_chars;
//     }
//   }
//   if (single_chars > floor(words_cut.size() * kMaxSingleCharPercentage)) {
//     return false;
//   }
//   return true;
// }
}  // namespace segmenter
}  // namespace nlp
