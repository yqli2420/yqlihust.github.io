// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#ifndef TTS_NLP_SEGMENTER_IMPL_PINYIN_ENCODER_H_
#define TTS_NLP_SEGMENTER_IMPL_PINYIN_ENCODER_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"

namespace nlp {
namespace segmenter {

class PinyinEncoder {
 public:
  PinyinEncoder(const vector<string>& one_byte, const vector<string>& two_byte);
  ~PinyinEncoder();

  // encode ying2ye4chang3 to save memory.
  bool Encode(const string& pinyin, int* syllable_num, string* encoded_pinyin);
  // Each element is a syllable.
  bool Encode(const vector<string>& prons, string* encoded_pinyin);

  string Decode(const char* encoded_str, int syllable_num);
  bool AddPinyin(const string& pinyin, int* syllable_num,
                 string* encoded_pinyin);

 private:
  void GenSyllableMap(const vector<string>& one_byte,
                      const vector<string>& two_byte);
  void GenIdMap(const vector<string>& one_byte, const vector<string>& two_byte);
  std::unordered_map<string, uint16> syllable_to_id_;
  std::unordered_map<uint16, string> id_to_syllable_;
};

}  // namespace segmenter
}  // namespace nlp
#endif  // TTS_NLP_SEGMENTER_IMPL_PINYIN_ENCODER_H_
