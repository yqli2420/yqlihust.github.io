// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_NLP_SEGMENTER_IMPL_BASE_SEGMENTER_H_
#define TTS_NLP_SEGMENTER_IMPL_BASE_SEGMENTER_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/util/utf8/utf8_util.h"
#include "tts/nlp/segmenter/impl/segmenter_def.h"
#include "tts/nlp/segmenter/impl/segmenter_util.h"

namespace nlp {
namespace segmenter {

class BaseSegmenter {
 public:
  BaseSegmenter();
  virtual ~BaseSegmenter();

  bool Cut(const string& str, const string& user_dict,
           vector<SegmentWord>* result) const;

 protected:
  virtual bool Cut(vector<util::Rune>::const_iterator begin,
                   vector<util::Rune>::const_iterator end,
                   const string& user_dict,
                   vector<SegmentWord>* result) const = 0;

 private:
  DISALLOW_COPY_AND_ASSIGN(BaseSegmenter);
};

// set punctuation after english words
void SetEnglishPuncPos(vector<SegmentWord>* segment_words);
// set english and number word_id
void SetSpecialWordId(vector<SegmentWord>* segment_words);
// merge digit words and alphabet words
void MergeWords(vector<SegmentWord>* segment_words);

}  // namespace segmenter
}  // namespace nlp
#endif  // TTS_NLP_SEGMENTER_IMPL_BASE_SEGMENTER_H_
