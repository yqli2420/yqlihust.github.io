// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_NLP_SEGMENTER_IMPL_HMM_SEGMENTER_H_
#define TTS_NLP_SEGMENTER_IMPL_HMM_SEGMENTER_H_

#include "third_party/sparsehash/dense_hash_map"
#include "tts/nlp/segmenter/impl/base_segmenter.h"

namespace nlp {
namespace segmenter {

typedef google::dense_hash_map<uint16_t, double> EmitProbMap;

enum HMMStatus {
  B = 0,
  E = 1,
  M = 2,
  S = 3,
  STATUS_SUM = 4,
};
enum EmitFormat {
  kCharacter = 0,
  kEmitProb,
};

class HMMSegmenter : public BaseSegmenter {
 public:
  explicit HMMSegmenter(const string& hmm_model);
  virtual ~HMMSegmenter();

  virtual bool Cut(vector<util::Rune>::const_iterator begin,
                   vector<util::Rune>::const_iterator end,
                   const string& user_dict, vector<SegmentWord>* result) const;

 private:
  bool LoadModel(const string& hmm_model);
  bool LoadStartProb(vector<string>::iterator* it);
  bool LoadTransProb(vector<string>::iterator* it);
  bool LoadEmitProb(vector<string>::iterator* it);
  void Viterbi(vector<util::Rune>::const_iterator begin,
               vector<util::Rune>::const_iterator end,
               vector<size_t>* status) const;
  bool CutPathWords(vector<util::Rune>::const_iterator begin,
                    vector<util::Rune>::const_iterator end,
                    const vector<size_t>& status,
                    vector<SegmentWord>* result) const;
  double GetEmitProb(const EmitProbMap& emit_prob, uint16_t key,
                     double def_value) const;

  double start_prob_[HMMStatus::STATUS_SUM];
  double trans_prob_[HMMStatus::STATUS_SUM][HMMStatus::STATUS_SUM];
  vector<EmitProbMap> emit_prob_;

  DISALLOW_COPY_AND_ASSIGN(HMMSegmenter);
};
}  // namespace segmenter
}  // namespace nlp
#endif  // TTS_NLP_SEGMENTER_IMPL_HMM_SEGMENTER_H_
