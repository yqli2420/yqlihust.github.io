// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_NLP_SEGMENTER_IMPL_SEGMENTER_DEF_H_
#define TTS_NLP_SEGMENTER_IMPL_SEGMENTER_DEF_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"

namespace nlp {
namespace segmenter {

static const int kOovWordId = kint32max;
struct SegmentWord {
  string word;
  string pron;
  string pos;
  int word_id = kOovWordId;
  bool pron_fixed = false;
  map<size_t, bool> p_pron_fixeds;
  vector<std::pair<int, string>> seted_pauses;
};

}  // namespace segmenter
}  // namespace nlp
#endif  // TTS_NLP_SEGMENTER_IMPL_SEGMENTER_DEF_H_
