// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: ranzhang@mobvoi.com (Dylan)

#ifndef TTS_NLP_SEGMENTER_IMPL_SEGMENTER_UTIL_H_
#define TTS_NLP_SEGMENTER_IMPL_SEGMENTER_UTIL_H_

#include "mobvoi/util/utf8/utf8_util.h"

namespace nlp {
namespace segmenter {

enum UserDictFormat {
  kUserDictWord = 0,
  kUserDictPron,
  kUserDictAllNum,
};
static const char kBlackMark[] = "black_list";

enum UniformFileFormat {
  kUnifId = 0,
  kUnifWord,
  kUnifAllNum,
};

static const char kDefaultPos[] = "n";
static const char kNamePos[] = "nr";

static const char kPronSylSign = ' ';
static const char kPronPhoneSign = '_';

void InitPosTypeMap(map<string, int>* pos_map);
size_t GetPosId(const string& pos);
string Tag(size_t pos_id);

enum SegmentParameters {
  kDartsDictInitialArraySlots = 0,
  kCombSegmentMinPhraseLen = 1,
  kLoadTrieFromFile = 2,
};

static const char kMandarin[] = "man";
static const char kCantonese[] = "can";
static const char kEng[] = "en";

static const int kMaxWordLen = 8;
static const int kMaxEnglishWordLen = 40;
static const char kDefaultLoadTrie[] = "1";

enum Status {
  kNone = 0,
  kDigital,
  kDigitalBegin,
  kDigitalEnd,
  kEnglish,
};

static const int kNotFoundWordId = 0;
// dict weight is positive, so this is large than all dict words
static const int kUserWordWeight = 10;
static const int kEncoderNum = -10.0;
static const uint8 kMaxUint8 = 255;
static const uint8 kMinUint8 = 0;

bool IsAlphabet(const vector<util::Rune>& unicode);

bool InList(const string& word, const char** word_list, int size);
int JudgeStatus(const string& word);
float WeightDecoding(uint8 weight_uint8);
uint8 WeightEncoding(float weight_float);

}  // namespace segmenter
}  // namespace nlp
#endif  // TTS_NLP_SEGMENTER_IMPL_SEGMENTER_UTIL_H_
