// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_NLP_SEGMENTER_IMPL_DICT_TRIE_H_
#define TTS_NLP_SEGMENTER_IMPL_DICT_TRIE_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "tts/nlp/segmenter/impl/pinyin_encoder.h"
#include "tts/util/trie/marisa_trie.h"

namespace nlp {
namespace segmenter {

const double kMinDouble = -3.14e+100;
const double kMaxDouble = 3.14e+100;

struct DictUnit {
  uint8 weight;
  char tag = 0;
  uint8 syllable_num = 0;
  // 1， for 2 bytes pending, 2, use pron for start address for pron string
  // like pron[0].
  char pron[2];
};

struct Dag {
  int word_id = trie::kNotFound;
  int next_pos = 0;
  vector<util::Rune> word;
  const DictUnit* dict_unit = NULL;

  string ToString() {
    string word_str;
    util::UnicodeToUtf8(word, &word_str);
    bool dict_is_null = (dict_unit == NULL);
    return StringPrintf("word_id: %d, next_pos: %d, word: %s, dict_unit: %d",
                        word_id, next_pos, word_str.c_str(), dict_is_null);
  }
};

class DictTrie {
 public:
  DictTrie(const string& dict_trie, const string& dict_unit);
  ~DictTrie();

  // find a word and return its dict unit
  const DictUnit* Find(vector<util::Rune>::const_iterator begin,
                       vector<util::Rune>::const_iterator end) const;

  // find word's prefix and form a dag return
  bool FindPrefix(vector<util::Rune>::const_iterator begin,
                  vector<util::Rune>::const_iterator end, size_t offset,
                  vector<Dag>* dag) const;

  void Save(const string& save_path) const;
  float GetMinWeight() const { return min_weight_; }
  float GetMaxWeight() const { return max_weight_; }
  string GetPron(const DictUnit& d) const;
  bool EncodePinyin(const string& pinyin, int* syllable_num,
                    string* encoded_pinyin);

 private:
  void LoadDict(const string& dict_unit_file);
  void SetMinWeight();
  void SetMaxWeight();

  std::unique_ptr<trie::MarisaTrie> trie_;
  // Save memory for it. DictUnit* will use 8 bytes.
  vector<DictUnit*> dict_units_;
  std::unique_ptr<PinyinEncoder> pinyin_encoder_;
  float min_weight_;
  float max_weight_;

  DISALLOW_COPY_AND_ASSIGN(DictTrie);
};

}  // namespace segmenter
}  // namespace nlp

#endif  // TTS_NLP_SEGMENTER_IMPL_DICT_TRIE_H_
