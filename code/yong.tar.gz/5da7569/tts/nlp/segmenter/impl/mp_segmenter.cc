// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/nlp/segmenter/impl/mp_segmenter.h"

#include <regex>  // NOLINT

#include "mobvoi/base/log.h"

#include "mobvoi/util/mysql/mysql_util.h"
#include "third_party/jsoncpp/json.h"
#include "tts/util/tts_util/util.h"

DEFINE_string(mysql_dict_word, "", "");

namespace nlp {
namespace segmenter {

static bool InBlack(const set<string> user_black_word, const Dag& dag) {
  string black_word;
  util::UnicodeToUtf8(dag.word, &black_word);
  if (user_black_word.find(black_word) != user_black_word.end()) {
    return true;
  }
  return false;
}

MPSegmenter::MPSegmenter() {}

MPSegmenter::MPSegmenter(const SegmenterResource& segmenter_resource) {
  dict_trie_.reset(new DictTrie(segmenter_resource.dict_trie(),
                                segmenter_resource.dict_unit()));
  LoadUserDict(segmenter_resource.language_dependency_dict());
  LoadUserDict(segmenter_resource.user_dict());
  LoadUniformDict(segmenter_resource.uniform_dict());
}

MPSegmenter::~MPSegmenter() {
  for (auto it = user_dict_.begin(); it != user_dict_.end(); ++it) {
    free(it->second);
  }
}

bool MPSegmenter::Cut(vector<util::Rune>::const_iterator begin,
                      vector<util::Rune>::const_iterator end,
                      const string& user_dict_ids,
                      vector<SegmentWord>* result) const {
  return CutInternal(begin, end, user_dict_ids, result);
}

bool MPSegmenter::CutInternal(vector<util::Rune>::const_iterator begin,
                              vector<util::Rune>::const_iterator end,
                              const string& user_dict_ids,
                              vector<SegmentWord>* result) const {
  if (end == begin) return false;

  vector<SegmentChar> segment_chars(end - begin);
  map<string, DictUnit*> user_dict;
  set<string> malloc_word;
  CreateUserDict(user_dict_ids, &user_dict, &malloc_word);

  // Build DAG
  BuildDag(begin, end, user_dict, &segment_chars);
  // Apply DP to find the maximum weight path in the DAG
  CalcDP(&segment_chars);
  // Push segmented words into result vector
  if (!CutSegChars(segment_chars, result)) {
    LOG(ERROR) << "segment empty.";
    return false;
  }
  UniformWordId(result);
  FreeDictUnit(user_dict, malloc_word);
  return true;
}

void MPSegmenter::FreeDictUnit(const map<string, DictUnit*>& user_dict,
                               const set<string>& malloc_word) const {
  for (const auto& word : malloc_word) {
    auto it = user_dict.find(word);
    if (it != user_dict.end()) {
      free(it->second);
    }
  }
}

void MPSegmenter::LoadUserDict(const string& user_dict_path) {
  vector<string> lines;
  tts::GetConfigCenterLines(user_dict_path, &lines);
  for (const auto& line : lines) {
    vector<string> segs;
    mobvoi::SplitStringToVector(line, tts::kCCSepMark, true, &segs);
    if (segs.size() != UserDictFormat::kUserDictAllNum) {
      LOG(WARNING) << "user dict invalid";
      continue;
    }
    string word_tmp = segs[UserDictFormat::kUserDictWord];
    string pron_tmp = segs[UserDictFormat::kUserDictPron];
    if (pron_tmp == kBlackMark) {
      user_black_word_.insert(word_tmp);
      continue;
    }
    DictUnit* dict_unit = CreateDictUnit(pron_tmp);
    if (!dict_unit) {
      LOG(INFO) << "user dict bad pron:" << word_tmp << " " << pron_tmp;
      continue;
    }
    // repeated word, covered by new word
    auto it = user_dict_.find(word_tmp);
    if (it != user_dict_.end()) {
      VLOG(2) << "word repeated: " << word_tmp << ", cover by new word";
      free(it->second);
    }
    user_dict_[word_tmp] = dict_unit;
  }
}

DictUnit* MPSegmenter::CreateDictUnit(const string& pron) const {
  DictUnit* dict_unit = nullptr;
  int syllable_num = 0;
  string encoded_pinyin;
  if (!dict_trie_->EncodePinyin(pron, &syllable_num, &encoded_pinyin)) {
    return dict_unit;
  }
  CHECK_LT(syllable_num, kuint8max) << "syllable_num is greater than 256.";
  dict_unit = reinterpret_cast<DictUnit*>(
      malloc(sizeof(DictUnit) + encoded_pinyin.size() - 2));
  dict_unit->syllable_num = syllable_num;
  memcpy(dict_unit->pron, encoded_pinyin.data(), encoded_pinyin.size());
  dict_unit->tag = GetPosId(kNamePos);
  // TODO(zhengzhang): fine tune this weight
  dict_unit->weight = segmenter::kMaxUint8;
  return dict_unit;
}

void MPSegmenter::LoadUniformDict(const string& uniform_dict_path) {
  vector<string> lines;
  tts::GetConfigCenterLines(uniform_dict_path, &lines);
  for (const auto& line : lines) {
    vector<string> segs;
    mobvoi::SplitStringToVector(line, tts::kCCSepMark, true, &segs);
    if (segs.size() != UniformFileFormat::kUnifAllNum) {
      LOG(WARNING) << "uniform dict invalid";
      continue;
    }
    int word_id = StringToInt(segs[UniformFileFormat::kUnifId]);
    vector<string> words;
    SplitString(segs[UniformFileFormat::kUnifWord], ' ', &words);
    for (const auto& word : words) {
      if (uniform_word_.find(word) != uniform_word_.end()) {
        LOG(WARNING) << "repeated uniform word: " << word;
        continue;
      }
      uniform_word_[word] = word_id;
    }
  }
}

void MPSegmenter::CreateUserDict(const string& user_dict_ids,
                                 map<string, DictUnit*>* user_dict,
                                 set<string>* malloc_word) const {
  for (const auto& it : user_dict_) {
    user_dict->insert(std::make_pair(it.first, it.second));
  }

  map<string, DictUnit*> mysql_user_dict;
  GetMysqlWord(user_dict_ids, &mysql_user_dict, malloc_word);
  for (const auto& mysql_word : mysql_user_dict) {
    string word = mysql_word.first;
    DictUnit* dict_unit = mysql_word.second;
    if (user_dict->find(word) != user_dict->end()) {
      user_dict->at(word) = dict_unit;
    } else {
      user_dict->insert(make_pair(word, dict_unit));
    }
  }
}

void MPSegmenter::GetMysqlWord(const string& user_dict_ids,
                               map<string, DictUnit*>* user_dict,
                               set<string>* malloc_word) const {
  if (FLAGS_mysql_dict_word.empty() || user_dict_ids.empty()) return;
  VLOG(2) << "user dict: " << user_dict_ids;
  vector<string> user_dict_list;
  SplitString(user_dict_ids, ',', &user_dict_list);
  string command =
      StringPrintf("select word, pron from dict_word where dict_id in ('%s');",
                   mobvoi::JoinVectorToString(user_dict_list, "', '").c_str());
  VLOG(2) << command;
  Json::Value data;
#ifndef FOR_PORTABLE
  util::GetMysqlResult(FLAGS_mysql_dict_word, command, &data, true);
#endif
  vector<string> dict_infos;
  for (auto word_info : data) {
    string word = word_info["word"].asString();
    if (word.empty()) continue;
    vector<string> prons;
    Json::Reader reader;
    Json::Value pron_node;
    reader.parse(word_info["pron"].asString(), pron_node);
    for (auto pron_info : pron_node) {
      string alpha_pron = pron_info["pron_of_alpha"].asString();
      string tone = pron_info["tone"].asString();
      prons.emplace_back(alpha_pron + tone);
    }
    string pron_str = JoinVector(prons, ' ');
    DictUnit* dict_unit = CreateDictUnit(pron_str);
    if (!dict_unit) {
      LOG(INFO) << "user dict bad pron:" << word << " " << pron_str;
      continue;
    }
    // repeated word, covered by new word
    auto it = user_dict->find(word);
    if (it != user_dict->end()) {
      VLOG(2) << "word repeated: " << word << ", cover by new word";
      free(it->second);
      user_dict->at(word) = dict_unit;
    } else {
      user_dict->insert(make_pair(word, dict_unit));
    }
    malloc_word->insert(word);
  }
}

// TODO(shunping) : 使用局部分词的方法，可以更好的处理消歧。
void MPSegmenter::BuildDag(vector<util::Rune>::const_iterator begin,
                           vector<util::Rune>::const_iterator end,
                           const map<string, DictUnit*>& user_dict,
                           vector<SegmentChar>* segment_chars) const {
  // Calc DAG
  for (size_t i = 0; i < segment_chars->size(); ++i) {
    SegmentChar& seg_char = segment_chars->at(i);
    seg_char.character = *(begin + i);
    seg_char.dag.clear();
    dict_trie_->FindPrefix(begin + i, end, i, &seg_char.dag);

    // delete user black word
    auto in_black = std::bind(InBlack, user_black_word_, std::placeholders::_1);
    seg_char.dag.erase(
        std::remove_if(seg_char.dag.begin(), seg_char.dag.end(), in_black),
        seg_char.dag.end());
    // add user dict words
    // TODO(zhengzhang): add max user word length to limit word search
    for (size_t j = 1; i + j - 1 < segment_chars->size(); ++j) {
      string user_word_tmp;
      util::UnicodeToUtf8(begin + i, begin + i + j, &user_word_tmp);
      auto it = user_dict.find(user_word_tmp);
      if (it != user_dict.end()) {
        VLOG(2) << "word find in user dict: " << user_word_tmp;
        Dag dag_tmp;
        dag_tmp.next_pos = i + j;
        dag_tmp.word = vector<util::Rune>(begin + i, begin + i + j);
        dag_tmp.dict_unit = it->second;
        seg_char.dag.push_back(dag_tmp);
      }
    }
    // if not found, use single word as only path
    if (seg_char.dag.empty()) {
      Dag dag_tmp;
      dag_tmp.next_pos = i + 1;
      dag_tmp.word = vector<util::Rune>(begin + i, begin + i + 1);
      VLOG(2) << "Add oov word : " << dag_tmp.ToString();
      seg_char.dag.push_back(dag_tmp);
    }
  }
  // TODO(shunping) : Make path for chinese people name.
}

void MPSegmenter::CalcDP(vector<SegmentChar>* segment_chars) const {
  for (auto it = segment_chars->rbegin(); it != segment_chars->rend(); ++it) {
    for (size_t i = 0; i < it->dag.size(); ++i) {
      const auto& dag_unit = it->dag[i];
      double weight_tmp = 0.0;
      int next_pos = dag_unit.next_pos;
      const DictUnit* dict_unit = dag_unit.dict_unit;
      if (next_pos < static_cast<int>(segment_chars->size())) {
        weight_tmp += segment_chars->at(next_pos).weight;
      }
      if (dict_unit) {
        // remove best path word like "第"
        weight_tmp += WeightDecoding(dict_unit->weight);
      } else {  // single OOV word
        weight_tmp += WeightDecoding(segmenter::kMaxUint8);
      }
      if (weight_tmp > it->weight) {
        it->weight = weight_tmp;
        it->best_path = i;
      }
    }
    VLOG(2) << util::RuneToWord(it->character)
            << "best path: " << it->best_path;
  }
}

bool MPSegmenter::CutSegChars(const vector<SegmentChar>& segmentChars,
                              vector<SegmentWord>* result) const {
  size_t i = 0;
  while (i < segmentChars.size()) {
    SegmentWord result_word;
    int best_path = segmentChars[i].best_path;
    Dag best_dag = segmentChars[i].dag[best_path];
    result_word.word_id =
        best_dag.word_id == trie::kNotFound ? kOovWordId : best_dag.word_id;
    const DictUnit* dict_unit = best_dag.dict_unit;
    util::UnicodeToUtf8(best_dag.word.begin(), best_dag.word.end(),
                        &result_word.word);
    if (dict_unit) {
      result_word.pron = dict_trie_->GetPron(*dict_unit);
      result_word.pos = Tag(dict_unit->tag);
      result_word.word_id = best_dag.word_id;
      if (user_dict_.find(result_word.word) != user_dict_.end()) {
        result_word.pron_fixed = true;
        vector<string> tmp_prons;
        SplitString(result_word.pron, ' ', &tmp_prons);
        for (size_t i = 0; i < tmp_prons.size(); ++i) {
          result_word.p_pron_fixeds[i] = true;
        }
      }
    } else {
      // OOV word
      VLOG(3) << "push oov word: " << result_word.word;
      result_word.pron = "";
      result_word.pos = kDefaultPos;
      result_word.word_id = best_dag.word_id;
    }
    result->push_back(result_word);
    i += best_dag.word.size();
  }
  if (result->empty()) return false;
  return true;
}

void MPSegmenter::UniformWordId(vector<SegmentWord>* result) const {
  for (auto& word : *result) {
    auto it = uniform_word_.find(word.word);
    if (it != uniform_word_.end()) {
      word.word_id = it->second;
    }
  }
}

}  // namespace segmenter
}  // namespace nlp
