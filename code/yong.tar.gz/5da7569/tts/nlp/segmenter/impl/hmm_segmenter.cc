// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/nlp/segmenter/impl/hmm_segmenter.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/string_util.h"

namespace nlp {
namespace segmenter {

static const char kHMMModelSepMark = ' ';
static const char kHMMEmitStatusSepMark = ':';
static const double kHMMMinDouble = -3.14e+100;

HMMSegmenter::HMMSegmenter(const string& hmm_model) { LoadModel(hmm_model); }

HMMSegmenter::~HMMSegmenter() {}

bool HMMSegmenter::Cut(vector<util::Rune>::const_iterator begin,
                       vector<util::Rune>::const_iterator end,
                       const string& user_dict,
                       vector<SegmentWord>* result) const {
  if (begin >= end) return false;
  vector<size_t> status;
  Viterbi(begin, end, &status);
  if (!CutPathWords(begin, end, status, result)) {
    return false;
  }
  return true;
}

bool HMMSegmenter::LoadModel(const string& hmm_model) {
  VLOG(2) << "loadModel: " << hmm_model;
  vector<string> lines;
  file::SimpleLineReader reader(hmm_model, true, "#");
  reader.ReadLines(&lines);
  if (lines.size() != 1 + 2 * HMMStatus::STATUS_SUM) return false;
  auto it = lines.begin();
  if (!LoadStartProb(&it)) return false;
  if (!LoadTransProb(&it)) return false;
  if (!LoadEmitProb(&it)) return false;
  return true;
}

bool HMMSegmenter::LoadStartProb(vector<string>::iterator* it) {
  vector<string> segs;
  SplitString(**it, kHMMModelSepMark, &segs);
  if (segs.size() != HMMStatus::STATUS_SUM) {
    LOG(ERROR) << "start prob illegal";
    return false;
  }
  for (size_t i = 0; i < HMMStatus::STATUS_SUM; ++i) {
    start_prob_[i] = atof(segs[i].c_str());
  }
  ++(*it);
  return true;
}

bool HMMSegmenter::LoadTransProb(vector<string>::iterator* it) {
  for (size_t i = 0; i < HMMStatus::STATUS_SUM; ++i) {
    vector<string> segs;
    SplitString(**it, kHMMModelSepMark, &segs);
    if (segs.size() != HMMStatus::STATUS_SUM) {
      LOG(ERROR) << "trans prob illegal";
      return false;
    }
    for (size_t j = 0; j < HMMStatus::STATUS_SUM; ++j) {
      trans_prob_[i][j] = atof(segs[j].c_str());
    }
    ++(*it);
  }
  return true;
}

bool HMMSegmenter::LoadEmitProb(vector<string>::iterator* it) {
  for (size_t i = 0; i < HMMStatus::STATUS_SUM; ++i) {
    EmitProbMap emit_prob_tmp;
    vector<string> segs;
    SplitString(**it, kHMMModelSepMark, &segs);
    if (segs.size() != HMMStatus::STATUS_SUM) {
      LOG(ERROR) << "emit prob illegal";
      return false;
    }
    for (size_t j = 0; j < HMMStatus::STATUS_SUM; ++j) {
      vector<string> status_segs;
      SplitString(segs[j], kHMMEmitStatusSepMark, &status_segs);
      if (2 != status_segs.size()) {
        LOG(ERROR) << "emit prob format illegal";
        return false;
      }
      vector<util::Rune> unicode;
      if (!util::Utf8ToUnicode(status_segs[EmitFormat::kCharacter], &unicode) ||
          unicode.size() != 1) {
        LOG(ERROR) << "decode failed";
        return false;
      }
      emit_prob_tmp.insert(std::make_pair(
          unicode[0], atof(status_segs[EmitFormat::kEmitProb].c_str())));
    }
    emit_prob_.push_back(emit_prob_tmp);
    ++(*it);
  }
  return true;
}

void HMMSegmenter::Viterbi(vector<util::Rune>::const_iterator begin,
                           vector<util::Rune>::const_iterator end,
                           vector<size_t>* status) const {
  // Status X Character matrix
  // matrix row is status, matrix column is input characters
  size_t character_num = end - begin;
  size_t cidx;       // index to the input characters
  size_t sidx;       // index to the status set
  size_t prev_sidx;  // previous index of status set

  size_t matrix_size = character_num * HMMStatus::STATUS_SUM;
  size_t now, old, stat;
  double tmp, end_e, end_s;

  vector<int> path(matrix_size);
  vector<double> weight(matrix_size);

  // Calculate the probability of starting from the 1st character
  // in any one status: weight[sidx][0]
  for (sidx = 0; sidx < HMMStatus::STATUS_SUM; ++sidx) {
    weight[0 + sidx * character_num] =
        start_prob_[sidx] +
        GetEmitProb(emit_prob_[sidx], *begin, kHMMMinDouble);
    path[0 + sidx * character_num] = -1;
  }

  double emit_prob;
  // DP algorithm to calculate weight[sidx][cidx]
  // time complexity: O(HMMStatus::STATUS_SUM * character_num)
  for (cidx = 1; cidx < character_num; ++cidx) {
    for (sidx = 0; sidx < HMMStatus::STATUS_SUM; ++sidx) {
      now = cidx + sidx * character_num;
      weight[now] = kHMMMinDouble;
      path[now] = HMMStatus::E;  // warning
      emit_prob = GetEmitProb(emit_prob_[sidx], *(begin + cidx), kHMMMinDouble);
      for (prev_sidx = 0; prev_sidx < HMMStatus::STATUS_SUM; ++prev_sidx) {
        old = cidx - 1 + prev_sidx * character_num;
        tmp = weight[old] + trans_prob_[prev_sidx][sidx] + emit_prob;
        if (tmp > weight[now]) {
          weight[now] = tmp;
          path[now] = prev_sidx;
        }
      }
    }
  }

  end_e = weight[character_num - 1 + HMMStatus::E * character_num];
  end_s = weight[character_num - 1 + HMMStatus::S * character_num];
  stat = 0;
  if (end_e >= end_s) {
    stat = HMMStatus::E;
  } else {
    stat = HMMStatus::S;
  }

  // Backtrack to find the minimum weight path from S to E
  status->resize(character_num);
  for (int c = character_num - 1; c >= 0; --c) {
    status->at(c) = stat;
    stat = path[c + stat * character_num];
  }
}

bool HMMSegmenter::CutPathWords(vector<util::Rune>::const_iterator begin,
                                vector<util::Rune>::const_iterator end,
                                const vector<size_t>& status,
                                vector<SegmentWord>* result) const {
  vector<util::Rune>::const_iterator left = begin;
  vector<util::Rune>::const_iterator right;
  for (size_t i = 0; i < status.size(); ++i) {
    if (status[i] == HMMStatus::E || status[i] == HMMStatus::S) {
      right = begin + i + 1;
      string word;
      if (util::UnicodeToUtf8(left, right, &word)) {
        SegmentWord segment_word;
        segment_word.word = word;
        result->push_back(segment_word);
      } else {
        LOG(ERROR) << "encode failed";
        return false;
      }
      left = right;
    }
  }
  return true;
}

double HMMSegmenter::GetEmitProb(const EmitProbMap& emit_prob, uint16_t key,
                                 double def_value) const {
  EmitProbMap::const_iterator cit = emit_prob.find(key);
  if (cit == emit_prob.end()) {
    return def_value;
  }
  return cit->second;
}
}  // namespace segmenter
}  // namespace nlp
