// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_NLP_SEGMENTER_IMPL_MP_SEGMENTER_H_
#define TTS_NLP_SEGMENTER_IMPL_MP_SEGMENTER_H_

#include "tts/nlp/segmenter/impl/base_segmenter.h"
#include "tts/nlp/segmenter/impl/dict_trie.h"
#include "tts/nlp/segmenter/proto/segmenter_resource.pb.h"

namespace nlp {
namespace segmenter {

struct SegmentChar {
  util::Rune character;
  vector<Dag> dag;
  int best_path;
  double weight = kMinDouble;
};

class MPSegmenter : public BaseSegmenter {
 public:
  MPSegmenter();
  explicit MPSegmenter(const SegmenterResource& segmenter_resource);
  virtual ~MPSegmenter();

  virtual bool Cut(vector<util::Rune>::const_iterator begin,
                   vector<util::Rune>::const_iterator end,
                   const string& user_dict_ids,
                   vector<SegmentWord>* result) const;

 private:
  bool CutInternal(vector<util::Rune>::const_iterator begin,
                   vector<util::Rune>::const_iterator end,
                   const string& user_dict_ids,
                   vector<SegmentWord>* result) const;

  void LoadUserDict(const string& user_dict_path);
  void LoadUniformDict(const string& uniform_dict_path);

  // create user dict from user_dict_ and user_dict_ids
  void CreateUserDict(const string& user_dict_ids,
                      map<string, DictUnit*>* user_dict,
                      set<string>* mallow_word) const;
  DictUnit* CreateDictUnit(const string& pron) const;
  void GetMysqlWord(const string& user_dict_ids,
                    map<string, DictUnit*>* user_dict,
                    set<string>* malloc_word) const;
  void FreeDictUnit(const map<string, DictUnit*>& user_dict,
                    const set<string>& malloc_word) const;
  void BuildDag(vector<util::Rune>::const_iterator begin,
                vector<util::Rune>::const_iterator end,
                const map<string, DictUnit*>& user_dict,
                vector<SegmentChar>* segment_chars) const;
  void CalcDP(vector<SegmentChar>* segment_chars) const;
  bool CutSegChars(const vector<SegmentChar>& segment_chars,
                   vector<SegmentWord>* result) const;
  void UniformWordId(vector<SegmentWord>* result) const;

  std::unique_ptr<DictTrie> dict_trie_;
  map<string, DictUnit*> user_dict_;
  set<string> user_black_word_;
  map<string, int> uniform_word_;

  DISALLOW_COPY_AND_ASSIGN(MPSegmenter);
};
}  // namespace segmenter
}  // namespace nlp

#endif  // TTS_NLP_SEGMENTER_IMPL_MP_SEGMENTER_H_
