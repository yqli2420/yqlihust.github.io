// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/nlp/segmenter/segmenter.h"

#include "mobvoi/base/file/proto_util.h"
#include "mobvoi/base/log.h"
#include "tts/nlp/segmenter/impl/mp_segmenter.h"
#include "tts/nlp/segmenter/proto/segmenter_resource.pb.h"
#include "tts/util/tts_util/util.h"

namespace nlp {
namespace segmenter {

Segmenter::Segmenter(const string& resource_file) {
  SegmenterResource resource;
  CHECK(mobvoi::ReadProtoFromTextFile(resource_file, &resource))
      << resource_file << " load failed!";
  string dir = mobvoi::File::FindFileDir(resource_file);
  resource.set_dict_trie(dir + resource.dict_trie());
  resource.set_dict_unit(dir + resource.dict_unit());
  resource.set_language_dependency_dict(dir +
                                        resource.language_dependency_dict());
  resource.set_user_dict(tts::AppendPath(dir, resource.user_dict()));
  resource.set_uniform_dict(tts::AppendPath(dir, resource.uniform_dict()));
  segmenter_.reset(static_cast<BaseSegmenter*>(new MPSegmenter(resource)));
}

Segmenter::~Segmenter() {}

bool Segmenter::WordSegmentation(const string& text,
                                 vector<SegmentWord>* segment_words) const {
  return WordSegmentation(text, "", segment_words);
}

bool Segmenter::WordSegmentation(const vector<tts::SsmlText>& texts,
                                 vector<SegmentWord>* segment_words) const {
  return WordSegmentation(texts, "", segment_words);
}

bool Segmenter::WordSegmentation(const string& text, const string& user_dict,
                                 vector<SegmentWord>* segment_words) const {
  return segmenter_->Cut(text, user_dict, segment_words);
}

bool Segmenter::WordSegmentation(const vector<tts::SsmlText>& texts,
                                 const string& user_dict,
                                 vector<SegmentWord>* segment_words) const {
  vector<tts::SsmlText> ptexts;
  vector<vector<std::pair<int, string>>> offsets_phone;
  vector<vector<std::pair<int, string>>> offsets_pause;
  // remove ssml phone key and record target phone offset
  ParseSsmlTags(texts, &ptexts, &offsets_phone, &offsets_pause);
  for (size_t i = 0; i < ptexts.size(); ++i) {
    tts::SsmlText text = ptexts[i];
    vector<SegmentWord> segment_words_tmp;
    segmenter_->Cut(text.text, user_dict, &segment_words_tmp);
    ProcessSsml(text, offsets_phone[i], offsets_pause[i], &segment_words_tmp);
    segment_words->insert(segment_words->end(), segment_words_tmp.begin(),
                          segment_words_tmp.end());
  }
  return true;
}

void Segmenter::ParseSsmlTags(
    const vector<tts::SsmlText>& texts,
    vector<tts::SsmlText>* text_without_ssml,
    vector<vector<std::pair<int, string>>>* offsets_phone,
    vector<vector<std::pair<int, string>>>* offsets_pause) const {
  string text_tmp;
  vector<std::pair<int, string>> offset_phone;
  vector<std::pair<int, string>> offset_pause;
  for (const auto& text : texts) {
    if (text.tag.name == tts::kSsmlWordKey) {
      if (!text_tmp.empty()) {
        text_without_ssml->emplace_back(tts::SsmlText(text_tmp));
        offsets_phone->emplace_back(offset_phone);
        offsets_pause->emplace_back(offset_pause);
        offset_phone.clear();
        offset_pause.clear();
        text_tmp.clear();
      }
      text_without_ssml->emplace_back(text);
      offsets_phone->emplace_back(offset_phone);
      offsets_pause->emplace_back(offset_pause);
    } else {
      if (text.tag.name == tts::kSsmlPhoneKey) {
        if (tts::IsChineseWord(text.text) &&
            util::utflen(text.text.c_str()) != 1) {
          continue;
        }
        // process phone p tags
        auto attr_it = text.tag.attrs.find(tts::kSsmlWordPhone);
        if (attr_it != text.tag.attrs.end()) {
          // TODO(zhengzhang) check if tag pron is legal
          offset_phone.emplace_back(
              std::make_pair(util::utflen(text_tmp.c_str()), attr_it->second));
        }
      } else if (text.tag.name == tts::kSsmlPauseKey) {
        if (!text_tmp.empty()) {
          // process pause pau tags
          auto attr_it = text.tag.attrs.find(tts::kSsmlPauseLevel);
          if (attr_it != text.tag.attrs.end()) {
            offset_pause.emplace_back(std::make_pair(
                util::utflen(text_tmp.c_str()) - 1, attr_it->second));
          }
        }
      }
      text_tmp += text.text;
    }
  }
  if (!text_tmp.empty()) {
    text_without_ssml->emplace_back(tts::SsmlText(text_tmp));
    offsets_phone->emplace_back(offset_phone);
    offsets_pause->emplace_back(offset_pause);
  }
}

void Segmenter::ProcessSsmlWord(const tts::SsmlText& text,
                                vector<SegmentWord>* result) const {
  if (text.tag.name == tts::kSsmlWordKey) {
    SegmentWord ssml_segment_word;
    ssml_segment_word.word = text.text;
    ssml_segment_word.pos = kDefaultPos;
    ssml_segment_word.word_id = kOovWordId;
    auto attr_it = text.tag.attrs.find(tts::kSsmlWordPhone);
    if (attr_it == text.tag.attrs.end()) {
      attr_it = text.tag.attrs.find(tts::kSsmlAsrWordPhone);
    }
    if (attr_it != text.tag.attrs.end() && !attr_it->second.empty()) {
      // TODO(zhengzhang): check if tag pron is legal
      ssml_segment_word.pron = attr_it->second;
      ssml_segment_word.pron_fixed = true;
      vector<string> tmp_prons;
      SplitString(ssml_segment_word.pron, ' ', &tmp_prons);
      for (size_t i = 0; i < tmp_prons.size(); ++i) {
        ssml_segment_word.p_pron_fixeds[i] = true;
      }
    } else {
      vector<string> prons;
      for (const auto& segment_word_tmp : *result) {
        prons.emplace_back(segment_word_tmp.pron);
      }
      ssml_segment_word.pron = JoinVector(prons, ' ');
    }
    result->clear();
    result->emplace_back(ssml_segment_word);
  }
}

void Segmenter::ProcessSsmlPhone(
    const tts::SsmlText& text,
    const vector<std::pair<int, string>>& phone_offset,
    vector<SegmentWord>* result) const {
  if (!phone_offset.empty()) {
    size_t word_offset = 0;
    int char_offset = 0;  // total char offset, sum of word length
    for (const auto& offset : phone_offset) {
      if (offset.second.empty()) {
        continue;
      }
      while (word_offset < result->size() &&
             char_offset + util::utflen(result->at(word_offset).word.c_str()) <=
                 offset.first) {
        char_offset += util::utflen(result->at(word_offset).word.c_str());
        word_offset += 1;
      }
      if (word_offset >= result->size()) return;
      if (tts::IsEnglishWord(result->at(word_offset).word)) {
        result->at(word_offset).pron = offset.second;
        result->at(word_offset).pron_fixed = true;
        continue;
      }
      vector<string> prons;
      SplitString(result->at(word_offset).pron, ' ', &prons);
      if (static_cast<size_t>(offset.first - char_offset) >= prons.size())
        continue;
      prons[offset.first - char_offset] = offset.second;
      result->at(word_offset).pron = JoinVector(prons, ' ');
      result->at(word_offset).p_pron_fixeds[offset.first - char_offset] = true;
    }
  }
}

void Segmenter::ProcessSsmlPause(
    const tts::SsmlText& text,
    const vector<std::pair<int, string>>& pause_offset,
    vector<SegmentWord>* result) const {
  if (!pause_offset.empty()) {
    size_t word_offset = 0, last_word_offset = 0;
    int char_offset = 0;  // total char offset, sum of word length
    for (const auto& offset : pause_offset) {
      while (word_offset < result->size() &&
             char_offset + util::utflen(result->at(word_offset).word.c_str()) <=
                 offset.first) {
        char_offset += util::utflen(result->at(word_offset).word.c_str());
        if (tts::IsChineseWord(result->at(word_offset).word) ||
            tts::IsEnglishWord(result->at(word_offset).word)) {
          last_word_offset = word_offset;
        }
        word_offset += 1;
      }
      if (word_offset >= result->size()) return;
      if (!tts::IsChineseWord(result->at(word_offset).word) &&
          !tts::IsEnglishWord(result->at(word_offset).word)) {
        result->at(last_word_offset)
            .seted_pauses.emplace_back(std::make_pair(
                util::utflen(result->at(last_word_offset).word.c_str()) - 1,
                offset.second));
      } else {
        result->at(word_offset)
            .seted_pauses.emplace_back(
                std::make_pair(offset.first - char_offset, offset.second));
      }
    }
  }
}

void Segmenter::ProcessSsml(const tts::SsmlText& text,
                            const vector<std::pair<int, string>>& phone_offset,
                            const vector<std::pair<int, string>>& pause_offset,
                            vector<SegmentWord>* result) const {
  ProcessSsmlWord(text, result);
  ProcessSsmlPhone(text, phone_offset, result);
  ProcessSsmlPause(text, pause_offset, result);
}

}  // namespace segmenter
}  // namespace nlp
