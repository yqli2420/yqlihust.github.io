// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/nlp/segmenter/segmenter.h"

#include "mobvoi/base/file/simple_line_reader.h"
#include "third_party/gtest/gtest.h"

#include "tts/util/tts_util/util.h"

namespace nlp {
namespace segmenter {

static const string kTestDataDir =  // NOLINT
    "tts/nlp/segmenter/test/testdata/";

static const char kWsSegSepMark = '\t';
static const char kWsWordSepMark = ' ';    // 今天 是 好日子
static const char kWsPronSepMark[] = "_";  // jin1 tian1_shi4_hao3 ri4 zi5
enum WsTestFormat {
  kWsText = 0,
  kWsWord,
  kWsPron,
  kWsTestAllNum,
};

class SegmenterTest : public ::testing::Test {
 protected:
  virtual void SetUp() {
    const string resource_config =
        "external/config/front_end/segmenter/man_segmenter.conf";
    segmenter_.reset(new Segmenter(resource_config));
  }
  void Cut(const string& str, vector<SegmentWord>* result) const {
    vector<tts::SsmlText> ssml_text;
    tts::SsmlParser::Instance().ParseText(str, &ssml_text);
    segmenter_->WordSegmentation(ssml_text, result);
  }
  void SegmenterCaseTest(const string& str,
                         const vector<string>& expect_result) const {
    vector<SegmentWord> result;
    Cut(str, &result);
    ASSERT_EQ(expect_result.size(), result.size()) << str;
    for (size_t i = 0; i < expect_result.size(); ++i) {
      EXPECT_EQ(expect_result[i], result[i].word)
          << "expect: " << expect_result[i] << " actual: " << result[i].word;
    }
  }
  void SegmenterCaseTest(const string& str, const vector<string>& expect_word,
                         const vector<string>& expect_pron) const {
    vector<SegmentWord> result;
    Cut(str, &result);
    ASSERT_EQ(expect_word.size(), result.size()) << str;
    for (size_t i = 0; i < expect_word.size(); ++i) {
      EXPECT_EQ(expect_word[i], result[i].word)
          << "expect: " << expect_word[i] << " actual: " << result[i].word;
    }
    ASSERT_EQ(expect_pron.size(), result.size()) << str;
    for (size_t i = 0; i < expect_pron.size(); ++i) {
      EXPECT_EQ(expect_pron[i], result[i].pron)
          << "expect: " << expect_pron[i] << " actual: " << result[i].pron;
    }
  }

  std::unique_ptr<Segmenter> segmenter_;
};

TEST_F(SegmenterTest, CaseTest) {
  const string str1 = "报警拨打一一零";
  const char* res1[] = {"报警", "拨打", "一一零"};
  const vector<string> result1(res1, res1 + arraysize(res1));
  SegmenterCaseTest(str1, result1);

  const string str2 = "排名第一";
  const char* res2[] = {"排名", "第一"};
  const vector<string> result2(res2, res2 + arraysize(res2));
  SegmenterCaseTest(str2, result2);

  const string str3 = "比例是一点三";
  const char* res3[] = {"比例", "是", "一点三"};
  const vector<string> result3(res3, res3 + arraysize(res3));
  SegmenterCaseTest(str3, result3);

  const string str4 = "水浒好汉有一百一十八个";
  const char* res4[] = {"水浒", "好汉", "有", "一百一十八个"};
  const vector<string> result4(res4, res4 + arraysize(res4));
  SegmenterCaseTest(str4, result4);

  const string str5 = "准确率是百分之十";
  const char* res5[] = {"准确率", "是", "百分之十"};
  const vector<string> result5(res5, res5 + arraysize(res5));
  SegmenterCaseTest(str5, result5);

  const string str6 = "我来自北京邮电大学。";
  const char* res6[] = {"我", "来自", "北京", "邮电", "大学", "。"};
  const vector<string> result6(res6, res6 + arraysize(res6));
  SegmenterCaseTest(str6, result6);

  // TODO(zhengzhang): fix this case
  // const string str7 =
  //     "小明硕士毕业于中国科学院计算所计算机学院,后在日本京都大学深造。";
  // const char* res7[] = {
  //   "小明", "硕士", "毕业于", "中国", "科学院", "计算", "所", "计算机",
  //   "学院", ",", "后", "在", "日本", "京都", "大学", "深造", "。"};
  // const vector<string> result7(res7, res7 + arraysize(res7));
  // SegmenterCaseTest(str7, result7);

  const string str8 = "中国你我他";
  const char* res8[] = {"中国", "你我", "他"};
  const vector<string> result8(res8, res8 + arraysize(res8));
  SegmenterCaseTest(str8, result8);
}

TEST_F(SegmenterTest, FileTest) {
  const string test_file = kTestDataDir + "segmenter_test.txt";
  file::SimpleLineReader reader(test_file, true, "#");
  vector<string> lines;
  reader.ReadLines(&lines);
  for (const auto& line : lines) {
    vector<string> segs;
    SplitString(line, kWsSegSepMark, &segs);
    vector<string> expect;
    SplitString(segs[WsTestFormat::kWsWord], kWsWordSepMark, &expect);
    SegmenterCaseTest(segs[WsTestFormat::kWsText], expect);
  }
}

TEST_F(SegmenterTest, SsmlTextTest) {
  const string test_file = kTestDataDir + "segmenter_ssml.txt";
  file::SimpleLineReader reader(test_file, true, "#");
  vector<string> lines;
  reader.ReadLines(&lines);
  for (const auto& line : lines) {
    vector<string> segs;
    SplitString(line, kWsSegSepMark, &segs);
    if (segs.size() != WsTestFormat::kWsTestAllNum) continue;
    vector<string> expect_word;
    vector<string> expect_pron;
    SplitString(segs[WsTestFormat::kWsWord], kWsWordSepMark, &expect_word);
    mobvoi::SplitStringToVector(segs[WsTestFormat::kWsPron], kWsPronSepMark,
                                false, &expect_pron);
    SegmenterCaseTest(segs[WsTestFormat::kWsText], expect_word, expect_pron);
  }
}

}  //  namespace segmenter
}  //  namespace nlp
