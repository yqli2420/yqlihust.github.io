// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/nlp/segmenter/impl/dict_trie.h"

#include "mobvoi/base/file/simple_line_reader.h"
#include "third_party/gtest/gtest.h"
#include "tts/nlp/segmenter/impl/segmenter_util.h"

namespace nlp {
namespace segmenter {

static const string kTestDataDir =       // NOLINT
    "tts/nlp/segmenter/test/testdata/";  // NOLINT

class DictTrieTest : public ::testing::Test {
 protected:
  virtual void SetUp() {
    const string dict_trie =
        "external/config/front_end/segmenter/mandarin_segmenter_word_dict.trie";
    const string dict_unit =
        "external/config/front_end/segmenter/mandarin_segmenter_dict.proto";
    dict_trie_.reset(new DictTrie(dict_trie, dict_unit));
  }
  void DictTrieFindTest(const string& word, const string& expect_pron,
                        const string& expect_pos) const {
    vector<util::Rune> unicode;
    util::Utf8ToUnicode(word, &unicode);
    const DictUnit* dict_unit =
        dict_trie_->Find(unicode.begin(), unicode.end());
    ASSERT_NE(nullptr, dict_unit);
    EXPECT_EQ(expect_pron, dict_trie_->GetPron(*dict_unit));
    EXPECT_EQ(expect_pos, Tag(dict_unit->tag));
  }
  void DictTrieFindPrefixTest(const string& word,
                              const vector<string>& expect_words) const {
    vector<util::Rune> unicode;
    util::Utf8ToUnicode(word, &unicode);
    vector<Dag> dag;
    dict_trie_->FindPrefix(unicode.begin(), unicode.end(), 0, &dag);
    ASSERT_EQ(expect_words.size(), dag.size());
    for (size_t i = 0; i < dag.size(); ++i) {
      string word_tmp;
      LOG(INFO) << dag[i].ToString();
      util::UnicodeToUtf8(dag[i].word, &word_tmp);
      EXPECT_EQ(expect_words[i], word_tmp) << "expect: " << expect_words[i]
                                           << " actual: " << word_tmp;
    }
  }

  std::unique_ptr<DictTrie> dict_trie_;
};

TEST_F(DictTrieTest, FindTest) {
  string word1 = "来到";
  string pron1 = "lai2 dao4";
  string pos1 = "v";
  DictTrieFindTest(word1, pron1, pos1);

  string word2 = "云计算";
  string pron2 = "yvn2 ji4 suan4";
  string pos2 = "n";
  DictTrieFindTest(word2, pron2, pos2);
}

TEST_F(DictTrieTest, FindPrefixTest) {
  string word = "清华";
  const char* words[] = {"清", "清华"};
  const vector<string> result(words, words + arraysize(words));
  DictTrieFindPrefixTest(word, result);
}

}  // namespace segmenter
}  // namespace nlp
