// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_NLP_SEGMENTER_SEGMENTER_H_
#define TTS_NLP_SEGMENTER_SEGMENTER_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "tts/nlp/segmenter/impl/segmenter_def.h"
#include "tts/util/ssml/ssml_parser.h"

namespace nlp {
namespace segmenter {

// SegmenterImpl
class BaseSegmenter;

class Segmenter {
 public:
  explicit Segmenter(const string& reosurce_file);
  ~Segmenter();

  bool WordSegmentation(const string& text,
                        vector<SegmentWord>* segment_words) const;
  bool WordSegmentation(const vector<tts::SsmlText>& texts,
                        vector<SegmentWord>* segment_words) const;
  bool WordSegmentation(const string& text, const string& user_dict,
                        vector<SegmentWord>* segment_words) const;
  bool WordSegmentation(const vector<tts::SsmlText>& texts,
                        const string& user_dict,
                        vector<SegmentWord>* segment_words) const;

 private:
  void ParseSsmlTags(
      const vector<tts::SsmlText>& texts,
      vector<tts::SsmlText>* text_without_ssml,
      vector<vector<std::pair<int, string>>>* offsets_phone,
      vector<vector<std::pair<int, string>>>* offsets_pause) const;
  void ProcessSsmlWord(const tts::SsmlText& text,
                       vector<SegmentWord>* result) const;
  void ProcessSsmlPhone(const tts::SsmlText& text,
                        const vector<std::pair<int, string>>& phone_offset,
                        vector<SegmentWord>* result) const;
  void ProcessSsmlPause(const tts::SsmlText& text,
                        const vector<std::pair<int, string>>& pause_offset,
                        vector<SegmentWord>* result) const;
  void ProcessSsml(const tts::SsmlText& text,
                   const vector<std::pair<int, string>>& phone_offset,
                   const vector<std::pair<int, string>>& pause_offset,
                   vector<SegmentWord>* result) const;

  std::unique_ptr<BaseSegmenter> segmenter_;

  DISALLOW_COPY_AND_ASSIGN(Segmenter);
};
}  // namespace segmenter
}  // namespace nlp

#endif  // TTS_NLP_SEGMENTER_SEGMENTER_H_
