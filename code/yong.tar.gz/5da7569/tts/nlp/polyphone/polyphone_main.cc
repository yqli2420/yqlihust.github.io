// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/nlp/polyphone/polyphone.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/file.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/time.h"
#include "third_party/perftools/heap-profiler.h"
#include "third_party/perftools/profiler.h"
#include "tts/nlp/segmenter/segmenter.h"
#include "tts/nlp/tn/text_normalizer.h"
#include "tts/util/tts_util/util.h"

DEFINE_string(language, "Mandarin", "tn language");
DEFINE_string(tn_conf, "external/config/front_end/tn/man_tn.conf",
              "tn reosurce config");
DEFINE_string(segmenter_conf,
              "external/config/front_end/segmenter/man_segmenter.conf",
              "segmenter reosurce config");
DEFINE_string(input, "你还有多少钱没还", "");
DEFINE_string(input_file, "", "");
DEFINE_bool(enable_save_tn, false, "");
DEFINE_string(polyphone_conf,
              "external/config/front_end/polyphone/man_polyphone.conf",
              "polyphone rules");
DEFINE_string(output_file, "", "");
DEFINE_int32(re_weight, 100, "prob threshold of polyphone");
DEFINE_string(tar_word, "", "set one polyphone word");
DEFINE_bool(heap_profile, false, "If true, enable heap profile");

static const char kPronSepMark = ' ';
static const char kTextSegSepMark = '\t';

int PolyphoneProcess(const nlp::tn::TextNormalizer* text_normalizer,
                     const nlp::segmenter::Segmenter* segmenter,
                     const nlp::polyphone::Polyphone* polyphone,
                     const vector<string>& input_texts,
                     const string& output_file) {
  int total_length = 0;
  vector<string> polyphone_result;
  for (const auto& text : input_texts) {
    bool res_flag = true;
    string norm_text;
    text_normalizer->Normalize(text, "", &norm_text);
    total_length += norm_text.size();

    vector<nlp::segmenter::SegmentWord> segment_words;
    segmenter->WordSegmentation(norm_text, &segment_words);
    vector<nlp::polyphone::PolyphoneToken> polyphone_tokens;
    for (const auto& segment_word : segment_words) {
      vector<string> prons;
      SplitString(segment_word.pron, kPronSepMark, &prons);
      nlp::polyphone::PolyphoneToken polyphone_token(segment_word.word,
                                                     segment_word.pos, prons);
      polyphone_tokens.push_back(polyphone_token);
    }
    map<int, int> polyphone_prob;
    polyphone->PolyphoneProcess(&polyphone_tokens, &polyphone_prob);
    for (auto prob : polyphone_prob) {
      VLOG(2) << prob.first << ":" << prob.second;
    }

    vector<string> result_prons;
    vector<string> res_pron;
    for (const auto& polyphone_token : polyphone_tokens) {
      result_prons.push_back(JoinVector(polyphone_token.prons, kPronSepMark));
      for (auto pron : polyphone_token.prons) res_pron.emplace_back(pron);
    }
    string tmp_result;
    if (FLAGS_enable_save_tn) {
      tmp_result = StringPrintf("%s%c%s%c%s%c", text.c_str(), kTextSegSepMark,
                                norm_text.c_str(), kTextSegSepMark,
                                JoinVector(result_prons, kPronSepMark).c_str(),
                                kTextSegSepMark);
      vector<string> tn_character;
      util::SplitUtf8String(norm_text.c_str(), &tn_character);
      int man_word_num = -1;
      res_flag = false;
      for (size_t i = 0; i < tn_character.size(); i++) {
        if (tts::IsChineseWord(tn_character[i])) {
          man_word_num++;
          if ((polyphone_prob.find(man_word_num) != polyphone_prob.end()) &&
              (FLAGS_tar_word.empty() || tn_character[i] == FLAGS_tar_word)) {
            auto iter = polyphone_prob.find(man_word_num);
            if (iter->second < FLAGS_re_weight && FLAGS_re_weight <= 100) {
              res_flag = true;
              tmp_result += StringPrintf("%s(%s:%i)", tn_character[i].c_str(),
                                         res_pron[i].c_str(), iter->second);
            } else {
              tmp_result += tn_character[i];
            }
          } else {
            tmp_result += tn_character[i];
          }
        } else {
          tmp_result += tn_character[i];
        }
      }
    } else {
      tmp_result = StringPrintf("%s%c%s", text.c_str(), kTextSegSepMark,
                                JoinVector(result_prons, kPronSepMark).c_str());
    }
    if (FLAGS_re_weight >= 100) {
      res_flag = true;
    }
    if (res_flag) polyphone_result.emplace_back(tmp_result);
  }
  if (output_file.empty()) {
    LOG(INFO) << JoinVector(polyphone_result, '\n');
  } else {
    mobvoi::File::WriteStringToFile(JoinVector(polyphone_result, '\n'),
                                    output_file);
  }
  return total_length;
}

int main(int argc, char** argv) {
  google::ParseCommandLineFlags(&argc, &argv, false);

  vector<string> input_texts;
  if (!FLAGS_input.empty()) {
    input_texts.push_back(FLAGS_input);
  } else if (!FLAGS_input_file.empty()) {
    file::SimpleLineReader file_reader(FLAGS_input_file, true, "#");
    file_reader.ReadLines(&input_texts);
  } else {
    LOG(FATAL) << "no input texts";
    return 0;
  }

  std::unique_ptr<nlp::tn::TextNormalizer> text_normalizer;
  text_normalizer.reset(
      new nlp::tn::TextNormalizer(FLAGS_language, FLAGS_tn_conf));

  std::unique_ptr<nlp::segmenter::Segmenter> segmenter;
  segmenter.reset(new nlp::segmenter::Segmenter(FLAGS_segmenter_conf));
  if (FLAGS_heap_profile) {
    LOG(INFO) << "enable heap profile...";
    HeapProfilerStart("t.mem");
  }

  std::unique_ptr<nlp::polyphone::Polyphone> polyphone;
  polyphone.reset(new nlp::polyphone::Polyphone(FLAGS_polyphone_conf));
  if (FLAGS_heap_profile) {
    LOG(INFO) << "Dump memory profiler.";
    HeapProfilerDump("model loaded");
  }

  int64 begin_time = mobvoi::GetTimeInMs();
  int total_length =
      PolyphoneProcess(text_normalizer.get(), segmenter.get(), polyphone.get(),
                       input_texts, FLAGS_output_file);
  if (FLAGS_heap_profile) {
    HeapProfilerStop();
  }

  int64 end_time = mobvoi::GetTimeInMs();
  int64 used_time = end_time - begin_time;
  LOG(INFO) << "g2p text length: " << total_length;
  LOG(INFO) << "used time: " << used_time;
  if (used_time) {
    LOG(INFO) << "performance(character/second): "
              << total_length * 1000.0 / used_time;
  }
  return 0;
}
