// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaoqin.feng@mobvoi.com

#ifndef TTS_NLP_POLYPHONE_CRF_POLYPHONE_H_
#define TTS_NLP_POLYPHONE_CRF_POLYPHONE_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "tts/nlp/polyphone/polyphone_impl.h"
#include "tts/util/crf/crf.h"

namespace nlp {
namespace polyphone {

struct InputToken {
  InputToken(const string& _word, const string& _pinyin, int _word_location,
             bool _is_target)
      : word(_word),
        pinyin(_pinyin),
        word_location(_word_location),
        is_target(_is_target) {}
  string word;
  string pinyin;
  int word_location;  // which word the character in
  bool is_target;     // is top n polyphone and single character (remove
                      // single in the future)
};

struct PolyphoneParms {
  int strict_len;     // enable predicter while word len > strict_len
  string model_type;  // model type (complex,simple,....)
};

class CrfPolyphone : public PolyphoneImpl {
 public:
  CrfPolyphone(const string& polyphone_model, const string& polyphone_dict);
  virtual ~CrfPolyphone();

  virtual bool PolyphoneProcess(vector<PolyphoneToken>* polyphone_tokens) const;
  virtual bool PolyphoneProcess(vector<PolyphoneToken>* polyphone_tokens,
                                map<int, int>* polyphone_prob) const;
  virtual mobvoi::unordered_set<string> GetPolyphoneModelDict() const;

 private:
  void LoadPolyphoneModel(const string& polyphone_dict_path,
                          const string& polyphone_model_path);
  bool IsTarget(const string& character, const string& word) const;
  void GenCrfFeat(const vector<InputToken>& tokens, int offset,
                  const vector<string>& pos_lists, string* feat) const;
  int EucDistance(const float a, const float b) const;
  void DoYiPolyphoneCheck(vector<InputToken>* input_tokens) const;
  bool Predict(const vector<string>& pos_lists, vector<InputToken>* tokens,
               map<int, int>* polyphone_prob) const;

  map<string, std::shared_ptr<crf::CrfModel>> polyphone_models_;
  map<string, PolyphoneParms> polyphone_dict_;
  DISALLOW_COPY_AND_ASSIGN(CrfPolyphone);
};

}  // namespace polyphone
}  // namespace nlp
#endif  // TTS_NLP_POLYPHONE_CRF_POLYPHONE_H_
