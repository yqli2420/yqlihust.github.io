// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaoqin.feng@mobvoi.com

#include "tts/nlp/polyphone/comb_polyphone.h"

namespace nlp {
namespace polyphone {

CombPolyphone::CombPolyphone(const PolyphoneResource& resource) {
  dict_polyphone_.reset(new DictPolyphone(
      resource.base_rule(), resource.language_dependency_rule(),
      resource.config_center(), resource.name_rule()));
  crf_polyphone_.reset(
      new CrfPolyphone(resource.polyphone_model(), resource.polyphone_dict()));
}

CombPolyphone::~CombPolyphone() {}

bool CombPolyphone::PolyphoneProcess(
    vector<PolyphoneToken>* polyphone_tokens) const {
  bool crf_tag, dict_tag;
  crf_tag = crf_polyphone_->PolyphoneProcess(polyphone_tokens);
  dict_tag = dict_polyphone_->PolyphoneProcess(polyphone_tokens);
  return crf_tag && dict_tag;
}

bool CombPolyphone::PolyphoneProcess(vector<PolyphoneToken>* polyphone_tokens,
                                     map<int, int>* polyphone_prob) const {
  bool crf_tag, dict_tag;
  dict_tag = dict_polyphone_->PolyphoneProcess(polyphone_tokens);
  crf_tag = crf_polyphone_->PolyphoneProcess(polyphone_tokens, polyphone_prob);
  return crf_tag && dict_tag;
}

mobvoi::unordered_set<string> CombPolyphone::GetPolyphoneModelDict() const {
  return crf_polyphone_->GetPolyphoneModelDict();
}

}  // namespace polyphone
}  // namespace nlp
