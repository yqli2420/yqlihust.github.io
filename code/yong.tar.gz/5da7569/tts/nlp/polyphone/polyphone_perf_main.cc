// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/nlp/polyphone/polyphone.h"
#include "mobvoi/base/file/file.h"
#include "mobvoi/base/file/simple_line_reader.h"

#include "mobvoi/base/string_util.h"
#include "mobvoi/base/time.h"
#include "mobvoi/util/utf8/utf8_util.h"
#include "tts/nlp/segmenter/segmenter.h"
#include "tts/nlp/tn/text_normalizer.h"
#include "tts/util/tts_util/test_perf.h"
#include "tts/util/tts_util/util.h"

DEFINE_string(language, "Mandarin", "tn language");
DEFINE_string(tn_conf, "external/config/front_end/tn/man_tn.conf",
              "tn reosurce config");
DEFINE_string(segmenter_conf,
              "external/config/front_end/segmenter/man_segmenter.conf",
              "segmenter reosurce config");
DEFINE_string(test_file,
              "tts/nlp/polyphone/testdata/polyphone_mandarin_test.txt",
              "format: text\tprons");
DEFINE_string(polyphone_conf,
              "external/config/front_end/polyphone/man_polyphone.conf",
              "polyphone rules");
DEFINE_string(polyphone_dict,
              "external/config/front_end/polyphone/polyphone.dict", "list");
DEFINE_string(word_accuracy_file, "word_accuracy.txt", "");
DEFINE_string(error_sentence_file, "error_sentence.txt", "");
// while all_labeled == false,TN = false
DEFINE_bool(all_labeled, true, "every word have pron");

static const RE2 ch_pattern("[\u4e00-\u9fa5]+");
static const RE2 ch_pron_pattern("[a-z]+[1-5]");
static const char kPronSepMark = ' ';
static const char kTextSegSepMark = '\t';
int polyphone_word_count = 0;
int polyphone_err_count = 0;
int polyphone_word_count_light = 0;
int polyphone_err_count_light = 0;
int doc_word_count = 0;

enum PolyphoneTestFormat {
  kInput = 0,
  kExpect,
  kPolyphoneTestAllNum,
};
struct PinyinErrCount {
  std::unordered_set<string> key_pinyins;
  map<string, int> pinyin_all_count;
  map<string, int> pinyin_err_count;
};
map<string, PinyinErrCount> word_error_counter;

void ReadAndParseLines(const string& test_file, vector<string>* input_texts,
                       vector<vector<string>>* expect_prons) {
  vector<string> texts;
  file::SimpleLineReader file_reader(test_file, true, "");
  file_reader.ReadLines(&texts);
  for (const auto& text : texts) {
    vector<string> segs;
    SplitString(text, kTextSegSepMark, &segs);
    if (PolyphoneTestFormat::kPolyphoneTestAllNum != segs.size()) {
      LOG(FATAL) << "format error: " << text;
    }

    string trim_text;
    // remove front # to add annotation sentences
    mobvoi::TrimString(segs[PolyphoneTestFormat::kInput], "#", &trim_text);
    mobvoi::TrimWhitespaceASCII(trim_text, mobvoi::TRIM_ALL, &trim_text);
    input_texts->emplace_back(trim_text);

    string trim_pron;
    mobvoi::TrimWhitespaceASCII(segs[PolyphoneTestFormat::kExpect],
                                mobvoi::TRIM_ALL, &trim_pron);
    vector<string> prons;
    SplitString(trim_pron, kPronSepMark, &prons);
    expect_prons->emplace_back(prons);
  }
}

void TextNormalize(const nlp::tn::TextNormalizer* text_normalizer,
                   const vector<string>& input_texts,
                   vector<string>* norm_texts) {
  for (const auto& input_text : input_texts) {
    string norm_text;
    text_normalizer->Normalize(input_text, "", &norm_text);
    norm_texts->emplace_back(norm_text);
  }
}

void WordSegmentation(
    const nlp::segmenter::Segmenter* segmenter,
    const vector<string>& input_texts,
    vector<vector<nlp::segmenter::SegmentWord>>* segments_words,
    int* word_num) {
  for (const auto& input_text : input_texts) {
    *word_num += util::utflen(input_text.c_str());
    vector<nlp::segmenter::SegmentWord> segment_words;
    segmenter->WordSegmentation(input_text, &segment_words);
    segments_words->emplace_back(segment_words);
  }
}

void PolyphoneProcess(
    const nlp::polyphone::Polyphone* polyphone,
    const vector<vector<nlp::segmenter::SegmentWord>>& segments_words,
    vector<vector<string>>* result_prons) {
  for (const auto& segment_words : segments_words) {
    vector<nlp::polyphone::PolyphoneToken> polyphone_tokens;
    for (const auto& segment_word : segment_words) {
      vector<string> prons;
      SplitString(segment_word.pron, kPronSepMark, &prons);
      nlp::polyphone::PolyphoneToken polyphone_token(segment_word.word,
                                                     segment_word.pos, prons);
      polyphone_tokens.push_back(polyphone_token);
    }
    polyphone->PolyphoneProcess(&polyphone_tokens);

    vector<string> result_pron;
    for (const auto& polyphone_token : polyphone_tokens) {
      result_pron.insert(result_pron.end(), polyphone_token.prons.begin(),
                         polyphone_token.prons.end());
    }
    result_prons->emplace_back(result_pron);
  }
}

// record the frequency & accuracy of error pron
void WriteWordErrorResultToFile() {
  vector<string> result;
  vector<string> res;
  int right, all;
  string document_word_count =
      "Document word all count : " + std::to_string(doc_word_count);
  right = polyphone_word_count - polyphone_err_count;
  all = polyphone_word_count;
  string all_accuracy =
      "All Accuracy : " + std::to_string(right) + " / " + std::to_string(all) +
      " = " +
      std::to_string(static_cast<double>(right) / static_cast<double>(all));
  right = polyphone_word_count - polyphone_word_count_light -
          polyphone_err_count + polyphone_err_count_light;
  all = polyphone_word_count - polyphone_word_count_light;
  string No_tone5_accuracy =
      "No Soft(tone=5) Accuracy : " + std::to_string(right) + " / " +
      std::to_string(all) + " = " +
      std::to_string(static_cast<double>(right) / static_cast<double>(all));
  LOG(INFO) << all_accuracy;
  LOG(INFO) << No_tone5_accuracy;
  string header =
      "word\tpinyin\terr_count\tall_count\taccuracy\tratio(for pinyin/word)";

  result.emplace_back(document_word_count);
  result.emplace_back(all_accuracy);
  result.emplace_back(No_tone5_accuracy);
  result.emplace_back(header);

  int pinyin_all_count = 0, pinyin_err_count = 0;
  for (auto word_counter : word_error_counter) {
    PinyinErrCount temp = word_counter.second;
    int all_count = 0;
    int err_count = 0;
    int no_tone_error_count = 0;
    for (auto pinyin : temp.key_pinyins) {
      pinyin_all_count = temp.pinyin_all_count[pinyin];
      pinyin_err_count = temp.pinyin_err_count[pinyin];
      all_count += pinyin_all_count;
      err_count += pinyin_err_count;
      if (pinyin.back() != '5') no_tone_error_count += pinyin_err_count;
    }
    for (auto pinyin : temp.key_pinyins) {
      pinyin_all_count = temp.pinyin_all_count[pinyin];
      pinyin_err_count = temp.pinyin_err_count[pinyin];
      res.emplace_back(word_counter.first);
      res.emplace_back(pinyin);
      res.emplace_back(std::to_string(pinyin_err_count));
      res.emplace_back(std::to_string(pinyin_all_count));
      res.emplace_back(std::to_string(
          static_cast<double>(pinyin_all_count - pinyin_err_count) /
          static_cast<double>(pinyin_all_count)));
      res.emplace_back(std::to_string(static_cast<double>(pinyin_all_count) /
                                      static_cast<double>(all_count)));
      result.emplace_back(JoinVector(res, kTextSegSepMark));
      res.clear();
    }
    res.emplace_back(word_counter.first);
    res.emplace_back(std::to_string(err_count));
    res.emplace_back(std::to_string(all_count));
    string acc =
        std::to_string(static_cast<double>(all_count - err_count) /
                       static_cast<double>(all_count)) +
        ":" +
        std::to_string(static_cast<double>(all_count - no_tone_error_count) /
                       static_cast<double>(all_count));
    res.emplace_back(acc);

    res.emplace_back(std::to_string(static_cast<double>(all_count) /
                                    static_cast<double>(doc_word_count)));

    result.emplace_back(JoinVector(res, kTextSegSepMark) + "\n");
    res.clear();
  }
  mobvoi::File::WriteStringToFile(JoinVector(result, '\n'),
                                  FLAGS_word_accuracy_file);
}
bool JudgeAlignment(vector<string>* utf_8, vector<string>* result_pron,
                    vector<string>* expect_pron) {
  vector<string> temp_utf_8_result;
  vector<string> temp_result_pron_result;
  vector<string> temp_expect_pron_result;
  for (size_t i = 0; i < utf_8->size(); ++i) {
    if (tts::IsChineseWord((*utf_8)[i]))
      temp_utf_8_result.emplace_back(utf_8->at(i));
  }
  for (size_t i = 0; i < result_pron->size(); ++i) {
    if (tts::IsChinesePron((*result_pron)[i]))
      temp_result_pron_result.emplace_back(result_pron->at(i));
  }
  for (size_t i = 0; i < expect_pron->size(); ++i) {
    if (tts::IsChinesePron((*expect_pron)[i]))
      temp_expect_pron_result.emplace_back(expect_pron->at(i));
  }
  if (temp_utf_8_result.size() == temp_result_pron_result.size() &&
      temp_result_pron_result.size() == temp_expect_pron_result.size()) {
    *utf_8 = temp_utf_8_result;
    *result_pron = temp_result_pron_result;
    *expect_pron = temp_expect_pron_result;
    return true;
  }
  return false;
}
bool JudgeAlignment(vector<string>* utf_8, vector<string>* result_pron) {
  vector<string> temp_utf_8_result;
  vector<string> temp_result_pron_result;
  vector<string> temp_expect_pron_result;
  for (size_t i = 0; i < utf_8->size(); ++i) {
    if (tts::IsChineseWord((*utf_8)[i]))
      temp_utf_8_result.emplace_back(utf_8->at(i));
  }
  for (size_t i = 0; i < result_pron->size(); ++i) {
    if (tts::IsChinesePron((*result_pron)[i]))
      temp_result_pron_result.emplace_back(result_pron->at(i));
  }
  if (temp_utf_8_result.size() == temp_result_pron_result.size()) {
    *utf_8 = temp_utf_8_result;
    *result_pron = temp_result_pron_result;
    return true;
  }
  return false;
}

void LoadPolyphoneDict(const string& path,
                       mobvoi::unordered_set<string>* polyphone_set) {
  vector<string> lines;
  vector<string> values;
  tts::GetConfigCenterLines(path, &lines);
  for (auto line : lines) {
    mobvoi::SplitStringToVector(line, ",", false, &values);
    polyphone_set->insert(values[0]);
  }
}
void CalcPerf(const vector<string>& input_texts,
              const vector<string>& norm_texts,
              const vector<vector<string>>& result_prons,
              const vector<vector<string>>& expect_prons,
              const mobvoi::unordered_set<string>& polyphone_set,
              tts::TestPerf* performance) {
  LOG(INFO) << "CalcPerf";
  vector<string> error_sentence;
  string header = "word\texcept\tactual\tindex\ttext";
  error_sentence.emplace_back(header);
  if (norm_texts.size() != result_prons.size() ||
      norm_texts.size() != expect_prons.size()) {
    LOG(ERROR) << "input mismatch";
  }
  int error_count = 0;
  for (size_t i = 0; i < norm_texts.size(); ++i) {
    vector<string> result_pron = result_prons[i];
    vector<string> expect_pron = expect_prons[i];
    vector<string> utf8;
    util::SplitUtf8String(norm_texts[i], &utf8);
    if (!JudgeAlignment(&utf8, &result_pron, &expect_pron)) {
      VLOG(2) << norm_texts[i];
      error_count++;
      continue;
    }
    doc_word_count += utf8.size();
    for (size_t j = 0; j < utf8.size(); ++j) {
      if (polyphone_set.find(utf8[j]) != polyphone_set.end()) {
        polyphone_word_count += 1;
        word_error_counter[utf8[j]].pinyin_all_count[expect_pron[j]] += 1;
        word_error_counter[utf8[j]].key_pinyins.insert(expect_pron[j]);
        if (expect_pron[j].back() == '5') polyphone_word_count_light += 1;
        if (expect_pron[j] != result_pron[j]) {
          polyphone_err_count += 1;
          if (expect_pron[j].back() == '5') polyphone_err_count_light += 1;
          word_error_counter[utf8[j]].pinyin_err_count[expect_pron[j]] += 1;
          performance->add_fp();
          VLOG(1) << "word:" << utf8[j] << "\t" << expect_pron[j] << "\t"
                  << result_pron[j] << "\tindex:" << j
                  << "\ttext: " << input_texts[i];
          error_sentence.emplace_back(
              "word:" + utf8[j] + "\t" + "expect:" + expect_pron[j] + "\t" +
              "pred:" + result_pron[j] + "\t" + "index:" + std::to_string(j) +
              "\t" + "text: " + input_texts[i]);
        } else {
          performance->add_tp();
        }
      }
    }
  }
  WriteWordErrorResultToFile();
  mobvoi::File::WriteStringToFile(JoinVector(error_sentence, '\n'),
                                  FLAGS_error_sentence_file);
  LOG(INFO) << "error_count : " << error_count;
}

void CalcPerfNotAllLabeled(const vector<string>& input_texts,
                           const vector<string>& norm_texts,
                           const vector<vector<string>>& result_prons,
                           const vector<vector<string>>& expect_prons,
                           const mobvoi::unordered_set<string>& polyphone_set,
                           tts::TestPerf* performance) {
  LOG(INFO) << "CalcPerfNotAllLabeled";
  vector<string> error_sentence;
  string header = "word\texcept\tactual\tindex\ttext";
  for (size_t i = 0; i < norm_texts.size(); ++i) {
    vector<string> result_pron = result_prons[i];
    vector<string> expect_pron = expect_prons[i];
    vector<string> utf8;
    util::SplitUtf8String(norm_texts[i], &utf8);
    if (!JudgeAlignment(&utf8, &result_pron)) {
      continue;
    }
    vector<string> re_expect_prons;
    for (size_t n = 0; n < utf8.size(); ++n)
      re_expect_prons.emplace_back("pinyin");
    int loc;
    for (auto& ep : expect_pron) {
      vector<string> infos;
      SplitString(ep, ':', &infos);
      loc = StringToInt(infos[0]);
      re_expect_prons[loc] = infos[1];
    }
    doc_word_count += utf8.size();
    for (size_t j = 0; j < utf8.size(); ++j) {
      if (re_expect_prons[j] == "pinyin") continue;
      if (polyphone_set.find(utf8[j]) != polyphone_set.end()) {
        polyphone_word_count += 1;
        word_error_counter[utf8[j]].pinyin_all_count[re_expect_prons[j]] += 1;
        word_error_counter[utf8[j]].key_pinyins.insert(re_expect_prons[j]);
        if (re_expect_prons[j].back() == '5') polyphone_word_count_light += 1;
        if (re_expect_prons[j] != result_pron[j]) {
          polyphone_err_count += 1;
          if (re_expect_prons[j].back() == '5') polyphone_err_count_light += 1;
          word_error_counter[utf8[j]].pinyin_err_count[re_expect_prons[j]] += 1;
          performance->add_fp();
          VLOG(1) << "word:" << utf8[j] << "\t" << re_expect_prons[j] << "\t"
                  << result_pron[j] << "\tindex:" << j
                  << "\ttext: " << input_texts[i];
          error_sentence.emplace_back(
              "word:" + utf8[j] + "\t" + "expect:" + re_expect_prons[j] + "\t" +
              "pred:" + result_pron[j] + "\t" + "index:" + std::to_string(j) +
              "\t" + "text: " + input_texts[i]);
        } else {
          performance->add_tp();
        }
      }
    }
  }
  LOG(INFO) << "CalcPerf";

  WriteWordErrorResultToFile();

  mobvoi::File::WriteStringToFile(JoinVector(error_sentence, '\n'),
                                  FLAGS_error_sentence_file);
}

int main(int argc, char** argv) {
  google::ParseCommandLineFlags(&argc, &argv, false);

  vector<string> input_texts;
  vector<vector<string>> expect_prons;
  ReadAndParseLines(FLAGS_test_file, &input_texts, &expect_prons);
  vector<string> norm_texts;
  if (!FLAGS_all_labeled) {
    std::unique_ptr<nlp::tn::TextNormalizer> text_normalizer;
    text_normalizer.reset(
        new nlp::tn::TextNormalizer(FLAGS_language, FLAGS_tn_conf));
    TextNormalize(text_normalizer.get(), input_texts, &norm_texts);
  } else {
    norm_texts = input_texts;
  }
  std::unique_ptr<nlp::segmenter::Segmenter> segmenter;
  segmenter.reset(new nlp::segmenter::Segmenter(FLAGS_segmenter_conf));
  vector<vector<nlp::segmenter::SegmentWord>> segments_words;
  int word_num = 0;
  WordSegmentation(segmenter.get(), norm_texts, &segments_words, &word_num);
  LOG(INFO) << word_num;
  std::unique_ptr<nlp::polyphone::Polyphone> polyphone;
  polyphone.reset(new nlp::polyphone::Polyphone(FLAGS_polyphone_conf));
  vector<vector<string>> result_prons;
  int64 begin_time = mobvoi::GetTimeInMs();
  PolyphoneProcess(polyphone.get(), segments_words, &result_prons);
  int64 end_time = mobvoi::GetTimeInMs();
  mobvoi::unordered_set<string> polyphone_set;
  LoadPolyphoneDict(FLAGS_polyphone_dict, &polyphone_set);
  for (auto& p : polyphone_set) LOG(INFO) << p;
  tts::TestPerf performance;
  if (FLAGS_all_labeled)
    CalcPerf(input_texts, norm_texts, result_prons, expect_prons, polyphone_set,
             &performance);
  else
    CalcPerfNotAllLabeled(input_texts, norm_texts, result_prons, expect_prons,
                          polyphone_set, &performance);
  int64 used_time = end_time - begin_time;
  LOG(INFO) << "used time: " << used_time;
  if (used_time) {
    LOG(INFO) << word_num * 1000.0 / used_time << " character/second";
  }
  LOG(INFO) << "acc: " << performance.Accuracy();
  return 0;
}
