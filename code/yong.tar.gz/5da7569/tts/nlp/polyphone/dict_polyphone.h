// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaoqin.feng@mobvoi.com

#ifndef TTS_NLP_POLYPHONE_DICT_POLYPHONE_H_
#define TTS_NLP_POLYPHONE_DICT_POLYPHONE_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "tts/nlp/polyphone/polyphone_impl.h"
namespace nlp {
namespace polyphone {

enum PolyphoneRuleType {
  kTypeKeyword = 0,
  kTypePos,
  kTypeIdx,
  kTypeTone,
  kTypeSingle,  // if single word, replace pron
  kTypeAll,     // replace all pron of this word
  kTypeSpecialName,
  kTypeGeneralName,
  kTypeError,
};

struct PolyphoneRule {
  string word;
  vector<string> prons;
  PolyphoneRuleType type;
  std::unordered_set<string> key_words;
  int offset;
};

class DictPolyphone : public PolyphoneImpl {
 public:
  DictPolyphone(const string& base_rule, const string& language_dependency_rule,
                const string& config_center, const string& name_rule);
  virtual ~DictPolyphone();

  virtual bool PolyphoneProcess(vector<PolyphoneToken>* polyphone_tokens) const;
  virtual bool PolyphoneProcess(vector<PolyphoneToken>* polyphone_tokens,
                                map<int, int>* polyphone_prob) const;
  virtual mobvoi::unordered_set<string> GetPolyphoneModelDict() const;

 private:
  void LoadPolyphoneRule(const string& polyphone_rule);
  void KeywordProcess(const PolyphoneRule& polyphone_rule,
                      vector<PolyphoneToken>* polyphone_tokens) const;
  void PosProcess(const PolyphoneRule& polyphone_rule,
                  vector<PolyphoneToken>* polyphone_tokens) const;
  void IdxProcess(const PolyphoneRule& polyphone_rule,
                  vector<PolyphoneToken>* polyphone_tokens) const;
  void ToneProcess(const PolyphoneRule& polyphone_rule,
                   vector<PolyphoneToken>* polyphone_tokens) const;
  void SingleProcess(const PolyphoneRule& polyphone_rule,
                     vector<PolyphoneToken>* polyphone_tokens) const;
  void AllProcess(const PolyphoneRule& polyphone_rule,
                  vector<PolyphoneToken>* polyphone_tokens) const;
  void SpecialNamePolyProcess(const PolyphoneRule& polyphone_name_rule,
                              vector<PolyphoneToken>* polyphone_tokens) const;
  void GeneralNamePolyProcess(const PolyphoneRule& polyphone_name_rule,
                              vector<PolyphoneToken>* polyphone_tokens) const;
  PolyphoneRule* FindPolyphoneRuleByWord(const string& word);
  int GetMaxKeyWordSize(const PolyphoneRule& polyphone_rule) const;

  vector<PolyphoneRule> polyphone_base_rule_;
  vector<PolyphoneRule> polyphone_special_name_rule_;
  vector<PolyphoneRule> polyphone_general_name_rule_;
  vector<string> polyphone_dict_;

  DISALLOW_COPY_AND_ASSIGN(DictPolyphone);
};

}  // namespace polyphone
}  // namespace nlp
#endif  // TTS_NLP_POLYPHONE_DICT_POLYPHONE_H_
