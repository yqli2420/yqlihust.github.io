// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaoqin.feng@mobvoi.com

#ifndef TTS_NLP_POLYPHONE_POLYPHONE_IMPL_H_
#define TTS_NLP_POLYPHONE_POLYPHONE_IMPL_H_

#include "mobvoi/base/compat.h"
#include "tts/nlp/polyphone/polyphone_def.h"

namespace nlp {
namespace polyphone {

class PolyphoneImpl {
 public:
  PolyphoneImpl() {}
  virtual ~PolyphoneImpl() {}

  // Gets the phonetic pronunciation for a word, return true if success
  // output pron is a vector of syllable joined with ' '
  // e.g. smartphone -> S M AA1 R T
  //                    F OW1 N
  virtual bool PolyphoneProcess(
      vector<PolyphoneToken>* polyphone_tokens) const = 0;
  virtual bool PolyphoneProcess(vector<PolyphoneToken>* polyphone_tokens,
                                map<int, int>* polyphone_prob) const = 0;
  virtual mobvoi::unordered_set<string> GetPolyphoneModelDict() const = 0;

 private:
  DISALLOW_COPY_AND_ASSIGN(PolyphoneImpl);
};

}  // namespace polyphone
}  // namespace nlp
#endif  // TTS_NLP_POLYPHONE_POLYPHONE_IMPL_H_
