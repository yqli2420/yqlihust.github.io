// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaoqin.feng@mobvoi.com

#ifndef TTS_NLP_POLYPHONE_POLYPHONE_DEF_H_
#define TTS_NLP_POLYPHONE_POLYPHONE_DEF_H_

namespace nlp {
namespace polyphone {

static const char kSpeManWord[] = "为";
static const char kSpeManWordPron[] = "wei4";

struct PolyphoneToken {
  PolyphoneToken(const string& _word, const string& _pos,
                 const vector<string>& _pron, bool _pron_fixed = false)
      : word(_word), pos(_pos), prons(_pron), pron_fixed(_pron_fixed) {}
  string word;
  string pos;
  vector<string> prons;
  bool pron_fixed = false;
  map<size_t, bool> p_pron_fixeds;
};

}  // namespace polyphone
}  // namespace nlp
#endif  // TTS_NLP_POLYPHONE_POLYPHONE_DEF_H_
