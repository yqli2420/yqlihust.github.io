// Copyright 2018 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/nlp/polyphone/polyphone.h"

#include "mobvoi/base/file/file.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "third_party/gtest/gtest.h"
#include "tts/nlp/segmenter/segmenter.h"
#include "tts/nlp/tn/text_normalizer.h"
#include "tts/util/tts_util/util.h"

namespace nlp {
namespace polyphone {

static const char kSegSepMark = '\t';
static const char kPronSepMark = ' ';
static const string kTestDataDir = "tts/nlp/polyphone/testdata";  // NOLINT
enum PolyphoneTestFormat {
  kInput = 0,
  kExpect,
  kPolyphoneTestAllNum,
};

void PolyphoneCaseTest(std::shared_ptr<tn::TextNormalizer> text_normalizer,
                       std::shared_ptr<segmenter::Segmenter> segmenter,
                       std::shared_ptr<Polyphone> polyphone, const string& text,
                       const string& pron) {
  string norm_text;
  text_normalizer->Normalize(text, "", &norm_text);

  vector<segmenter::SegmentWord> segment_words;
  segmenter->WordSegmentation(norm_text, &segment_words);

  vector<PolyphoneToken> polyphone_tokens;
  for (const auto& segment_word : segment_words) {
    vector<string> prons;
    SplitString(segment_word.pron, kPronSepMark, &prons);
    polyphone::PolyphoneToken polyphone_token(segment_word.word,
                                              segment_word.pos, prons);
    polyphone_tokens.push_back(polyphone_token);
  }
  polyphone->PolyphoneProcess(&polyphone_tokens);

  vector<string> result_prons;
  for (const auto& polyphone_token : polyphone_tokens) {
    result_prons.push_back(JoinVector(polyphone_token.prons, kPronSepMark));
  }
  EXPECT_EQ(pron, JoinVector(result_prons, kPronSepMark)) << text;
}

void PolyphoneFileTest(std::shared_ptr<tn::TextNormalizer> text_normalizer,
                       std::shared_ptr<segmenter::Segmenter> segmenter,
                       std::shared_ptr<Polyphone> polyphone,
                       const string& test_file) {
  vector<string> lines;
  file::SimpleLineReader file_reader(test_file, true, "#");
  file_reader.ReadLines(&lines);
  for (const auto& line : lines) {
    vector<string> segs;
    SplitString(line, kSegSepMark, &segs);
    ASSERT_EQ(PolyphoneTestFormat::kPolyphoneTestAllNum, segs.size());
    string input = segs[PolyphoneTestFormat::kInput];
    string expect = segs[PolyphoneTestFormat::kExpect];
    PolyphoneCaseTest(text_normalizer, segmenter, polyphone, input, expect);
  }
}

TEST(PolyphoneTest, OtherRuleTest) {
  LOG(INFO) << "begin other rule polyphone test";
  const string tn_conf = "external/config/front_end/tn/man_tn.conf";
  const string segmenter_conf =
      "external/config/front_end/segmenter/man_segmenter.conf";
  const string polyphone_conf =
      "external/config/front_end/polyphone/man_polyphone.conf";
  std::shared_ptr<tn::TextNormalizer> text_normalizer;
  text_normalizer.reset(
      new nlp::tn::TextNormalizer(tts::kMandarinTypeString, tn_conf));
  std::shared_ptr<segmenter::Segmenter> segmenter;
  segmenter.reset(new segmenter::Segmenter(segmenter_conf));
  std::shared_ptr<Polyphone> polyphone;
  polyphone.reset(new Polyphone(polyphone_conf));

  {  // tone
    const string text1 = "一闹";
    const string expect1 = "yi1 nao4";
    PolyphoneCaseTest(text_normalizer, segmenter, polyphone, text1, expect1);

    const string text2 = "一汽";
    const string expect2 = "yi1 qi4";
    PolyphoneCaseTest(text_normalizer, segmenter, polyphone, text2, expect2);
  }

  {  // single
    const string text1 = "单杰华";
    const string expect1 = "shan4 jie2 hua2";
    PolyphoneCaseTest(text_normalizer, segmenter, polyphone, text1, expect1);

    const string text2 = "单行线";
    const string expect2 = "dan1 xing2 xian4";
    PolyphoneCaseTest(text_normalizer, segmenter, polyphone, text2, expect2);
  }

  {  // all
    const string text2 = "地上";
    const string expect2 = "di4 shang4";
    PolyphoneCaseTest(text_normalizer, segmenter, polyphone, text2, expect2);
  }
}

TEST(PolyphoneTest, MandarinPolyphoneTest) {
  LOG(INFO) << "begin madarin polyphone test";
  const string tn_conf = "external/config/front_end/tn/man_tn.conf";
  const string segmenter_conf =
      "external/config/front_end/segmenter/man_segmenter.conf";
  const string polyphone_conf =
      "external/config/front_end/polyphone/man_polyphone.conf";
  std::shared_ptr<tn::TextNormalizer> text_normalizer;
  text_normalizer.reset(
      new nlp::tn::TextNormalizer(tts::kMandarinTypeString, tn_conf));
  std::shared_ptr<segmenter::Segmenter> segmenter;
  segmenter.reset(new segmenter::Segmenter(segmenter_conf));
  std::shared_ptr<Polyphone> polyphone;
  polyphone.reset(new Polyphone(polyphone_conf));
#ifndef FOR_PORTABLE
  const string test_file =
      mobvoi::File::JoinPath(kTestDataDir, "polyphone_mandarin_test.txt");
#else
  const string test_file = mobvoi::File::JoinPath(
      kTestDataDir, "polyphone_mandarin_test_offline.txt");
#endif
  PolyphoneFileTest(text_normalizer, segmenter, polyphone, test_file);
  LOG(INFO) << "finish madarin polyphone test";
}

#ifndef FOR_PORTABLE
TEST(PolyphoneTest, TaiwanesePolyphoneTest) {
  LOG(INFO) << "begin taiwanese polyphone test";
  const string tn_conf = "external/config/front_end/tn/tw_tn.conf";
  const string segmenter_conf =
      "external/config/front_end/segmenter/tw_segmenter.conf";
  const string polyphone_conf =
      "external/config/front_end/polyphone/tw_polyphone.conf";
  std::shared_ptr<tn::TextNormalizer> text_normalizer;
  text_normalizer.reset(
      new nlp::tn::TextNormalizer(tts::kMandarinTypeString, tn_conf));
  std::shared_ptr<segmenter::Segmenter> segmenter;
  segmenter.reset(new segmenter::Segmenter(segmenter_conf));
  std::shared_ptr<Polyphone> polyphone;
  polyphone.reset(new Polyphone(polyphone_conf));
#ifndef FOR_PORTABLE
  const string test_file =
      mobvoi::File::JoinPath(kTestDataDir, "polyphone_taiwanese_test.txt");
#else
  const string test_file = mobvoi::File::JoinPath(
      kTestDataDir, "polyphone_taiwanese_test_offline.txt");
#endif

  PolyphoneFileTest(text_normalizer, segmenter, polyphone, test_file);
  LOG(INFO) << "finish taiwanese polyphone test";
}
#endif

}  // namespace polyphone
}  // namespace nlp
