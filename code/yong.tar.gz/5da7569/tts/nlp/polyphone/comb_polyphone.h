// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaoqin.feng@mobvoi.com

#ifndef TTS_NLP_POLYPHONE_COMB_POLYPHONE_H_
#define TTS_NLP_POLYPHONE_COMB_POLYPHONE_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "tts/nlp/polyphone/crf_polyphone.h"
#include "tts/nlp/polyphone/dict_polyphone.h"
#include "tts/nlp/polyphone/proto/polyphone_resource.pb.h"

namespace nlp {
namespace polyphone {

class CombPolyphone : public PolyphoneImpl {
 public:
  explicit CombPolyphone(const PolyphoneResource& resource);
  virtual ~CombPolyphone();

  virtual bool PolyphoneProcess(vector<PolyphoneToken>* polyphone_tokens) const;
  virtual bool PolyphoneProcess(vector<PolyphoneToken>* polyphone_tokens,
                                map<int, int>* polyphone_prob) const;
  virtual mobvoi::unordered_set<string> GetPolyphoneModelDict() const;

 private:
  std::unique_ptr<DictPolyphone> dict_polyphone_;
  std::unique_ptr<CrfPolyphone> crf_polyphone_;

  DISALLOW_COPY_AND_ASSIGN(CombPolyphone);
};

}  // namespace polyphone
}  // namespace nlp
#endif  // TTS_NLP_POLYPHONE_COMB_POLYPHONE_H_
