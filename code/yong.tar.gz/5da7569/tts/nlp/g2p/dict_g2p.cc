// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/nlp/g2p/dict_g2p.h"
#include "tts/nlp/g2p/g2p_util.h"
#include "tts/util/tts_util/util.h"

#include "mobvoi/base/log.h"

namespace nlp {
namespace g2p {

enum UserDictFormat {
  kUserDictWord = 0,
  kUserDictPron,
  kUserDictAllNum,
};

static const int kMaxPinyinLen = 6;
static const int kMaxPinyinWordNum = 3;

DictG2p::DictG2p(const string& user_dict, const string& config_center,
                 const string& word_dict, const string& pinyin_dict) {
  LoadUserDict(user_dict);
  LoadUserDict(config_center);
  LoadWordDict(word_dict);
  tts::LoadMapFromFile(pinyin_dict, &pinyin_dict_);
}

DictG2p::~DictG2p() {}

bool DictG2p::GetPron(const string& text, vector<string>* syl_prons) const {
  if (GetPronFromUserDict(text, syl_prons)) return true;

  string input_lower = tts::ToLower(text);
  if (GetPronFromWordDict(input_lower, syl_prons)) return true;

  if (tts::AllUpper(text)) {
    GetSinglePron(input_lower, syl_prons);
    return true;
  }

  if (ProcessPinyin(input_lower, syl_prons)) return true;

  return false;
}

// new word will overwrite old word
void DictG2p::LoadUserDict(const string& user_dict_path) {
  vector<string> lines;
  tts::GetConfigCenterLines(user_dict_path, &lines);
  for (const auto& line : lines) {
    vector<string> segs;
    mobvoi::SplitStringToVector(line, tts::kCCSepMark, true, &segs);
    if (segs.size() != UserDictFormat::kUserDictAllNum) {
      LOG(WARNING) << "Format ERROR: " << line;
      continue;
    }
    user_dict_[segs[UserDictFormat::kUserDictWord]] =
        segs[UserDictFormat::kUserDictPron];
  }
}

// StringMap ptr reset and OpenModelFile should come together
void DictG2p::LoadWordDict(const string& word_dict) {
  if (word_dict.empty()) return;
  word_dict_.reset(new mobvoi::StringMap());
  word_dict_->OpenModelFile(word_dict);
}

bool DictG2p::GetPronFromUserDict(const string& text,
                                  vector<string>* syl_prons) const {
  if (user_dict_.find(text) == user_dict_.end()) return false;
  ParseSyllable(user_dict_.at(text), syl_prons);
  return true;
}

bool DictG2p::GetPronFromWordDict(const string& text,
                                  vector<string>* syl_prons) const {
  if (!word_dict_) return false;
  string pron_str;
  if (!word_dict_->Find(text, &pron_str)) return false;
  vector<string> phonemes;
  SplitString(pron_str, ' ', &phonemes);
  JoinSyllable(phonemes, syl_prons);
  return true;
}

bool DictG2p::ProcessPinyin(const string& text,
                            vector<string>* syl_prons) const {
  string text_tmp = text;
  auto it = text_tmp.find(tts::kPinyinTag);
  if (it != string::npos) {
    text_tmp = text_tmp.substr(it + tts::kPinyinTag.size());
  }

  vector<string> pinyins;
  if (!SplitPinyin(text_tmp, &pinyins)) return false;
  if (pinyins.size() > kMaxPinyinWordNum) return false;
  for (const auto& pinyin : pinyins) {
    auto it = pinyin_dict_.find(pinyin);
    vector<string> syl_pinyins;
    if (it != pinyin_dict_.end()) {
      ParseSyllable(it->second, &syl_pinyins);
    }
    syl_prons->insert(syl_prons->end(), syl_pinyins.begin(), syl_pinyins.end());
  }
  return true;
}

bool DictG2p::SplitPinyin(const string& text, vector<string>* pinyins) const {
  if (text.empty()) return false;
  // process pinyin segs e.g. xi'an
  vector<string> text_segs;
  SplitString(text, '\'', &text_segs);
  for (const auto& text_seg : text_segs) {
    vector<string> pinyin_segs;
    if (!SplitPinyinString(text_seg, &pinyin_segs)) return false;
    pinyins->insert(pinyins->end(), pinyin_segs.begin(), pinyin_segs.end());
  }
  return true;
}

bool DictG2p::SplitPinyinString(const string& text,
                                vector<string>* pinyins) const {
  vector<size_t> next_offset(text.size(), 0);
  // dynamic generate path from the end to the begining
  for (size_t i = 0; i < text.size(); ++i) {
    size_t begin = text.size() - i - 1;
    size_t max_len = std::min(text.size() - begin, (size_t)kMaxPinyinLen);
    for (size_t len = max_len; len > 0; --len) {
      size_t next_off = begin + len;
      if (next_off < text.size() && next_offset[next_off] == 0) continue;
      string sub_str = text.substr(begin, len);
      if (pinyin_dict_.find(sub_str) != pinyin_dict_.end()) {
        next_offset[begin] = next_off;
        break;
      }
    }
  }
  size_t off_tmp = 0;
  if (!next_offset[off_tmp]) return false;
  while (off_tmp < text.size()) {
    pinyins->emplace_back(text.substr(off_tmp, next_offset[off_tmp] - off_tmp));
    off_tmp = next_offset[off_tmp];
  }
  return true;
}

}  // namespace g2p
}  // namespace nlp
