// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#ifndef TTS_NLP_G2P_COMB_G2P_H_
#define TTS_NLP_G2P_COMB_G2P_H_

#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "re2/re2.h"
#include "tts/util/tts_util/util.h"
#include "tts/nlp/g2p/g2p_util.h"
#include "tts/nlp/g2p/dict_g2p.h"
#include "tts/nlp/g2p/phonetisaurus_g2p.h"
#include "tts/nlp/g2p/proto/g2p_resource.pb.h"

namespace nlp {
namespace g2p {

struct Symbol2Pron {
  const string symbol;
  const string pron;
};

class CombG2p : public G2pImpl {
 public:
  explicit CombG2p(const G2pResource& resource);
  virtual ~CombG2p();

  virtual bool GetPron(const string& text, vector<string>* syl_prons) const;
  bool GetAbbvPron(const string& text, vector<string>* syl_prons) const;


 private:
  std::unique_ptr<DictG2p> dict_g2p_;
  std::unique_ptr<PhonetisaurusG2p> phonetisaurus_g2p_;

  DISALLOW_COPY_AND_ASSIGN(CombG2p);
};

}  // namespace g2p
}  // namespace nlp

#endif  // TTS_NLP_G2P_COMB_G2P_H_
