// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/nlp/g2p/g2p_util.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/util/utf8/utf8_util.h"
#include "re2/re2.h"
#include "tts/util/tts_util/util.h"

namespace nlp {
namespace g2p {

static const char* kEnglishSinglePron[] = {
    "EY1",   "B_IY1",   "S_IY1",           "D_IY1",   "IY1",
    "EH1_F", "JH_IY1",  "EY1_CH",          "AY1",     "JH_EY1",
    "K_EY1", "EH1_L",   "EH1_M",           "EH1_N",   "OW1",
    "P_IY1", "K_Y_UW1", "AA1_R",           "EH1_S",   "T_IY1",
    "Y_UW1", "V_IY1",   "D_AH1_B L_Y_UW0", "EH1_K_S", "W_AY1",
    "Z_IY1",
};

// phoneme in 1 syllable are joined with '_', each syllable is seperate with ' '
// e.g. D_AH1_B L_Y_UW0
static const char kPhoneSepMark[] = "_";
static const char kSylSepMark = ' ';

void ParseSyllable(const string& pron, vector<string>* syl_prons) {
  SplitString(pron, kSylSepMark, syl_prons);
  static re2::RE2 phone_sep(kPhoneSepMark);
  for (auto& pron_tmp : *syl_prons) {
    re2::RE2::GlobalReplace(&pron_tmp, phone_sep, " ");
  }
}

void GetSinglePron(const string& text_lower, vector<string>* syl_prons) {
  vector<util::Rune> unicodes;
  util::Utf8ToUnicode(text_lower, &unicodes);
  for (const auto unicode : unicodes) {
    if (unicode >= 'a' && unicode <= 'z') {
      vector<string> syl;
      ParseSyllable(kEnglishSinglePron[unicode - 'a'], &syl);
      syl_prons->insert(syl_prons->end(), syl.begin(), syl.end());
    }
  }
}

bool HasEngVowel(const vector<string>& phonemes) {
  for (const string& phoneme : phonemes) {
    if (tts::IsEngVowel(phoneme)) return true;
  }
  return false;
}

// english syllable rules:
// split by vowels, consonant joint to next syllable
// if consonant more tha:n 1, split the first consonant into previous syllable
void JoinSyllable(const vector<string>& phonemes, vector<string>* syl_prons) {
  vector<string> phonemes_tmp;
  vector<vector<string>> syllables_tmp;
  for (const string& phoneme : phonemes) {
    if (tts::IsEngVowel(phoneme)) {
      phonemes_tmp.emplace_back(phoneme);
      // if more than 1 consonant, split first one into previous syllable
      if (phonemes_tmp.size() > 2 && syllables_tmp.size() > 0) {
        syllables_tmp.back().emplace_back(phonemes_tmp.front());
        phonemes_tmp.erase(phonemes_tmp.begin());
      }
      syllables_tmp.emplace_back(phonemes_tmp);
      phonemes_tmp.clear();
    } else {
      phonemes_tmp.emplace_back(phoneme);
    }
  }
  // add left consonant
  if (!phonemes_tmp.empty()) {
    if (!syllables_tmp.empty()) {
      syllables_tmp.back().insert(syllables_tmp.back().end(),
                                  phonemes_tmp.begin(), phonemes_tmp.end());
    } else {
      syllables_tmp.emplace_back(phonemes_tmp);
    }
  }
  // join syllable string
  for (size_t i = 0; i < syllables_tmp.size(); ++i) {
    syl_prons->emplace_back(JoinVector(syllables_tmp[i], ' '));
  }
}

}  // namespace g2p
}  // namespace nlp
