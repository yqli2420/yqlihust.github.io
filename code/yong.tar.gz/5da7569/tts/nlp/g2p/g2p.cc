// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/nlp/g2p/g2p.h"

#include "mobvoi/base/file/file.h"
#include "mobvoi/base/file/proto_util.h"
#include "tts/nlp/g2p/comb_g2p.h"
#include "tts/nlp/g2p/proto/g2p_resource.pb.h"
#include "tts/util/tts_util/util.h"

namespace nlp {
namespace g2p {

G2p::G2p(const string& resource_file) {
  G2pResource resource;
  CHECK(mobvoi::ReadProtoFromTextFile(resource_file, &resource))
      << resource_file << " load failed!";
  string dir = mobvoi::File::FindFileDir(resource_file);
  resource.set_user_dict(tts::AppendPath(dir, resource.user_dict()));
  resource.set_config_center(tts::AppendPath(dir, resource.config_center()));
  resource.set_word_dict(tts::AppendPath(dir, resource.word_dict()));
  resource.set_pinyin_dict(tts::AppendPath(dir, resource.pinyin_dict()));
  resource.set_g2p_model(tts::AppendPath(dir, resource.g2p_model()));

  g2p_.reset(static_cast<G2pImpl*>(new CombG2p(resource)));
}

G2p::~G2p() {}

bool G2p::GetPron(const string& text, vector<string>* syl_prons) const {
  return g2p_->GetPron(text, syl_prons);
}

}  // namespace g2p
}  // namespace nlp
