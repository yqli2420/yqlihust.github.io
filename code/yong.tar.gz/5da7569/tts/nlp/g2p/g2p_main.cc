// Copyright 2014 Mobvoi Inc. All Rights Reserved.
// Author: qli@mobvoi.com (Qian Li)
// Created on: Jul 23, 2014
//
// Given a g2p model and a text to be parsed, we produce the pronunciation
// of this text.

#include "tts/nlp/g2p/g2p.h"
#include "mobvoi/base/basictypes.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/base/time.h"
#include "mobvoi/util/utf8/utf8_util.h"

DEFINE_string(resource_file, "external/config/front_end/g2p/eng_g2p.conf",
              "g2p config file");
DEFINE_string(text, "", "text to be parsed");
DEFINE_string(text_file, "", "");

int main(int argc, char** argv) {
  google::ParseCommandLineFlags(&argc, &argv, false);

  nlp::g2p::G2p g2p(FLAGS_resource_file);

  vector<string> lines;
  if (!FLAGS_text.empty()) {
    lines.emplace_back(FLAGS_text);
  } else if (!FLAGS_text_file.empty()) {
    file::SimpleLineReader reader(FLAGS_text_file);
    reader.ReadLines(&lines);
  } else {
    LOG(FATAL) << "set --text or --text_file";
  }

  int64 begin_time = mobvoi::GetTimeInMs();
  int bytes = 0;
  for (const string& line : lines) {
    bytes += util::utflen(line.c_str());
    vector<string> words;
    SplitString(line, ' ', &words);
    for (const auto& word : words) {
      vector<string> word_prons;
      g2p.GetPron(word, &word_prons);
      LOG(INFO) << word + ": " + mobvoi::JoinVectorToString(word_prons, " / ");
    }
  }
  int64 end_time = mobvoi::GetTimeInMs();
  int64 used_time = end_time - begin_time;
  if (used_time) {
    LOG(INFO) << "convert bytes:" << bytes << ", used time in Ms:" << used_time
              << ", performance :" << bytes * 1000 / used_time
              << " bytes/second";
  }
  return 0;
}
