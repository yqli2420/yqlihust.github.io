// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/nlp/g2p/comb_g2p.h"

namespace nlp {
namespace g2p {

static const Symbol2Pron kEngAbbv2Pron[] = {
    {"t", "AH0 N T"}, {"s", "Z"}, {"re", "R"}, {"ve", "V"},
    {"ll", "L"},      {"m", "M"}, {"d", "D"},
};

CombG2p::CombG2p(const G2pResource& resource) {
  dict_g2p_.reset(new DictG2p(resource.user_dict(), resource.config_center(),
                              resource.word_dict(), resource.pinyin_dict()));
  phonetisaurus_g2p_.reset(new PhonetisaurusG2p(resource.g2p_model()));
}

CombG2p::~CombG2p() {}

bool CombG2p::GetPron(const string& text, vector<string>* syl_prons) const {
  return dict_g2p_->GetPron(text, syl_prons) || GetAbbvPron(text, syl_prons) ||
         phonetisaurus_g2p_->GetPron(text, syl_prons);
}

// get english abbviation's pron
bool CombG2p::GetAbbvPron(const string& text, vector<string>* syl_prons) const {
  static re2::RE2 engabbv_pattern("([A-Za-z]+)(')(t|s|re|ll|m|ve|d)");
  if (RE2::FullMatch(text, engabbv_pattern)) {
    string prefix;
    string postfix;
    RE2::Extract(text, engabbv_pattern, "\\1", &prefix);
    RE2::Extract(text, engabbv_pattern, "\\3", &postfix);
    vector<string> syl_prons_tmp;
    GetPron(prefix, &syl_prons_tmp);
    for (const auto& abbv_str : kEngAbbv2Pron) {
      if (abbv_str.symbol == postfix) {
        syl_prons_tmp.emplace_back(abbv_str.pron);
      }
    }
    // re syllable
    vector<string> phonemes_tmp;
    SplitString(JoinVector(syl_prons_tmp, ' '), ' ', &phonemes_tmp);
    JoinSyllable(phonemes_tmp, syl_prons);
    return true;
  }
  return false;
}
}  // namespace g2p
}  // namespace nlp
