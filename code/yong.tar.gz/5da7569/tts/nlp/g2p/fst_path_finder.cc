/*
 FstPathFinder.cpp

 Copyright (c) [2012-], Josef Robert Novak
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
  modification, are permitted #provided that the following conditions
  are met:

  * Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above
    copyright notice, this list of #conditions and the following
    disclaimer in the documentation and/or other materials provided
    with the distribution.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 OF THE POSSIBILITY OF SUCH DAMAGE.
  ----------------
    Original author: chris taylor

    OpenFst forum post title: "Natural code for printing all strings accepted by
 an FST?"
    OpenFst forum post link:
 http://openfst.cs.nyu.edu/twiki/bin/view/Forum/FstForum#Natural_code_for_printing_all_st

  ----------------

    2011-04-07: Modified by Josef Novak

    Modified to build a 'paths' object to store the individual paths
    and associated weights, rather than just print them out from
    inside the class.  Useful if you want to return the paths for further
    processing.
*/

#include "tts/nlp/g2p/fst_path_finder.h"

#include "mobvoi/base/log.h"

using fst::ArcIterator;
using fst::StdArc;
using fst::SymbolTable;
using fst::TropicalWeight;
using fst::VectorFst;

namespace nlp {
namespace g2p {

FstPathFinder::FstPathFinder(const unordered_set<string>& skipset)
    : skip_seqs_(skipset) {}

/*
  Main search function.  Initiates the WFSA traversal.
  We are making three potentially dangerous assumptions
  here regarding the input FST:

  1. It has *ALREADY* been run through the shortestpath algorithm
     *This guarantees the the FST is acyclic and that the paths are
     sorted according to path cost.
  2. It has *ALREADY* been projected
     *This just saves us some hassle.
  3. The symbol tables have been stored in the input FST
     *This just saves us some hassle.

  If the input FST does not meet these conditions this will
cause problems.
*/
void FstPathFinder::FindAllStrings(VectorFst<StdArc>& fst) {
  isyms_ = (SymbolTable*)fst.InputSymbols();   // NOLINT
  osyms_ = (SymbolTable*)fst.OutputSymbols();  // NOLINT
  if (isyms_ == NULL || osyms_ == NULL) {
    return;
  }
  vector<string> ipath;
  vector<string> opath;
  FindAllStringsHelper(fst, fst.Start(), ipath, opath, TropicalWeight::One());
  return;
}

/*
  Determine whether or not the input path has been added
  to the paths vector or not.  If it hasn't, add it, otherwise
  discard it.
*/
void FstPathFinder::AddOrDiscardPath(PathData pdata) {
  auto it = unique_strings_.find(pdata.ipath);
  if (it == unique_strings_.end()) {
    paths_.push_back(pdata);
    unique_strings_.insert(pdata.ipath);
  }
  return;
}

/*
  Recursively traverse the WFSA and build up a vector of
  unique paths and associated costs.
*/
void FstPathFinder::FindAllStringsHelper(VectorFst<StdArc>& fst, int state,
                                         vector<string>& ipath,
                                         vector<string>& opath,
                                         TropicalWeight cost) {
  if (state < 0) {
    LOG(ERROR) << "state < 0, skip.";
    return;
  }
  if (fst.Final(state) != TropicalWeight::Zero()) {
    PathData pdata;
    pdata.ipath = ipath;
    pdata.opath = opath;
    pdata.pathcost = Times(cost, fst.Final(state)).Value();
    AddOrDiscardPath(pdata);
    ipath.clear();
    opath.clear();
    return;
  }

  for (ArcIterator<VectorFst<StdArc> > iter(fst, state); !iter.Done();
       iter.Next()) {
    StdArc arc = iter.Value();
    if (arc.nextstate < 0) continue;
    string isymbol = isyms_->Find(arc.ilabel);
    string osymbol = osyms_->Find(arc.olabel);

    auto iit = skip_seqs_.find(isymbol);
    if (iit == skip_seqs_.end()) {
      ipath.push_back(isymbol);
    }
    auto oit = skip_seqs_.find(osymbol);
    if (oit == skip_seqs_.end()) {
      opath.push_back(osymbol);
    }
    FindAllStringsHelper(fst, arc.nextstate, ipath, opath,
                         Times(cost, arc.weight.Value()));
  }
}

}  // namespace g2p
}  // namespace nlp
