/*
 * FstPathFinder.hpp

 Copyright (c) [2012-], Josef Robert Novak
 All rights reserved.

 Redistribution and use in source and binary forms, with or without
  modification, are permitted #provided that the following conditions
  are met:

  * Redistributions of source code must retain the above copyright 
    notice, this list of conditions and the following disclaimer.
  * Redistributions in binary form must reproduce the above 
    copyright notice, this list of #conditions and the following 
    disclaimer in the documentation and/or other materials provided 
    with the distribution.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED 
 OF THE POSSIBILITY OF SUCH DAMAGE.
  ----------------
    Original author: Chris Taylor

    OpenFst forum post title: "Natural code for printing all strings accepted by an FST?"
    OpenFst forum post link: http://openfst.cs.nyu.edu/twiki/bin/view/Forum/FstForum#Natural_code_for_printing_all_st

  ----------------

    2011-04-07: Modified by Josef Novak 

    Modified to build a 'paths' object to store the individual paths
    and associated weights, rather than just print them out from 
    inside the class.  Useful if you want to return the paths for further
    processing.
*
*/
#ifndef TTS_NLP_G2P_FST_PATH_FINDER_H_
#define TTS_NLP_G2P_FST_PATH_FINDER_H_

#include "mobvoi/base/compat.h"
#include "mobvoi/base/hash.h"
#include "third_party/openfst/include/fst/vector-fst.h"

namespace nlp {
namespace g2p {

struct PathData {
  vector<string> ipath;
  vector<string> opath;
  float pathcost;
};

class FstPathFinder {
 public:
  explicit FstPathFinder(const unordered_set<string>& skipset);

  void FindAllStrings(fst::StdVectorFst& fst);  // NOLINT
  vector<PathData> paths() { return paths_; }

 private:
  void AddOrDiscardPath(PathData pdata);
  void FindAllStringsHelper(fst::StdVectorFst& fst,  // NOLINT
                            int state,
                            vector<string>& ipath,  // NOLINT
                            vector<string>& opath,  // NOLINT
                            fst::TropicalWeight cost);

  vector<PathData> paths_;
  const unordered_set<string>& skip_seqs_;
  unordered_set<vector<string>, mobvoi::StringVectorHasher> unique_strings_;
  fst::SymbolTable* isyms_;  // This class doesn't own the pointer.
  fst::SymbolTable* osyms_;  // This class doesn't own the pointer.
  DISALLOW_COPY_AND_ASSIGN(FstPathFinder);
};

}  // namespace g2p
}  // namespace nlp
#endif  // TTS_NLP_G2P_FST_PATH_FINDER_H_
