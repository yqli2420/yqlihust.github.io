// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/nlp/g2p/g2p.h"
#include "mobvoi/base/compat.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/util/utf8/charset_util.h"
#include "re2/re2.h"

DEFINE_string(resource_file, "external/config/front_end/g2p/eng_g2p.conf",
              "g2p config file");
DEFINE_string(test_file, "",
              "file format: text \t pron, pron of one word are seperated with "
              "' ' and between words are seperated with '_'");

static const char kFormatSepMark = '\t';
static const char kPhonemeSepMark = ' ';
static const char kWordSepMark = '_';
enum G2pFileFormat {
  kG2pText = 0,
  kG2pPron,
  kG2pAllNum,
};

struct Performance {
  int sent_num = 0;
  int word_num = 0;
  int right_sent_num = 0;
  int right_word_num = 0;
  int right_sent_without_tone = 0;
  int right_word_without_tone = 0;
  void Display() const;
};

void Performance::Display() const {
  if (!sent_num || !word_num) return;
  LOG(INFO) << "all sentence number: " << sent_num;
  LOG(INFO) << "right sentence / wrong sentence: " << right_sent_num << " / "
            << sent_num - right_sent_num;
  LOG(INFO) << "sent acc: " << 100.0 * right_sent_num / sent_num << "%";
  LOG(INFO) << "right word / wrong word: " << right_word_num << " / "
            << word_num - right_word_num;
  LOG(INFO) << "sent acc: " << 100.0 * right_sent_num / sent_num << "%";

  LOG(INFO) << "without tone";
  LOG(INFO) << "right sentence / wrong sentence: " << right_sent_without_tone
            << " / " << sent_num - right_sent_without_tone;
  LOG(INFO) << "word acc: " << 100.0 * right_sent_without_tone / sent_num
            << "%";
  LOG(INFO) << "right sentence / wrong sentence: " << right_word_without_tone
            << " / " << word_num - right_word_without_tone;
  LOG(INFO) << "word acc: " << 100.0 * right_word_without_tone / word_num
            << "%";
}

bool Check(const vector<string>& prons, const vector<string>& expect_prons,
           Performance* performance) {
  if (prons.size() != expect_prons.size()) return false;
  bool correct = true;
  bool without_tone_correct = true;
  for (size_t i = 0; i < prons.size(); ++i) {
    if (prons[i] == expect_prons[i]) {
      ++performance->right_word_num;
    } else {
      correct = false;
    }
    string pron_without_tone = prons[i];
    string expect_pron_without_tone = expect_prons[i];
    static re2::RE2 num("\\d");
    re2::RE2::GlobalReplace(&pron_without_tone, num, "");
    re2::RE2::GlobalReplace(&expect_pron_without_tone, num, "");
    if (pron_without_tone == expect_pron_without_tone) {
      ++performance->right_word_without_tone;
    } else {
      without_tone_correct = false;
    }
  }
  if (correct) {
    ++performance->right_sent_num;
    return true;
  }
  if (without_tone_correct) ++performance->right_sent_without_tone;
  return false;
}

int main(int argc, char** argv) {
  google::ParseCommandLineFlags(&argc, &argv, false);

  unique_ptr<nlp::g2p::G2p> g2p_;
  g2p_.reset(new nlp::g2p::G2p(FLAGS_resource_file));

  vector<string> lines;
  file::SimpleLineReader reader(FLAGS_test_file);
  reader.ReadLines(&lines);

  Performance performance;
  for (const auto& line : lines) {
    vector<string> segs;
    SplitString(line, kFormatSepMark, &segs);
    if (segs.size() != G2pFileFormat::kG2pAllNum) {
      LOG(ERROR) << "Bad line:" << line;
      continue;
    }
    ++performance.sent_num;
    const string& text = segs[G2pFileFormat::kG2pText];
    const string& expect_sentence_pron = segs[G2pFileFormat::kG2pPron];
    vector<string> expect_word_prons;
    SplitString(expect_sentence_pron, kWordSepMark, &expect_word_prons);

    vector<string> words;
    SplitString(text, ' ', &words);
    performance.word_num += words.size();
    vector<string> prons;
    for (const auto& word : words) {
      vector<string> word_pron;
      g2p_->GetPron(word, &word_pron);
      prons.emplace_back(JoinVector(word_pron, ' '));
    }
    if (!Check(prons, expect_word_prons, &performance)) {
      LOG(WARNING) << "sentence error: " << line;
      LOG(WARNING) << "actual result: " << JoinVector(prons, kWordSepMark);
    }
  }

  performance.Display();
  return 0;
}
