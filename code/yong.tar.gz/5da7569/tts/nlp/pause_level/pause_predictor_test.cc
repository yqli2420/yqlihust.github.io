// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: zhengzhang@mobvoi.com (Allen)

#include "tts/nlp/pause_level/pause_predictor.h"
#include "third_party/gtest/gtest.h"
#include "tts/nlp/segmenter/segmenter.h"

namespace nlp {
namespace prosody {

class PausePredictorTest : public ::testing::Test {
 protected:
  virtual void SetUp() {
    const string segmenter_conf =
        "external/config/front_end/segmenter/man_segmenter.conf";

    const string pause_model =
        "external/config/front_end/pause_model/mandarin_pause_model";

    segmenter_.reset(new nlp::segmenter::Segmenter(segmenter_conf));
    pause_predictor_.reset(new PausePredictor(pause_model));
  }

  void GenPausePredictToken(const string& text,
                            vector<InputToken>* tokens) const {
    vector<nlp::segmenter::SegmentWord> segment_words;
    segmenter_->WordSegmentation(text, &segment_words);
    for (const auto& segment_word : segment_words) {
      nlp::prosody::InputToken token;
      token.word = segment_word.word;
      token.word_id = segment_word.word_id;
      token.pos = segment_word.pos;
      tokens->emplace_back(token);
    }
  }

  void TokenCaseTest(const vector<InputToken>& tokens,
                     const vector<string>& expect_words) const {
    ASSERT_EQ(expect_words.size(), tokens.size());
    for (size_t i = 0; i < tokens.size(); ++i) {
      EXPECT_EQ(expect_words[i], tokens[i].word)
          << "expect: " << expect_words[i] << " result: " << tokens[i].word;
    }
  }

  void PauseCaseTest(const vector<InputToken>& tokens,
                     const vector<int>& expect_pause_level) const {
    vector<int> result;
    pause_predictor_->Predict(tokens, &result);
    EXPECT_EQ(expect_pause_level, result);
  }

  std::unique_ptr<PausePredictor> pause_predictor_;
  std::unique_ptr<nlp::segmenter::Segmenter> segmenter_;
};

TEST_F(PausePredictorTest, PauseTest) {
  const string text1 = "今天的天气万里无云.";
  vector<InputToken> tokens1;
  GenPausePredictToken(text1, &tokens1);
  const vector<string> expect_words1 = {"今天", "的", "天气", "万里无云", "."};
#ifndef FOR_PORTABLE
  const vector<int> expect_pause_level1 = {0, 2, 3, 4, 4};
#else
  const vector<int> expect_pause_level1 = {0, 2, 3, 4, 4};
#endif
  TokenCaseTest(tokens1, expect_words1);
  PauseCaseTest(tokens1, expect_pause_level1);

  const string text2 =
      "一艘搭载三十三名韩国游客的游船在匈牙利首都布达佩斯多瑙河上沉没";
  vector<InputToken> tokens2;
  GenPausePredictToken(text2, &tokens2);
  const vector<string> expect_words2 = {
      "一艘", "搭载",   "三十三名", "韩国",     "游客",   "的", "游船",
      "在",   "匈牙利", "首都",     "布达佩斯", "多瑙河", "上", "沉没",
  };

#ifndef FOR_PORTABLE
  const vector<int> expect_pause_level2 = {2, 2, 4, 2, 0, 2, 4,
                                           2, 2, 3, 2, 0, 2, 4};
#else
  const vector<int> expect_pause_level2 = {2, 2, 3, 2, 0, 2, 4,
                                           2, 2, 3, 2, 0, 2, 4};
#endif
  TokenCaseTest(tokens2, expect_words2);
  PauseCaseTest(tokens2, expect_pause_level2);
}

}  // namespace prosody
}  // namespace nlp
