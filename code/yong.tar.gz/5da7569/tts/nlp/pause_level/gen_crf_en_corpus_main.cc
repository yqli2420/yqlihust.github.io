// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaoqin.feng@mobvoi.com (xiaoqin.feng)

#include "mobvoi/base/file.h"
#include "mobvoi/base/file/proto_util.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/hash_tables.h"
#include "mobvoi/base/log.h"
#include "mobvoi/util/string/string_map.h"
#include "mobvoi/util/utf8/charset_util.h"
#include "mobvoi/util/utf8/utf.h"
#include "re2/re2.h"
#include "tts/nlp/pause_level/pause_predictor.h"
#include "tts/util/tts_util/util.h"

DEFINE_string(trie_dict, "external/config/front_end/g2p/eng_marisa",
              "trie_dict");
DEFINE_string(raw_file, "training/front_end/crf/en_23811.txt",
              "input raw file");
DEFINE_string(train_file, "training/front_end/crf/en_pause_corpus.train",
              "output train");
DEFINE_string(test_file, "training/front_end/crf/en_pause_corpus.test",
              "output test");
DEFINE_int32(test_set_number, 500, "testing set size(in sentences)");
DEFINE_int32(train_set_number, 200000, "training set size(in sentences)");

string GenerateData(int word_id, int flag) {
  return StringPrintf("%d\t%d", word_id, flag);
}

int main(int argc, char** argv) {
  google::ParseCommandLineFlags(&argc, &argv, false);
  mobvoi::StringMap m;
  m.OpenModelFile(FLAGS_trie_dict);
  vector<string> lines;
  file::SimpleLineReader reader(FLAGS_raw_file);
  reader.ReadLines(&lines);
  int test_set = (FLAGS_test_set_number > static_cast<int>(lines.size()))
                     ? lines.size()
                     : FLAGS_test_set_number;
  int train_set =
      (FLAGS_train_set_number + test_set > static_cast<int>(lines.size()))
          ? lines.size() - test_set
          : FLAGS_train_set_number;

  FILE* f_train = fopen(FLAGS_train_file.c_str(), "w");
  CHECK(f_train) << "Fail to open file:" << FLAGS_train_file;
  FILE* f_test = fopen(FLAGS_test_file.c_str(), "w");
  CHECK(f_test) << "Fail to open file:" << FLAGS_test_file;
  for (size_t i = 0; i < lines.size(); ++i) {
    if (i % 1000 == 0) LOG(INFO) << "processing sentence: " << i;
    if (i >= static_cast<size_t>(train_set + test_set)) break;
    vector<string> result;
    vector<string> pieces;
    SplitString(lines[i], '%', &pieces);
    if (pieces.empty()) return false;
    for (size_t j = 0; j < pieces.size(); ++j) {
      vector<string> eng;
      SplitString(pieces[j], ' ', &eng);
      if (eng.empty()) return false;
      int flag = 0;
      for (size_t k = 0; k < eng.size(); ++k) {
        size_t key_id;
        string input_lower = tts::ToLower(eng[k]);
        if (!m.FindKeyID(input_lower, &key_id)) {
          key_id = tts::kEnglishKeyId;
        }
        if (k == eng.size() - 1) flag = 1;
        string tmp = GenerateData(key_id, flag);
        result.push_back(tmp);
      }
    }
    string result_str = JoinVector(result, '\n');
    if (i < static_cast<size_t>(train_set)) {
      fprintf(f_train, "%s\n\n", result_str.c_str());
    } else if (i < static_cast<size_t>(train_set + test_set)) {
      fprintf(f_test, "%s\n\n", result_str.c_str());
    }
  }
  fclose(f_train);
  fclose(f_test);
  return 0;
}
