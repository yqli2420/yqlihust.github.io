// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "mobvoi/base/file.h"
#include "mobvoi/base/file/proto_util.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/hash_tables.h"
#include "mobvoi/base/log.h"
#include "mobvoi/util/utf8/charset_util.h"
#include "mobvoi/util/utf8/utf.h"
#include "re2/re2.h"
#include "tts/nlp/pause_level/pause_predictor.h"
#include "tts/nlp/segmenter/segmenter.h"
#include "tts/nlp/tn/text_normalizer.h"
#include "tts/synthesizer/label_generator/label_util.h"
#include "tts/util/tts_util/util.h"

DEFINE_string(raw_file, "training/front_end/crf/prosody_150000.txt",
              "input raw file");
DEFINE_string(train_file, "training/front_end/crf/pause_corpus.train",
              "output train");
DEFINE_string(test_file, "training/front_end/crf/pause_corpus.test",
              "output test");
DEFINE_int32(train_set_number, 200000, "training set size(in sentences)");
DEFINE_int32(test_set_number, 500, "testing set size(in sentences)");
DEFINE_int32(pause_level, 1, "generate pause level");
DEFINE_string(word_id, "", "generate word id dict");
DEFINE_string(darts_type, "marisa", "segmenter darts type");
DEFINE_string(segmenter_conf,
              "external/config/front_end/segmenter/man_segmenter.conf",
              "segmenter reosurce config");
DEFINE_string(tn_conf, "external/config/front_end/tn/man_tn.conf",
              "tn reosurce config");

// tn only use postprocess, language independent
static const char kLanguage[] = "Mandarin";

bool SplitTextToSegs(const string& text, vector<std::pair<string, int>>* segs) {
  vector<string> pieces;
  SplitString(text, '#', &pieces);
  if (pieces.empty()) return false;
  for (size_t i = 0; i < pieces.size(); ++i) {
    string content = (i == 0) ? pieces[i] : pieces[i].substr(1);
    if (content.empty()) {
      if (i != pieces.size() - 1) {
        // LOG(ERROR) << "fail to parse line" << text;
        return false;
      } else {
        continue;
      }
    }
    int pause_level;
    if (i < pieces.size() - 1) {
      if (!isdigit(pieces[i + 1][0])) {
        // LOG(ERROR) << "fail to parse pause level" << text;
        return false;
      } else {
        pause_level = StringToInt(pieces[i + 1].substr(0, 1));
      }
    } else {
      pause_level = nlp::prosody::PauseLevelList::kBreakLevel;
    }
    segs->push_back(std::make_pair(content, pause_level));
  }
  return true;
}

string GenerateData(const string& cword, int word_id, const string& pos,
                    int flag) {
  return StringPrintf("%d\t%s\t%d\t%d", word_id, pos.c_str(),
                      util::utflen(cword.c_str()), flag);
}

int main(int argc, char** argv) {
  google::ParseCommandLineFlags(&argc, &argv, false);

  vector<string> lines;
  file::SimpleLineReader reader(FLAGS_raw_file);
  reader.ReadLines(&lines);
  int test_set = (FLAGS_test_set_number > static_cast<int>(lines.size()))
                     ? lines.size()
                     : FLAGS_test_set_number;
  int train_set =
      (FLAGS_train_set_number + test_set > static_cast<int>(lines.size()))
          ? lines.size() - test_set
          : FLAGS_train_set_number;

  std::unique_ptr<nlp::segmenter::Segmenter> segmenter;
  segmenter.reset(new nlp::segmenter::Segmenter(FLAGS_segmenter_conf));

  std::unique_ptr<nlp::tn::TextNormalizer> text_normalizer;
  text_normalizer.reset(new nlp::tn::TextNormalizer(kLanguage, FLAGS_tn_conf));

  FILE* f_train = fopen(FLAGS_train_file.c_str(), "w");
  CHECK(f_train) << "Fail to open file:" << FLAGS_train_file;

  FILE* f_test = fopen(FLAGS_test_file.c_str(), "w");
  CHECK(f_test) << "Fail to open file:" << FLAGS_test_file;
  map<int, string> word_ids;

  for (size_t i = 0; i < lines.size(); ++i) {
    if (i % 1000 == 0) LOG(INFO) << "processing sentence: " << i;
    if (i >= static_cast<size_t>(train_set + test_set)) break;
    string line_tmp;
    mobvoi::TrimWhitespaceASCII(lines[i], mobvoi::TRIM_ALL, &line_tmp);
    vector<string> result;
    vector<std::pair<string, int>> segs;
    if (!SplitTextToSegs(line_tmp, &segs)) continue;
    for (size_t j = 0; j < segs.size(); ++j) {
      string norm;
      util::ConvertDbcToSbc(segs[j].first, &norm);
      text_normalizer->PostProcess(&norm);
      vector<nlp::segmenter::SegmentWord> segment_words;
      segmenter->WordSegmentation(norm, &segment_words);
      for (size_t k = 0; k < segment_words.size(); ++k) {
        const nlp::segmenter::SegmentWord& segment_word = segment_words[k];
        string cword = segment_word.word;
        int word_id = segment_word.word_id;
        string pos = segment_word.pos;
        // LOG(INFO) << cword << " " << word_id << " " << pos;
        if (word_ids.find(word_id) == word_ids.end()) word_ids[word_id] = cword;
        int flag;
        if (cword == tts::kSepMarkSilence || cword == tts::kSepMarkSP ||
            cword == tts::kSepMarkLP) {
          flag = 1;
        } else if (cword == tts::kSepMarkPhrase) {
          flag =
              (FLAGS_pause_level > nlp::prosody::PauseLevelList::kPhraseLevel)
                  ? 0
                  : 1;
        } else {
          if (k == segment_words.size() - 1 &&
              segs[j].second >= FLAGS_pause_level) {
            flag = 1;
          } else {
            flag = 0;
          }
        }
        string tmp = GenerateData(cword, word_id, pos, flag);
        result.push_back(tmp);
      }
    }
    string result_str = JoinVector(result, '\n');
    if (i < static_cast<size_t>(train_set)) {
      fprintf(f_train, "%s\n\n", result_str.c_str());
    } else if (i < static_cast<size_t>(train_set + test_set)) {
      fprintf(f_test, "%s\n\n", result_str.c_str());
    }
  }
  if (!FLAGS_word_id.empty()) {
    FILE* f_word_id = fopen(FLAGS_word_id.c_str(), "w");
    for (auto& it : word_ids) {
      fprintf(f_word_id, "%d\t%s\n", it.first, it.second.c_str());
    }
    fclose(f_word_id);
  }
  fclose(f_train);
  fclose(f_test);
  return 0;
}
