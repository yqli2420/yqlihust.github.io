// Copyright 2015 Mobvoi Inc. All Rights Reserved.
// Author: spye@mobvoi.com (Shunping Ye)

#include "tts/nlp/pause_level/pause_predictor.h"

#include "mobvoi/base/file.h"
#include "mobvoi/base/file/proto_util.h"
#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/flags.h"
#include "mobvoi/base/hash.h"
#include "mobvoi/base/log.h"
#include "mobvoi/base/string_util.h"
#include "mobvoi/util/utf8/utf8_util.h"
#include "third_party/sparsehash/sparse_hash_map"
#include "tts/nlp/segmenter/proto/segmenter_resource.pb.h"
#include "tts/util/tts_util/util.h"

//  pause_predictor_model answer.
static const int kConvertPauseLevel = 2;

namespace nlp {
namespace prosody {

PausePredictor::PausePredictor(const string& pause_model) {
  model_.reset(new crf::CrfModel(pause_model));
}

PausePredictor::~PausePredictor() {}

bool PausePredictor::Predict(const vector<InputToken>& tokens,
                             vector<int>* result) const {
  // all_level_result is level x token_size matrix
  vector<vector<int>> all_level_result;
  for (int clevel = 0; clevel < model_->GetModelLevel(); ++clevel) {
    vector<int> cresult;
    if (!GetPauseLevel(tokens, clevel, &cresult)) {
      return false;
    }
    all_level_result.emplace_back(cresult);
  }
  if (VLOG_IS_ON(2)) {
    for (int i = 0; i < model_->GetModelLevel(); ++i) {
      VLOG(2) << "The Pause level" << i << "result:";
      for (size_t j = 0; j < all_level_result[i].size(); ++j) {
        VLOG(2) << tokens[j].word << " " << all_level_result[i][j];
      }
    }
  }
  MergeResult(all_level_result, result);
  VLOG(2) << "Pause prediction result";
  for (size_t i = 0; i < tokens.size(); ++i) {
    VLOG(2) << "id: " << i << " " << tokens[i].word << " " << result->at(i);
  }
  return true;
}

void PausePredictor::GenPauseFeat(const InputToken& token, string* feat) const {
  int word_id = token.word_id;
  const string& pos = token.pos;
  *feat = StringPrintf("%d\t%s\t%d", word_id, pos.c_str(),
                       util::utflen(token.word.c_str()));
  VLOG(2) << *feat;
}

bool PausePredictor::GetPauseLevel(const vector<InputToken>& tokens, int level,
                                   vector<int>* result) const {
  vector<string> feat_lines;
  for (size_t i = 0; i < tokens.size(); ++i) {
    string feat_line;
    GenPauseFeat(tokens[i], &feat_line);
    feat_lines.emplace_back(feat_line);
  }
  vector<string> pred_result;
  if (!model_->DoCrfPred(level, feat_lines, &pred_result)) return false;
  for (size_t i = 0; i < tokens.size(); ++i) {
    result->emplace_back(StringToInt(pred_result[i]));
  }
  return true;
}

// merge all level results
// high level break point should set to next lowerer level break point
// e.g.  0 1 0 + 0 2 0 = 0 2 0
//       0 0 1 + 0 2 0 = 0 0 2
void PausePredictor::MergeResult(const vector<vector<int>> all_level_result,
                                 vector<int>* result) const {
  if (all_level_result.empty()) return;
  result->resize(all_level_result[0].size(), 0);
  for (size_t level = 0; level < all_level_result.size(); ++level) {
    int pause_level = level + kConvertPauseLevel;
    vector<int> cur_level = all_level_result[level];
    for (size_t i = 0; i < cur_level.size(); ++i) {
      // jump non break point
      if (cur_level[i] == 0) continue;

      // if first level, set result directly
      if (level == 0) {
        result->at(i) = pause_level;
        continue;
      }
      // otherwise, find next lowerer level break point to set
      for (size_t j = i; j < cur_level.size(); ++j) {
        if (result->at(j) == pause_level - 1) {
          result->at(i) = pause_level;
          break;
        }
      }
    }
  }
}

}  // namespace prosody
}  // namespace nlp
