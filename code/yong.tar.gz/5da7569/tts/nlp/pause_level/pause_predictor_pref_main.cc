// Copyright 2019 Mobvoi Inc. All Rights Reserved.
// Author: xiaoiqn.feng@mobvoi.com

#include "tts/nlp/pause_level/pause_predictor.h"

#include "mobvoi/base/file/simple_line_reader.h"
#include "mobvoi/base/time.h"
#include "mobvoi/util/utf8/utf8_util.h"
#include "tts/nlp/segmenter/segmenter.h"
#include "tts/synthesizer/label_generator/label_def.h"
#include "tts/util/tts_util/util.h"

DEFINE_string(text_file, "", "");
DEFINE_string(segmenter_conf,
              "external/config/front_end/segmenter/man_segmenter.conf",
              "segmenter reosurce config");
DEFINE_string(pause_model,
              "external/config/front_end/pause_model/mandarin_pause_model",
              "pause model");

struct PauseErrCount {
  int right_count;
  int all_count;
};
map<int, PauseErrCount> word_error_counter;

bool SplitTextToSegs(const string &text, vector<std::pair<string, int>> *segs) {
  vector<string> pieces;
  SplitString(text, '#', &pieces);
  if (pieces.empty()) return false;
  for (size_t i = 0; i < pieces.size(); ++i) {
    string content = (i == 0) ? pieces[i] : pieces[i].substr(1);
    if (content.empty()) {
      if (i != pieces.size() - 1) {
        // LOG(ERROR) << "fail to parse line" << text;
        return false;
      } else {
        continue;
      }
    }
    int pause_level;
    if (i < pieces.size() - 1) {
      if (!isdigit(pieces[i + 1][0])) {
        // LOG(ERROR) << "fail to parse pause level" << text;
        return false;
      } else {
        pause_level = StringToInt(pieces[i + 1].substr(0, 1));
      }
    } else {
      pause_level = nlp::prosody::PauseLevelList::kBreakLevel;
    }
    pause_level =
        pause_level > tts::kPauseLevelSP ? tts::kPauseLevelPhrase : pause_level;
    pause_level = pause_level == tts::kPauseLevelSP ? tts::kPauseLevelPhrase
                                                    : pause_level;

    segs->push_back(std::make_pair(content, pause_level));
  }
  return true;
}

void GenPausePredictToken(const string &text,
                          nlp::segmenter::Segmenter *segmenter,
                          vector<nlp::prosody::InputToken> *tp) {
  vector<nlp::segmenter::SegmentWord> segment_words;
  segmenter->WordSegmentation(text, &segment_words);
  for (size_t i = 0; i < segment_words.size(); ++i) {
    nlp::segmenter::SegmentWord t_word = segment_words[i];
    nlp::prosody::InputToken tp_tmp;
    tp_tmp.word = t_word.word;
    tp_tmp.word_id = t_word.word_id;
    tp_tmp.pos = t_word.pos;
    tp->push_back(tp_tmp);
  }
}

void GetPauseLevel(const vector<std::pair<string, int>> &text,
                   nlp::segmenter::Segmenter *segmenter,
                   nlp::prosody::PausePredictor *pause_predictor) {
  vector<nlp::prosody::InputToken> tp;
  for (size_t i = 0; i < text.size(); ++i) {
    GenPausePredictToken(text[i].first, segmenter, &tp);
  }
  vector<int> result;
  if (pause_predictor->Predict(tp, &result)) {
    size_t t_len = 0;
    size_t p_len = 0;
    size_t p_offset = 0;
    for (size_t i = 0; i < text.size(); ++i) {
      t_len += util::utflen(text[i].first.c_str());
      bool flag = true;
      while (p_offset < tp.size() && flag) {
        p_len += util::utflen(tp[p_offset].word.c_str());
        if (t_len == p_len) {
          result[p_offset] = result[p_offset] - 1;
          word_error_counter[text[i].second].all_count += 1;
          VLOG(1) << text[i].first << " : " << text[i].second << " : "
                  << result[p_offset];
          if (text[i].second == result[p_offset]) {
            word_error_counter[text[i].second].right_count += 1;
          }
          flag = false;
        }
        p_offset += 1;
        if (p_len > t_len) flag = false;
      }
    }
  }
}

int main(int argc, char **argv) {
  google::ParseCommandLineFlags(&argc, &argv, false);
  std::unique_ptr<nlp::segmenter::Segmenter> segmenter;
  std::unique_ptr<nlp::prosody::PausePredictor> pause_predictor;

  segmenter.reset(new nlp::segmenter::Segmenter(FLAGS_segmenter_conf));
  pause_predictor.reset(new nlp::prosody::PausePredictor(FLAGS_pause_model));

  vector<string> lines;
  file::SimpleLineReader reader(FLAGS_text_file);
  reader.ReadLines(&lines);
  int64 begin_time = mobvoi::GetTimeInMs();
  int word_num = 0;
  for (size_t i = 0; i < lines.size(); ++i) {
    string line_tmp;
    mobvoi::TrimWhitespaceASCII(lines[i], mobvoi::TRIM_ALL, &line_tmp);
    vector<string> result;
    vector<std::pair<string, int>> segs;
    word_num += util::utflen(line_tmp.c_str());
    if (!SplitTextToSegs(line_tmp, &segs)) continue;
    GetPauseLevel(segs, segmenter.get(), pause_predictor.get());
  }

  int64 used_time = mobvoi::GetTimeInMs() - begin_time;
  LOG(INFO) << "used time: " << used_time;
  if (used_time) {
    LOG(INFO) << word_num * 1000.0 / used_time << " character/second";
  }

  for (auto word_error : word_error_counter) {
    float acc =
        word_error.second.right_count / (word_error.second.all_count + 1e-6);
    LOG(INFO) << "pause level : " << word_error.first
              << " acc : " << word_error.second.right_count << " / "
              << word_error.second.all_count << " = " << acc;
  }
  return 0;
}
