#!/bin/bash

ulimit -c unlimited
export LD_LIBRARY_PATH=libs

bin/tts_grpc_service_main --flagfile=flag/tts_server_main.flag   --grpc_host=0.0.0.0 --grpc_port=8298 --http_host=0.0.0.0 --http_port=8299 1>>log/log.txt 2>>log/log.txt &