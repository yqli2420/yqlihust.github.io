#coding=utf8
# -*- coding: utf-8 -*-
# Allen @ 2017-11-27 19:44:40
"""
stress test with post request
"""
import multiprocessing
import sys
import urllib
import os
import time
import argparse

HEADERS = {'User-Agent':'Mozilla/5.0 (Windows NT 6.1; rv:14.0) Gecko/20100101 Firefox/14.0.1',
           'Referer':'http://202.112.136.157:8800/index.php?action=index',
           'Content-Type':'audio/mp3'}

pid_info = multiprocessing.Manager().dict()
end = multiprocessing.Value('d', 0)

def process_info():
    print(end.value)
    while not end.value:
        time.sleep(0.1)
        os.system('clear')
        for process in pid_info.items():
            print('process: {pid} text: {text} / {loop}'.format(pid = process[0], text = process[1][0], loop = process[1][1]))

def sent_post(ip_port, text):
    pid = os.getpid()
    if pid in pid_info and text == pid_info[pid][0]:
        pid_info[pid] = [pid_info[pid][0], pid_info[pid][1] + 1]
    else:
        pid_info[pid] = [text, 1]
    url = 'http://{ip_port}/api/synthesis/hts'.format(ip_port = ip_port)
    data = urllib.parse.urlencode({'text':text,'product':'Ticwatch2','device_id':'73590E00-A658-430A-BBA1-7E9C7E87D572','voice':'female','language':'unknown','audio_type':'speex-wb-8'})  
    req = urllib.request.Request(url, headers=HEADERS,data=data)
    response = urllib.request.urlopen(req)
    # print response.read()

def stress_test(test_file, ip_port, process, loop_time):
    process_pool = multiprocessing.Pool(processes = process)
    process_infos = multiprocessing.Pool(processes = 1)
    with open(test_file) as fp:
        for line in fp.readlines():
            text = line.strip()
            for i in range(loop_time * process):
                process_pool.apply_async(sent_post, (ip_port, text))
    process_infos.apply_async(process_info)
    process_pool.close()
    process_pool.join()
    end.value = 1

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--ip_port', default='10.1.194.174:10078', help='ip and port')
    parser.add_argument('--test_file', default='./server.txt', help='test data')
    parser.add_argument('--process', type=int, default=1, help='thread number')
    parser.add_argument('--loop', type=int, default=10, help='loop time for each sentence')
    
    args = parser.parse_args()
    print('start stress test using {} process'.format(args.process))
    stress_test(args.test_file, args.ip_port, args.process, args.loop)
    print('done')

if __name__ == '__main__':
    main()
